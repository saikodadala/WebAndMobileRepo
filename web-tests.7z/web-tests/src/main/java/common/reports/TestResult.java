package common.reports;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class TestResult {
	/* copied from TestEngine*/
	public static ArrayList<Integer> stepNum=new ArrayList<Integer>();
	public static ArrayList<Integer> PassNum = new ArrayList<Integer>();
	public static ArrayList<Integer> FailNum = new ArrayList<Integer>();
	public static Map<BrowserContext,Integer> passCounter = new LinkedHashMap<BrowserContext, Integer>();
	public static Map<BrowserContext, Integer> failCounter = new LinkedHashMap<BrowserContext, Integer>();
	public static ArrayList<String> testName = new ArrayList<String>();
	public static ArrayList<String> testNameSeq = new ArrayList<String>();
	public static String testCaseExecutionTime;
	public static Map<BrowserContext, Map<String, String>> testDescription = new LinkedHashMap<BrowserContext, Map<String, String>>();
	public static Map<BrowserContext, Map<String, String>> testResults = new LinkedHashMap<BrowserContext, Map<String, String>>();
	public static ArrayList<String> testCaseResults=new ArrayList<String>();	
	public static ArrayList<String> testCaseResultStatus=new ArrayList<String>();
	public static ArrayList<String> testCaseFailStatus=new ArrayList<String>();
	public static ArrayList<String> testCasePassStatus=new ArrayList<String>();
	
	/*copied from HtmlReportSupport*/

	public static Long iStartTime;
	public static Long iEndTime;
	public static Long iExecutionTime;
	public static Long iSuiteStartTime ;
	public static Long iSuite_StartTime;
	public static Long iSuiteEndTime ;
	public static Double iSuiteExecutionTime ;
	public static Double iSuiteTotalExecutionTime ;
	public ArrayList<Double> list = new ArrayList<Double>();
	public static Long startStepTime;
	public static Long endStepTime;
	public static Double stepExecutionTime;
	public static ArrayList<String> strTestName = new ArrayList<String>();
	public static ArrayList<String> startedAt = new ArrayList<String>();
	public static ArrayList<String> tc_name = new ArrayList<String>();
	public static Map<BrowserContext, String> packageName = new LinkedHashMap<BrowserContext, String>();
	/*mapBrowserContextTestCaseRef contains BrowserContext as key , Map<testpackage:testname,status> as value*/
	public static Map<BrowserContext, Map<String, String>> mapBrowserContextTestCaseRef = new LinkedHashMap<BrowserContext, Map<String, String>>();
	public static Map<BrowserContext, Map<String, String>> executionTime = new LinkedHashMap<BrowserContext, Map<String, String>>();

	public String currentSuite = "";
	public int pCount = 0;
	public int fCount = 0;

	public static String workingDir = System.getProperty("user.dir").replace(File.separator, "/");
	;
	public static Map<BrowserContext, Integer> BFunctionNo = new LinkedHashMap<BrowserContext, Integer>();
	
	/**/
}
