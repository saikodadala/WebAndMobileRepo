package pages.Movilizer;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import seleniumUtilities.GenericMethods;

public class CommonPage extends GenericMethods {
	/**
	 * Locators and reusable methods for Home Page
	 * 
	 * @author Sai Kodadala
	 *
	 */

	private By enterpriseName=By.cssSelector("[class='enterprise-title active-border'] span");   
	private By mainFrame=By.cssSelector("[class='gwt-Frame']");
	private By listbox = By.xpath("//div[@role='listbox']");
	private By tablerows = By.xpath("//tbody[@class='p-datatable-tbody']/tr");
	private By pagination = By.xpath("//div[contains(@class,'page-btn item-btn ')]");
	private By itemsnumber = By.xpath("(//span[@class='bold'])[1]");
	private By disableArrow = By.cssSelector("[class='page-btn nav-btn disable']");
	private By enableArrow = By.cssSelector("[class='page-btn nav-btn']");


	private By honeywellLogoFrame=By.cssSelector("[class='insp-logo-frame']");
	private By loadingIcon=By.cssSelector("[class='ui loader-wrap loading-alignments loading']");	
	private By addAssetBtn=By.xpath("//*[text()='ADD ASSET']");
	
	private By ellipseIcon = By.xpath("//div[contains(@class,'p-datatable')]/table/tbody/tr/td[@class='column-ellipse']");
	private By abstractAssetEllipseIcon=By.cssSelector("tbody tr [class='column-ellipse']");
	private By moreactionsPopup = By.xpath("//div[text()='More actions']");
	private By tasksAndAssetsOption=By.xpath("//span[text()='Tasks And Assets']");
	
	public void selectSideMenuOption(String option)throws Throwable{
		if(option.equalsIgnoreCase("Asset hierarchy&Tasks")){
			waitForPageLoaded();
			driver.switchTo().defaultContent();
			waitForVisibilityOfElement(mainFrame, "mainFrame",20);
			switchToFrame(mainFrame); 
			waitForPageLoaded();
			By loc=By.xpath("//div[@class='sidebar ']//a[@href='#']/i");
			waitForVisibilityOfElement(loc, option,10);
			click(loc,option);
			waitForPageLoaded();
		}else{
			waitForPageLoaded();
			driver.switchTo().defaultContent();
			waitForVisibilityOfElement(mainFrame, "mainFrame",20);
			switchToFrame(mainFrame); 
			waitForPageLoaded();
			By loc=By.xpath("//div[@class='sidebar ']//a[contains(@href,'"+option+"')]/i");
			waitForVisibilityOfElement(loc, option,10);
			click(loc,option);
			waitForPageLoaded();
		}
		
	}

	//select levelhirarchy from Round template
	public void selectlevelhirarchy(String levelhirarchyname) throws Throwable
	{

		By selectlevlhirarchy = By.xpath("//div[text()='"+levelhirarchyname+"']");
		setFocusAndClick(selectlevlhirarchy,"Select levelhirarchy");  		
	}

	public void validate_ShowHide() throws Throwable {
		boolean flag = false;
		waitForVisibilityOfElement(By.xpath("//th[@class='column-ellipse']"),"Ellipse",20);
		click(By.xpath("//th[@class='column-ellipse']"),"Dropdownlist");

		waitForVisibilityOfElement(By.xpath("//div[@class='ui vertical vertical-menu  menu']"),"Menulist",10);
		List<WebElement> menulist = getWebElementList(By.xpath("//a[@class='item']//input[@type='checkbox']"), "Menulist"); 
		int totalmenulist = menulist.size();
		List<WebElement> checkeditems = driver.findElements(By.xpath("//div[@class='ui checked checkbox']/input[@type='checkbox']")); 
		List<WebElement> uncheckeditems = driver.findElements(By.xpath("//div[@class='ui checkbox']/input[@type='checkbox']"));

		System.out.println("CHECKED SIZES"+checkeditems.size());
		// Hide Functionality
		for(int i= checkeditems.size();i>0;i--) { 

			waitForVisibilityOfElement(By.xpath("//div[@class='ui vertical vertical-menu  menu']"),"Checkboxes",10);
			List<WebElement> checkeditems1 = driver.findElements(By.xpath("//div[@class='ui checked checkbox']/input[@type='checkbox']")); 
			((JavascriptExecutor)driver).executeScript("arguments[0].click();", checkeditems1.get(i-1));
			//			waitForVisibilityOfElement(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"),"Datable",20); 
			click(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"), "Dropdownlist");
		}

		// Show Functionality
		for(int i=totalmenulist;i>0;i--) 
		{ 
			//			waitForVisibilityOfElement(By.xpath("//div[@class='ui checkbox']/label"),"label names",10);
			List<WebElement> uncheckeditems1 = driver.findElements(By.xpath("//div[@class='ui checkbox']/input[@type='checkbox']")); 
			List<WebElement> uncheckeditemstext = driver.findElements(By.xpath("//div[@class='ui checkbox']/label"));
			String s = uncheckeditemstext.get(i-1).getText();
			((JavascriptExecutor)driver).executeScript("arguments[0].click();", uncheckeditems1.get(i-1));

			List<WebElement> tablecol = driver.findElements(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@tabindex]/span[@class='p-column-title']"));
			for(WebElement e:tablecol) { 
				System.out.println("Validating Table column name "+e.getText()+" with selected column name"+s);
				flag = e.getText().equalsIgnoreCase(s);
				if(flag) { 
					System.out.println("Verifying Show Functionality"); 
					break;
				}
			}
			if(!flag) {
				//		reporter.failureReport("Failed due to incorrect data :: ",  "checkbox value is not present in Datatable : ",driver);
			}
			waitForVisibilityOfElement(By .xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"),"ellipse",15); 
			click(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"), "Dropdownlist");
		}
	}

	public void invisibleOfHoneywellLogo() throws Throwable{
		waitForInVisibilityOfElement(honeywellLogoFrame, "Wait till Honeywell Logo disappears", 10);
	}

	public void waitForPageLoaded() throws Throwable {
		new WebDriverWait(driver, 30).until((ExpectedCondition<Boolean>) wd ->
		((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
		By loc=By.cssSelector("[class='ui loader-wrap loading-alignments loading']");
		waitForInVisibilityOfElement(loc, "Loader", 120);
	}

	public void invisibleOfLoader() throws Throwable{
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 20);
	}

	public void validateTableRecordsCount(String pageCount) throws Throwable {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElements(getWebElementList(tablerows, "Elements")));
		// Validating 1-20
		Assert.assertEquals(String.valueOf(getElementsSize(tablerows)), pageCount);
	}

	public void validate20RecordPagination(String page1, String page2) throws Throwable {
		List<WebElement> paginationvalues = getWebElementList(pagination, "pagination list");
		waitForPageLoaded();
		WebElement element = paginationvalues.get(0);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
		waitForPageLoaded();
		validateTableRecordsCount(page1);

		WebElement element1 =paginationvalues.get(1);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element1);
		waitForPageLoaded();

		validateTableRecordsCount(page2);
		waitForPageLoaded();
		paginationvalues.get(0);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}

	public void arrowDisableState() throws Throwable {
		isElementPresent(disableArrow, "disableArrow");
	}



	public void arrowEnableState() throws Throwable {
		isElementPresent(enableArrow, "enableArrow");
	}

	public void selectNumberOfPages(String perPage) throws Throwable {
		waitForVisibilityOfElement(listbox, "Listbox", 20);
		click(listbox, "Click on listbox");
		selectItems_perpage(perPage);
	}

	public void validatePagination(String count) throws Throwable {
		List<WebElement> paginationvalues = getWebElementList(pagination, "pagination list");
		for (int i = 0; i < paginationvalues.size(); i++) {
			waitForPageLoaded();
			WebElement element = paginationvalues.get(i);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			waitForPageLoaded();
			validateTableRecordsCount(count);
		}
		WebElement element = paginationvalues.get(0);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}

	public void clickOnThreeDots() throws Throwable {
		waitForPageLoaded();
		this.pageLoader();
		waitForVisibilityOfElement(By.xpath("//th[@class='column-ellipse']"),"Ellipse",20);
		click(By.xpath("//th[@class='column-ellipse']"),"Dropdownlist");

	}

	public void selectAllCoumns() throws Throwable {
		boolean flag = false;		
		waitForPageLoaded();
		List<WebElement> menulist = getWebElementList(By.xpath("//a[@class='item']//input[@type='checkbox']"), "Menulist"); 
		int totalmenulist = menulist.size();
		List<WebElement> checkeditems = driver.findElements(By.xpath("//div[@class='ui checked checkbox']/input[@type='checkbox']")); 

		System.out.println("CHECKED SIZES"+checkeditems.size());
		// Hide Functionality
		for(int i= checkeditems.size();i>0;i--) { 
			waitForPageLoaded();			
			List<WebElement> checkeditems1 = driver.findElements(By.xpath("//div[@class='ui checked checkbox']/input[@type='checkbox']")); 
			((JavascriptExecutor)driver).executeScript("arguments[0].click();", checkeditems1.get(i-1)); 
			click(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"), "Dropdownlist");
		}

		// Show Functionality
		for(int i=totalmenulist;i>0;i--) 
		{ 
			List<WebElement> uncheckeditems1 = driver.findElements(By.xpath("//div[@class='ui checkbox']/input[@type='checkbox']")); 
			List<WebElement> uncheckeditemstext = driver.findElements(By.xpath("//div[@class='ui checkbox']/label"));
			String s = uncheckeditemstext.get(i-1).getText();
			((JavascriptExecutor)driver).executeScript("arguments[0].click();", uncheckeditems1.get(i-1));

			List<WebElement> tablecol = driver.findElements(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@tabindex]/span[@class='p-column-title']"));
			for(WebElement e:tablecol) { 
				flag = e.getText().equalsIgnoreCase(s);
				if(flag) { 
					System.out.println("Verifying Show Functionality"); 
					break;
				}
			}
			if(!flag) {				
				logfailinfo("checkbox value is not present in Datatable");
			}
			waitForVisibilityOfElement(By .xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"),"ellipse",15); 
			click(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"), "Dropdownlist");
		}
	}

	public void selectedColumnsAvailableInTheTable() throws Throwable {
		boolean flag = false;		
		waitForPageLoaded();
		List<WebElement> menulist = getWebElementList(By.xpath("//a[@class='item']//input[@type='checkbox']"), "Menulist"); 
		int totalmenulist = menulist.size();
		List<WebElement> checkeditems = driver.findElements(By.xpath("//div[@class='ui checked checkbox']/input[@type='checkbox']")); 

		System.out.println("CHECKED SIZES"+checkeditems.size());
		// Hide Functionality
		for(int i= checkeditems.size();i>0;i--) { 
			waitForPageLoaded();			
			List<WebElement> checkeditems1 = driver.findElements(By.xpath("//div[@class='ui checked checkbox']/input[@type='checkbox']")); 
			((JavascriptExecutor)driver).executeScript("arguments[0].click();", checkeditems1.get(i-1)); 
			click(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"), "Dropdownlist");
		}

		// Show Functionality
		for(int i=totalmenulist;i>0;i--) 
		{ 
			List<WebElement> uncheckeditems1 = driver.findElements(By.xpath("//div[@class='ui checkbox']/input[@type='checkbox']")); 
			List<WebElement> uncheckeditemstext = driver.findElements(By.xpath("//div[@class='ui checkbox']/label"));
			String s = uncheckeditemstext.get(i-1).getText();
			((JavascriptExecutor)driver).executeScript("arguments[0].click();", uncheckeditems1.get(i-1));

			List<WebElement> tablecol = driver.findElements(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@tabindex]/span[@class='p-column-title']"));
			for(WebElement e:tablecol) { 
				flag = e.getText().equalsIgnoreCase(s);
				if(flag) { 
					System.out.println("Verifying Show Functionality"); 
					break;
				}
			}
			if(!flag) {				
				logfailinfo("checkbox value is not present in Datatable");
			}
			waitForVisibilityOfElement(By .xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"),"ellipse",15); 
			click(By.xpath("//div[contains(@class,'p-datatable')]/table/thead/tr/th[@class='column-ellipse']"), "Dropdownlist");
		}
	}
	
	public void verifyShowHideThreeDots() throws Throwable {
		waitForPageLoaded();
		this.pageLoader();
		waitForVisibilityOfElement(By.xpath("//th[@class='column-ellipse']"),"Ellipse",20);
		isElementPresent(By.xpath("//th[@class='column-ellipse']"),"Dropdownlist");

	}
	public void verifyTableAssetThreeDots() throws Throwable {
		waitForVisibilityOfElement(ellipseIcon, "ellipseIcon", 10);
		mouseHover(ellipseIcon, "ellipseIcon");
	}	
	public void clickEllipse() throws Throwable {
		waitForVisibilityOfElement(ellipseIcon, "ellipseIcon", 10);
		click(ellipseIcon, "Click ellipseIcon");
	}
	
	public void verifyTableAbstractAssetThreeDots() throws Throwable {
		waitForVisibilityOfElement(abstractAssetEllipseIcon, "ellipseIcon", 10);
		mouseHover(abstractAssetEllipseIcon, "ellipseIcon");
	}
	public void verifyMoreActions() throws Throwable {
		waitForVisibilityOfElement(moreactionsPopup, "More actions", 10);
		isElementPresent(moreactionsPopup, "More actions");
	}
	public void clickADDAssetBtn() throws Throwable{
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		waitForVisibilityOfElement(addAssetBtn,"addAssetBtn",5);
		click(addAssetBtn, "ADD ASSET button");
	}
	public void clickOnTasksAndAssetsOption() throws Throwable {
		waitForVisibilityOfElement(tasksAndAssetsOption, "tasksAndAssetsOption", 10);
		click(tasksAndAssetsOption, "tasksAndAssetsOption");
	}
}
