package pages.Movilizer;


import org.openqa.selenium.By;

import seleniumUtilities.GenericMethods;

public class UnitDetailsPage extends GenericMethods {

	private By unitDetails = By.xpath("//div[text()='Unit Details']");
	private By unitNamesHeader=By.xpath("//span[text()='Unit Names']");
	private By unitNameTextBox=By.xpath("[class='react-tagsinput react-tagsinput--focused']");
	private By editUnitName=By.xpath("//*[text()='Unit Details']/..//button[@data-testid='editBtn']");
	private By addHereHeader=By.xpath("//span[text()='Add Here']");
	private By unitNamePlaceholder=By.cssSelector("[placeholder='Type Unit Names seperated by semi-colon(;)']");
	private By cancelButton=By.xpath("//*[contains(@data-testid,'CancelButtonDesc')]");
	private By saveButton=By.xpath("//*[contains(@data-testid,'SaveButtonLabel')]");
	private By confirmationPopHeader=By.xpath("//*[text()='Confirmation']");
	private By confirmationInstructionMessage=By.xpath("//*[text()='One or more levels beneath will alter their present settings, Do you want to proceed anyway?']");
	private By successMessage=By.xpath("//*[text()='Configuration Updated Successfully']");
	private By errorMessage=By.xpath("//*[text()='Failed to update configuration']");
	private By createdUnitName=By.cssSelector("[class='react-tagsinput react-tagsinput--focused'] span span");
	
	public void clickon_UnitDetailsLink() throws Throwable {	
		waitForPageLoaded();
		waitForVisibilityOfElement(unitDetails,"Unit Details",15);
		scrollToWebElement(unitDetails);
		waitForPageLoaded();		
		click(unitDetails, "Unit Details");		
	}
	
	public void verifyUnitNameHeader() throws Throwable {		
		waitForVisibilityOfElement(unitNamesHeader,"Unit Name",15);
		isElementDisplayed(unitNamesHeader, "Unit Name");
	}
    
	public void verifyUnitNameTextBox() throws Throwable {		
		waitForVisibilityOfElement(unitNameTextBox,"Unit Name TextBox",15);
		isElementDisplayed(unitNameTextBox, "Unit Name TextBox");
	}
	
	public void clickonEditLink() throws Throwable {		
		waitForVisibilityOfElement(editUnitName,"Edit",15);
		clickJS(editUnitName, "Edit");
	}
	
	public void verifyAddHereHeader() throws Throwable {		
		waitForVisibilityOfElement(addHereHeader,"Add here header",15);
		isElementDisplayed(addHereHeader, "Add here header");
	}
    
	public void verifyUnitNamePlaceHolder() throws Throwable {		
		waitForVisibilityOfElement(unitNamePlaceholder,"Unit Name Placeholder",15);
		isElementDisplayed(unitNamePlaceholder, "Unit Name Placeholder");
	}
	
	public void enterUnitNames(String unitName) throws Throwable{
		waitForVisibilityOfElement(unitNamePlaceholder,"Unit Name",15);
		clearText(unitNamePlaceholder);
		setText(unitNamePlaceholder,unitName, "Unit Name");
	}
	
	public void verifyCancelButton() throws Throwable {		
		waitForVisibilityOfElement(cancelButton,"Cancel button",15);
		isElementDisplayed(cancelButton, "Cancel button");
	}
	
	public void verifySaveButton() throws Throwable {		
		waitForVisibilityOfElement(saveButton,"Save button",15);
		isElementDisplayed(saveButton, "Save button");
	}
	
	public void clickOnSaveButton() throws Throwable {		
		waitForVisibilityOfElement(saveButton,"Save button",15);
		click(saveButton, "Save button");
	}
	public void verifyConfirmationPopupHeader() throws Throwable {		
		waitForVisibilityOfElement(confirmationPopHeader,"confirmation popup header",15);
		isElementDisplayed(confirmationPopHeader, "confirmation popup header");
	}
	
	public void verifyConfirmationInstructionMessage() throws Throwable {		
		waitForVisibilityOfElement(confirmationInstructionMessage,"confirmationInstructionMessage",15);
		isElementDisplayed(confirmationInstructionMessage, "confirmationInstructionMessage");
	}
	
	public void verifyConfirmationFlag(String action) throws Throwable{
		By loc=By.xpath("//*[text()='"+action+"']");
		waitForVisibilityOfElement(loc,action,15);
		isElementDisplayed(loc, action);	
	}
	public void clickOnConfirmationFlag(String action) throws Throwable{
		By loc=By.xpath("//*[text()='"+action+"']");
		waitForVisibilityOfElement(loc,action,15);
		click(loc, action);	
	}
	
	public void verifySuccessMessage() throws Throwable{
		waitForVisibilityOfElement(successMessage,"Success Message",15);
		isElementDisplayed(successMessage,"Success Message");	
	}
	
	public void verifyUnitDetailsSection() throws Throwable {		
		waitForPageLoaded();
		isElementNotPresent(unitDetails, "Unit Details Link");
	}
	
	public void verifyPortSDKErrorMessage() throws Throwable{
		waitForVisibilityOfElement(errorMessage,"Error Message",15);
		isElementDisplayed(errorMessage,"Error Message");	
	}
	
	public void verifyNonContinousErrorMessage(String errorString) throws Throwable{
		By errorMsg=By.xpath("//*[text()='"+errorString+"']");
		waitForVisibilityOfElement(errorMsg,"Error Message",15);
		isElementDisplayed(errorMsg,"Error Message");	
	}
	
	public void validateUnitName(String unitName) throws Throwable{
		validateCheckPointNotMatch(createdUnitName, unitName, "Unit Name");		
	}
	public void clickOnCancelButton() throws Throwable {		
		waitForVisibilityOfElement(cancelButton,"Cancel button",15);
		click(cancelButton, "Cancel button");
	}
	
	public void enterUnitName(String unitName) throws Throwable {  
		By unitNameL=By.xpath("//*[text()="+unitName+"");
		By fieldUnitName=By.xpath("//*[text()='Select A Unit Name']");
        click(fieldUnitName, "fieldUnitName");
        click(unitNameL, "unitName");
    }

    
}
