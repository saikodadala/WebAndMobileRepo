package pages.Movilizer;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import seleniumUtilities.GenericMethods;

public class AddAbstractAssetPage extends GenericMethods{

	/*** Label **/
	private By backendLbl=By.xpath("//span[@class='input-label-message' and contains(text(),'Backend')]");
	private By assetnameLbl=By.xpath("//span[@class='input-label-message' and text()='Asset Name']");
	private By categoryLbl=By.xpath("//span[@class='input-label-message' and text()='Criticality']");
	private By criticalityLbl=By.xpath("//span[@class='input-label-message' and text()='Criticality']");
	private By assetTypeLbl=By.xpath("//span[@class='input-label-message' and text()='Asset Type']");
	private By assetModeLbl=By.xpath("//span[@class='input-label-message' and text()='Asset Mode']");
	private By preConditionLbl=By.xpath("//*[text()='Precondition Check']");
	private By contactLbl=By.xpath("//*[text()='Contact']");
	private By ownerOrganizationLbl=By.xpath("//*[text()='Owner Organization']");
	private By addInformationLbl=By.xpath("//*[text()='ADDITIONAL INFORMATION']");



	/**Input Fields   **/

	private By submitButton=By.xpath("//button[@type='button']/child::div[text()='Submit']");
	private By cancelButton=By.xpath("//button[@type='button']/child::div[text()='Cancel']");
	private By backendIpt=By.xpath("(//span[@class='input-label-message' and text()='Backend ID']/following::input[@placeholder='Type here'])[1]");
	private By assetNameIpt=By.xpath("(//span[@class='input-label-message' and text()='Asset Name']/following::input[@placeholder='Type here'])[1]");
	private By categoryIpt=By.xpath("(//span[@class='input-label-message' and text()='Category']/following::input[@placeholder='Type here'])[1]");
	private By criticalityIpt=By.xpath("(//span[@class='input-label-message' and text()='Criticality']/following::input[@placeholder='Type here'])[1]");
	private By typeIpt=By.xpath("(//span[@class='input-label-message' and text()='Type']/following::input[@placeholder='Type here'])[1]");
	private By modesIpt=By.xpath("//span[@class='input-label-message' and text()='Modes']/following::input[@class='react-tagsinput-input']");
	private By preConditionCheckbox=By.xpath("//*[text()='Precondition Check']/../input[@type='checkbox']");
	private By contactIpt=By.xpath("(//span[@class='input-label-message' and text()='Contact']/following::input[@placeholder='Type here'])[1]");
	private By ownerOrgIpt=By.xpath("(//span[@class='input-label-message' and text()='Owner Organization']/following::input[@placeholder='Type here'])[1]");

	private By addNewRowbtn=By.xpath("//div[@data-test='header-item' and text()='Add New Row']");
	private By headLineIpt=By.xpath("(//div[@class='additional-field-cell']//child::input)[1]");
	private By descrptionHeadlineIpt=By.xpath("(//div[@class='additional-field-cell']//child::input)[2]");

	private By addLinkbtn=By.xpath("//div[@data-test='header-item' and text()='Add Link']");
	private By descrptionLinkIpt=By.xpath("(//div[@class='additional-field-cell']//child::input)[3]");
	private By linkIpt=By.xpath("(//div[@class='additional-field-cell']//child::input)[4]");

	/**Validation Error message**/
	private By assetNameError=By.xpath("//*[text()='Please enter Asset Name']");
	private By assetTypeError=By.xpath("//*[text()='Please enter Asset Type']");
	private By successAlert=By.xpath("//span[contains(text(),'Asset Added Succesfully')]");
	private By editAlert=By.xpath("//span[text()='Abstract Asset Edited Successfully']");
	private By deleteAlert=By.xpath("//*[contains(text(),'deleted successfully')]");
	private By closeIcon=By.xpath("//div[@class='close-wrapper']/i");	
	private By WindowCancelmsg=By.xpath("//div[contains(text(), 'Closing the window will reset')]");
	private By WindowCancelconfirmbtn=By.xpath("//div[contains(text(), 'Closing the window will reset')]/following::button[2]");

	private By assetNamePlaceholder=By.xpath("(//span[@class='input-label-message' and text()='Asset Name']/following::input[@placeholder='Type here'])[1]");
	private By selectabstract=By.xpath("//*[text()='Select Abstract Asset']/../following-sibling::div/input");
	private By extendsid=By.xpath("//div[@class='ui single-input input-field fluid disabled']//input");
	private By assetttype=By.xpath("//div[@class='ui single-input asset-type-width fluid disabled']//input");
	private By assethirarchytasks=By.xpath("//i[@class='h-icon global organization sidebar-icon']");
	private By moreactions=By.xpath("(//span[@class='popup-pointer']/i)[2]");
	private By clickonextend=By.xpath("//*[text()='Extend']/..");
	private By validateextended=By.xpath("//div[text()='Extended']");
	private By Task = By.xpath(("//a[text()='Tasks']"));
	private By taskposition=By.xpath("//span[text()='Task Position']/../..//input");
	private By type=By.xpath("(//div[@class='ui scuf-dropdown-wrapper input-field-custom fluid disabled'])[3]");
	private By mode=By.xpath("//span[text()='Asset Mode']/../..");






	public void enterBackendID(String name)throws Throwable{
		waitForVisibilityOfElement(backendIpt, "Backend ID",30);
		setText(backendIpt, name, "Backend ID");
		pressTab(backendIpt);
	}

	public void enterAssetName(String name)throws Throwable{
		waitForVisibilityOfElement(assetNameIpt, "Asset Name",30);
		setText(assetNameIpt, name, "Asset Name");
		pressTab(assetNameIpt);
	}

	public void enterCategory(String name)throws Throwable{
		waitForVisibilityOfElement(categoryIpt, "Category",30);
		setText(categoryIpt, name, "Category");
		pressTab(categoryIpt);
	}

	public void enterCriticality(String name)throws Throwable{
		waitForVisibilityOfElement(criticalityIpt, "criticality",25);
		setText(criticalityIpt, name, "criticality");
		pressTab(criticalityIpt);
	}

	public void enterAssetType(String name)throws Throwable{
		waitForVisibilityOfElement(typeIpt, "Asset Type",25);
		setText(typeIpt, name, "Asset Type");
		pressTab(typeIpt);
	}
	public void enterModes(String name)throws Throwable{
		waitForVisibilityOfElement(modesIpt, "Asset Modes",25);
		setText(modesIpt, name, "Asset Modes");
		pressTab(modesIpt);
	}

	public void enterContact(String name)throws Throwable{
		waitForVisibilityOfElement(contactIpt, "Contact",20);
		setText(contactIpt, name, "Contact");
		pressTab(contactIpt);
	}

	public void enterOwnerOrg(String name)throws Throwable{
		waitForVisibilityOfElement(ownerOrgIpt, "Owner Org",20);
		setText(ownerOrgIpt, name, "Owner Org");
		pressTab(ownerOrgIpt);
	}

	public void clickAddNewRowbtn() throws Throwable {
		waitForVisibilityOfElement(addNewRowbtn, "addNewRowbtn",20);
		click(addNewRowbtn, "addNewRowbtn");
	}


	public void enterAddInfoHeadline(String name)throws Throwable{
		waitForVisibilityOfElement(headLineIpt, "AddInfoHeadline",15);
		setText(headLineIpt, name, "AddInfoHeadline");
		pressTab(headLineIpt);
	}


	public void enterAddinfoDescription(String name)throws Throwable{
		waitForVisibilityOfElement(descrptionHeadlineIpt, "Owner Org",15);
		setText(descrptionHeadlineIpt, name, "AddInfoHeadline");
		pressTab(descrptionHeadlineIpt);
	}



	public void clickAddLinkbtn() throws Throwable {
		waitForVisibilityOfElement(addLinkbtn, "addLinkbtn",15);
		clickJS(addLinkbtn, "addLinkbtn");
	}


	public void enterLinkDescription(String name)throws Throwable{
		waitForVisibilityOfElement(descrptionLinkIpt, "enterLinkDescription",15);
		setText(descrptionLinkIpt, name, "enterLinkDescription");
		pressTab(descrptionLinkIpt);
	}


	public void enterLink(String name)throws Throwable{
		waitForVisibilityOfElement(linkIpt, "enterLink",15);
		setText(linkIpt, name, "enterLink");
		pressTab(linkIpt);
	}


	public void clickSubmitbtn() throws Throwable {
		waitForVisibilityOfElement(submitButton, "submit",20);
		click(submitButton, "Submit");
	}

	public void clickCancelbtn() throws Throwable {
		waitForVisibilityOfElement(cancelButton, "Cancel",15);
		click(cancelButton, "Cancel");
		waitForVisibilityOfElement(WindowCancelmsg, "WindowCancelmsg",15);
		verifyElementDisplayed(WindowCancelmsg,"Validating Close Window Pop-up",true);
		click(WindowCancelconfirmbtn, "Confirm Button");	
	}

	public void verifyAssetNameMandyErrormsg() throws Throwable{
		verifyElementDisplayed(assetNameError,"Validating error message",true);
	}

	public void verifyAssetTypeMandyErrormsg() throws Throwable{
		verifyElementDisplayed(assetTypeError,"Validating error message",true);
	}

	public void verifySuccessAlert(String type) throws Throwable{
		if(type.equalsIgnoreCase("Addition")) {
			waitForVisibilityOfElement(successAlert,"SucessAlert",15);
			verifyElementDisplayed(successAlert,"Validating success message",true);
			click(closeIcon,"Click on cancel button");
		}else if(type.equalsIgnoreCase("Edit")) {
			waitForVisibilityOfElement(editAlert,"EditAlert",15);
			verifyElementDisplayed(editAlert,"Validating alert message",true);
			click(closeIcon,"Click on cancel button");
		}else if(type.equalsIgnoreCase("Delete")) {
			waitForVisibilityOfElement(deleteAlert,"DeleteAlert",15);
			verifyElementDisplayed(deleteAlert,"Validating alert message",true);
			click(closeIcon,"Click on cancel button");
		}
	}



	//enter AssetName
	public void enterAssetname(String assetname) throws Throwable
	{

		waitForVisibilityOfElement(assetNamePlaceholder,"assetNamePlaceholder",15);
		setText(assetNamePlaceholder,assetname, "entered Asset name");	
	}


	//select abstract asset option
	public void selectAbstractasset(String abstractname) throws Throwable
	{

		//	clearText(selectabstract);
		waitForVisibilityOfElement(selectabstract,"selectabstract",5);
		pressTab(selectabstract);
		driver.findElement(selectabstract).sendKeys(Keys.ENTER);

		for (int i = 0; i < abstractname.length(); i++){
			char c = abstractname.charAt(i);
			String s = new StringBuilder().append(c).toString();
			//    setText(selectabstract,abstractname,"Enter abstractname");
			driver.findElement(selectabstract).sendKeys(s);
		}    

		By selectoption=By.xpath("//span[text()='"+abstractname+"']");
		waitForVisibilityOfElement(selectoption,"selectoption",15);
		click(selectoption,"select Abstractoption");

	}

	public void isenabled()
	{
		boolean result;
		result = driver.findElement(extendsid).isEnabled();
		if(result)
		{
			logfailinfo("Extends id filed is editable,suppose to be non editable");
		}
		result = driver.findElement(assetttype).isEnabled();
		if(result)
		{
			logfailinfo("Asset type filed is editable,suppose to be non editable");
		}

	}

	public void verifysuccessmessage() throws Throwable
	{

		waitForVisibilityOfElement(successAlert,"successAlert",10);
		verifyElementDisplayed(successAlert,"Validating success message",true);
		click(closeIcon,"Click on cancel button");	

	}

	public void clickonAssethirarchtasks() throws Throwable
	{

		waitForVisibilityOfElement(assethirarchytasks,"Assethirarchytasks",15);	
		click(assethirarchytasks,"assethirarchytasks");
		waitForPageLoaded();

	}

	//click on asset
	public void clickonAsset(String assetname) throws Throwable
	{

		By clickonAsset=By.xpath("//div[text()='"+assetname+"']");
		waitForVisibilityOfElement(clickonAsset,"clickonAsset",10);
		click(clickonAsset,"clickonAsset");
	}

	//click on more actions
	public void clickonMoreActions() throws Throwable
	{

		waitForVisibilityOfElement(moreactions,"Click on moreactions",10);
		scrollToWebElement(moreactions);
		click(moreactions,"clickonMoreActions");	

	}


	//extend option is displayed
	public void extendoptiondisplayed()
	{

		boolean result = driver.findElement(clickonextend).isDisplayed();
		if(!result)
		{
			logfailinfo("Extend option is not displayed");
		}

	}

	//click on extend
	public void clickonextend() throws Throwable
	{

		waitForVisibilityOfElement(clickonextend,"click on extend",10);
		click(clickonextend,"clickon extend");	
	}

	public void validate_Extended() throws Throwable
	{

		waitForVisibilityOfElement(validateextended,"validate extend text",10);
		boolean result = driver.findElement(validateextended).isDisplayed();
		if(!result)
		{
			logfailinfo("Extend text is not displayed");

		}

	}

	// click on task
	public void clickonTask() throws Throwable {
		waitForPageLoaded();
		waitForVisibilityOfElement(Task,"Task",15);
		click(Task, "Click on Task");
	}

	public void is_enabled() throws Throwable
	{
		boolean result;
		waitForVisibilityOfElement(taskposition, "taskposition", 10);
		result = driver.findElement(taskposition).isEnabled();
		if(result)
		{
			logfailinfo("task position id filed is editable,suppose to be non editable");
		}
		scrollToWebElement(type);
		result = driver.findElement(type).isSelected();
		if(result)
		{
			logfailinfo("type filed is editable,suppose to be non editable");
		}
		scrollToWebElement(mode);
		result = driver.findElement(mode).isSelected();
		if(result)
		{
			logfailinfo("mode filed is editable,suppose to be non editable");
		}
	}

}
