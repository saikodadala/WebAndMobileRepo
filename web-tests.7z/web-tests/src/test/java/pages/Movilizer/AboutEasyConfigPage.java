package pages.Movilizer;


import org.openqa.selenium.By;

import seleniumUtilities.GenericMethods;

public class AboutEasyConfigPage extends GenericMethods {

    private By mainFrame = By.cssSelector("[class='gwt-Frame']");
    private By aboutEasyConfig = By.cssSelector("i[class='h-icon building badge-info sidebar-icon']");
    private By LevelHeading = By.cssSelector("span[class='cursor-hand']");
    private By buildInfoTableCell1 = By.xpath("(//td[@class='info-table-padding'])[1]");
    private By buildInfoTableCell2 = By.xpath("(//td[@class='info-table-padding'])[2]");
    private By buildInfoTableCell3 = By.xpath("(//td[@class='info-table-padding'])[3]");
    private By buildInfoTableCell4 = By.xpath("(//td[@class='info-table-padding'])[4]");
    private By buildInfoTableCell5 = By.xpath("(//td[@class='info-table-padding'])[5]");
    private By buildInfoTableCell6 = By.xpath("(//td[@class='info-table-padding'])[6]");
    private By buildInfoTableCell7 = By.xpath("(//td[@class='info-table-padding'])[7]");
    private By buildInfoTableCell8 = By.xpath("(//td[@class='info-table-padding'])[8]");
    private By buildInfoTableCell9 = By.xpath("(//td[@class='info-table-padding'])[9]");
    private By buildInfoTableCell10 = By.xpath("(//td[@class='info-table-padding'])[10]");




    public void verifyLevelHeading(String levelHeadingE) throws Throwable {
        waitForVisibilityOfElement(mainFrame, "mainFrame",20);
        switchToFrame(mainFrame);
        String levelHeading = getText(LevelHeading,"GetLevelHeading");
        validateCheckPointEquals(levelHeading,levelHeadingE,"EnterpriseHeader" );
    }

    public void clickAboutEasyConfigIcon() throws Throwable {
        waitForVisibilityOfElement(aboutEasyConfig, "mainFrame",30);
        click(aboutEasyConfig,"aboutEasyConfigIcon");
    }

    public void buildInfo(String heading1,String heading2,String heading3, String heading4, String heading5,String heading6) throws Throwable {
        String cell1Heading = getText(buildInfoTableCell1,"BuildVersion");
        validateCheckPointEquals(cell1Heading,heading1,"BuildVersion" );

        String cell2Value = getText(buildInfoTableCell2,"VersionValue");
        boolean numeric = cell2Value.isEmpty();
        //System.out.println(numeric);
        String value=Boolean.toString(!numeric);
        //System.out.println(value);
        validateCheckPointEquals(value,"true","VerifyString" );
        //numeric = cell2Value.matches("\\d+(\\.\\d+)?");
        //boolean isNumeric = cell2Value.chars().allMatch( Character::isDigit );

        String cell3Heading = getText(buildInfoTableCell3,"Asset&TaskTemplate");
        validateCheckPointEquals(cell3Heading,heading2,"Asset&TaskTemplate" );

        String cell4Value = getText(buildInfoTableCell4,"V01");
        validateCheckPointEquals(cell4Value,heading6,"V01" );

        String cell5Heading = getText(buildInfoTableCell5,"UserTemplate");
        validateCheckPointEquals(cell5Heading,heading3,"UserTemplate" );

        String cell6Value = getText(buildInfoTableCell6,"V01");
        validateCheckPointEquals(cell6Value,heading6,"V01" );

        String cell7Heading = getText(buildInfoTableCell7,"DeviceTemplate");
        validateCheckPointEquals(cell7Heading,heading4,"DeviceTemplate" );

        String cell8Value = getText(buildInfoTableCell8,"V01");
        validateCheckPointEquals(cell8Value,heading6,"V01" );

        String cell9Heading = getText(buildInfoTableCell9,"LanguageSetTemplate");
        validateCheckPointEquals(cell9Heading,heading5,"LanguageSetTemplate" );

        String cell10Value = getText(buildInfoTableCell10,"V01");
        validateCheckPointEquals(cell10Value,heading6,"V01" );

    }






}
