package pages.Movilizer;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.Assert;

import org.openqa.selenium.WebDriver;

import seleniumUtilities.GenericMethods;

public class DevicePage extends GenericMethods {

	private By manageDevicesIcon=By.cssSelector("[class='h-icon building smartphone sidebar-icon']");
	private By addNewDeviceBtn=By.xpath("//*[text()='Add New Device']");
	private By breadCrumb=By.cssSelector("[class='ui breadcrumb flexible-levels-breadcrumb']");
	//	private By addDeviceBtn=By.xpath("//div[@class='actions']//div[contains(text(),'Add New Device')]");
	private By addDeviceBtn=By.xpath("//button[@class='ui medium button primary']/div");
	private By breadcrumLevelname=By.xpath("//div[@class='divider']/following-sibling::a[@class='section']");
	private By enterprise=By.xpath("//a[@class='section' and text()='Enterprise']");
	private By addDeviceHeader=By.xpath("//*[text()='Add New Device']");
	private By emailLabel=By.xpath("//*[text()='Email/Phone']");
	private By deviceNameLabel=By.xpath("//*[text()='Device Name']");
	private By deviceTypeLabel=By.xpath("//*[text()='Device Type']");
	private By deviceNameTextbox=By.xpath("//*[text()='Device Name']/../..//input[@type='text']");
	private By emailLabeltextbox=By.xpath("//*[text()='Email/Phone']/../..//input[@type='text']");
	private By dropDown=By.xpath("//div[@class=\"ui fluid selection dropdown\"]");
	private By successAlert=By.xpath("//span[contains(text(),'Device Added/Updated Successfully')]");
	private By listofElements=By.xpath("//div[@class='visible menu transition']/div");
	//	private By invalidEmail=By.xpath("//span[text()='Invalid Phone number/Email id']");
	private By invalidEmail=By.xpath("//span[text()='Please enter email/phone number between 5 and 128']");
	//	private By invalidDeviceName=By.xpath("//span[text()='Invalid Device Name']");
	private By invalidDeviceName=By.xpath("Please enter device name between 1 and 31 characters");
	private By lowercaseEmail=By.xpath("//span[text()='Please enter email in lower case']");		
	private By longEmail=By.xpath("//span[text()='Please enter email/phone number between 5 and 128']");
	private By longName=By.xpath("//span[text()='Please enter device name between 1 and 31 characters']");
	private By emptyEmail=By.xpath("//span[text()='Please enter email/phone number']");
	private By emptyDeviceName=By.xpath("//span[text()='Please enter device name']");
	private By searchDevices=By.xpath("//input[@placeholder='Search devices']");
	private By noDevices=By.xpath("//*[text()='No devices added yet.']");
	private By getTemplatelabel=By.xpath("//*[text()='Get Template']");
	private By importList=By.xpath("//*[text()='Import List']");
	private By exportListlabel=By.xpath("//*[text()='Export List']");
	private By filterIcon=By.cssSelector("[class='header-bar-item filter-panel-icon']");
	private By deleteIcon=By.xpath("//div[contains(@class,'p-datatable')]/table/tbody/tr/td/following::img[contains(@src,'/ui/easyconfig/static/media/Delete')]");
	private By deleteDeviceHeader=By.xpath("//*[text()='Delete Device']");
	private By deleteConfirmMsg=By.xpath("//*[contains(text(),'Are you sure you want to delete the Device')]");
	private By confirm=By.xpath("//*[text()='Confirm']");
	private By cancel=By.xpath("//*[text()='Cancel']");
	private By browseButton=By.xpath("//div[@class='button-content' and text()='BROWSE EXCEL(.xlsx)']");
	private By uploadtextmsg=By.xpath("//*[text()='Drop an Excel(.xlsx) file here to upload']");
	private By orText=By.xpath("//*[text()='Or']");
	private By importDevices=By.xpath("//div[@class='button-content' and text()='Import Devices']");
	private By importListLabel=By.xpath("//label[text()='Import List']");
	private By invalidFile=By.xpath("//*[text()='Invalid File Uploaded']");
	private By goBackAddDevices=By.xpath("//*[text()='Go back to add devices']");
	private By resetFile=By.xpath("//div[@class='button-content' and text()='Reset File']");
	private By successTickmark=By.xpath("//div[contains(@class,'')]/following::img[contains(@src,'/ui/easyconfig/static/media/Success')]");
	private By importing=By.xpath("//*[contains(text(),'Importing')]");
	private By addmoredevices=By.xpath("//*[text()='Add more devices']");
	private By donemsg=By.xpath("//*[text()='Done']");
	private By closeIcon=By.xpath("//div[@class='close-wrapper']/i");
	private By deleteAlert=By.xpath("//*[text()='Device Deleted Successfully']");
	private By confirmAndSubmit=By.xpath("//*[text()='Confirm and submit']");
	private By editDropdown=By.xpath("//div[contains(@class,'ui fluid selection')]");
	private By editIcon=By.xpath("//div[contains(@class,'p-datatable')]/table/tbody/tr/td/following::img[contains(@src,'/ui/easyconfig/static/media/edit')]");  
	private By tableRecords=By.xpath("//div[contains(@class,'p-datatable')]/table/tbody/tr");
	private By totalCount=By.cssSelector("[class='total-count']");
	private By noDevicesText=By.xpath("//*[text()='No devices added yet.']");
	private By deviceConfigurationHeader=By.xpath("//h1[text()='Device Configuration']");
	private By nodeviceImage=By.cssSelector("[class='no-devices-image']");
	private By breadCrumbList=By.cssSelector("[class='section']");
	private By importerrormsg=By.xpath("//*[text()='Please download the complete list of errors and re-attempt after correction is missing']");
	private By goBacktoaddDevices=By.xpath("//*[text()='Go back to add devices']");
	private By downloadErrors=By.xpath("//*[text()='Download Errors']");
	private By importFailedtext=By.xpath("//*[contains(text(),'Failed to Import')]");
	private By noLevelText=By.xpath("//*[text()='Please select a level to view devices.']");
	private By loadingIcon=By.cssSelector("[class='ui loader-wrap loading-alignments loading']");
	private By enterpriseMsg=By.xpath("//*[text()='Please select a level to view records']");
	private By invalidEmail1=By.xpath("//span[text()='Invalid Phone number/Email id']");

	//locators for pagination
	private	By listbox = By.xpath("//div[@role='listbox']");
	private	By itemsnumber = By.xpath("(//span[@class='bold'])[1]");
	private	By tablerows = By.xpath("//tbody[@class='p-datatable-tbody']/tr");
	private	By pagination = By.xpath("//div[contains(@class,'page-btn item-btn ')]");
	private By LevelMsg=By.xpath("//*[contains(text(),'Please select a level')]");

	public void enterDetails(String email,String device) throws Throwable {
		//waitforPresenceofElement(addDeviceBtn,"addDeviceBtn",15);
		waitforPresenceofElement(emailLabeltextbox,"emailLabeltextbox",15);
		clearText(emailLabeltextbox);
		setTextWithoutClear(emailLabeltextbox,email, "entered email address");
	//	setText(emailLabeltextbox,email, "entered email address");
		clearText(deviceNameTextbox);
		setTextWithoutClear(deviceNameTextbox,device, "entered device name");
	}

	public void clickOnAddDeviceBtn() throws Throwable{
		waitForVisibilityOfElement(addDeviceBtn,"addDeviceBtn",10);
		click(addDeviceBtn,"addDeviceBtn");
	}

	public void clickOnAddNewDeviceBtn() throws Throwable{
		waitForVisibilityOfElement(addNewDeviceBtn,"addNewDeviceBtn",10);
		click(addNewDeviceBtn, "addDeviceBtn");    	
	}

	public void chooseOption(String menuoption) throws Throwable {
		// Phone : Intelligent Wearables : Tablet
		boolean flag = false;

		try {
			waitForVisibility_Elements(dropDown,"dropDown",10);
			click(dropDown,"Dropdownlist");
			List<WebElement> menulist = getWebElementList(listofElements, menuoption);
			for (WebElement e : menulist) {
				LOG.info(e.getText());
				if (e.getText().equalsIgnoreCase(menuoption)) {
					flag = true;
					e.click();
					LOG.info(menuoption + " :" + " tapped successfully");
					break;
				}
			}
			if (!flag) {
				LOG.info("No Element found");
				logfailinfo("Menu option is not displayed " + menuoption);
			}
		} catch (Exception e) {
			LOG.info("Not clicked on menu option");
		}
	}

	public void verifySuccessAlert() throws Throwable{
		waitForVisibilityOfElement(successAlert,"successAlert",30);
		verifyElementDisplayed(successAlert,"Validating success message",true);
		click(closeIcon,"Click on cancel button");
	}

	public void verifyinvalidNameLength(String errorOption) throws Throwable{		
		verifyTextMatching(longName,errorOption, "Validating longName error message");
	}

	public void verifyinvalidEmailLength(String errorOption) throws Throwable{		
		verifyTextMatching(longEmail,errorOption, "Validating longEmail error message");
	}

	public void verifybothinvalid() throws Throwable{
		boolean result = false;
		result = verifyElementDisplayed(invalidEmail1,"Validating invalidEmail error message",true);
		if(!result){
			Assert.fail("invalidEmail Element not visible");
		}
		verifyElementDisplayed(invalidDeviceName,"Validating error message",true);
	}

	public void verifybothemptyvalues() throws Throwable{
		verifyElementDisplayed(emptyEmail,"Validating error message",true);
		verifyElementDisplayed(emptyDeviceName,"Validating error message",true);
	}

	public void verifylowerCaseEmail(String lowerEmail) throws Throwable{
		verifyTextMatching(lowercaseEmail,lowerEmail,"Validating lower case message");
	}

	public void searchDevices(String device) throws Throwable {
		waitForPageLoaded();
		waitForVisibilityOfElement(searchDevices,"searchDevices",10);
		clearText(searchDevices);
		setText(searchDevices,device, "enter device address");
		clickEnter(searchDevices);
	}

	public void clickOnDeleteIcon() throws Throwable{  
		verifyElementDisplayed(deleteConfirmMsg,"Validating Delete confirmation message",true);
		click(confirm, "Confirm Button");	
	}

	public void verifyDeleteAlert() throws Throwable{
		waitForVisibilityOfElement(deleteAlert,"deleteAlert",10);
		verifyElementDisplayed(deleteAlert,"Validating delete alert message",true);
		click(closeIcon,"Click on cancel cross mark");
	}

	public void clickOnImportlistIcon() throws Throwable{
		waitForVisibilityOfElement(importList,"importList",15);
		click(importList, "ImportList Icon");
	}

	public void importFile(String filename) throws Throwable{
		Robot robot = new Robot();
		robot.setAutoDelay(1000);
		String file = System.getProperty("user.dir")+"\\resources\\movilizer\\TestData\\"+filename+".xlsx";
		StringSelection stringSelection = new StringSelection(file);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
		robot.delay(1000);
		robot.keyPress(KeyEvent.VK_META);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_META);
		robot.keyRelease(KeyEvent.VK_TAB);
		robot.delay(500);
		//Open Goto window
		robot.keyPress(KeyEvent.VK_META);
		robot.keyPress(KeyEvent.VK_SHIFT);
		robot.keyPress(KeyEvent.VK_G);
		robot.keyRelease(KeyEvent.VK_META);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		robot.keyRelease(KeyEvent.VK_G);

        //Paste the clipboard value
		robot.keyPress(KeyEvent.VK_META);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_META);
		robot.keyRelease(KeyEvent.VK_V);
		//Press Enter key to close the Goto window and Upload window
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.delay(500);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

//		robot.keyPress(KeyEvent.VK_CONTROL);
//		robot.keyPress(KeyEvent.VK_V);
//		robot.delay(1000);
//		robot.keyRelease(KeyEvent.VK_V);
//		robot.keyRelease(KeyEvent.VK_CONTROL);
//		robot.delay(1000);
//		robot.keyPress(KeyEvent.VK_ENTER);
//		robot.delay(1000);
//		robot.keyPress(KeyEvent.VK_CONTROL);
//		robot.keyPress(KeyEvent.VK_V);
//		robot.delay(1000);
//		robot.keyRelease(KeyEvent.VK_V);
//		robot.keyRelease(KeyEvent.VK_CONTROL);
//		robot.delay(1000);
//		robot.keyPress(KeyEvent.VK_ENTER);
//		robot.keyRelease(KeyEvent.VK_ENTER);
		verifyElementDisplayed(resetFile,"Found",true);
		if(isElementPresent(importDevices, "Importdevices button")){
			click(importDevices,"Tap on importDevices button");
		}else{
			click(donemsg,"Tap on Done button");
		}
	}

	public void verifySuccessMsg() throws Throwable{
		verifyElementDisplayed(successTickmark,"Tick displayed",true);
		verifyElementDisplayed(importing,"message displayed",true);
		verifyElementDisplayed(addmoredevices,"message displayed",true);
		verifyElementDisplayed(donemsg,"message displayed",true);
		click(donemsg,"Tap on Done button");
	}

	public void clickOnExportlistIcon() throws Throwable{
		//		Thread.sleep(3000);
		waitForVisibilityOfElement(exportListlabel,"exportListlabel",10);
		click(exportListlabel, "ExportList Icon");
	}

	public void clickOnEditIcon() throws Throwable{
		waitForVisibilityOfElement(editIcon,"editIcon",15);
		click(editIcon, "Edit Icon");
	}

	public void clickOnConfirmAndSubmit() throws Throwable{
		waitForVisibilityOfElement(confirmAndSubmit,"confirmAndSubmit",15);
		click(confirmAndSubmit, "confirmAndSubmit Icon");
	}

	public void verifyTablecount() throws Throwable{
		int size = getElementsSize(tableRecords);

	}

	public void verifyBrowserPopupmsg() throws Throwable{
		verifyElementDisplayed(uploadtextmsg,"Drop an excel file message",true);
		verifyElementDisplayed(browseButton,"Browse excel files button",true);
		click(browseButton, "Browse Button");
	}

	public void verifyDeviceType(String devicetype) throws Throwable{
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		By loc=By.cssSelector("[class='p-datatable-row'] div");
		List<WebElement> elems=driver.findElements(loc);
		String expUser=elems.get(2).getText();
		if(devicetype.equalsIgnoreCase(expUser)){
			System.out.println("Successfully updated device"+expUser);
		}else{
			logfailinfo( "Failed to update device");
		}
	}

	public void verifyDeviceName(String devicename) throws Throwable{
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		By loc=By.cssSelector("[class='p-datatable-row'] div");
		waitForVisibilityOfElement(loc, "Table records", 5);
		List<WebElement> elems=driver.findElements(loc);
		String expUser=elems.get(1).getText();
		if(devicename.equalsIgnoreCase(expUser)){
			System.out.println("Successfully created device"+expUser);
		}else{
			logfailinfo("Verify created record in device table");
		}
	}

	public void verifyDeviceTable() throws Throwable{
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		By loc=By.cssSelector("[class='p-datatable-row'] div");
		List<WebElement> elems=driver.findElements(loc);

		if(elems.size()>5){
			logfailinfo("Record is getting displayed,supposed to be not display");
		}else{
			System.out.println("Verify updated record in user table");
		}
	}

	public void verifyEmptyDevices(String empMsg) throws Throwable{
		waitForVisibilityOfElement(noDevicesText,"No Devices",20);
		verifyTextMatching(noDevicesText,empMsg,"Validating no devices message");
	}

	public void verifyDeviceHeader() throws Throwable{
		verifyElementDisplayed(deviceConfigurationHeader,"Header verified",true);
	}

	public void verifyImg() throws Throwable{
		waitForVisibilityOfElement(nodeviceImage,"No Devices Image",15);
		verifyElementDisplayed(nodeviceImage,"Validating no device image",true);
	}

	public void verifyBreadcrumb(String levelname) throws Throwable{
		boolean flag = false;
		List<WebElement> menulist = getWebElementList(breadCrumbList, "levelnames");
		for (WebElement e : menulist) {
			LOG.info(e.getText());
			if (e.getText().equalsIgnoreCase(levelname)) {
				flag = true;
				e.click();
				LOG.info(levelname + " :" + " is available on breadcrumb");
				break;
			}
		}
		if (!flag) {
			LOG.info("Invalid Levelname hierarchy found");
		}
	}

	public void verifyUIlabels() throws Throwable{
		waitForVisibilityOfElement(importList,"Importlist icon",15);
		verifyElementDisplayed(importList,"Validating import liste",true);
		verifyElementDisplayed(exportListlabel,"Validating Exportlist label",true);
		verifyElementDisplayed(getTemplatelabel,"Validating get template labele",true);
	}

	public void verifyFailedMsg() throws Throwable{
		waitForVisibilityOfElement(importerrormsg,"Importlist Error msg",15);
		verifyElementDisplayed(importerrormsg,"Verfied error message",true);
		verifyElementDisplayed(importFailedtext,"Verfied error message",true);
		verifyElementDisplayed(goBacktoaddDevices,"Verfied error message",true);
		verifyElementDisplayed(downloadErrors,"Verfied error message",true);
	}

	public void clickOnDownloadErrors() throws Throwable{
		waitForVisibilityOfElement(downloadErrors,"Download errors button",10);
		click(downloadErrors, "Downloading errors ");
	}

	public void verifyNoDeviceHeader() throws Throwable{
		isElementNotPresent(deviceConfigurationHeader,"Header verified");
	}

	public void selectEnterpriseDevices(String empMsg) throws Throwable{
		waitForVisibilityOfElement(noLevelText,"No Devices",20);
		verifyTextMatching(noLevelText,empMsg,"Validating no Level selected message");
	}

	// select levelhirarchy from devices
	public void selectlevelhirarchy_device(String levelhirarchyname) throws Throwable {
		waitforPresenceofElement(LevelMsg, "Enterprise level Device message", 20);
		waitForPageLoaded();
		By selectlevlhirarchy = By.xpath("//div[text()='" + levelhirarchyname + "']");
		List<WebElement> list= driver.findElements(By.cssSelector("[class='loader-content'] [class='content']"));
		for(int i=0;i<list.size();i++){
			if(isElementPresent(selectlevlhirarchy, "Level")){
				setFocusAndClick(selectlevlhirarchy, "Select levelhirarchyfrom Devices");
				break;
			}else{
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
						list.get(i));
			}
		}		

	}

	// Selection of device type
	public void selectDeviceType(String devicetype) throws Throwable{
		By checkboxestoselect =By.xpath("//input[@type='checkbox']/../label");
		List<WebElement> checkboxes = getWebElementList(checkboxestoselect,"Checkboxes to select for filtering");

		for(int i=0;i<checkboxes.size();i++)
		{
			waitForVisibilityOfElement(checkboxestoselect, "Checkboxes", 5);
			String checkboxtext=checkboxes.get(i).getText();
			System.out.println("Types of Devices "+checkboxtext);
			WebElement element = checkboxes.get(i);
			try
			{
				if (checkboxtext.equalsIgnoreCase(devicetype)) {
					element.click();
					break;
				}
			}
			catch (Exception e) {
				waitForPageLoaded();//Thread.sleep() used to click by using Javascript Executor
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",element);
				waitForPageLoaded();
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			}
		}
	}

	// validating FILTERS functionality on Device
	public void ValidateFilterTypes(String actualtype) throws Throwable{
		By table=By.xpath("//tbody[@class='p-datatable-tbody']/tr/td[3]/div[@class='cell-data-wrap']");
		List<WebElement> talbedata = getWebElementList(table,"Table data");
		for (WebElement e : talbedata) {
			LOG.info("Actual value "+e.getText());
			validateCheckPointEquals(actualtype,e.getText(),"Validating type of filter");
		}
	}

	// vclick on devicetype down
	public void clickdevicetypeDropdown() throws Throwable{
		By loc=By.xpath("//*[@class='section-label-text'][text()='Device Type']");
		waitForVisibilityOfElement(loc, "DeviceType tapped",15);
		click(loc, "Filter option");
	}

	// PAGINATION for round template
	public void Verify_Pagination_Devices() throws Throwable 
	{
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		waitForVisibilityOfElement(listbox, "Listbox",20);
		click(listbox, "Click on listbox");
		selectItems_perpage("20 per page");
		WebDriverWait wait= new WebDriverWait(driver,30);  
		wait.until(ExpectedConditions.visibilityOfAllElements(getWebElementList(tablerows,"Elements")));
		// Validating 1-20
		//validateCheckPointMatch(itemsnumber,"1 - 20 ","20 items per page");
		Assert.assertEquals(String.valueOf(getElementsSize(tablerows)),"20");

		clickonListbox();
		selectItems_perpage("10 per page");
		// Validating 1-20
		wait.until(ExpectedConditions.visibilityOfAllElements(getWebElementList(tablerows,"Elements")));
		//validateCheckPointMatch(itemsnumber,"1 - 10","10 items per page");
		Assert.assertEquals(String.valueOf(getElementsSize(tablerows)),"10");

		waitForPageLoaded();
		List<WebElement> paginationvalues = getWebElementList(pagination,"pagination list");
		for (int i = 0; i < paginationvalues.size(); i++) {
			WebElement element = paginationvalues.get(i);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			waitForPageLoaded();
		}
	}

	public void verifyDevicesSearch(String expectedValue) throws Throwable {

		By rowLoc = By.xpath("//*[@class='p-datatable-row']");
		List<WebElement> elems = driver.findElements(rowLoc);
		if (expectedValue.equalsIgnoreCase("No records found")) {
			logpassinfo("No records found in the table");
		} else {
			int count = 0;
			for (int i = 0; i < elems.size(); i++) {
				i++;
				By loc = By.xpath("//*[@class='p-datatable-row'][" + i + "]//td//div");
				List<WebElement> eles = driver.findElements(loc);
				for (int j = 0; j < eles.size(); j++) {
					String expUser = elems.get(j).getText();
					if (expUser.contains(expectedValue)) {
						Assert.assertTrue(expUser.contains(expectedValue));
						count++;
						break;
					}
				}

			}
			if (count == 0) {
				logfailinfo("No matching records are available");
				Assert.fail("No matching records are available");
			} else {
				logpassinfo("Matching records are available with searching value");
			}
		}

	}
	public void verifyInvalidPhonenumber(String invalidphonenumber) throws Throwable{
		verifyTextMatching(invalidEmail1,invalidphonenumber,"Validating phonenumber message");

	}




}
