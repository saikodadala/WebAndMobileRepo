package pages.Movilizer;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import seleniumUtilities.GenericMethods;

public class AbstractAssetPage extends GenericMethods {

	private By abstractAsset=By.xpath("//*[text()='Abstract Assets']");
	private By headerMessage=By.xpath("//*[text()='Configuration']");
	private By metaLanguageHeader=By.cssSelector("[class='meta language-set-header']");
	private By searchAbstractAssetTextBox=By.cssSelector("[placeholder='Search Abstract Asset']");
	private By assetTotal=By.cssSelector("[class='total-count']");
	private By pageDropDown=By.cssSelector("[class='pages-dropdown'] i");
	private By addAbstractAssetButton=By.xpath("//*[contains(text(),'Add Abstract Asset')]/i");
	private By filterIcon=By.cssSelector("[class='header-bar-item filter-panel-icon']");
	private By dataTable=By.cssSelector("[class='p-datatable-wrapper']");
	private By pagenationInfo=By.cssSelector("[class='page-btn item-btn active']");
	private By pageNavigation=By.cssSelector("[class='nav-container']");
	private By threeDotsInTableRecords=By.cssSelector("[class='popup-pointer']");
	private By tableRecords=By.xpath("//*[@class='p-datatable-row'][1]");
	private By abstractAssetDetailsPage=By.xpath("//*[text()='ABSTRACT ASSET DETAILS']");
	private By mainFrame=By.cssSelector("[class='gwt-Frame']");
	private By configuraton=By.xpath("//a[contains(@href,'Configuration')]/i");
	private By abstractAssetfirstrecord = By.xpath("//div[contains(@class,'p-datatable')]/table/tbody/tr[1]");
	private By noTasksText=By.xpath("//*[text()='No Tasks added yet']");
	private By noTasksImage=By.xpath("//img[contains(@src,'/ui/easyconfig/static/media/no_abstract_assets')]");
	private By addNewTaskBtn=By.xpath("//*[@class='button-content' and text()='Add New Task']");
	
	public void clickOnAbstractAssetOption() throws Throwable{
		click(abstractAsset, "Abstract asset");
	}

	public void verifyImportPadding(String padding) throws Throwable{
		By loc=By.xpath("//*[text()='"+padding+"']");
		isElementDisplayed(loc, padding);
	}

	public void verifyConfigurationHeader() throws Throwable{
		isElementDisplayed(headerMessage, "Configuration header");
	}

	public void verifyMetaLanguageHeader() throws Throwable{
		isElementDisplayed(metaLanguageHeader, "meta language header");
	}

	public void verifyAbstractAssetSearchBox() throws Throwable{
		waitForVisibilityOfElement(searchAbstractAssetTextBox, "Abstract asset search box",20);
		isElementDisplayed(searchAbstractAssetTextBox, "Abstract asset search box");
	}

	public void verifyAbstractAssetTotal() throws Throwable{
		isElementDisplayed(assetTotal, "Abstract asset total");
	}

	public void verifyPageDropdown() throws Throwable{
		isElementDisplayed(pageDropDown, "Page dropdown");
	}

	public void verifyAddAbstractAssetButton() throws Throwable{
		isElementDisplayed(addAbstractAssetButton, "Add abstract asset button");
	}
	public void verifyFilterIcon() throws Throwable{
		isElementDisplayed(filterIcon, "filterIcon");
	}
	public void verifyDataTable() throws Throwable{
		isElementDisplayed(dataTable, "dataTable");
	}
	public void verifyPagenationInfo() throws Throwable{
		waitforPresence_Elements(pagenationInfo, "pagenationInfo",10);
		isElementDisplayed(pagenationInfo, "pagenationInfo");
	}

	public void verifyPagenavigation() throws Throwable{
		isElementDisplayed(pageNavigation, "pageNavigation");
	}
	public void clickOnFirstRecord() throws Throwable{
		List<WebElement> list=driver.findElements(tableRecords);
		int count=list.size();
		if(count>0){
			click(tableRecords, "First record");
		}else{
			//	reporter.SuccessReport("Verify table records", "No records are available for click");
		}
	}
	public void verifyAbstractAssetDetailsPage() throws Throwable{
		isElementDisplayed(abstractAssetDetailsPage, "abstractAssetDetailsPage");
	}

	public void validateErrorMessage(String fieldName,String text) throws Throwable{
		By loc=By.xpath("//*[text()='"+text+"']");
		waitForVisibilityOfElement(loc,fieldName,30);
		verifyTextMatching(loc, text, fieldName);
	}

	public void clickonConfiguration() throws Throwable
	{
		waitForVisibilityOfElement(mainFrame, "mainFrame",40);
		switchToFrame(mainFrame);
		waitForVisibilityOfElement(configuraton,"Configuration",20);	
		click(configuraton,"Click on configuraiton");
	}











	
	public void clickOnThreeDots() throws Throwable{

		By locator=By.cssSelector("[class='popup-pointer']");
		waitForVisibilityOfElement(locator,"Three dots",20);
		List<WebElement> elems=driver.findElements(locator);
		elems.get(0).click();	
	}
	
	public void clickOnRecordAction(String action) throws Throwable{
		By locator=By.xpath("//*[text()='"+action+"']");
		waitForVisibilityOfElement(locator,action,20);
		click(locator, action);
	}
		
	public void clickon_firstAbstractAsset() throws Throwable {
		waitForVisibilityOfElement(abstractAssetfirstrecord,"AddAbstractbtn",10);
		click(abstractAssetfirstrecord, "Click on Add Abstract Assets button");
	}	
	
	public void verifyAbstractTasksEmptyMessage(String empMsg) throws Throwable{
		waitForVisibilityOfElement(noTasksText,"NoAttachmentstext",20);
		verifyTextMatching(noTasksText,empMsg,"Validating no attachemnts message");
	}
	
	public void verifyNoTasksImg() throws Throwable{
		waitForVisibilityOfElement(noTasksImage,"NoDocsImage",15);
		verifyElementDisplayed(noTasksImage,"Validating no attachments image",true);
	}
	
	public void clickOnAddNewTaskBtn() throws Throwable{
		waitForPageLoaded();
		waitforPresenceofElement(addNewTaskBtn,"addNewTaskBtn",15);
		scrollToWebElement(addNewTaskBtn);
		clickJS(addNewTaskBtn,"addNewTaskBtn");
	}
}
