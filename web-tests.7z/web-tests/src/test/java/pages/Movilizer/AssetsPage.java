package pages.Movilizer;

import org.openqa.selenium.By;
import seleniumUtilities.GenericMethods;

public class AssetsPage extends GenericMethods {

	
	/**
	 * Locators and reusable methods for Home Page
	 * 
	 * @author Sai Kodadala
	 *
	 */

	private By enterpriseName=By.cssSelector("[class='enterprise-title active-border'] span");   
    private By mainFrame=By.cssSelector("[class='gwt-Frame']");    
    private By closeSuccessMessage=By.cssSelector("[class='close-wrapper']");
    

    public void mouseOverOnEnterprise()throws Throwable{
    	waitForPageLoaded();
    	driver.switchTo().defaultContent();
	    waitForPageLoaded();
    	waitForVisibilityOfElement(mainFrame, "mainFrame",20);
        switchToFrame(mainFrame);
        waitForVisibilityOfElement(enterpriseName, "Enterprise",20);
        mouseHoverJS(enterpriseName, "Enterprise");      
    }
    
    
    public void clickOnCloseSuccessMessage()throws Throwable{
        waitForVisibilityOfElement(closeSuccessMessage, "closeSuccessMessage",15);
        click(closeSuccessMessage,"closeSuccessMessage");
    }
}
