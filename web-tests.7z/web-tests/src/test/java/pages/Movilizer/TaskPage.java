package pages.Movilizer;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import seleniumUtilities.GenericMethods;

public class TaskPage extends GenericMethods {

	// locators
	private By Task = By.xpath(("//a[text()='Tasks']"));
	private By enterpriseLevel = By.xpath("//*[text()='Please select a level to view records']");
	private By addTaskIcon = By.xpath("//*[text()='Add Task']");
	private By createTaskHeader = By.xpath("//*[text()='Create Task for ']");
	private By DisabledLimitsTab = By
			.xpath("//*[@class='active disabled link step item']//child::div[text()='Limits']");
	private By taskDeatilsLbl = By.xpath("//div[text()='Task Details']");
	private By primaryInfoLbl = By.xpath("//div[text()='Primary Information']");
	private By taskNameField = By
			.xpath("//span[@class='input-label-message' and text()='Name']/../..//input[@placeholder='Type here']");
	private By taskDescField = By.xpath(
			"//span[@class='input-label-message' and text()='Description']/../..//input[@placeholder='Type here']");
	private By taskPositionField = By.xpath(
			"//span[@class='input-label-message' and text()='Task Position']/../..//input[@placeholder='Hint Text']");
	private By taskTypedropDown = By.xpath(
			"//span[@class='input-label-message' and text()='Type']/../..//div[@class='ui fluid selection dropdown']");
	private By taskAssetModes = By.xpath("//*[text()='Select Asset Modes']");
	private By taskLocField = By.xpath(
			"//span[@class='input-label-message' and text()='Location ID']/../..//input[@placeholder='Type here']");
	private By taskGPSField = By.xpath(
			"//span[@class='input-label-message' and text()='Location (GPS coordinates)']/../..//input[@placeholder='Type here']");
	private By taskLocDescField = By.xpath(
			"//span[@class='input-label-message' and text()='Location Description']/../..//input[@placeholder='Type here']");
	private By nextBtn = By.xpath("//*[@class='button-content' and text()='Next']");
	private By resetBtn = By.xpath("//*[@class='button-content' and text()='RESET']");
	private By tasktypelist = By.xpath("//div[@class='visible menu transition']/div");
	private By limitvalueField = By
			.xpath("//span[@class='input-label-message' and text()='Value']/../..//input[@placeholder='Type here']");
	private By addLimitBtn = By.xpath("//*[@class='button-content' and text()=' Add Limit']");
	private By saveBtn = By.xpath("//*[@class='button-content' and text()='Save']");
	private By taskSuccessAlert = By.xpath("//span[contains(text(),'Task Added/Edited Successfully')]");
	private By taskNameMandate = By.xpath("//*[text()='Please enter Task Name']");
	private By taskPositionMandate = By.xpath("//*[text()='Please enter Task Position']");
	private By taskTypeMandate = By.xpath("//*[text()='Please select atleast one task type']");
	private By taskGlobalSearch = By.cssSelector("[placeholder='Global Search']");
	private By taskTotal = By.cssSelector("[class='total-count']");
	private By taskpageDropDown = By.cssSelector("[class='ui selection dropdown']");
	private By taskDataTable = By.cssSelector("[class='p-datatable p-component p-datatable-scrollable  hover-over']");
	private By taskcloseicon = By.cssSelector("[class='close-icon-wrap']");
	private By closeWindowHeader = By.xpath("//*[text()='Close Window']");
	private By closeWindowMsg = By
			.xpath("//*[text()='Closing the window will reset all the information entered. Are you sure?']");
	private By closeIcon = By.xpath("//div[@class='close-wrapper']/i");
	private By locValvalidation = By.xpath("//*[text()='Value must be a numeric']");
	private By confirm = By.xpath("//*[text()='Confirm']");
	private By cancelBtn = By.xpath("//*[text()='Cancel']");
	private By firstRecordEllipse = By
			.xpath("//div[contains(@class,'p-datatable')]/table/tbody/tr/td[@class='column-ellipse']");
	private By deleteTask = By.xpath("//*[contains(text(),'Delete Task')]");
	private By deleteConfirmMsg = By.xpath("//*[contains(text(),'Are you sure you want to delete')]");
	private By deleteTaskAlert = By.xpath("//*[text()='Task Deleted Successfully']");
	private By activeLimitsTab = By.xpath("//*[@class='link step item']//child::div[text()='Limits']");
	private By activeDeviationCondn = By
			.xpath("//*[@class='link step item']//child::div[text()='Derivation Conditions']");
	private By activeSupportiveContent = By
			.xpath("//*[@class='link step item']//child::div[text()='Supportive Content']");
	private By taskNameValidation = By.xpath("//*[text()='Task Name cannot be more than 128 characters']");
	private By taskBckIDValidation = By.xpath("//*[text()='Task Backend Id cannot be more than 128 characters']");
	private By backendField = By.xpath(
			"//span[@class='input-label-message' and text()='Backend ID']/../..//input[@placeholder='Type here']");
	private By pagenationInfo = By.cssSelector("[class='first-btn page-btn active']");
	private By predefinedvalues = By.xpath("//span[text()='Predefined Values']/../..//input");
	private By dropdownicon = By.xpath("//span[@class='input-label-message' and text()='Value']/../..//i");
	private By selectdate = By.xpath("//span[text()='Value']/../..//input");
	private By Tasks = By.xpath("//a[text()='Tasks']");
	private By disableFormulaTextBox = By.cssSelector("[class='react-tags disable-input-box']");
	private By taskdescription = By.xpath(
			"//span[@class='input-label-message' and text()='Description']/../..//input[@placeholder='Type here']");
	private By taskcategory = By.xpath("//div[@data-testid='task-category-list']//div[@role='option']");
	private By limitcategory = By.xpath("//div[@data-testid='limit-category']//div[@role='option']");
	private By taskcriticalityicon = By.xpath("((//*[text()='Criticality'])/../..//i)[2]");
	private By taskcriticlity = By.xpath("//div[@data-testid='task-criticality-list']//div[@role='option']");
	private By taskcategoryicon = By.xpath("(//*[text()='Category'])[2]/../..//i");
	private By assetmode = By.xpath("//*[text()='Asset Mode']/../..//div[@role='listbox']");
	private By assetmodeoption = By
			.xpath("//div[@class='ui scuf-dropdown-wrapper expanded input-field-custom fluid']//div[@role='option']");
	private By LocIDPlaceholder = By
			.xpath("//span[@class='input-label-message' and text()='Location ID']/../..//input");
	private By LocPlaceholder = By
			.xpath("//span[@class='input-label-message' and text()='Location (GPS coordinates)']/../..//input");
	private By LocDescPlaceholder = By
			.xpath("//span[@class='input-label-message' and text()='Location Description']/../..//input");
	private By SAPTagPlaceholder = By.xpath(
			"(//span[@class='input-label-message' and text()='SAP Tag']/following::input[@placeholder='Type here'])[1]");
	private By DCSTagPlaceholder = By.xpath(
			"(//span[@class='input-label-message' and text()='DCS Tag']/following::input[@placeholder='Type here'])[1]");
	private By HistorianTagPlaceholder = By.xpath(
			"(//span[@class='input-label-message' and text()='Historian Tag']/following::input[@placeholder='Type here'])[1]");
	private By FieldTagPlaceholder = By.xpath(
			"(//span[@class='input-label-message' and text()='Field Tag']/following::input[@placeholder='Type here'])[1]");
	private By addnewrow = By.xpath("//*[contains(text(),'Add New Row')]/.");
	private By additionalheader = By.xpath("(//input[@data-test='input-key'])[1]");
	private By additionaldescription = By.xpath("(//input[@data-test='input-value'])[1]");
	private By addlink = By.xpath("//*[contains(text(),'Add Link')]/.");
	private By linkdescription = By.xpath("(//input[@data-test='input-key'])[2]");
	private By link = By.xpath("(//input[@data-test='input-value'])[2]");
	private By cause = By
			.xpath("//span[@class='input-label-message' and text()='Cause']/../..//input[@placeholder='Type here']");
	private By consequences = By.xpath(
			"//span[@class='input-label-message' and text()='Consequences']/../..//input[@placeholder='Type here']");
	private By actions = By
			.xpath("//span[@class='input-label-message' and text()='Action']/../..//input[@placeholder='Type here']");
	private By discard = By.xpath("//*[text()='Discard']");
	private By editBtn = By.xpath("//*[@class='edit-action' and text()='Edit']");
	private By conditionaltaskdropDown = By.xpath("//div[@role='combobox']//div[text()='Select Task']");
	private By conditionaltasklist = By.xpath("//div[@role='listbox']//div[@class='selected item']");
	private By activeLimitsSection = By.xpath("//*[@class='active item' and text()='Limits']");
	private By taskDetailsPage = By.xpath("//div[@class='task-header']");
	private By conditionaltaskDetailsPage_Label = By
			.xpath("//span[@class='conditional-task-readonly-label' and text() = 'Conditional Task: ']");
	private By conditionaltaskDetailsPage_name = By.xpath("//div[@class='scuf-col col-4']//div");
	private By backArrowPointerBtn = By.xpath("//*[@data-testid='show-cursor-pointer']");
	private By editLimitBtn = By
			.xpath("//div[@class='limit-data-card']/..//div[@class='button-content' and text() = 'Edit']");
	
	
	// click on task
	public void clickonTask() throws Throwable {
		// Thread.sleep(5000);
		// waitForVisibilityOfElement(Task,"Task",15);
		click(Task, "Click on Task");
	}

	// select level hirarchy
	public void selectlevelhirachy(String levelhirarchyname) throws Throwable {

		driver.switchTo().defaultContent();
		By mainFrame = By.cssSelector("[class='gwt-Frame']");
		switchToFrame(mainFrame);
		waitforPresenceofElement(enterpriseLevel, "Enterprise level message", 10);
		waitForPageLoaded();
		By selectlevlhirarchy = By.xpath("//div[text()='" + levelhirarchyname + "']");
		List<WebElement> list = driver.findElements(By.cssSelector("[class='loader-content'] [class='content']"));
		// waitForVisibilityOfElement(selectlevlhirarchy,"selectlevlhirarchy",10);
		for (int i = 0; i < list.size(); i++) {
			if (isElementPresent(selectlevlhirarchy, "Level")) {
				setFocusAndClick(selectlevlhirarchy, "Select levelhirarchyfrom round template");
				break;
			} else {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", list.get(i));
			}
		}
		// Thread.sleep(5000);
	}

	public void enterTaskName(String name) throws Throwable {
		waitForVisibilityOfElement(taskNameField, "Task Name", 30);
		clearText(taskNameField);
		setText(taskNameField, name, "Task Name");
		pressTab(taskNameField);
	}

	public void enterTaskPosition(String name) throws Throwable {
		waitForVisibilityOfElement(taskPositionField, "Task PositionField", 30);
		setText(taskPositionField, name, "Task Position");
	}

	// This methos is select the specific tasktype from list
	public void chooseTaskType(String menuoption) throws Throwable {
		boolean flag = false;

		try {
			scrollToWebElement(taskTypedropDown);
			click(taskTypedropDown, "Dropdownlist");
			List<WebElement> menulist = getWebElementList(tasktypelist, menuoption);
			for (WebElement e : menulist) {
				LOG.info(e.getText());
				if (e.getText().equalsIgnoreCase(menuoption)) {
					flag = true;
					e.click();
					LOG.info(menuoption + " :" + " tapped successfully");
					break;
				}
			}
			if (!flag) {
				LOG.info("No Element found");
			}
		} catch (Exception e) {
			LOG.info("Not clicked on menu option");
		}
	}

	// click on Next button
	public void clickonNext() throws Throwable {
		waitForPageLoaded();
		clickJS(nextBtn, "Click on next Button");
	}

	// click on RESET button
	public void clickonReset() throws Throwable {
		click(resetBtn, "Click on Reset Button");
	}

	public void enterLimitName(String name) throws Throwable {
		waitForVisibilityOfElement(taskNameField, "Limit Name", 30);
		setText(taskNameField, name, "Limit Name");
	}

	public void enterLimitValue(String name) throws Throwable {
		waitForVisibilityOfElement(limitvalueField, "Limit valueField", 30);
		setText(limitvalueField, name, "Limit value");
	}

	// click on Add Limit button
	public void clickonAddLimitBtn() throws Throwable {
		waitForPageLoaded();
		scrollToWebElement(addLimitBtn);
		click(addLimitBtn, "Click on addLimit Button");
	}

	// click on Save button
	public void clickonsaveBtn() throws Throwable {
		click(saveBtn, "Click on Save Button");
	}

	public void verifyTaskSuccessAlert(String type) throws Throwable {
		if (type.equalsIgnoreCase("Addition")) {
			waitForVisibilityOfElement(taskSuccessAlert, "successAlert", 10);
			verifyElementDisplayed(taskSuccessAlert, "Validating success message", true);
			click(closeIcon, "Click on cancel button");
		} else if (type.equalsIgnoreCase("Edit")) {
			waitForVisibilityOfElement(taskSuccessAlert, "successAlert", 10);
			verifyElementDisplayed(taskSuccessAlert, "Validating success message", true);
			click(closeIcon, "Click on cancel button");
		} else if (type.equalsIgnoreCase("Delete")) {
			waitForVisibilityOfElement(deleteTaskAlert, "successAlert", 10);
			verifyElementDisplayed(deleteTaskAlert, "Validating success message for Deletion", true);
			click(closeIcon, "Click on cancel button");
		}
	}

	public void verifyTaskMandatoryMsg() throws Throwable {
		isElementDisplayed(taskNameMandate, "Validating taskNameMandate error message");
	}

	public void verifyTaskPositionMandatoryMsg() throws Throwable {
		isElementDisplayed(taskPositionMandate, "Validating  taskPositionMandate error message");
	}

	public void verifyTaskTypeMandatoryMsg() throws Throwable {
		isElementDisplayed(taskTypeMandate, "Validating taskTypeMandate error message");
	}

	public void verifyTasksSearchBox() throws Throwable {
		isElementDisplayed(taskGlobalSearch, "Tasks search box");
	}

	public void verifyTasksTotal() throws Throwable {
		isElementDisplayed(taskTotal, "Task total");
	}

	public void verifyTaskPageDropdown() throws Throwable {
		isElementDisplayed(taskpageDropDown, "Page dropdown");
	}

	public void verifyTaskDataTable() throws Throwable {
		waitForVisibilityOfElement(taskDataTable, "dataTable", 10);
		waitforPresenceofElement(taskDataTable, "dataTable", 15);
		isElementDisplayed(taskDataTable, "dataTable");
	}

	public void verifyinvalidCharlengthtaskPosition(String errormsg) throws Throwable {
		verifyTextMatching(locValvalidation, errormsg, "Validating locValvalidation error message");
	}

	public void verifyinvalidCharlengthtaskName(String errormsg) throws Throwable {
		verifyTextMatching(taskNameValidation, errormsg, "Validating taskNameValidation error message");
	}

	public void verifyinvalidCharlengthtaskBckID(String errormsg) throws Throwable {
		verifyTextMatching(taskBckIDValidation, errormsg, "Validating  taskBckIDValidation error message");
	}

	public void enterTaskInvalidDetails(String longname, String length) throws Throwable {
		waitForPageLoaded();
		if (length.equalsIgnoreCase("numeric")) {
			clickJS(taskPositionField, longname);
			setText(taskPositionField, longname, "entered LOCATION name");
		} else if (length.equalsIgnoreCase("128chars")) {
			setText(taskNameField, longname, "entered 129chars");
		}
	}

	public void verifyTaskPage() throws Throwable {
		waitForVisibilityOfElement(createTaskHeader, "Task Header Available", 10);
		waitForVisibilityOfElement(taskNameField, "Task Name Header Available", 10);
		isElementDisplayed(createTaskHeader, "dataTable");
	}

	public void searchTask(String taskname) throws Throwable {
		clearText(taskGlobalSearch);
		setText(taskGlobalSearch, taskname, "enter the task name to search");
		clickEnter(taskGlobalSearch);
	}

	public void verifyTaskName(String devicename) throws Throwable {
		waitForPageLoaded();
		By loc = By.cssSelector("[class='p-datatable-row'] div");
		waitForVisibilityOfElement(loc, "Table records", 5);
		List<WebElement> elems = driver.findElements(loc);
		String expUser = elems.get(0).getText();
		if (devicename.equalsIgnoreCase(expUser)) {
			System.out.println("Successfully created Task  " + expUser);
		} else {
			Assert.fail("Unable to Verify created record in Task Data table");
		}
	}

	public void clicktaskcrossicon() throws Throwable {
		click(taskcloseicon, "Click on Tick wrong");
	}

	public void closewindowpopup() throws Throwable {
		waitForVisibilityOfElement(closeWindowHeader, "Verified Close Window Header", 10);
		isElementDisplayed(closeWindowMsg, "Verified Close Window Header");
		isElementDisplayed(confirm, "Verified Confirm button");
		isElementDisplayed(cancelBtn, "Verified cancel button");
	}

	public void clickConfirmButton() throws Throwable {
		int count = driver.findElements(confirm).size();
		if (count > 0) {
			click(confirm, "clicked confirm button");
		}
	}

	// wait till first record of tasks on Ellipse
	public void waittilltaskappears() throws Throwable {
		waitForVisibilityOfElement(firstRecordEllipse, "waitFortaskdisplay", 10);
	}

	public void clickOnTaskEllipse() throws Throwable {
		scrollToWebElement(firstRecordEllipse);
		click(firstRecordEllipse, "Click ellipseIcon");
	}

	public void clickOnRecordAction(String action) throws Throwable {
		By locator = By.xpath("//div[@class='ui vertical vertical-menu  menu']//*[text()='" + action + "']");
		waitForVisibilityOfElement(locator, action, 20);
		click(locator, action);
	}

	public void deletetaskwindowpopup() throws Throwable {
		waitForVisibilityOfElement(deleteTask, "Verified delete Task Window Header", 10);
		isElementDisplayed(deleteConfirmMsg, "Verified deleteTask message");
		isElementDisplayed(confirm, "Verified Confirm button");
		isElementDisplayed(cancelBtn, "Verified cancel button");
	}

	// wait till first record of task disappears by Ellipse
	public void waittilltaskdisappears() throws Throwable {
		waitForInVisibilityOfElement(firstRecordEllipse, "waitFortaskdisappear", 10);
	}

	public void verifyLimitsSection() throws Throwable {
		waitForVisibilityOfElement(activeLimitsTab, "Verified active Limits Section Header", 10);
		isElementDisplayed(activeDeviationCondn, "Verified active Limits Section message");
	}

	public void verifySupportiveContentSection() throws Throwable {
		waitForVisibilityOfElement(activeSupportiveContent, "Verified activeSupportiveContent Header", 10);
		isElementDisplayed(activeSupportiveContent, "Verified activeSupportiveContent message");
	}

	public void enterTaskBCKendInvalidDetails(String longname, String length) throws Throwable {
		setText(backendField, longname, "entered 129chars");
	}

	public void verifyPagenationInfo() throws Throwable {
		waitforPresence_Elements(pagenationInfo, "pagenationInfo", 10);
		isElementDisplayed(pagenationInfo, "pagenationInfo");
	}

	@SuppressWarnings("unused")
	public void enterPredefinedValues(String predefinedval) throws Throwable {

		waitforPresence_Elements(predefinedvalues, "predefinedvalues", 10);
		setText(predefinedvalues, predefinedval, "Predefined values");
		clickEnter(predefinedvalues);
	}

	public void enterpredefinedvalue_Date(String datevalue) throws Throwable {

		Date date = new Date();
		String modifiedDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		datevalue = modifiedDate;
		clearText(predefinedvalues);
		clickEnter(predefinedvalues);
		setText(predefinedvalues, datevalue, "predefinedvalues");
	}

	public void clickondropdownicon() throws Throwable {

		int size = driver.findElements(dropdownicon).size();
		if (size > 0) {
			waitForVisibilityOfElement(dropdownicon, "dropdown icon", 10);
			click(dropdownicon, "dropdown icon");
		}
	}

	public void selectlimitvalue_as(String value) throws Throwable {

		By selectoption = By.xpath("//div[@role='option' and text()='" + value + "']");
		int size = driver.findElements(selectoption).size();
		if (size > 0) {
			waitForVisibilityOfElement(selectoption, "selectoption", 10);
			click(selectoption, "select option");
		} else {
			waitForVisibilityOfElement(selectdate, "Select date", 10);
			setText(selectdate, value, "Select date");
		}
	}

	public void verifytasksuccess() throws Throwable {
		waitForVisibilityOfElement(taskSuccessAlert, "successAlert", 10);
		verifyElementDisplayed(taskSuccessAlert, "Validating success message", true);
		click(closeIcon, "Click on cancel button");
	}

	public void clickonTasks() throws Throwable {
		waitForVisibilityOfElement(Tasks, "Click on Tasks", 15);
		click(Tasks, "Click on Tasks");
	}

	public void clickontaskicon() throws Throwable {
		waitForPageLoaded();
		click(addTaskIcon, "clicked Add Task icon");
	}

	public void creattask_differentype(String tasktype, String taskname, String numericvalue, String predefinedvalue,
			String limitname, String limittype) throws Throwable {

		scrollBottom();
		clickonTasks();
		verifyTaskDataTable();
		clickontaskicon();
		verifyTaskPage();
		enterTaskName(taskname);
		enterTaskPosition(numericvalue);
		chooseTaskType(tasktype);
		enterPredefinedValues(predefinedvalue);
		clickonNext();
		verifyLimitsSection();
		enterLimitName(limitname);
		chooseTaskType(limittype);
		clickondropdownicon();
		selectlimitvalue_as(predefinedvalue);
		clickonAddLimitBtn();
		clickonNext();
		verifySupportiveContentSection();
		clickonsaveBtn();
	}

	public void creattask_differentype(String tasktype, String taskname, String numericvalue, String date,
			String predefinedvalue, String limitname, String limittype) throws Throwable {

		scrollBottom();
		clickonTasks();
		verifyTaskDataTable();
		clickontaskicon();
		verifyTaskPage();
		enterTaskName(taskname);
		enterTaskPosition(numericvalue);
		chooseTaskType(tasktype);
		enterpredefinedvalue_Date(date);
		clickonNext();
		verifyLimitsSection();
		enterLimitName(limitname);
		chooseTaskType(limittype);
		clickondropdownicon();
		selectlimitvalue_as(predefinedvalue);
		clickonAddLimitBtn();
		clickonNext();
		verifySupportiveContentSection();
		clickonsaveBtn();
	}

	public void verifyFormulaTextBox() throws Throwable {
		int count = driver.findElements(disableFormulaTextBox).size();
		if (count > 0) {
			LOG.info("Formulat text box disabled");
		}
	}

	// enter primary information
	public void enterprimaryinformation(String taskname, String description, String backendid, String position,
			String tasktype) throws Throwable {
		waitForVisibilityOfElement(taskNameField, "Task Name", 10);
		clearText(taskNameField);
		setText(taskNameField, taskname, "Task Name");
		pressTab(taskNameField);
		setText(taskdescription, description, "Task description");
		setText(backendField, backendid, "Backend id");
		click(taskcategoryicon, "Taskcategoryicon");
		waitForVisibilityOfElement(taskcategory, "taskcategory option", 6);
		click(taskcategory, "taskcategory option");
		click(taskcriticalityicon, "Taskcategoryicon");
		waitForVisibilityOfElement(taskcriticlity, "taskcriticlity option", 6);
		click(taskcriticlity, "option");
		waitForVisibilityOfElement(taskPositionField, position, 6);
		setText(taskPositionField, position, "Task Position");
		chooseTaskType(tasktype);
		click(assetmode, "AssetMode");
		click(assetmodeoption, "Asset Mode option");
	}

	// enter location details
	public void enterlocationdetails(String locationid, String coordinates, String locationdes) throws Throwable {

		waitForVisibilityOfElement(LocIDPlaceholder, "LocIDPlaceholder", 3);
		// location id
		setText(LocIDPlaceholder, locationid + System.currentTimeMillis(), "entered LOC ID");
		// location coordinates
		setText(LocPlaceholder, coordinates, "entered location coordinates");
		// location descripition
		setText(LocDescPlaceholder, locationdes + System.currentTimeMillis(), "entered LOC Description");

	}

	// enter tagdetails
	public void entertagdetails(String saptag, String dcstag, String historiantag, String filedtag) throws Throwable {

		waitForVisibilityOfElement(SAPTagPlaceholder, "SAPTagPlaceholder", 5);
		// sap tag
		setText(SAPTagPlaceholder, saptag + System.currentTimeMillis(), "entered SAPTag");
		// dcs tag
		setText(DCSTagPlaceholder, dcstag + System.currentTimeMillis(), "entered DCSTag");
		// historain tag
		setText(HistorianTagPlaceholder, historiantag + System.currentTimeMillis(), "entered HistorianTag");
		setText(FieldTagPlaceholder, filedtag + System.currentTimeMillis(), "entered FieldTag");
	}

	// enter additional information
	public void enteradditinalinformation() throws Throwable {
		clickonAddnewrow();
		enterheaderdescriptioin();
		enterheaderinformation();

	}

	// click on Addnewrow
	public void clickonAddnewrow() throws Throwable {
		waitForVisibilityOfElement(addnewrow, "Click on AddNew Row", 10);
		scrollToWebElement(addnewrow);
		click(addnewrow, "AddNew Row button");
	}

	// enter header information
	public void enterheaderinformation() throws Throwable {
		waitForVisibilityOfElement(additionalheader, "additionalheader", 5);
		setText(additionalheader, "additionalheader", "additionalheader");
	}

	// enter header description
	public void enterheaderdescriptioin() throws Throwable {
		waitForVisibilityOfElement(additionaldescription, "additionaldescription", 5);
		setText(additionaldescription, "additionaldescription", "additionaldescription");
	}

	// click on AddLink
	public void clickonAddLink() throws Throwable {
		waitForVisibilityOfElement(addlink, "Click on AddNew link", 10);
		click(addlink, "Click on AddLink");
	}

	// enter link description
	public void enterlinkdescriptioin() throws Throwable {
		waitForVisibilityOfElement(linkdescription, "linkdescription", 10);
		setText(linkdescription, "linkdescription", "linkdescription");
	}

	// enter link
	public void enterlink() throws Throwable {
		waitForVisibilityOfElement(link, "link", 3);
		setText(link, "https://or2.test.dev.movilizer.cloud", "linkdescription");
	}

	// enter limit details
	public void enterlimitdetails(String limitname, String type, String predefinedvalue, String causevalue,
			String conseq, String action) throws Throwable {

		verifyLimitsSection();
		enterLimitName(limitname);
		chooseTaskType(type);
		enterLimitValue(predefinedvalue);
		setText(backendField, "Backend112", "Backend id");
		setText(cause, causevalue, "Cause");
		setText(consequences, conseq, "Consequence");
		setText(actions, action, "Action");
		clickonAddLimitBtn();
		clickonNext();
		clickonsaveBtn();

	}

	public void enterlimit_details(String limitname, String type, String predefinedvalue, String causevalue,
			String conseq, String action, String backendId) throws Throwable {
		verifyLimitsSection();
		enterLimitName(limitname);
		chooseTaskType(type);
		enterLimitValue(predefinedvalue);
		setText(backendField, backendId, "Backend id");
		setText(cause, causevalue, "Cause");
		setText(consequences, conseq, "Consequence");
		setText(actions, action, "Action");
		clickonAddLimitBtn();
	}

	public void verifyTaskLimits(String limitType, String value) throws Throwable {
		By loc = By.xpath("//*[text()='" + limitType + "']/../../following-sibling::div//*[text()='" + value + "']");
		isElementDisplayed(loc, "Limit");
	}

	public void verifyTaskErrorMessage(String message) throws Throwable {
		By loc = By.xpath("//*[text()='" + message + "']");
		isElementDisplayed(loc, "Error Message");
	}

	public void clickOnDiscard() throws Throwable {
		waitForVisibilityOfElement(discard, "discard button", 15);
		click(discard, "discard button");
	}

	public void creattask_withLimit(String tasktype, String taskname, String numericvalue, String date, String value1,
			String limitname1, String limittype1, String value2, String limitname2, String limittype2)
			throws Throwable {

		scrollBottom();
		clickonTasks();
		verifyTaskDataTable();
		clickontaskicon();
		verifyTaskPage();
		enterTaskName(taskname);
		enterTaskPosition(numericvalue);
		chooseTaskType(tasktype);
		enterpredefinedvalue_Date(date);
		clickonNext();
		verifyLimitsSection();
		enterLimitName(limitname1);
		chooseTaskType(limittype1);
		clickondropdownicon();
		selectlimitvalue_as(value1);
		clickonAddLimitBtn();
		enterLimitName(limitname2);
		chooseTaskType(limittype2);
		clickondropdownicon();
		selectlimitvalue_as(value2);
		clickonAddLimitBtn();
		clickonNext();
		verifySupportiveContentSection();
		clickonsaveBtn();
	}

	public void verifyTaskDetailsPage(String taskname) throws Throwable {
		waitForVisibilityOfElement(taskDetailsPage, "Verified Task Section Header", 10);
		isElementDisplayed(taskDetailsPage, taskname);

	}

	public void verifyConditionaTaskLimitsDetailsPage(String taskname) throws Throwable {
		waitForVisibilityOfElement(activeLimitsSection, "Verified active Limits Section Header", 10);
		waitForVisibilityOfElement(conditionaltaskDetailsPage_Label, "Verified active Limits Section Header", 10);
		isElementDisplayed(conditionaltaskDetailsPage_name, taskname);
	}

	public void enterConditionalimitdetails(String limitname, String type, String predefinedvalue, String causevalue,
			String conseq, String action, String taskname) throws Throwable {
		verifyLimitsSection();
		enterLimitName(limitname);
		chooseTaskType(type);
		enterLimitValue(predefinedvalue);
		setText(backendField, "Backend112", "Backend id");
		setText(cause, causevalue, "Cause");
		setText(consequences, conseq, "Consequence");
		setText(actions, action, "Action");
		// choose conditional check box
		By checkboxestoselect = By.xpath("//input[@type='checkbox']/../label");
		driver.findElement(checkboxestoselect).click();
		// Select Conditional task
		chooseConditionalTask(taskname);
		clickonAddLimitBtn();
		clickonNext();
		clickonsaveBtn();

	}

	// This method is select the specific conditionaltasktype from list
	public void chooseConditionalTask(String taskname) throws Throwable {
		boolean flag = false;
		try {
			scrollToWebElement(conditionaltaskdropDown);
			click(conditionaltaskdropDown, "Dropdownlist");
			List<WebElement> menulist = getWebElementList(conditionaltasklist, taskname);
			for (WebElement e : menulist) {
				LOG.info(e.getText());
				if (e.getText().equalsIgnoreCase(taskname)) {
					flag = true;
					e.click();
					LOG.info(taskname + " :" + " tapped successfully");
					break;
				}
			}
			if (!flag) {
				LOG.info("No Element found");
			}
		} catch (Exception e) {
			LOG.info("Not clicked on menu option");
		}
	}

	public void clickonBackArrowPointer() throws Throwable {
		waitForPageLoaded();
		clickJS(backArrowPointerBtn, "Click on Back Arrow Pointer Button");
	}

	// click on Edit button in Limit section
	public void clickonLimitEdit() throws Throwable {
		waitForPageLoaded();
		clickJS(editLimitBtn, "Click on Edit Button");
	}

	// This method is select the uncheck conditionaltasktype from list
	public void uncheckConditionalTask(String taskname) throws Throwable {

		getText(conditionaltaskDetailsPage_name, taskname);
		By checkboxestoselect = By.xpath("//input[@type='checkbox']/../label");
		boolean condition = driver.findElement(checkboxestoselect).isSelected();
		if (condition == true) {
			driver.findElement(checkboxestoselect).click();
		}

		By saveChange_Limit = By.xpath("//class[@button-content='checkbox' and text() = 'SAVE CHANGE']");
		driver.findElement(saveChange_Limit).click();

	}
	
}
