package pages.Movilizer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import seleniumUtilities.GenericMethods;

public class ConfigurationPage extends GenericMethods {

	private By AbstractAssetsLink = By.xpath("//span[text()='Abstract Assets']");
	private By AddAbstractbtn = By.xpath("//div[text()='Add Abstract Asset']");
	private By ExportList = By.xpath("//a[text()='Export List']");
	private By ImportList = By.xpath("//span[text()='Import List']");
	private By GetTemplate = By.xpath("//a[text()='Get Template']");
	private By AbstractAssetPageHeader = By.xpath("//div[@class='meta language-set-header']");
	private By searchAbstractAsset = By.xpath("//input[@placeholder='Search Abstract Asset' and @class='input-box']");
	private By searchAbstractAssetName = By.xpath("//thead[@class='p-datatable-thead']/following::div[1]");
	private By AddNewAbstractbtn = By.xpath("//div[text()='Add New Asset']");

	private By configuration=By.xpath("//a[@href='#/Configuration']/i");
	private By rounds=By.xpath("//div[text()='Rounds']");
	private By scheduledays=By.xpath("//*[text()='Scheduling Days']");
	private By noofdayoptions=By.xpath("//div[@role='listbox' and @class='visible menu transition']/div[@role='option']");
	private By dropdown=By.xpath("//span[text()='No. of days']/../..//div[@role='combobox']");
	private By successmessage=By.xpath("//span[text()='Configuration Updated Successfully']");
	private By enterpriseLevel=By.xpath("//*[text()='Please select a level to view records']");
	private By navigatetoEnterpirse=By.xpath("//div[@class='enterprise-title false']/..//i");
	private By taskConfiguarationToggle=By.cssSelector("[data-test='task-config-toggle']+span");
	private By expandTaskConfig=By.xpath("//*[@data-test='task-config-toggle']/../following-sibling::span/span");
	private By addCriticality=By.xpath("//*[text()='Add Criticality']");
	private By criticalityTextBox=By.xpath("//*[text()='Criticality Name']/..//input");
	private By saveTaskCriticality=By.xpath("//*[text()='Criticality Name']/..//button//*[text()='SAVE']");
	private By editAssociatedEmails=By.cssSelector("[data-testid='edit-email-tags'] i");
	private By associatedEmailsTextBox=By.cssSelector("[class='email-setup-form'] span+input");
	private By saveSettingsOfEmailSetup=By.xpath("//*[@class='email-setup-form']/preceding-sibling::div//div[@class='add-save-button']");


	public void verifyHeaderMessage(String message) throws Throwable{
		String expectedString=getText(AbstractAssetPageHeader, "Header Message");
		validateTextUsingContains(expectedString,message);
	}

	public void Export_isDispalyed() throws Throwable {
		waitForPageLoaded();
		waitforPresenceofElement(ExportList,"ExportList",15);
		isElementDisplayed(ExportList,"Verify that Export List is Diplayed in the Abstract Asset Config Page.");
	}

	public void clickon_AbstractAssets() throws Throwable {
		//scrollToWebElement(AbstractAssetsLink);
		waitForVisibilityOfElement(AbstractAssetsLink,"AbstractAssetsLink",15);
		clickJS(AbstractAssetsLink, "Click on the Abstract Assets");
	}

	public void clickon_AddAbstractAssetsbtn() throws Throwable {
		waitForVisibilityOfElement(AddAbstractbtn,"AddAbstractbtn",10);
		click(AddAbstractbtn, "Click on Add Abstract Assets button");
	}

	public void searchAbstractAssets(String AbstractAsset) throws Throwable {
		waitForVisibilityOfElement(searchAbstractAsset,"searchAbstractAsset",10);
		clearText(searchAbstractAsset);
		setText(searchAbstractAsset,AbstractAsset, "enter the Abstract asset to search");
		clickEnter(searchAbstractAsset);
	}

	public void VerifyAbstractAssetName(String ExpectedAbstractAssetName) throws Throwable {
		waitForVisibilityOfElement(searchAbstractAssetName,"searchAbstractAssetName",10);
		String ActualAbstractAssetName=getText(searchAbstractAssetName);
		System.out.println("ActualAbstractAssetName: "+ActualAbstractAssetName);
		verifyTextMatching(searchAbstractAssetName, ActualAbstractAssetName, "ActualAbstractAssetName");

	}

	public void VerifyAbstractAssetNameNotfound(String ExpectedAbstractAssetName) throws Throwable {
		waitForVisibilityOfElement(searchAbstractAssetName,"searchAbstractAssetName",10);
		String ActualAbstractAssetName=getText(searchAbstractAssetName);
		System.out.println("ActualAbstractAssetName: "+ActualAbstractAssetName);
		validateCheckPointNotMatch(searchAbstractAssetName,ExpectedAbstractAssetName,ActualAbstractAssetName);

	}

	public void clickon_Add_AbstractAssetsbutton() throws Throwable {
		waitForVisibilityOfElement(AddNewAbstractbtn,"AddAbstractbtn",10);
		click(AddNewAbstractbtn, "Click on Add Abstract Assets button");
	}

	public void Clickonconfiguration() throws Throwable
	{
		waitForVisibilityOfElement(configuration,"Clickonconfiguration",10);
		click(configuration, "clickonconfiguration button");	
	}

	public void ScheduleRounds() throws Throwable
	{
		scrollToWebElement(scheduledays);

	}


	public void clickonnofofdays_dropdown() throws Throwable
	{

		//	waitForVisibilityOfElement(dropdown,"Click on dropdown",5);
		//	scrollToWebElement(dropdown);
		clickJS(dropdown,"Dropdown");

	}

	public void clickonrounds() throws Throwable {

		waitForPageLoaded();
		scrollToWebElement(rounds);
		waitForVisibilityOfElement(rounds,"Clickonrounds",10);
		clickJS(rounds,"Clickonrounds");
	}

	@SuppressWarnings("unlikely-arg-type")
	public void noofdays() throws Throwable
	{
		ArrayList<Integer> expectedoptions = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6,7));

		List<WebElement> options = getWebElementList(noofdayoptions,"Noofdayoptions");
		for(int i=0;i<expectedoptions.size();i++) {
			expectedoptions.get(i).equals(options.get(i).getText());	
		}
	}


	public void selectoption() throws Throwable
	{
		Random rand = new Random();
		int x = rand.nextInt(8);
		By selectoption=By.xpath("//div[text()='"+x+"']");
		waitForVisibilityOfElement(selectoption,"selectoption",5);
		clickJS(selectoption,"selectoption");
		sendKeysActionsEsc(selectoption);
	}

	public void successmessage() throws Throwable
	{

		waitForVisibilityOfElement(successmessage,"successmessage",15);
		isElementDisplayed(successmessage,"successmessage");
	}
	//select level hirarchy
	public void selectlevelhirachy(String levelhirarchyname) throws Throwable
	{

		driver.switchTo().defaultContent();
		By mainFrame=By.cssSelector("[class='gwt-Frame']");
		switchToFrame(mainFrame);
		waitforPresenceofElement(enterpriseLevel, "Enterprise level message", 10);
		waitForPageLoaded();
		By selectlevlhirarchy = By.xpath("//div[text()='" + levelhirarchyname + "']");
		List<WebElement> list= driver.findElements(By.cssSelector("[class='loader-content'] [class='content']"));
		// waitForVisibilityOfElement(selectlevlhirarchy,"selectlevlhirarchy",10);
		for(int i=0;i<list.size();i++){
			if(isElementPresent(selectlevlhirarchy,"Level")){
				setFocusAndClick(selectlevlhirarchy,"Select levelhirarchyfrom round template");
				break;
			}else{
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",list.get(i));
			}
		}
		//Thread.sleep(5000);
	}

	public void Scheduledays_isVisible() throws Throwable
	{

		int size = driver.findElements(scheduledays).size();
		if(size>0)
		{
			logfailinfo("Scheduledays option is displayed,supposed to be not to display at enterprise level");
		}	
	}

	public void navigateto_EnterpriseLevel() throws Throwable
	{

		waitForVisibilityOfElement(navigatetoEnterpirse,"navigatetoEnterpirse",6);
		click(navigatetoEnterpirse,"(navigatetoEnterpirse");

	}

	public void ScheduledaysisVisible() throws Throwable
	{

		int size = driver.findElements(scheduledays).size();
		System.out.println(size);
		if(!(size>=0))
		{
			logfailinfo("Scheduledays option not  displayed");
		}	
	}

	public void clickTaskConfiguarationStatus()throws Throwable{
		waitForVisibilityOfElement(taskConfiguarationToggle, "taskConfiguarationToggle", 15);
		String s=getText(taskConfiguarationToggle);
		if(s.equalsIgnoreCase("Disabled")){
			click(taskConfiguarationToggle, "taskConfiguarationToggle");
		}
	}
	public void clickOnTaskConfiguarationExpand()throws Throwable{
		waitForVisibilityOfElement(expandTaskConfig, "expandTaskConfig", 15);
		click(expandTaskConfig, "expandTaskConfig");		
	}
	public void clickOnAddTaskCriticality()throws Throwable{
		waitForVisibilityOfElement(addCriticality, "addCriticality", 15);
		click(addCriticality, "addCriticality");		
	}
	public void enterTaskCriticality(String criticality)throws Throwable{
		waitForVisibilityOfElement(criticalityTextBox, "criticalityTextBox", 15);
		clearText(criticalityTextBox);
		setText(criticalityTextBox, criticality,"criticalityTextBox");		
	}
	public void clickOnSaveTaskCriticality()throws Throwable{
		waitForVisibilityOfElement(saveTaskCriticality, "saveTaskCriticality", 15);
		click(saveTaskCriticality, "saveTaskCriticality");		
	}
	public void verifyTaskCriticalityCreated(String criticality)throws Throwable{
		By loc=By.cssSelector("[value='"+criticality+"']");
		waitForVisibilityOfElement(loc, criticality, 15);
		isElementDisplayed(loc, criticality);
	}
	public void editTaskCriticality(String criticality)throws Throwable{
		By loc=By.cssSelector("[value='"+criticality+"']+button");
		waitForVisibilityOfElement(loc, criticality, 15);
		click(loc, criticality);
	}
	public void deleteTaskCriticality(String criticality)throws Throwable{
		By loc=By.cssSelector("[value='"+criticality+"']+button+button");
		waitForVisibilityOfElement(loc, criticality, 15);
		click(loc, criticality);
	}
	public void verifyTaskCriticalityDeleted(String criticality)throws Throwable{
		By loc=By.cssSelector("[value='"+criticality+"']");
		int i=driver.findElements(loc).size();
		if(i==0){
			LOG.info("Task criticality deleted successfully");
		}
	}
	public void editAssociatedEmailsTaskCriticality()throws Throwable{		
		waitForVisibilityOfElement(editAssociatedEmails, "editAssociatedEmails", 15);
		click(editAssociatedEmails, "editAssociatedEmails");
	}
	public void enterAssociatedEmailsTaskCriticality(String email)throws Throwable{		
		waitForVisibilityOfElement(associatedEmailsTextBox, "associatedEmailsTextBox", 15);
		setText(associatedEmailsTextBox,email, "associatedEmailsTextBox");
	}
	public void saveAssociatedEmailsTaskCriticality()throws Throwable{		
		waitForVisibilityOfElement(saveSettingsOfEmailSetup, "saveSettingsOfEmailSetup", 15);
		click(saveSettingsOfEmailSetup, "saveSettingsOfEmailSetup");
	}
	public void verifyTaskCriticalityAssociatedEmail(String mail)throws Throwable{
		By loc=By.xpath("//*[text()='"+mail+"']");
		int i=driver.findElements(loc).size();
		if(i==0){
			LOG.info("Task criticality asscoiated emails saved successfully");
		}
	}
	public void verifyUserAtEnterpriseLevel()throws Throwable{
		By loc =By.cssSelector("[class='section breadcrumb-item-first']+div+[class='section breadcrumb-item-last']");
		int i=driver.findElements(loc).size();
		if(i==0){
			LOG.info("User at enterprise level");
		}
	}
	public void deleteTasksAssociatedMail(String mail)throws Throwable{
		By loc=By.xpath("//*[text()='"+mail+"']/a");
		click(loc, "mail");
	}

}

