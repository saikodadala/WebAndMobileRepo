package pages.Movilizer;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import seleniumUtilities.GenericMethods;

public class ManageUsers extends GenericMethods {

	private By addUserBtn = By.xpath("//button[@class='ui medium button primary']/div[text()='Add User']");
	private By confirmAndSubmit = By
			.xpath("//button[@class='ui medium button primary']/div[text()='Confirm and submit']");
	private By successMessage = By.cssSelector("[class='title']");
	private By closePopup = By.xpath("//div[@class='close-wrapper']/i");
	public static String userRecord = "";
	private By globalSearchBox = By.xpath("//*[@placeholder='Global Search' or @placeholder='Search assets' or @placeholder='Search Abstract Asset']");
	private By listbox = By.xpath("//div[@role='listbox']");
	private By tablerows = By.xpath("//tbody[@class='p-datatable-tbody']/tr");
	private By pagination = By.xpath("//div[contains(@class,'page-btn item-btn ')]");
	private By itemsnumber = By.xpath("(//span[@class='bold'])[1]");
	private By loadingIcon=By.cssSelector("[class='ui loader-wrap loading-alignments loading']");
	private By disableArrow=By.cssSelector("[class='page-btn nav-btn disable']");
	
	private By addIndividuallyRadioButton=By.xpath("//*[text()='Add Individually']/../input");
	private By importListRadioButton=By.xpath("//*[text()='Import List']/../input");
	private By enterpriseLevel=By.xpath("//*[text()='Please select a level to view records']");
	
	public void clickOnAddUserButton() throws Throwable {
		waitForPageLoaded();
		List<WebElement> elements = getWebElementList(addUserBtn, "Add User button");
		if (elements.size() == 1) {
			waitForVisibilityOfElement(addUserBtn, "Add User button", 15);
			click(addUserBtn, "Add User button");
		} else {
			elements.get(1).click();
		}

	}

	public void enterUserDetails(String fieldName, String value) throws Throwable {
		By locator = By.xpath("//input[@placeholder='" + fieldName + "']");
		clearText(locator);
		waitForVisibilityOfElement(locator, fieldName, 15);
		setText(locator, value, fieldName);
	}
	
	public void addUserPopValiations() throws Throwable {
		waitforPresenceofElement(addIndividuallyRadioButton, "addIndividuallyRadioButton", 20);
		isElementDisplayed(addIndividuallyRadioButton, "addIndividuallyRadioButton");
		isElementDisplayed(importListRadioButton, "importListRadioButton");
		
	}

	public String getUserDetails(String fieldName) throws Throwable {
		By locator = By.xpath("//input[@placeholder='" + fieldName + "']");
		userRecord = getText(locator);
		return userRecord;
	}

	public void clickOnThreeDots(String id) throws Throwable {
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		By locator=By.cssSelector("[class='popup-pointer']");
		waitForVisibilityOfElement(locator, "Three Dots",15);
		List<WebElement> elems=driver.findElements(locator);
		elems.get(0).click();	
	}

	public void clickOnRecordAction(String action) throws Throwable {
		By locator = By.xpath("//*[text()='" + action + "']");
		waitForVisibilityOfElement(locator, action, 15);
		click(locator, action);
	}

	public void clickOnConfirmAndSubmit() throws Throwable {
		waitForVisibilityOfElement(confirmAndSubmit, "Confirm and submit", 15);
		click(confirmAndSubmit, "Confirm and submit button");
	}

	public void clickOnDeleteUserAction(String action) throws Throwable {
		By locator = By.xpath("//*[text()='" + action + "']");
		waitForVisibilityOfElement(locator, action, 15);
		click(locator, action);
	}

	public void validateErrorMessage(String fieldName, String text) throws Throwable {
		By loc = By.xpath("//*[text()='" + fieldName + "']/../following-sibling::div/*[@class='ui error-message']");
		verifyTextMatching(loc, text, fieldName);

	}

	// select levelhirarchy from user
	public void selectlevelhirarchy_User(String levelhirarchyname) throws Throwable {
		driver.switchTo().defaultContent();
		By mainFrame = By.cssSelector("[class='gwt-Frame']");
		switchToFrame(mainFrame);
		waitforPresenceofElement(enterpriseLevel, "Enterprise level message", 10);
		waitForPageLoaded();
		By selectlevlhirarchy = By.xpath("//div[text()='" + levelhirarchyname + "']");
		List<WebElement> list = driver.findElements(By.cssSelector("[class='loader-content'] [class='content']"));
		 
		for (int i = 0; i < list.size(); i++) {
			if (isElementPresent(selectlevlhirarchy, "Level")) {
				setFocusAndClick(selectlevlhirarchy, "Select levelhirarchyfrom round template");
				break;
			} else {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", list.get(i));
			}
		}

	}

	public void verifySuccessMessage(String text) throws Throwable {
		waitForPageLoaded();
		waitForVisibilityOfElement(successMessage, "successMessage", 20);
		String expecteText = getText(successMessage);
		if (expecteText.equalsIgnoreCase(text)) {
			waitForPageLoaded();
			// reporter.SuccessReportWithScreenshot("Verify user added", "User
			// successfully added", driver);
		} else if (isElementPresent(closePopup, "closePopup")) {
			waitForPageLoaded();
			waitForVisibilityOfElement(closePopup, "closePopup", 15);
			click(closePopup, "Close Popup");
		}
	}

	public void verifyEmployeeId(String empId) throws Throwable {
		By loc = By.cssSelector("[class='p-datatable-row'] div");
		List<WebElement> elems = driver.findElements(loc);
		String expEmpId = elems.get(0).getText();
		if (empId.equalsIgnoreCase(expEmpId)) {
			// reporter.SuccessReportWithScreenshot("Verify created record in
			// user table", "Successfully created user"+expEmpId, driver);
		} else {
			// reporter.failureReport("Verify created record in user table",
			// "Failed to create user", driver);
		}
		// reporter.SuccessReportWithScreenshot("Final verification screenshot",
		// "", driver);
	}

	public void verifyUser(String user) throws Throwable {
		By loc = By.cssSelector("[class='p-datatable-row'] div");
		List<WebElement> elems = driver.findElements(loc);
		String expUser = elems.get(1).getText();
		if (user.equalsIgnoreCase(expUser)) {
			// reporter.SuccessReportWithScreenshot("Verify updated record in
			// user table", "Successfully updated user"+expUser, driver);
		} else {
			// reporter.failureReport("Verify updated record in user table",
			// "Failed to update user", driver);
		}
		// reporter.SuccessReportWithScreenshot("Final verification screenshot",
		// "", driver);

	}

	public void verifyUserTable(String user) throws Throwable {
		By loc = By.cssSelector("[class='p-datatable-row'] div");
		List<WebElement> elems = driver.findElements(loc);

		if (elems.size() > 0) {
			// reporter.SuccessReportWithScreenshot("Verify updated record in
			// user table", "Successfully deleted user" ,driver);
		} else {
			// reporter.failureReport("Verify updated record in user table",
			// "Failed to delete user", driver);
		}
		// reporter.SuccessReportWithScreenshot("Final verification screenshot",
		// "", driver);
	}

	public void enterEmployeeIdInSearchBox(String text) throws Throwable {
		waitForPageLoaded();
		waitForVisibilityOfElement(globalSearchBox, "Global SearchBox", 20);
		clearText(globalSearchBox);
		setText(globalSearchBox, text, "Global SearchBox");
	}

	public void verifyManageUserGlobalSearch(String expectedValue) throws Throwable {

		By rowLoc = By.xpath("//*[@class='p-datatable-row']");
		List<WebElement> elems = driver.findElements(rowLoc);
		if (expectedValue.equalsIgnoreCase("No records found")) {
			logpassinfo("No records found in the table");
		} else {
			int count = 0;
			for (int i = 0; i < elems.size(); i++) {
				i++;
				By loc = By.xpath("//*[@class='p-datatable-row'][" + i + "]//td//div");
				List<WebElement> eles = driver.findElements(loc);
				for (int j = 0; j < eles.size(); j++) {
					String expUser = elems.get(j).getText();
					if (expUser.contains(expectedValue)) {
						Assert.assertTrue(expUser.contains(expectedValue));
						count++;
						break;
					}
				}

			}
			if (count == 0) {
				logfailinfo("No matching records are available");
				Assert.fail("No matching records are available");
			} else {
				logpassinfo("Matching records are available with searching value");
			}
		}

	}

	public void verifyLandingPageAttributes(String text) throws Throwable {
		By loc = By.xpath("//*[text()='" + text + "']");
		isElementDisplayed(loc, text);
	}

	public void validateEmptyFieldErrorMessage(String fieldName) throws Throwable {
		By loc = By.xpath("//*[text()='" + fieldName + "']");
		verifyTextMatching(loc, fieldName, fieldName);

	}

	// PAGINATION for round template
	public void Verify_Pagination_Roundtemplate() throws Throwable {

		waitForVisibilityOfElement(listbox, "Listbox", 20);
		click(listbox, "Click on listbox");
		selectItems_perpage("20 per page");
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElements(getWebElementList(tablerows, "Elements")));
		// Validating 1-20
		// validateCheckPointMatch(itemsnumber,"1 - 20 ","20 items per page");
		Assert.assertEquals(String.valueOf(getElementsSize(tablerows)), "20");

		clickonListbox();
		selectItems_perpage("10 items");
		// Validating 1-20
		wait.until(ExpectedConditions.visibilityOfAllElements(getWebElementList(tablerows, "Elements")));
		validateCheckPointMatch(itemsnumber, "1 - 10", "10 items per page");
		Assert.assertEquals(String.valueOf(getElementsSize(tablerows)), "10");

		waitForPageLoaded();
		List<WebElement> paginationvalues = getWebElementList(pagination, "pagination list");
		for (int i = 0; i < paginationvalues.size(); i++) {
			WebElement element = paginationvalues.get(i);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			waitForPageLoaded();
		}
	}

}
