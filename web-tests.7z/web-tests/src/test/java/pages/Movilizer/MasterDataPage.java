package pages.Movilizer;

import org.openqa.selenium.By;

import seleniumUtilities.GenericMethods;

public class MasterDataPage extends GenericMethods {
	
	/**
	 * Locators and reusable methods for Home Page
	 * 
	 * @author Vinod Bollibisai
	 *
	 */

	private By masterData=By.id("gwt-debug-itemMasterdata");   
    private By systemID=By.id("gwt-debug-MASTERDATA_SystemID");    
    private By masterDataPoolTextbox=By.id("gwt-debug-MASTERDATA_DataPool");
    private By masterDataKey=By.xpath("//input[@id='gwt-debug-MASTERDATA_EntryKeyItem']");
    private By masterDataKeyButton=By.id("gwt-debug-MASTERDATA_EntryKeyItem_Button");
    private By masterDataPool_RT=By.xpath("//td[@role='menuitem' and text()='RoundTemplates']");

    public void clickOnMasterData(String masterkeyValue)throws Throwable{
        waitForVisibilityOfElement(masterData, "masterData Menu",15);
        click(masterData,"masterData Menu");
        selectDropdownByValue(systemID, "20002", "QA WebService");
        clearText(masterDataPoolTextbox);
        click(masterDataPool_RT,"masterData Menu");
        setText(masterDataKey,masterkeyValue, "entered Backend ID");
        clickEnter(masterDataKeyButton);
    }
}
