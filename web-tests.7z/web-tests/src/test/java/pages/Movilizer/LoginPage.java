package pages.Movilizer;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;


import common.reports.ConfigFileReadWrite;
import common.reports.ReporterConstants;

import io.restassured.response.Response;
import seleniumUtilities.GenericMethods;


import static io.restassured.RestAssured.given;

public class LoginPage extends GenericMethods {

	private By userName = By.id("username");
	private By password = By.id("password");
	private By or_signin = By.id("submitButton");
	private By or2_signin = By.id("kc-login");
	String appEnvironment=ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "appEnvironment");



	@SuppressWarnings("null")
	public void enterUserName(String strUserName)throws Throwable{
		waitForVisibilityOfElement(userName, "username",10);
		setText(userName,strUserName,"UserName");
	}

	public void executeCreateAssetApi(String token){
		Response request=given().contentType("application/json").header("Authentication",token)
				.body("​​​​​​​​{\"parentPool\": \"Assets\",\"parentId\": \"473cb9fa10544a88ef323ea0d3ae8a2\",\"name\": \"name\",\"type\": \"type\",\"description\": \"PERMIT\",\"priority\": \"priority\",\"text\": \"text\",\"start\": 2,\"end\": 6}")
				.when().post("https://test.psr.plus.movilizer.cloud/ui/portal-sdk/services/work_notification/addmany").then().using().extract().response();

		/**
		 * {​​​​​​​\"name\":\"NEW ASST12 safdsa\", \"type\":\"PUMP\", \"location\":null, \"fieldTag\":\"\", \"historianTag\":\"\", \"historianTagEnabled\":false, \"uploadSource\":-1, \"taskIds\":null, \"tasks\":null, \"modes\":[\"STRAT\",\"RUN\",\"STIP\"], \"saptag\":\"\", \"dcstag\":\"\", \"parentPool\":\"Levels\", \"parentId\":\"0805acc921f42b082f3340103c320ad\", \"extendsId\":\"HFIR_ROOT_ENTITY_ID\", \"id\":null, \"group\":null, \"creatorType\":null, \"creatorId\":null, \"created\":null, \"modifierType\":null, \"modifierId\":null, \"modified\":null, \"backendId\":\"\", \"attachedProperties\":{​​​​​​​\"class\":\"\"}​​​​​​​, \"abstract\":false}​​​​​​
		 */
		String body=request.getBody().asString();
		int status=request.getStatusCode();
	}

	public void executeCreateUserApi(String token){
		Response request=given().header("x-auth-token",token)
				.body("{\"employeeId\":\"empId8724398200003168721436821648264826487284218482468264826482468264826482363\", \"name\":\"emp0227342943168721436821648264826487284218482468264826482468264826482363\", \"password\":\"emp992943168721436821648264826487284218482468264826482468264826482363\", \"roleId\":null, \"email\":\"emp9@gmail.com\", \"id\":\"empId294316872143682164826000264872842184824682648264824682648264823632943168721436821648264826487284218482468264826482468264826482363\", \"parentPool\":\"Levels\", \"parentId\":\"b6e894bf87a4768926b548b072cf65a\", \"extendsId\":\"HFIR_ROOT_ENTITY_ID\", \"group\":null, \"creatorType\":null, \"creatorId\":null, \"created\":null, \"modifierType\":null, \"modifierId\":null, \"modified\":null, \"backendId\":null, \"attachedProperties\":{}, \"abstract\":false}")
				.contentType("application/json")
				.when().post("https://or2.test.dev.movilizer.cloud/ui/portal-sdk/services/user/addTo/Levels/b6e894bf87a4768926b548b072cf65a");

		String body=request.getBody().asString();
		int status=request.getStatusCode();
		if(status==200){
			System.out.println("User added successfully");
		}
	}

	public void executeCreateDeviceApi(String token){
		Response request=given().header("x-auth-token",token)
				.body("{\"employeeId\":\"empId8724398200003168721436821648264826487284218482468264826482468264826482363\", \"name\":\"emp0227342943168721436821648264826487284218482468264826482468264826482363\", \"password\":\"emp992943168721436821648264826487284218482468264826482468264826482363\", \"roleId\":null, \"email\":\"emp9@gmail.com\", \"id\":\"empId294316872143682164826000264872842184824682648264824682648264823632943168721436821648264826487284218482468264826482468264826482363\", \"parentPool\":\"Levels\", \"parentId\":\"b6e894bf87a4768926b548b072cf65a\", \"extendsId\":\"HFIR_ROOT_ENTITY_ID\", \"group\":null, \"creatorType\":null, \"creatorId\":null, \"created\":null, \"modifierType\":null, \"modifierId\":null, \"modified\":null, \"backendId\":null, \"attachedProperties\":{}, \"abstract\":false}")
				.contentType("application/json")
				.when().post("https://or2.test.dev.movilizer.cloud/ui/portal-sdk/services/user/addTo/Levels/b6e894bf87a4768926b548b072cf65a");

		String body=request.getBody().asString();
		int status=request.getStatusCode();
		if(status==200){
			System.out.println("User added successfully");
		}
	}

	public String getCookie(){    	 
		Cookie authToken=driver.manage().getCookieNamed("auth");
		String token=authToken.getValue();
		return token;    	
	}

	public void enterpassWord(String strPassword)throws Throwable{
		waitForVisibilityOfElement(password, "password",15);
		setText(password,strPassword,"password");
	}

	public void clickSignIn()throws Throwable{

		if(appEnvironment.equalsIgnoreCase("or2")){
			waitForVisibilityOfElement(or2_signin, "signin",15);
			click(or2_signin,"signIn"); 
		}else if(appEnvironment.equalsIgnoreCase("or")){
			waitForVisibilityOfElement(or_signin, "signin",15);
			click(or_signin,"signIn"); 
		}
	}

	public void getApiActions() throws InterruptedException{    	
		String token=this.getCookie();
		//        this.executeCreateAssetApi(token);
		this.executeCreateUserApi(token);
		//    	this.executeCreateUserApi(token);
	}



}
