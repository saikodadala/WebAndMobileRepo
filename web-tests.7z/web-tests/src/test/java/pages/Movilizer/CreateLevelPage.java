package pages.Movilizer;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import seleniumUtilities.GenericMethods;

public class CreateLevelPage extends GenericMethods {

    private By verifyLevelAddedMsg = By.xpath("//span[contains(text(),'Level Added Succesfully')]");
    private By timeZone = By.xpath("//div[@role='combobox']/input");
    private By inputTimeZone = By.xpath("//div[@class=\"ui fluid search selection upward dropdown\"]/input");
    private By selectTimeZone = By.xpath("//div[text()='Asia/Kolkata']");
    private By verifyLevelAddFailureMsg = By.xpath("//span[contains(text(),'Failed to Add Level')]");
    private By assetHierarchyTasks = By.xpath("//a[@class='active link item']");
    private By enterpriseHeading = By.xpath("//span[text()='Enterprise']");
    private By getPageHeading = By.xpath("//span[@class='treeview-header']");
    private By getEnterpriseGeneralHeader = By.cssSelector("[data-testid='display-text']");
    private By mainFrame = By.cssSelector("[class='gwt-Frame']");
    private By levelName = By.cssSelector("[class='level-title active-border'] span:nth-child(2)");
    private By levelThreeDots = By.cssSelector("[class='level-title active-border'] span span i");
    private By editLevel = By.xpath("//*[text()='Edit Level']");    
    private By getLevelGeneralHeader = By.xpath("//span[@class='title']");
    private By levelNamPath = By.cssSelector("[placeholder='Type here']");
    private By submitButton = By.xpath("//div[text()='SUBMIT']");
    private By verifyLevelEditedMsg = By.xpath("//span[contains(text(),'Level Edited Successfully')]");
    private By deleteLevel = By.xpath("//*[text()='Delete Level']");
    private By confirmButton = By.xpath("//*[text()='Confirm']");
    private By verifyLevelDeletedMsg = By.xpath("//span[contains(text(),'deleted successfully')]");
    private By explorerView = By.cssSelector("[class='right-corner']");
    private By hoverOnHeadingLevel = By.xpath("(//span[@class='level-name cursor-hand'])[1]");    
    private By click3dotsCreatedLevel = By.xpath("(//i[@class='h-icon icon ellipsis horizontal'])[last()]");
    private By click3dotsEnterpriseLevel = By.xpath("//i[@class='h-icon icon ellipsis horizontal']");
    private By viewDetailsButton = By.xpath("//button[@data-test='confirm-btn']");
    private By hierarchyLevel= By.xpath("//span[@class='right-corner cursor-hand']");
    private By searchPath= By.xpath("(//i[@class='sc-bdVaJa hdaiaz h-icon common search-icon pointer'])[1]");
    private By inputLevelName= By.xpath("(//input[@data-test=\"search-input\"])[1]");
    private By searchResults= By.cssSelector("div[class='content'] span[class='level-name cursor-hand']");
    private By closePopUp= By.xpath("//i[@class='sc-bdVaJa idoaSV h-icon common']");
    private By assetHierarchy_Tasks = By.cssSelector(".active.link.item");

    private By close=By.cssSelector(".close-wrapper i");
    
    String actualLevelCreationMSG = "Level Added Succesfully";
    String actualLevelCreationFailureMSG = "Failed to Add Level";
    String pageHeading = "Levels Hierarchy";
    String enterpriseGeneralMessage = "Please select a level to view records";
    String actualLevelEditMSG = "Level Edited Successfully";
    String actualLevelDelMSG = "deleted successfully";


    public void verifyLevelCreationMSG() throws Throwable {

		//	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		waitforPresenceofElement(verifyLevelAddedMsg, "verifyLevelAddedMsg", 20);
		validateCheckPointMatch(verifyLevelAddedMsg, actualLevelCreationMSG, "verifyLevelAddedMsg");
		waitForPageLoaded();
		waitforPresenceofElement(close, "closepopup",10);
		List<WebElement> list=driver.findElements(close);
		if(list.size()>0){
			clickJS(close,"Close popup");
		}		
		waitForPageLoaded();
	}
    
    public void verifyCreatedLevelsCount(int count) throws Throwable{
    	List<WebElement> list=driver.findElements(By.cssSelector("[class='ui breadcrumb flexible-levels-breadcrumb'] a"));
    	int breadcrumbCount=list.size();
    	verifyTextEquals(String.valueOf(count), String.valueOf(breadcrumbCount));
    }
    
    public void verifyCreatedExplorerLevelsCount(int count) throws Throwable{
    	List<WebElement> list=driver.findElements(By.xpath("//*[@class='level-name cursor-hand'][text()=' LEVEL-']"));
    	int breadcrumbCount=list.size()-1;
    	verifyTextEquals(String.valueOf(count), String.valueOf(breadcrumbCount));
    }


    public void enterTimeZone(String timezoneVal) throws Throwable {
        //waitForVisibilityOfElement(inputTimeZone, "timeZone");
        //click(inputTimeZone, "timeZone");
        //setText(inputTimeZone, timezoneVal, "timeZoneSetText");
        click(selectTimeZone, "selectedTimeZone");
//        pressTab(timeZone);

    }
    
    public void verifyAssetHierarchyTasksEnabled() throws Throwable {
        isElementPresent(assetHierarchyTasks, "assetHierarchyTasks");
        isElementDisplayed(assetHierarchyTasks, "assetHierarchyTasks");
    }

    public void enterpriseHeading() throws Throwable {
        isElementPresent(enterpriseHeading, "enterpriseHeading");
        isElementDisplayed(enterpriseHeading, "enterpriseHeading");
    }

    public void getPageHeading_verify() throws Throwable {
        validateCheckPointContains(getPageHeading, pageHeading, "getPageHeading&Verify");

    }

    public void getEnterpriseGeneralMSG_Verify() throws Throwable {
        validateCheckPointContains(getEnterpriseGeneralHeader, enterpriseGeneralMessage, "enterpriseGeneralMessage&Verify");
    }

    public void swtichToFrame() throws Throwable {
        waitForPageLoaded();
        driver.switchTo().defaultContent();
        waitForPageLoaded();
        waitForVisibilityOfElement(mainFrame, "mainFrame",15);
        switchToFrame(mainFrame);

    }

    public void clickOnCreatedLevel(String LevelName) throws Throwable {
        driver.findElement(By.xpath("//div[@innertext='" + LevelName + "']")).click();
        waitForLoadAll();
    }


    public void hoverOnCreatedLevel() throws Throwable {
    	waitForPageLoaded();
        waitForVisibilityOfElement(levelName, "levelName",15);
        mouseHoverJS(levelName, "levelName");
    }

    
    public void clickOnEditLevel() throws Throwable {
        waitForVisibilityOfElement(editLevel, "EditLevel",15);
        click(editLevel, "EditLevel");
    }

    public void clearTextLevelName() throws Throwable {
    	click(levelNamPath, "levelName");
        clearText(levelNamPath);
    }

    public void getLevelGeneralMSG_Verify() throws Throwable {
       

        waitForVisibility_Elements(verifyLevelEditedMsg, "verifyLevelEditedMsg", 20);
        validateCheckPointContains(verifyLevelEditedMsg, actualLevelEditMSG, "verifyLevelEditedMsg");
//        waitForInVisibilityOfElement(verifyLevelEditedMsg, "verifyLevelEditedMsg", 20);
        waitforPresenceofElement(close, "closepopup",10);
		List<WebElement> list=driver.findElements(close);
		if(list.size()>0){
			clickJS(close,"Close popup");
		}	

        
    }

    public void enterLevelName(String name) throws Throwable {
        waitForVisibilityOfElement(levelNamPath, "editLevelName",15);
        setText(levelNamPath, name, "editLevelName");
        pressTab(levelNamPath);        
    }

    public void clickSubmitButton() throws Throwable {
    	click(levelNamPath,"Level Name");    	
    	WebDriverWait wait = new WebDriverWait(driver, 10);
    	waitForVisibilityOfElement(submitButton, "submitButton",15);
        wait.until(ExpectedConditions.elementToBeClickable(submitButton)).click();        
//        click(submitButton, "submitButton");        
    }

    public void clickOnDeleteLevel() throws Throwable {
        waitForVisibilityOfElement(deleteLevel, "DeleteLevel",15);
        click(deleteLevel, "DeleteLevel");
    }


    public void clickConfirmButton() throws Throwable {
        waitForVisibilityOfElement(confirmButton, "ConfirmButton",15);
        click(confirmButton, "ConfirmButton");
    }


    public void getDelLevelMSG_Verify() throws Throwable {

        waitForVisibility_Elements(verifyLevelDeletedMsg, "verifyLevelDeletedMsg", 20);
        validateCheckPointContains(verifyLevelDeletedMsg, actualLevelDelMSG, "verifyLevelDelMsg");
        waitForInVisibilityOfElement(verifyLevelDeletedMsg, "verifyLevelDeletedMsg", 20);

    }

    public void clickOnExplorerView() throws Throwable {

        waitForVisibilityOfElement(explorerView, "ClickExplorerView",15);
        click(explorerView, "ClickExplorerView");

    }

    public void hoverOnLevelHeading() throws Throwable {

        waitForVisibilityOfElement(hoverOnHeadingLevel, "Level-01",15);
        mouseHoverJS(hoverOnHeadingLevel, "Level-01");

    }

    public void hoverExplorerViewCreatedLevel(String levelName) throws Throwable {

        By explorerViewCreatedLevel = By.xpath("//span[@class='level-name cursor-hand'][text()='"+levelName+"']");
        waitForVisibilityOfElement(explorerViewCreatedLevel, "levelName",15);
        mouseHover(explorerViewCreatedLevel, "levelName");


    }

    public void click3DotsCreatedLevel() throws Throwable {
    	waitForVisibilityOfElement(click3dotsCreatedLevel, "levelThreeDotsOfCreatedLevel",15);
        waitforElementtobeClickable(click3dotsCreatedLevel,"levelThreeDotsOfCreatedLevel",15);
        click(click3dotsCreatedLevel, "levelThreeDotsOfCreatedLevel");
    }
    
    public void clickOnthreeDotsCreatedLevel() throws Throwable {
    	waitForPageLoaded();
    	waitForVisibilityOfElement(click3dotsCreatedLevel, "levelThreeDotsOfCreatedLevel",15);
        waitforElementtobeClickable(click3dotsCreatedLevel,"levelThreeDotsOfCreatedLevel",15);
        clickJS(click3dotsCreatedLevel, "levelThreeDotsOfCreatedLevel");
    }
    public void clickOnthreeDotsAtEnterPriseLevel() throws Throwable {
    	waitForPageLoaded();
    	By loc=By.cssSelector("[class='enterprise-title active-border']");
    	moveToElement(loc, "Enterprise level");
    	waitForVisibilityOfElement(click3dotsEnterpriseLevel, "3dotsEnterpriseLevel",15);
        waitforElementtobeClickable(click3dotsEnterpriseLevel,"3dotsEnterpriseLevel",15);
        clickJS(click3dotsEnterpriseLevel, "3dotsEnterpriseLevel");
    }
    

    public void clickViewDetailsButton() throws Throwable {        
        waitForVisibilityOfElement(viewDetailsButton, "viewDetailsButton",15);
        click(viewDetailsButton, "viewDetailsButton");
    }

    public void clickLevelHierarhyView() throws Throwable {
        waitForVisibilityOfElement(hierarchyLevel, "HierarchylevelThreeDots",15);
        click(hierarchyLevel, "HierarchyLevelThreeDots");
    }

    public void clickSearchBox() throws Throwable {

        waitForVisibilityOfElement(searchPath, "clickSearchBox",15);
        click(searchPath, "clickSearchBox");
    }

    public void enterLevelnameSearchBox(String levelname) throws Throwable {    	
        waitForVisibilityOfElement(inputLevelName, "enterLevelnameSearchBox",10);
        clearText(inputLevelName);
        setText(inputLevelName, levelname, "enterLevelnameSearchBox");
    }

    public void verifysearchResults(String levelNameExpected) throws Throwable {
        String getLevelNameActual =  getText(searchResults, "getTextSearchResultsLevelName");
        System.out.println(getLevelNameActual);
        verifyTextEquals(getLevelNameActual,levelNameExpected);
    }

    public void levelNameRandGenerator(String levelname)throws Throwable{
        String levelgenerator = generateRandomNumber(9);
        System.out.println(levelgenerator);
        String concatenateWithLevelName = levelname+levelgenerator;
        System.out.println(concatenateWithLevelName);
        //waitForVisibilityOfElement(createLevel, "createLevel");
        setText(levelNamPath, concatenateWithLevelName, "Level name with RandGen");
        pressTab(levelNamPath);
    }


    public void hoverOnTheCreatedLevel(String levelName) throws Throwable {

        By addedlevelpath = By.xpath("//span[text()='"+levelName+"']");
        waitForVisibilityOfElement(addedlevelpath, "AddedLevelName",10);
        mouseHoverJS(addedlevelpath, "AddedLevelName");
        //click(addedlevelpath, "AddedLevelName");

    }

    public String generateLevelRandom(String levelname)throws Throwable{
        String levelgenerator = generateRandomNumber(9);
        System.out.println(levelgenerator);
        String concatenateWithLevelName = levelname+levelgenerator;
        System.out.println(concatenateWithLevelName);
        //waitForVisibilityOfElement(createLevel, "createLevel");
//        setText(levelNamPath, concatenateWithLevelName, "Level name with RandGen");
//        pressTab(levelNamPath);
        return concatenateWithLevelName;
    }
    
    public void searchCreatedLevel(int position) throws Throwable{
    	By SearchIcon=By.cssSelector("[data-test='search-icon']");
    	WebElement searchIcon=driver.findElements(SearchIcon).get(position);    	
    	searchIcon.click();
    	waitForPageLoaded();    	
    }
    
    public void enterLevelNameonExplorerView(String levelname,int position) throws Throwable{
    	By SearchIcon=By.cssSelector("input[data-test='search-input']");
    	WebElement searchIcon=driver.findElements(SearchIcon).get(position);
    	searchIcon.clear();
    	searchIcon.sendKeys(levelname);
    	waitForPageLoaded();  
    }

    public boolean verifysearch_Results(String levelNameExpected) throws Throwable {
        List<WebElement> list=driver.findElements(By.cssSelector("[class='levels'] span"));
        boolean flag=false;
        if(list.size()==0){
     	   flag=true;
        }
        return flag;
     }
    
    public void verifyRecordDisplay(String levelName) throws Throwable{

        By explorerViewCreatedLevel = By.xpath("//span[@class='level-name cursor-hand'][text()='"+levelName+"']");
        waitForVisibilityOfElement(explorerViewCreatedLevel, "levelName",15);
        isElementDisplayed(explorerViewCreatedLevel, "levelName");
    }


    public void clickOnAssetHierarchyAndTasks() throws Throwable {
        waitForVisibilityOfElement(assetHierarchy_Tasks, "assetHierarchy_Tasks",15);
        click(assetHierarchy_Tasks, "assetHierarchy_Tasks");
    }

}













