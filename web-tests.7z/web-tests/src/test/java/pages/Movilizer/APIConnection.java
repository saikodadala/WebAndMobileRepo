package pages.Movilizer;
import org.openqa.selenium.Cookie;
import seleniumUtilities.GenericMethods;

public class APIConnection extends GenericMethods  {

	public String getCookie(){    	 
    	Cookie authToken=driver.manage().getCookieNamed("_gorilla_csrf");
    	String token=authToken.getValue();
    	return token;    	
    }
}
