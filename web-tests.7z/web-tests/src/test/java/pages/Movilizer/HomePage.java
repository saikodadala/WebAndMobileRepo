
package pages.Movilizer;import org.openqa.selenium.By;
import seleniumUtilities.GenericMethods;public class HomePage extends GenericMethods {
	/**
	 * Locators and reusable methods for Home Page
	 *
	 * @author Sai Kodadala
	 *
	 */ private By mainMenu=By.id("gwt-debug-NavigationMenu");
	 private By easyConfig=By.id("gwt-debug-mmEasyConfig");
	 private By templates=By.cssSelector("[class='h-icon building doc-test sidebar-icon']");
	 private By manageUsers=By.cssSelector("[class='h-icon building operations sidebar-icon']");
	 private By mainFrame=By.cssSelector("[class='gwt-Frame']");
	 private By manageDevicesIcon=By.cssSelector("[class='h-icon building smartphone sidebar-icon']");
	 private By createLevel=By.xpath("//*[text()='Create Level']");
	 private By submitButton1=By.cssSelector("[class='ui medium button primary']");
	 private By enterpriseThreeDots=By.cssSelector("[class='enterprise-title active-border'] span span i");
	 private By timeZone=By.cssSelector("[class='ui active visible fluid search selection upward dropdown'] input");
	 private By submitButton = By.xpath("//div[text()='SUBMIT']");
	 private By levelName=By.cssSelector("[placeholder='Type here']"); 
	 private By systemoverview=By.id("gwt-debug-mmSystem");
	 private By movilizerPlatformLogo=By.id("mainLogoAnchor");
	 private By manageDevicesactiveIcon=By.cssSelector("[class='active link item']");
	 
	 public void clickOnMainMenu()throws Throwable{
		 waitForVisibilityOfElement(mainMenu, "mainMenu",80);
		 click(mainMenu,"mainMenu");
	 }
	 public void clickOnEasyConfig()throws Throwable{
		 waitForVisibilityOfElement(easyConfig, "easyConfig",20);
		 click(easyConfig,"easyConfig");
	 }
	 public void clickOnEnterpriseThreeDots()throws Throwable{

		 waitForVisibilityOfElement(enterpriseThreeDots, "enterpriseThreeDots",20);
		 click(enterpriseThreeDots,"enterpriseThreeDots"); }
	 public void clickOnCreateLevel()throws Throwable{
		 waitForVisibilityOfElement(createLevel, "createLevel",20);
		 click(createLevel,"create Level option");
	 }
	 public void enterLevelName(String name)throws Throwable{
		 waitForVisibilityOfElement(createLevel, "createLevel",20);
		 mouseHover(submitButton, "submitButton");
		 setText(levelName, name, "Level name");
		 pressTab(levelName);
	 }
	 public void enterTimeZone(String time)throws Throwable{
		 waitForVisibilityOfElement(timeZone, "timeZone",20);
		 setText(timeZone, time, "Time zone");
		 driver.findElement(By.xpath("//span[text()='"+time+"']")).click();
		 pressTab(timeZone);
	 }
	 public void clickOnSubmit()throws Throwable{
		 waitForVisibilityOfElement(submitButton, "submitButton",20);
		 click(submitButton,"submitButton");
	 }
	 public void clickOnRoundTemplate()throws Throwable{
		 driver.switchTo().defaultContent();
		 waitForVisibilityOfElement(mainFrame, "mainFrame",10);
		 switchToFrame(mainFrame);
		 //clickJS(templates,"Round template");
		 click(templates,"Round template");
	 }
	 public void clickOnManageDevices()throws Throwable{
		
		 waitForVisibilityOfElement(manageDevicesIcon, "Manage Devices",10);
		 click(manageDevicesIcon,"Manage Devices");
	 }
	 
	 public void switchFrame() throws Throwable{
		 waitForPageLoaded();
		 driver.switchTo().defaultContent();
		 waitForPageLoaded();
	     waitForVisibilityOfElement(mainFrame, "mainFrame",10);
	     switchToFrame(mainFrame);
	 }
	 
	 public void movilizerPlatform() throws Throwable{
	     waitForVisibilityOfElement(movilizerPlatformLogo, "Movilizer Platform",15);
	 }
	 
	 public void activeItem() throws Throwable{
	     waitForVisibilityOfElement(manageDevicesactiveIcon, "manageDevices activeIcon",15);
	 }
	 public void setLevelName(String name)throws Throwable{
		 waitForVisibilityOfElement(levelName, "levelName",20);		 
		 setText(levelName, name, "Level name");
		 pressTab(levelName);
	 }
}

