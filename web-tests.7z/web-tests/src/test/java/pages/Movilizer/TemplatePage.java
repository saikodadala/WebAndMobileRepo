package pages.Movilizer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import common.Apiutils.Api;
import seleniumUtilities.GenericMethods;

public class TemplatePage extends GenericMethods {

	private By TestTemplateLevel1 = By.xpath("//*[contains(text(),'0111')]");
	private By threeDotsForCreateLevel = By.xpath("[class='h-icon icon ellipsis horizontal']");
	private By createLevel = By.xpath("//*[text()='Create Level']");
	private By templates = By.cssSelector("[class='h-icon building doc-test sidebar-icon']");
	private By roundTemplateBtn = By.xpath("//*[text()='Add Round Template']");
	private By nextBtn = By.cssSelector("[class='ui medium button primary']");
	private By roundTemplateName = By.xpath("//input[@data-testid='TemplateName']");
	private By gracePeriod = By.cssSelector("[placeholder='Enter period']");
	private By createBtn = By.xpath("//*[text()='Create']");
	private By mainFrame = By.cssSelector("[class='gwt-Frame']");
	private By category = By.cssSelector("[placeholder='Enter category name']");
	private By categoryErrormsg = By.xpath("//span[@class='ui error-message']");

	// locators
	private By msg = By.xpath("//*[text()='Please select a level to create Round Template.']");
	private By verifytext_Noroundtemplatesaddedyet = By.xpath("//div[@class='noDataListContainer']//span");
	private By addroundtemplatebtn = By.cssSelector("[class='button-content']");
	private By roundtemplateOption = By.xpath("//*[text()='Round Template']");
	private By firstbreadcrumb = By.xpath("//a[@class='section breadcrumb-item-first']");
	private By lastbreadcrumb = By.xpath("//div[@class='section breadcrumb-item-last']");
	private By header = By.xpath("//div[@class=' header-issue']");
	private By checkbox = By.xpath("//div[@class='ui fitted checkbox select-all-checkbox']");
	private By addselected = By.xpath("//div[starts-with(@data-testid,'add-selected')]");
	private By roundtemplatecreate_successful = By.xpath("//span[@class='title']");
	private By closepopup = By.xpath("//div[@class='close-wrapper']/i");

	private By step2HeaderMessage=By.xpath("//*[contains(@class,'scuf-col scuf-grid asset-info-name topAssetInfoText')]");
	private By backButton=By.cssSelector("[data-testid='back-button']");
	private By assetSearchTextBox=By.cssSelector("[placeholder='Search assets']");
	private By filterIcon=By.cssSelector("[class='header-bar-item filter-panel-icon'] i");
	private By noAssetsInTable=By.cssSelector("[class='no-assets-selected-container']");
	private By availableAssetsInTable=By.cssSelector("[class='asset-name-badge'] div");
	private By resetAllFiltersLink=By.cssSelector("[class='filter-item reset-all'] span");
	private By filterCount=By.cssSelector("[class='ui blue circular label badge ']");


	//Locators for pagination
	private	By webElement = null;
	private By flitericon = By.xpath("//div[@class='header-bar-item filter-panel-icon']/i");
	private By careticon = By.xpath("//i[@class='h-icon global caret-up section-label-icon fitted']");
	private By itemsnumber = By.xpath("(//span[@class='bold'])[1]");
	private By listbox = By.xpath("//div[@role='listbox']");
	private By tablerows = By.xpath("//tbody[@class='p-datatable-tbody']/tr");
	private By pagination = By.xpath("//div[contains(@class,'page-btn item-btn ')]");

	//Locators for filters
	private By filtervalue = By.xpath("//div[@class='section-label-text']");
	private By resetfileter=By.xpath("//span[text()='Reset all filters']");
	private By notasksPopupmsg = By.xpath("//div[@class='scrolling content']");

	//Advanced round template
	private By advancedRoundtemplateOption = By.xpath("//*[text()='Advanced Round Template']");
	private By addActivitySet=By.xpath("//*[text()='Add Activity Set']");
	private By activityName=By.xpath("//*[text()='Display Name']/../..//input");
	private By assetCheckBox=By.cssSelector("[class='assetListClassWorkflow'] th input");
	private By selectAssetButton=By.xpath("//div[text()='Select Asset']");
	private By addCheckList=By.xpath("//*[text()='Add Checklist']");
	private By selectTaskButton=By.xpath("//div[text()='Select Task']");
	private By advancedRT=By.cssSelector("input[placeholder='Name']");
	private By saveAndNext=By.xpath("//*[text()='Save and Next']");

	//Locators for existing round template
	private By RT_Records=By.xpath("//tbody[@class='p-datatable-tbody']/tr");
	private By createNewRoundTempalteFromThisLink=By.cssSelector("[data-btn='createFromExisting']");
	
	public void clickOnTemplateLevel1() throws Throwable {
		String str = "0111";
		List<WebElement> elem = driver.findElements(By.cssSelector("[class='loader-content'] div[role='listitem']"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		for (WebElement e : elem) {
			System.out.println(e.getText());
			if (str.equalsIgnoreCase(e.getText())) {
				e.click();
				scrollToWebElement(templates);
				scrollUP();
				break;
			}

			je.executeScript("arguments[0].scrollIntoView(true);", e);

		}
	}

	public void clickOnCreateLevel() throws Throwable {
		waitForVisibilityOfElement(threeDotsForCreateLevel, "threeDotsForCreateLevel",15);
		setFocusAndClick(threeDotsForCreateLevel, "threeDotsForCreateLevel");
		waitForVisibilityOfElement(createLevel, "createLevel",15);
		setFocusAndClick(createLevel, "createLevel");
	}

	public void clickOnRoundTemplateButton() throws Throwable {
		waitForVisibilityOfElement(roundTemplateBtn,"roundTemplateBtn",10);
		click(roundTemplateBtn, "Round Template Button");
	}

	public void clickOnLevel2() throws Throwable {
		By level = By.xpath("//*[text()='Level2']/../input");
		waitForVisibilityOfElement(level,"level",10);
		clickJS(level, "Level2");
	}

	public void clickOnLevel3() throws Throwable {
		By level = By.xpath("//*[text()='Level3']/../input");
		waitForVisibilityOfElement(level,"level",10);
		clickJS(level, "Level3");
	}

	public void clickOnLevel4() throws Throwable {
		By level = By.xpath("//*[text()='Level4']/../input");
		waitForVisibilityOfElement(level,"level",10);
		clickJS(level, "Level4");
	}

	public void clickOnNextButton() throws Throwable {
		waitForVisibilityOfElement(nextBtn,"nextBtn",10);
		clickJS(nextBtn, "next button");
	}

	public void selectAsset() throws Throwable {
		By loc = By.xpath("(//*[@class='sc-bdVaJa dCNSGI h-icon common'])[1]");
		waitForVisibilityOfElement(loc,"loc",10);
		clickJS(loc, "Asset");
	}

	public void selectTask() throws Throwable {
		By loc = By.xpath("(//*[@class='sc-bdVaJa bKuwvi h-icon common'])[1]");
		waitForVisibilityOfElement(loc,"loc",10);
		clickJS(loc, "Asset");
	}

	public void enterRoundTemplateName() throws Throwable {
		waitForVisibilityOfElement(roundTemplateName,"roundTemplateName",15);
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		setText(roundTemplateName, "RoundTemplate" + date1, "roundTemplateName");
	}

	public void enterGracePeroid() throws Throwable {
		waitForVisibilityOfElement(gracePeriod,"gracePeriod",10);
		setText(gracePeriod, "20", "gracePeriod");
	}

	public void clickOnCreateButton() throws Throwable {
		waitForVisibilityOfElement(createBtn,"createBtn",15);
		clickJS(createBtn, "createBtn");
	}

	public void clickOnUserLevel(String level) throws Throwable {
		String str = level;
		waitForVisibilityOfElement(mainFrame, "mainFrame",10);
		switchToFrame(mainFrame);
		List<WebElement> elem = driver.findElements(By.cssSelector("[class='loader-content'] div[role='listitem']"));
		JavascriptExecutor je = (JavascriptExecutor) driver;
		for (WebElement e : elem) {
			System.out.println(e.getText());
			if (str.equalsIgnoreCase(e.getText())) {
				e.click();
				scrollToWebElement(templates);
				scrollUP();
				break;
			}

			je.executeScript("arguments[0].scrollIntoView(true);", e);

		}
	}

	// Verify msg if level hirarchy not selected
	public void verifymsg_iflevelnotselected(String expectedtext) throws Throwable {

		waitForVisibilityOfElement(msg,"msg",10);
		String actualtext = getText(msg);
		System.out.println("The text is " + actualtext);
		validateCheckPointMatch(msg, expectedtext, actualtext);

	}

	// select levelhirarchy from Round template
	public void selectlevelhirarchy_Rountemplate(String levelhirarchyname) throws Throwable {

		By selectlevlhirarchy = By.xpath("//div[text()='" + levelhirarchyname + "']");
		setFocusAndClick(selectlevlhirarchy, "Select levelhirarchyfrom round template");

	}

	// verify message
	public void verify_msg_No_templateaddedyet(String expectedtext) throws Throwable {
		waitForPageLoaded();
		waitForVisibilityOfElement(verifytext_Noroundtemplatesaddedyet,"verifytext_Noroundtemplatesaddedyet",10);
		String actualtext = getText(verifytext_Noroundtemplatesaddedyet);
		validateCheckPointMatch(verifytext_Noroundtemplatesaddedyet, expectedtext, actualtext);
	}

	// verify Add round template button is displayed
	public void verify_Addroundtemplate_Displayed() throws Throwable {
		waitForVisibilityOfElement(addroundtemplatebtn,"addroundtemplatebtn",15);
		isEnabled(addroundtemplatebtn);
		isElementDisplayed(addroundtemplatebtn, "Add round template button");

	}

	public void verify_Addroundtemplate_Count() throws Throwable {
		List<WebElement> list=driver.findElements(addroundtemplatebtn);
		try{
			if(list.size()>1){
				logfailinfo("more than one 'Add Round Template' button are displayed");
				Assert.fail("more than one 'Add Round Template' button are displayed");
			}
		}catch(Exception e){

		}
		waitForVisibilityOfElement(addroundtemplatebtn,"addroundtemplatebtn",15);
		isEnabled(addroundtemplatebtn);
		isElementDisplayed(addroundtemplatebtn, "Add round template button");

	}

	// verify bread crumb(Round template page,after clicking level hirarchy)
	public void verify_breadcrumb(String expectedbreadcrumb) throws Throwable {
		String actualtext = "";
		waitForVisibilityOfElement(firstbreadcrumb,"firstbreadcrumb",15);
		scrollToWebElement(firstbreadcrumb);
		actualtext = getText(firstbreadcrumb);
		validateCheckPointMatch(firstbreadcrumb, "Enterprise", "Firstbreadcrumb");
		actualtext = getText(lastbreadcrumb);
		validateCheckPointMatch(lastbreadcrumb, expectedbreadcrumb.trim(), "Lastbreadcrumb");

	}

	// verify header
	public void verify_header(String expectedheadername) throws Throwable {

		String actualheader = getText(header);
		System.out.println("Headername is " + actualheader);
		validateCheckPointMatch(header, expectedheadername, actualheader);
	}

	// click on Add round template

	public void clickon_Addroundtemplate() throws Throwable {
		waitForPageLoaded();
		List<WebElement> list=driver.findElements(addroundtemplatebtn);
		waitForVisibilityOfElement(addroundtemplatebtn,"addroundtemplatebtn",10);
		waitforElementtobeClickable(addroundtemplatebtn,"addroundtemplatebtn",10);
		list.get(1).click();
	}

	public void clickon_roundtemplate() throws Throwable {
		waitForVisibilityOfElement(roundtemplateOption,"roundtemplateOption",10);
		clickJS(roundtemplateOption, "roundtemplateOption");
	}

	// verify level hirarchy is displayed
	public void levelhirarchy_isDispalyed(String levelhirarchyname) throws Throwable {

		By levelhirachy = locator(levelhirarchyname, "Verify level hirarchy");
		waitForVisibilityOfElement(levelhirachy,"levelhirachy",10);
		isElementDisplayed(levelhirachy, "Verify levelhirarchy");
	}

	// verify assets are displayed for the level hirarchy created
	public void assets_isDispalyed(String assetname) throws Throwable {		
		By asset = locator(assetname, "Verify Assets,created for level hirarchy");
		waitForVisibilityOfElement(asset,"asset",10);
		// scrollToWebElement(asset);
		isElementDisplayed(asset, "Verify Asset,Verify Asset created for level hirarchy");
	}

	// verify task is displayd for the assets created
	public void task_isDispalyed(String taskname) throws Throwable {

		By task = locator(taskname, "Verify task,created for asset");
		waitForVisibilityOfElement(task,"task",10);
		isElementDisplayed(task, "Verify task,Verify task created for assets");
	}

	public boolean handlePopAlertContinue() throws Throwable{
		By alert=By.xpath("//*[text()='Continue']");
		boolean flag=false;
		if(isElementPresent(alert, "alert")){
			click(alert, "alert");
			flag=true;
		}
		return flag;
	}

	// click on checkbox
	public void clickbox() throws Throwable {

		click(checkbox, "Click on checkbox to select assets");
	}

	// click on add selected
	public void clickonAddselected() throws Throwable {
		click(addselected, "Click on add selected");
	}

	// Enter roundtemplate name
	public void Enter_Roundtemplate(String roundtemplatename) throws Throwable {
		waitForVisibilityOfElement(roundTemplateName, "Roundtemplatename",10);
		setText(roundTemplateName, roundtemplatename, "Roundtemplatename");

	}

	// Enter graceperiod value
	public void Enter_Graceperiod(String graceperiodname) throws Throwable {
		setText(gracePeriod, graceperiodname, "Graceperiod");
	}

	// verify is round created successfully or not
	public void verify_Roundtemplatecreated(String roundtemplatename) throws Throwable {

		waitForVisibilityOfElement(roundtemplatecreate_successful,"roundtemplatecreate_successful",20);
		isElementDisplayed(roundtemplatecreate_successful, "roundtemplatecreate_successful");
		String text = getText(roundtemplatecreate_successful);
		//		Assert.assertTrue(text.contains(roundtemplatename));

	}
	// close popup

	public void closepopup() throws Throwable {

		waitForVisibilityOfElement(closepopup, "Close popup", 5);
		clickJS(closepopup, "Close popup");
	}

	/**
	 * Clear asset search box
	 * @throws Throwable
	 */
	public void clearAssetSearchBox() throws Throwable{
		clearText(assetSearchTextBox);
	}


	public void clickOnFilterIcon() throws Throwable{
		waitForVisibilityOfElement(filterIcon, "filterIcon",15);
		click(filterIcon, "Filter icon");
	}


	public void filterWithAssetNameStep2(String lableName) throws Throwable{
		By loc=By.xpath("//*[@class='section-label-text'][text()='"+lableName+"']");
		click(loc, "Filter option");
	}
	
	public void selectAllColumns(String name) throws Throwable{
		By threeDots=By.cssSelector("[class='h-icon icon ellipsis horizontal popup-icon-bg']");
		By colName=By.xpath("//label[text()='"+name+"']");
		By colStatus=By.xpath("//label[text()='"+name+"']/../../div[@class='ui checkbox']");
		click(threeDots,"three dots");
		waitForPageLoaded();
		boolean status=driver.findElement(colStatus).isDisplayed();
		if(status){
			click(colName, name);
		}
		
	}

	public void selectFilterItems(String lableName) throws Throwable{
		By loc=By.xpath("//*[@class='section-label-text'][text()='"+lableName+"']/../following-sibling::div//*[@class='ui checkbox toggle-item']");
		click(loc, "Filter option");
	}

	/**
	 * Verify records displayed in the table
	 * @throws Throwable
	 */
	public void verifyRecordsDisplayedInTheTable(String columnName) throws Throwable{
		List<WebElement> headersList=driver.findElements(By.xpath("//th/span[1]"));
		int count=0;
		for(int i=0;i<headersList.size();i++){
			String headerName=headersList.get(i).getText();
			if(headerName.equalsIgnoreCase(columnName)){
				count=i;
				break;
			}
		}
		count++;
		By loc=By.xpath("//*[@class='p-datatable-row']//td["+count+"]");
		By locator=By.xpath("//*[@class='section-label-text'][text()='"+columnName+"']/../following-sibling::div//*[@class='ui checked checkbox toggle-item']");
		String expectedText=getText(loc);
		String actualText=getText(locator);
		verifyTextEquals(actualText, expectedText);

	}

	public void clickOnResetAllFiltersLink() throws Throwable{
		clickJS(resetAllFiltersLink, "resetAllFiltersLink");
	}

	public void verifyFilterCount() throws Throwable{
		getText(filterCount);
		//	reporter.SuccessReportWithScreenshot("Verify filter count", "Filter count is : "+ count, driver);
	}
	/**
	 * Verify asset searching functionality
	 * @throws Throwable
	 */
	public void enterAssetNameInSearchBox() throws Throwable{
		List<WebElement> list=getWebElementList(availableAssetsInTable, "assets");
		String assetName="";
		if(list.size()>0){
			assetName=list.get(0).getText();
		}
		setText(assetSearchTextBox, assetName, "Search with asset");		
	}

	/**
	 * Validation of no records available in the table 
	 * @param message
	 * @throws Throwable
	 */
	public void noRecordsAvailableInTable(String message) throws Throwable{
		String expMessage=getText(noAssetsInTable, "no records message");
		validateTextUsingContains(expMessage,message);		
	}

	public void verifyIsBackButtonAvailable() throws Throwable{
		isElementDisplayed(backButton, "Back button");
	}


	/**
	 * Check table is availability 
	 * @param table
	 * @throws Throwable
	 */
	public void tableAvailabity(String table) throws Throwable{
		By loc=By.cssSelector("[class='create-template2-tables-column "+table+"-margin-1rem']");
		isElementDisplayed(loc, table+"available");
	}

	/**
	 * Verify step-2 header message
	 * @param message
	 * @throws Throwable
	 */
	public void verifyHeaderMessage(String message) throws Throwable{
		String expectedString=getText(step2HeaderMessage, "Header Message");
		validateTextUsingContains(expectedString,message);
	}

	/**
	 * Verify current /active padding menu
	 * @param step
	 * @throws Throwable
	 */
	public void verifyCurrentActivePadding(String step) throws Throwable{
		By loc=By.cssSelector("[class='active link step item zero-padding stepper-container'][data-testid='"+step+"']");
		isElementDisplayed(loc, step+"active padding");
	}


	/**
	 * level selection at step-2
	 * @param level
	 * @throws Throwable
	 */
	public void levelSelection(String level) throws Throwable  {

		By levelCheckBox=By.xpath("//div[contains(text(),'"+level+"')]/following-sibling::div//*[@type='checkbox']/..");
		List<WebElement> eles=getWebElementList(levelCheckBox, "Available levels");
		if(level.contains("SUB")){
			for(int i=0;i<eles.size();i++){
				eles.get(i).click();			
			}
		}else{
			for(int i=1;i<eles.size();i++){
				eles.get(i).click();			
			}
		}

	}

	// click on filter icon
	public void clickonfilter() throws Throwable {

		waitForVisibilityOfElement(flitericon, "Filter icon",15);
		click(flitericon, "Filter icon");
	}

	// click on caret icon
	public void clickoncaret() throws Throwable {

		waitForVisibilityOfElement(careticon, "Filtertype caret",15);
		click(careticon, "Filtertype caret");
	}

	public void selectItems_perpage(String itemperpage) throws Throwable {
		By itemsperpage = locator(itemperpage, itemperpage);
		waitForVisibilityOfElement(itemsperpage, itemperpage,15);
		clickJS(itemsperpage, "Click on item per page");
	}



	//select level hirarchy from Assethirarchy menu
	public void selectlevelhirarchy(String levelhirachy) throws Throwable
	{

		By selectlevelhirarchy= locator(levelhirachy,"Select levelhirachy");
		waitForVisibilityOfElement(selectlevelhirarchy,"selectlevelhirarchy",10);
		setFocusAndClick(selectlevelhirarchy,"Select levelhirachy");
	}


	// validate filters in round template page
	public void Filters_Roundtemplate() throws Throwable
	{
		String filtername="";
		waitForVisibilityOfElement(filtervalue, "Filter values", 5);
		clickonfilter();
		List<WebElement> filters = getWebElementList(filtervalue,"filter values");

		for(int i=0;i<filters.size();i++)
		{
			filtername=filters.get(i).getText();
			//	reporter.SuccessReport("Filter validation is ", filtername.toLowerCase());
			By carerticon = By.xpath("//div[text()='"+filtername+"']/../i");
			click(carerticon,"Caret icon");
			By items = By.xpath("//div[text()='"+filtername+"']/../..//div[@class='section-content']//label");
			List<WebElement> checkboxes = getWebElementList(items,"checkboxes to select");
			waitForPageLoaded();
			for(int j=0;j<checkboxes.size();j++)
			{
				WebElement element = checkboxes.get(j);
				try {
					element.click();
				} catch (Exception e) {
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",element);
					element.click();
				}
				String text = checkboxes.get(j).getText();
				By value=By.xpath("//div[text()='"+text+"']");
				validateCheckPointMatch(value,text,"Validate text");
				click(resetfileter,"reset fileter");
			}
			carerticon = By.xpath("//div[text()='"+filtername+"']/../i");
			click(carerticon,"Caret icon");
		}
	}

	// PAGINATION for round template
	public void Verify_Pagination_Roundtemplate() throws Throwable 
	{

		waitForVisibilityOfElement(listbox, "Listbox",20);
		click(listbox, "Click on listbox");
		selectItems_perpage("20 items");
		WebDriverWait wait= new WebDriverWait(driver,30);  
		wait.until(ExpectedConditions.visibilityOfAllElements(getWebElementList(tablerows,"Elements")));
		// Validating 1-20
		validateCheckPointMatch(itemsnumber,"1 - 20 ","20 items per page");
		Assert.assertEquals(String.valueOf(getElementsSize(tablerows)),"20");

		clickonListbox();
		selectItems_perpage("10 items");
		// Validating 1-20
		wait.until(ExpectedConditions.visibilityOfAllElements(getWebElementList(tablerows,"Elements")));
		validateCheckPointMatch(itemsnumber,"1 - 10","10 items per page");
		Assert.assertEquals(String.valueOf(getElementsSize(tablerows)),"10");

		waitForVisibilityOfElement(pagination, "pagination", 5);
		List<WebElement> paginationvalues = getWebElementList(pagination,"pagination list");
		for (int i = 0; i < paginationvalues.size(); i++) {
			WebElement element = paginationvalues.get(i);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			waitForPageLoaded();
		}
	}

	// Enter category value
	public void enterCategory(String catvalue) throws Throwable {
		clearText(category);
		setText(category, catvalue, "CategoryValue");
	}

	// verify error message
	public void verify_errormsg(String expectedtext) throws Throwable {
		waitForInVisibilityOfElement(categoryErrormsg,"categoryErrormsg",20);
		String actualtext = getText(categoryErrormsg);
		validateCheckPointMatch(categoryErrormsg, expectedtext, actualtext);
	}

	public String mouseHoverOnTemplateName() throws Throwable {
		String uuidnum = null;
		waitForVisibilityOfElement(By.xpath("(//tr[@class='p-datatable-row']//td)[2]"), "mainFrame",15);
		click(By.xpath("(//tr[@class='p-datatable-row']//td)[2]"),"Round template");
		waitForVisibilityOfElement(By.xpath("//h1[text()='Round Template details']"),"Roundtemplatedetails",15);

		WebElement ele = driver.findElement(By.xpath("//div[@class='templateName-Label-Hover contentTempClass']"));
		Actions action = new Actions(driver);
		action.moveToElement(ele).perform();

		WebElement uuid = driver.findElement(By.xpath("//div[@class='ui right center mini popup transition visible ui tooltip']/div"));
		String tooltip_msg=uuid.getText();
		System.out.println(tooltip_msg);

		String[] words=tooltip_msg.split("\\s");
		System.out.println("second word is " + words[1]);
		uuidnum = words[1];
		return uuidnum;
	}

	// verify error message
	public void mandatory_Popupmsg(String expectedtext) throws Throwable {
		waitForPageLoaded();
		waitForVisibilityOfElement(notasksPopupmsg,"categoryErrormsg",20);
		String actualtext = getText(notasksPopupmsg);
		validateCheckPointMatch(notasksPopupmsg, expectedtext, actualtext);
		System.out.println("Matched n Passed");
	}
	
	public void clickOnCreatedRTRecord() throws Throwable{
		waitForPageLoaded();
		click(RT_Records, "Round Template");
	}
	
	public void clickOnNewRoundTemplateFromThisLink() throws Throwable{
		waitForPageLoaded();
		click(createNewRoundTempalteFromThisLink,"Create new round template from this");
	}
	public void clickonAdvancedRoundtemplate() throws Throwable {
		waitForVisibilityOfElement(advancedRoundtemplateOption,"advancedRoundtemplateOption",10);
		clickJS(advancedRoundtemplateOption, "advancedRoundtemplateOption");
	}
	public void clickonAddActivitySet() throws Throwable {
		waitForVisibilityOfElement(addActivitySet,"addActivitySet",10);
		clickJS(addActivitySet, "addActivitySet");
	}
	public void enterAddActivitySet() throws Throwable {
		waitForVisibilityOfElement(activityName,"activityName",10);
		setText(activityName, "activityName","activityName");
	}
	public void clickonAssetCheckBox() throws Throwable {
		waitForVisibilityOfElement(assetCheckBox,"assetCheckBox",10);
		clickJS(assetCheckBox, "assetCheckBox");
	}
	public void clickonSelectAsset() throws Throwable {
		waitForVisibilityOfElement(selectAssetButton,"selectAssetButton",10);
		clickJS(selectAssetButton, "selectAssetButton");
	}
	public void clickonSelectTask() throws Throwable {
		waitForVisibilityOfElement(selectTaskButton,"selectTaskButton",10);
		clickJS(selectTaskButton, "selectTaskButton");
	}
	public void clickonCheckList() throws Throwable {
		waitForVisibilityOfElement(addCheckList,"addCheckList",10);
		clickJS(addCheckList, "addCheckList");
	}
	public void enterAdvancedRTName(String advancedRTName) throws Throwable {
		waitForVisibilityOfElement(advancedRT,"advancedRT Name",10);
		setText(advancedRT, advancedRTName,"advancedRTName");
	}
	public void clickonSaveAndNext() throws Throwable {
		waitForVisibilityOfElement(saveAndNext,"saveAndNext",10);
		clickJS(saveAndNext, "saveAndNext");
	}
}

