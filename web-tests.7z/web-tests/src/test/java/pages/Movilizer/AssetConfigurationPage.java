package pages.Movilizer;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import common.reports.ConfigFileReadWrite;
import common.reports.ReporterConstants;
import seleniumUtilities.GenericMethods;

public class AssetConfigurationPage extends GenericMethods {

	private By noAssetImage=By.cssSelector("[class='no-devices-image']");
	private By noAssetText=By.xpath("//*[text()='No assets added yet']");
	private By addAssetBtn=By.xpath("//*[text()='ADD ASSET']");
	private By assetConfigurationHeader=By.xpath("//h1[text()='Asset Configuration']");
	private By addAssetTitle=By.xpath("//*[text()='Add Asset']");
	private By cancelBtn=By.xpath("//button[@type='button']/following::div[text()='Cancel']");
	private By submitBtn=By.xpath("//button[@type='button']/following::div[text()='Submit']");
	private By primarySecLbl=By.xpath("//span[@class='input-label-message' and text()='PRIMARY INFORMATION']");
	private By backEndLbl=By.xpath("//span[@class='input-label-message' and contains(text(),'Backend')]");
	private By assetnameLbl=By.xpath("//span[@class='input-label-message' and text()='Asset Name']");
	private By assetnameMandate=By.xpath("//span[@class='input-label-message' and text()='Asset Name']/../*[@class='ui red circular empty label badge  circle-padding']");
	private By assetTypeMandate=By.xpath("//span[@class='input-label-message' and text()='Asset Type']/following::div[@class='ui red circular empty label badge  circle-padding']");
	private By idCodeLbl=By.xpath("//span[@class='input-label-message' and text()='Identification Code']");
	private By inheritTxt=By.xpath("//*[text()='Inherit from Abstract Asset']");
	private By inheritCheckbox=By.xpath("(//*[text()='Inherit from Abstract Asset']/preceding::input[@type='checkbox'])[1]");
	private By extendsIDLbl=By.xpath("//span[@class='input-label-message' and text()='Extends ID']");
	private By criticalityLbl=By.xpath("//span[@class='input-label-message' and text()='Criticality']");
	private By assetTypeLbl=By.xpath("//span[@class='input-label-message' and text()='Asset Type']");
	private By assetModeLbl=By.xpath("//span[@class='input-label-message' and text()='Asset Mode']");
	private By preConditionCheckbox=By.xpath("//*[text()='Precondition Check']/../input[@type='checkbox']");
	private By preConditionLbl=By.xpath("//*[text()='Precondition Check']");
	private By contactLbl=By.xpath("//*[text()='Contact']");
	private By ownerOrganizationLbl=By.xpath("//*[text()='Owner Organization']");
	private By locDetailsLbl=By.xpath("//*[text()='LOCATION DETAILS']");
	private By locIDLbl=By.xpath("//*[text()='Location ID']");
	private By locationLbl=By.xpath("//*[text()='Location']");
	private By locDescLbl=By.xpath("//*[text()='Location Description']");
	private By tagDetailsLbl=By.xpath("//*[text()='TAG DETAILS']");
	private By sapTagLbl=By.xpath("//*[text()='SAP Tag']");
	private By dcsTagLbl=By.xpath("//*[text()='DCS Tag']");
	private By historianTagLbl=By.xpath("//*[text()='Historian Tag']");
	private By enableHisTagLbl=By.xpath("//*[text()='Enable Historian Tag']");
	private By fieldTagLbl=By.xpath("//*[text()='Field Tag']");
	private By addInfoLbl=By.xpath("//*[text()='ADDITIONAL INFORMATION']");
	private By addNewRowLbl=By.xpath("//*[text()='Add New Row']");
	private By headLineLbl=By.xpath("//*[text()='Headline']");
	private By linksSection=By.xpath("//*[text()='LINKS']");
	private By linkDescLbl=By.xpath("//*[text()='LINKS']/following::table/thead/tr/th/span[text()='Description']");
	private By linkLbl=By.xpath("//*[text()='LINKS']/following::table/thead/tr/th/span[text()='Link']");
	private By addLinkLbl=By.xpath("//*[text()='Add Link']");
	private By assetNameField=By.xpath("//*[text()='Please enter Asset Name']");
	private By assetTypeField=By.xpath("//*[text()='Please enter Asset Type']");
	private By bckIDValidation=By.xpath("//*[text()='Maximum length 128 is exceeded']");
	private By assetNameValidation=By.xpath("//*[text()='Asset name Maximum length 128 is exceeded']");
	private By idCodeValidation=By.xpath("//*[text()='Identification code cannot be more than 1024 characters']");
	private By criticalityValidation=By.xpath("//*[text()='Criticality cannot be more than 128 characters']");
	private By assetTypeValidation=By.xpath("//*[text()='Asset type Maximum length 32 is exceeded']");
	private By assetModeValidation=By.xpath("//*[text()='Maximum length 32 exceeded for individual mode']");
	private By assetModeLimitation=By.xpath("//*[text()='Maximum length 255 exceeded for all modes']");
	private By contactLimitation=By.xpath("//*[text()='Contact cannot be more than 128 characters']");
	private By ownerOrgLimitation=By.xpath("//*[text()='Owner Organization cannot be more than 128 characters']");
	private By locIDLimitation=By.xpath("//*[text()='Location id cannot be more than 128 characters']");
	private By locValvalidation=By.xpath("//*[text()='Value must be numeric and separated by ;']");
	private By locDescLimitation=By.xpath("//*[text()='Location description cannot be more than 128 characters']");
	private By sapTagLimitation=By.xpath("//*[text()='Asset SAP tag Maximum length 64 is exceeded']");
	private By dcsTagLimitation=By.xpath("//*[text()='Asset DCS tag Maximum length 64 is exceeded']");
	private By historianTagLimitation=By.xpath("//*[text()='Asset Historian tag Maximum length 64 is exceeded']");
	private By fieldTagLimitation=By.xpath("//*[text()='Field tag cannot be more than 64 characters']");
	private By locLimitation=By.xpath("//*[text()='Each location coordinate cannot be more than 32 characters']");
	private By bckIdPlaceholder=By.xpath("//span[@class='input-label-message' and text()='Backend ID']/../..//input[@placeholder='Type here']");
	private By assetNamePlaceholder=By.xpath("(//span[@class='input-label-message' and text()='Asset Name']/following::input[@placeholder='Type here'])[1]");
	private By idCodePlaceholder=By.xpath("//span[@class='input-label-message' and text()='Identification Code']/../..//input[@placeholder='Type here']");
	private By criticalityPlaceholder=By.xpath("(//span[@class='input-label-message' and text()='Criticality']/following::input[@placeholder='Type here'])[1]");
	private By assetTypePlaceholder=By.xpath("(//span[@class='input-label-message' and text()='Asset Type']/following::input[@placeholder='Type here'])[1]");
	private By assetModePlaceholder=By.xpath("//span[@class='input-label-message' and text()='Asset Mode']/following::input[@class='react-tagsinput-input']");
	private By contactPlaceholder=By.xpath("//span[@class='input-label-message' and text()='Contact']/../..//input[@placeholder='Type here']");
	private By LocIDPlaceholder=By.xpath("//span[@class='input-label-message' and text()='Location ID']/following::input[@placeholder='Type ID here']");
	private By LocPlaceholder=By.xpath("//span[@class='input-label-message' and text()='Location (GPS coordinates)']/following::input[@placeholder='Type coordinates e.g. 10.12325;15.45601']");
	private By LocDescPlaceholder=By.xpath("//span[@class='input-label-message' and text()='Location Description']/following::input[@placeholder='Type description here']");
	private By SAPTagPlaceholder=By.xpath("(//span[@class='input-label-message' and text()='SAP Tag']/following::input[@placeholder='Type here'])[1]");
	private By DCSTagPlaceholder=By.xpath("(//span[@class='input-label-message' and text()='DCS Tag']/following::input[@placeholder='Type here'])[1]");
	private By HistorianTagPlaceholder=By.xpath("(//span[@class='input-label-message' and text()='Historian Tag']/following::input[@placeholder='Type here'])[1]");
	private By FieldTagPlaceholder=By.xpath("(//span[@class='input-label-message' and text()='Field Tag']/following::input[@placeholder='Type here'])[1]");
	private By OwnerOrgPlaceholder=By.xpath("(//span[@class='input-label-message' and text()='Owner Organization']/following::input[@placeholder='Type here'])[1]");		
	private By closeIcon=By.xpath("//div[@class='close-wrapper']/i");
	private By successAlert=By.xpath("//span[contains(text(),'Asset Added Succesfully')]");
	private By ellipseIcon=By.xpath("//div[contains(@class,'p-datatable')]/table/tbody/tr/td[@class='column-ellipse']");
	private By primaryDetailsLbl=By.xpath("//span[@class='input-label-message' and text()='PRIMARY DETAILS']");
	private By parentLvlLbl=By.xpath("//span[@class='input-label-message' and text()='Parent Level']");
	private By viewMoreLink=By.xpath("//a[contains(text(),'View More')]");
	private By editLink=By.xpath("//*[contains(text(),'Edit')]");
	private By deleteLink=By.xpath("//*[contains(text(),'Delete')]");
	private By type=By.xpath("//span[@class='input-label-message' and contains(text(),'Type')]");
	private By mode=By.xpath("//span[@class='input-label-message' and contains(text(),'Mode')]");
	private By searchAssets=By.xpath("//input[@placeholder='Search assets']");
	private By editAsset=By.xpath("//*[contains(text(),'Edit Asset')]");
	private By editAlert=By.xpath("//*[text()='Asset Edited Successfully']");
	private By getAsset=By.xpath("(//div[contains(@class,'p-datatable')]/table/tbody/tr/td)[2]");
	private By deleteAsset=By.xpath("//*[contains(text(),'Delete Asset')]");
	private By deleteConfirmMsg=By.xpath("//*[contains(text(),'Are you sure you want to delete')]");
	private By confirm=By.xpath("//*[text()='Confirm']");
	private By deleteAlert=By.xpath("//*[contains(text(),'deleted successfully')]");
	private By failedDeleteAlert=By.xpath("//*[contains(text(),'delete failed, please check if assset is assigned to a Round Template')]");
	private By subAssetsTab=By.xpath("//*[text()='Sub Assets']");
	private By addSubAssetIcon=By.xpath("//*[text()='Add Asset']");
	private By searchSubAssets=By.xpath("//input[@placeholder='Global Search']");
	private By searchResult=By.xpath("//div[contains(@class,'p-datatable')]/table/tbody/tr/td[2]");
	private By tableHeader=By.cssSelector("[class='p-datatable-thead']");
	private By emptyRecordstext=By.xpath("//*[text()='No records found']");
	private By enterpriseLevel=By.xpath("//*[text()='Please select a level to view records']");

	//locators
	private By Asset =By.xpath(("(//tr[@class='p-datatable-row']//td)[2]"));
	private By SubAsset=By.xpath(("//a[text()='Sub Assets']"));
	private By Tasks=By.xpath("//a[text()='Tasks']");

	//attachment locators
	private By noDocsImage=By.xpath("//img[@alt='No Documents']");
	private By noDocsText=By.xpath("//*[text()='No attachments added yet']");
	private By addattachment=By.xpath("//a[@data-testid='addattachment']");
	private By attachmentsTab=By.xpath("//a[text()='Attachments']");
	private By addAttachments=By.xpath("//a[text()='Add attachments']");
	private By browseFile=By.xpath("//div[@class='button-content' and text()='Browse File']");
	private By successAttachemntAlert=By.xpath("//span[text()='Attachments Added successfully']");
	private By Dropimgs=By.xpath("//*[text()='Drop images(.xls, .xlsx, .png, .jpg, .jpeg, .pdf, .mp4) file to upload']");
	private By loadingIcon=By.cssSelector("[class='ui loader-wrap loading-alignments loading']");
	private By addTaskIcon=By.xpath("//*[text()='Add Task']");
	private By selectAsbstractAsset=By.xpath("//*[text()='Select Abstract Asset']/../following-sibling::div/input");
	
	public void verifyEmptyMessage(String empMsg) throws Throwable{
		waitForVisibilityOfElement(noAssetText,"NoAssetstext",20);
		verifyTextMatching(noAssetText,empMsg,"Validating no assets message");
	}

	public void verifyEmptyImg() throws Throwable {
		waitForVisibilityOfElement(noAssetImage, "NoAssetImage", 15);
		verifyElementDisplayed(noAssetImage, "Validating no asset image", true);
	}

	public void clickOnsubmitBtn() throws Throwable {
		waitForVisibilityOfElement(submitBtn, "Submittbutton", 15);
		click(submitBtn, "submitBtn");
	}

	public void verifybothemptyvalues() throws Throwable {
		verifyElementDisplayed(assetNameField, "Validating error message", true);
		verifyElementDisplayed(assetTypeField, "Validating error message", true);
	}

	public void enterDetails(String length,String longname) throws Throwable {
		if(length.equalsIgnoreCase("Nonnumeric")){
			waitForVisibilityOfElement(LocPlaceholder,"LocPlaceholder",5);
			setText(LocPlaceholder,longname, "entered LOCATION name");
		}else if(length.equalsIgnoreCase("33chars")){
			waitForVisibilityOfElement(assetModePlaceholder,"assetModePlaceholder",5);
			setText(assetModePlaceholder,longname, "entered assetMode");
			waitForVisibilityOfElement(assetTypePlaceholder,"assetTypePlaceholder",5);
			setText(assetTypePlaceholder,longname, "entered assetType name");
		}else if(length.equalsIgnoreCase("65chars")){
			waitForVisibilityOfElement(SAPTagPlaceholder,"SAPTagPlaceholder",5);
			setText(SAPTagPlaceholder,longname, "entered SAPTag");
			waitForVisibilityOfElement(DCSTagPlaceholder,"DCSTagPlaceholder",5);
			setText(DCSTagPlaceholder,longname, "entered DCSTag");
			waitForVisibilityOfElement(HistorianTagPlaceholder,"HistorianTagPlaceholder",5);
			setText(HistorianTagPlaceholder,longname, "entered HistorianTag");
			waitForVisibilityOfElement(FieldTagPlaceholder,"FieldTagPlaceholder",5);
			setText(FieldTagPlaceholder,longname, "entered FieldTag");
		}else if(length.equalsIgnoreCase("129chars")){
			waitForVisibilityOfElement(bckIdPlaceholder,"bckIdPlaceholder",15);
			setText(bckIdPlaceholder,longname, "entered Backend ID");
			waitForVisibilityOfElement(assetNamePlaceholder,"assetNamePlaceholder",15);
			setText(assetNamePlaceholder,longname, "entered Asset name");
			waitForVisibilityOfElement(idCodePlaceholder,"idCodePlaceholder",5);
			setText(idCodePlaceholder,longname, "entered ID Code");
			waitForVisibilityOfElement(criticalityPlaceholder,"criticalityPlaceholder",5);
			setText(criticalityPlaceholder,longname, "entered criticality name");
			waitForVisibilityOfElement(contactPlaceholder,"contactPlaceholder",5);
			setText(contactPlaceholder,longname, "entered Contact num");
			waitForVisibilityOfElement(OwnerOrgPlaceholder,"OwnerOrgPlaceholder",5);
			setText(OwnerOrgPlaceholder,longname, "entered Owner Org name");
			waitForVisibilityOfElement(LocIDPlaceholder,"LocIDPlaceholder",5);
			setText(LocIDPlaceholder,longname, "entered LOC ID");
			waitForVisibilityOfElement(LocDescPlaceholder,"LocDescPlaceholder",6);
			setText(LocDescPlaceholder,longname, "entered LOC Description");
		}	else if(length.equalsIgnoreCase("1024chars")){			
			longname=getRandomString(1025);
			setText(idCodePlaceholder,longname,"identification code");
		}
	}

	public void verifybothinvalid(String fieldname, String errormsg) throws Throwable {
		if (fieldname.equalsIgnoreCase("location")) {
			verifyTextMatching(locValvalidation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("assettype")) {
			verifyTextMatching(assetTypeValidation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("assetmode")) {
			verifyTextMatching(assetModeValidation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("backendid")) {
			verifyTextMatching(bckIDValidation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("assetname")) {
			verifyTextMatching(assetNameValidation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("criticality")) {
			verifyTextMatching(criticalityValidation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("contact")) {
			verifyTextMatching(contactLimitation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("owner")) {
			verifyTextMatching(ownerOrgLimitation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("locationID")) {
			verifyTextMatching(locIDLimitation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("description")) {
			verifyTextMatching(locDescLimitation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("SAP")) {
			verifyTextMatching(sapTagLimitation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("DCS")) {
			verifyTextMatching(dcsTagLimitation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("Historian")) {
			verifyTextMatching(historianTagLimitation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("Field")) {
			verifyTextMatching(fieldTagLimitation, errormsg, "Validating error message");
		} else if (fieldname.equalsIgnoreCase("identificationCode")) {
			verifyTextMatching(idCodePlaceholder, errormsg, "Validating error message");
		}
	}

	public void clickADDAssetBtn() throws Throwable{
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		waitForVisibilityOfElement(addAssetBtn,"addAssetBtn",5);
		click(addAssetBtn, "ADD ASSET button");
	}

	public void enterAssetDetails(String assetnm) throws Throwable {
		waitForVisibilityOfElement(bckIdPlaceholder,"bckIdPlaceholder",5);
		setText(bckIdPlaceholder,"BCKID"+System.currentTimeMillis(), "entered Backend ID");
		waitForVisibilityOfElement(assetNamePlaceholder,"assetNamePlaceholder",5);
		setText(assetNamePlaceholder,assetnm, "entered Asset name");
		waitForVisibilityOfElement(idCodePlaceholder,"idCodePlaceholder",5);
		setText(idCodePlaceholder,"IDCode"+System.currentTimeMillis(), "entered ID Code");
		waitForVisibilityOfElement(criticalityPlaceholder,"criticalityPlaceholder",5);
		waitForVisibilityOfElement(assetTypePlaceholder,"assetTypePlaceholder",5);
		setText(assetTypePlaceholder,"type"+System.currentTimeMillis(), "entered assetType name");
		waitForVisibilityOfElement(assetModePlaceholder,"assetModePlaceholder",5);
		setText(assetModePlaceholder,"Mode"+System.currentTimeMillis(), "entered assetMode");
		waitForVisibilityOfElement(contactPlaceholder,"contactPlaceholder",5);
		setText(contactPlaceholder,"Contact"+System.currentTimeMillis(), "entered Contact num");
		waitForVisibilityOfElement(OwnerOrgPlaceholder,"OwnerOrgPlaceholder",5);
		setText(OwnerOrgPlaceholder,"Owner"+System.currentTimeMillis(), "entered Owner Org name");
		waitForVisibilityOfElement(LocIDPlaceholder,"LocIDPlaceholder",5);
		//setText(LocIDPlaceholder,"LOCID"+System.currentTimeMillis(), "entered LOC ID");
		//waitForVisibilityOfElement(LocPlaceholder,"LocPlaceholder",5);
		//setText(LocPlaceholder,"21.43", "entered LOCATION name");
		//waitForVisibilityOfElement(LocDescPlaceholder,"LocDescPlaceholder",5);
		//setText(LocDescPlaceholder,"LOCDESC"+System.currentTimeMillis(), "entered LOC Description");
		waitForVisibilityOfElement(SAPTagPlaceholder,"SAPTagPlaceholder",5);
		setText(SAPTagPlaceholder,"SAP"+System.currentTimeMillis(), "entered SAPTag");
		waitForVisibilityOfElement(DCSTagPlaceholder,"DCSTagPlaceholder",5);
		setText(DCSTagPlaceholder,"DCS"+System.currentTimeMillis(), "entered DCSTag");
		waitForVisibilityOfElement(HistorianTagPlaceholder,"HistorianTagPlaceholder",5);
		setText(HistorianTagPlaceholder,"Hist"+System.currentTimeMillis(), "entered HistorianTag");
		waitForVisibilityOfElement(FieldTagPlaceholder,"FieldTagPlaceholder",5);
		setText(FieldTagPlaceholder,"Field"+System.currentTimeMillis(), "entered FieldTag");
	}

	public void verifySuccessAlert(String type) throws Throwable{
		if(type.equalsIgnoreCase("Addition")) {
			
			waitForVisibilityOfElement(successAlert,"successAlert",10);
			verifyElementDisplayed(successAlert,"Validating success message",true);
			click(closeIcon,"Click on cancel button");
		}else if(type.equalsIgnoreCase("Edit")) {
		
			waitForVisibilityOfElement(editAlert,"editAlert",10);
			verifyElementDisplayed(editAlert,"Validating alert message",true);
			click(closeIcon,"Click on cancel button");
		}else if(type.equalsIgnoreCase("Delete")) {
			waitForVisibilityOfElement(deleteAlert,"deleteAlert",50);
			verifyElementDisplayed(deleteAlert,"Validating alert message",true);
			click(closeIcon,"Click on cancel button");
		}else if(type.equalsIgnoreCase("Attachments")){
			waitForVisibilityOfElement(successAttachemntAlert,"successAlert",5);
			verifyElementDisplayed(successAttachemntAlert,"Validating success message",true);
			click(closeIcon,"Click on cancel button");
		}
	}

	public void searchAssets(String asset) throws Throwable {
		waitForVisibilityOfElement(searchAssets, "searchAssets", 5);
		clearText(searchAssets);
		setText(searchAssets, asset, "enter search asset");
		clickEnter(searchAssets);
	}

	public void clickEllipse() throws Throwable {
		waitForVisibilityOfElement(ellipseIcon, "ellipseIcon", 10);
		click(ellipseIcon, "Click ellipseIcon");
	}

	public void selectsearch_result() throws Throwable{
		waitForPageLoaded();
		waitForVisibilityOfElement(searchResult,"editellipseIcon",15);
		click(searchResult, "Edit ellipseIcon");
		waitForPageLoaded();
	}

	public void verifyassetDetailsPage() throws Throwable {
		verifyElementDisplayed(primaryDetailsLbl, "Validating primary Details", true);
		verifyElementDisplayed(parentLvlLbl, "Validating parentLvl Details", true);
		verifyElementDisplayed(backEndLbl, "Validating Details", true);
		verifyElementDisplayed(extendsIDLbl, "Validating  Details", true);
		verifyElementDisplayed(idCodeLbl, "Validating  Details", true);
		verifyElementDisplayed(criticalityLbl, "Validating  Details", true);
		verifyElementDisplayed(type, "Validating  Details", true);
		verifyElementDisplayed(mode, "Validating  Details", true);
		verifyElementDisplayed(contactLbl, "Validating  Details", true);
		verifyElementDisplayed(ownerOrganizationLbl, "Validating  Details", true);
		verifyElementDisplayed(preConditionLbl, "Validating  Details", true);
		verifyElementDisplayed(viewMoreLink, "Validating  Details", true);
		verifyElementDisplayed(locDetailsLbl, "Validating  Details", true);
		verifyElementDisplayed(locIDLbl, "Validating  Details", true);
		verifyElementDisplayed(locationLbl, "Validating  Details", true);
		verifyElementDisplayed(locDescLbl, "Validating  Details", true);
		verifyElementDisplayed(tagDetailsLbl, "Validating  Details", true);
		verifyElementDisplayed(sapTagLbl, "Validating  Details", true);
		verifyElementDisplayed(dcsTagLbl, "Validating  Details", true);
		verifyElementDisplayed(historianTagLbl, "Validating  Details", true);
		verifyElementDisplayed(fieldTagLbl, "Validating  Details", true);
	}

	public void clickOnEditIcon(String link) throws Throwable {
		if (link.equalsIgnoreCase("Edit")) {
			waitForVisibilityOfElement(editLink, "editLink", 5);
			click(editLink, "Edit Icon");
		} else if (link.equalsIgnoreCase("Delete")) {
			waitForVisibilityOfElement(deleteLink, "deleteLink", 5);
			click(deleteLink, "Delete Button");
			verifyElementDisplayed(deleteAsset, "Validating Delete Asset Pop-up", true);
			verifyElementDisplayed(deleteConfirmMsg, "Validating Delete confirmation message", true);
			click(confirm, "Confirm Button");
		}
	}

	public void editDetails(String editassetname) throws Throwable {

		waitForVisibilityOfElement(assetNamePlaceholder, "assetNamePlaceholder", 10);
		clearText(assetNamePlaceholder);
		setText(assetNamePlaceholder, editassetname, "entered Asset name");
		waitForVisibilityOfElement(assetTypePlaceholder, "assetTypePlaceholder", 5);
		clearText(assetTypePlaceholder);
		setText(assetTypePlaceholder, "edittype" + System.currentTimeMillis(), "entered assetType name");
	}

	public void clickOnTab(String tabname) throws Throwable {
		if (tabname.equalsIgnoreCase("Sub Assets")) {
			waitforPresenceofElement(subAssetsTab,"subAssetsTab",15);
			clickJS(subAssetsTab, "SubAssetsTab");
		}else if(tabname.equalsIgnoreCase("Attachments")) {
			scrollBottom();
			waitForPageLoaded();
			waitForVisibilityOfElement(attachmentsTab,"Attachments tab",10);
			setFocusAndClick(attachmentsTab, "Attachment Button");
		}
	}

	public void clickOnIcon(String iconname) throws Throwable{
		if(iconname.equalsIgnoreCase("Add Asset")) {
			
			scrollToWebElement(addSubAssetIcon);
			waitForVisibilityOfElement(addSubAssetIcon,"addSubAssetIcon",10);
			click(addSubAssetIcon,"addSubAssetIcon");
		} else if (iconname.equalsIgnoreCase("Add attachments")) {
			
			scrollToWebElement(addAttachments);
			waitForVisibilityOfElement(addAttachments, "Add attachments", 10);
			click(addAttachments, "Add attachments Button");
		}else if(iconname.equalsIgnoreCase("Add Task")) {
			waitForPageLoaded();
			scrollToWebElement(addTaskIcon);
			click(addTaskIcon, "clicked Add Task icon");
		}
	}

	public void searchSubAssets(String asset) throws Throwable {
		scrollToWebElement(searchSubAssets);
		waitForVisibilityOfElement(searchSubAssets, "searchSubAssets", 5);
		clearText(searchSubAssets);
		setText(searchSubAssets, asset, "enter search asset");
		clickEnter(searchSubAssets);
	}

	//select level hirarchy
	public void selectlevelhirachy(String levelhirarchyname) throws Throwable
	{
		driver.switchTo().defaultContent();
		By mainFrame = By.cssSelector("[class='gwt-Frame']");
		switchToFrame(mainFrame);
		waitforPresenceofElement(enterpriseLevel, "Enterprise level message", 10);
		waitForPageLoaded();
		By selectlevlhirarchy = By.xpath("//div[text()='" + levelhirarchyname + "']");
		List<WebElement> list = driver.findElements(By.cssSelector("[class='loader-content'] [class='content']"));		 
		for(int i=0;i<list.size();i++){
			if(isElementPresent(selectlevlhirarchy, "Level")){
				setFocusAndClick(selectlevlhirarchy, "Select levelhirarchyfrom round template");
				break;
			}else{
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",list.get(i));
			}
		}
	}

	//click on Asset
	public void clickonAsset() throws Throwable
	{
		waitForPageLoaded();
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 20);
		waitForVisibilityOfElement(Asset,"Asset",15);
		click(Asset,"Click on Asset");
	}

	// click on Sub Assets
	public void clickonSubAsset() throws Throwable {
		waitForVisibilityOfElement(SubAsset, "Click on SubAsset", 15);
		click(SubAsset, "Click on SubAsset");
	}

	// validatig sorting in assets page
	@SuppressWarnings("unchecked")
	public void Validate_Sorting() throws Throwable {

		@SuppressWarnings("rawtypes")
		ArrayList obtainedlist = new ArrayList();
		String value = "";
		By count = By.xpath("//thead[@class='p-datatable-thead']//th");
		waitForVisibilityOfElement(count, "count", 10);
		int rowscount = getElementsSize(count);
		for (int i = 2; i <= rowscount - 1; i++) {
			// click on sort button for ascending order
			By sortingbutton = By.xpath("//thead[@class='p-datatable-thead']/tr/th[" + i + "]//span[2]");
			waitForVisibilityOfElement(sortingbutton, "sortingbutton", 15);
			driver.findElement(sortingbutton).click();
			int columncount = driver.findElements(By.xpath("//tbody[@class='p-datatable-tbody']//tr[" + i + "]/td"))
					.size();
			obtainedlist.clear();
			for (int j = 1; j <= columncount - 1; j++) {
				value = driver.findElement(By.xpath("//tbody[@class='p-datatable-tbody']//tr[" + j + "]/td[" + i + "]"))
						.getText();
				try {
					Integer val = Integer.valueOf(value);
					obtainedlist.add(val);
				} catch (Exception ex) {
					obtainedlist.add(value);
				}
			}
			//	sorting_isAscending(obtainedlist);
			// click on sort button for descending order
			sortingbutton = By.xpath("//thead[@class='p-datatable-thead']/tr/th[" + i + "]//span[2]");
			waitForVisibilityOfElement(sortingbutton, "sortingbutton", 10);
			driver.findElement(sortingbutton).click();
			obtainedlist.clear();
			for (int j = 1; j <= columncount - 1; j++) {
				value = driver.findElement(By.xpath("//tbody[@class='p-datatable-tbody']//tr[" + j + "]/td[" + i + "]"))
						.getText();
				try {
					Integer val = Integer.valueOf(value);
					obtainedlist.add(val);
				} catch (Exception ex) {
					obtainedlist.add(value);
				}
			}
			//	sorting_isDescending(obtainedlist);
		}
	}

	//Click on Cal button
	public void clickCancel() throws Throwable{
		waitForVisibilityOfElement(cancelBtn,"Click on Cancel",15);
		click(cancelBtn,"Click on Cancel");
	}

	//
	public void verifyTable() throws Throwable{
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		waitForVisibilityOfElement(noAssetText,"NoAssetstext",20);
		//		Commented since this logic doesn't work because currently behaviour is changed
		//		By loc=By.cssSelector("[class='p-datatable-row'] div");
		//		waitForVisibilityOfElement(loc, "Table records", 10);
		//		List<WebElement> elems=driver.findElements(loc);
		//
		//		if(elems.size()>0){
		//			logfailinfo("Verify updated record in table");
		//		}else{
		//			System.out.println("Verify updated record in table");
		//		}
	}

	public void verifyNoDocsImg() throws Throwable{
		waitForVisibilityOfElement(noDocsImage,"NoDocsImage",15);
		verifyElementDisplayed(noDocsImage,"Validating no attachments image",true);
	}

	public void verifyDocsEmptyMessage(String empMsg) throws Throwable{
		waitForVisibilityOfElement(noDocsText,"NoAttachmentstext",20);
		verifyTextMatching(noDocsText,empMsg,"Validating no attachemnts message");
	}

	public void verifyDeviceType(String devicetype) throws Throwable{
		
		By loc=By.cssSelector("[class='p-datatable-row'] div");
		waitForVisibilityOfElement(loc, "Table records", 10);
		List<WebElement> elems = driver.findElements(loc);
		String expUser=elems.get(2).getText();
		System.out.println(expUser);
		if(devicetype.equalsIgnoreCase(expUser)){
			System.out.println("Verify updated record in user table");
		} else {
			System.out.println("Failed to update device");
		}
		//reporter.SuccessReportWithScreenshot("Final verification screenshot", "", driver);
	}
		
	

	public void entersubAssetDetails(String assetnm) throws Throwable {
		waitForVisibilityOfElement(bckIdPlaceholder,"bckIdPlaceholder",5);
		setText(bckIdPlaceholder,"BCKID"+System.currentTimeMillis(), "entered Backend ID");
		waitForVisibilityOfElement(assetNamePlaceholder,"assetNamePlaceholder",5);
		setText(assetNamePlaceholder,assetnm, "entered Asset name");
		waitForVisibilityOfElement(idCodePlaceholder,"idCodePlaceholder",5);
		setText(idCodePlaceholder,"IDCode"+System.currentTimeMillis(), "entered ID Code");
		waitForVisibilityOfElement(criticalityPlaceholder,"criticalityPlaceholder",5);
		waitForVisibilityOfElement(assetTypePlaceholder,"assetTypePlaceholder",5);
		setText(assetTypePlaceholder,"type"+System.currentTimeMillis(), "entered assetType name");
		waitForVisibilityOfElement(assetModePlaceholder,"assetModePlaceholder",5);
		setText(assetModePlaceholder,"Mode"+System.currentTimeMillis(), "entered assetMode");
		waitForVisibilityOfElement(contactPlaceholder,"contactPlaceholder",5);
		setText(contactPlaceholder,"Contact"+System.currentTimeMillis(), "entered Contact num");
		waitForVisibilityOfElement(OwnerOrgPlaceholder,"OwnerOrgPlaceholder",5);
		//			setText(OwnerOrgPlaceholder,"Owner"+System.currentTimeMillis(), "entered Owner Org name");
		waitForVisibilityOfElement(LocIDPlaceholder,"LocIDPlaceholder",5);
		//			setText(LocIDPlaceholder,"LOCID"+System.currentTimeMillis(), "entered LOC ID");
		//			waitForVisibilityOfElement(LocPlaceholder,"LocPlaceholder",5);
		//			setText(LocPlaceholder,"21.43", "entered LOCATION name");
		//			waitForVisibilityOfElement(LocDescPlaceholder,"LocDescPlaceholder",5);
		//			setText(LocDescPlaceholder,"LOCDESC"+System.currentTimeMillis(), "entered LOC Description");
		waitForVisibilityOfElement(SAPTagPlaceholder,"SAPTagPlaceholder",5);
		setText(SAPTagPlaceholder,"SAP"+System.currentTimeMillis(), "entered SAPTag");
		waitForVisibilityOfElement(DCSTagPlaceholder,"DCSTagPlaceholder",5);
		setText(DCSTagPlaceholder,"DCS"+System.currentTimeMillis(), "entered DCSTag");
		waitForVisibilityOfElement(HistorianTagPlaceholder,"HistorianTagPlaceholder",5);
		setText(HistorianTagPlaceholder,"Hist"+System.currentTimeMillis(), "entered HistorianTag");
		waitForVisibilityOfElement(FieldTagPlaceholder,"FieldTagPlaceholder",5);
		setText(FieldTagPlaceholder,"Field"+System.currentTimeMillis(), "entered FieldTag");
	}

	//click on Sub Assets
	public void clickonTasks() throws Throwable
	{
		waitForVisibilityOfElement(Tasks,"Click on Tasks",15);
		click(Tasks,"Click on Tasks");
	}

	//click on BrowseFile button in BrowserPop
	public void verifyAttachemntsBrowsepopupmsg() throws Throwable{
		verifyElementDisplayed(Dropimgs,"Drop an excel file message",true);
		verifyElementDisplayed(browseFile,"Browse  files button",true);
		click(browseFile, "Browse Button");
	}

	public void clickOnEllipse() throws Throwable{
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		By locator=By.cssSelector("[class='popup-pointer']");
		waitForVisibilityOfElement(locator, "Three Dots",15);
		List<WebElement> elems=driver.findElements(locator);
		elems.get(0).click();	
	}

	public void verifysubassetTable() throws Throwable{
		
		waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
		waitForVisibilityOfElement(tableHeader,"Header of the taable",20);
		isElementDisplayed(emptyRecordstext, "Norecords found");
	}
	
	public void verifyAssetConfigurationHeader() throws Throwable{
		waitForVisibilityOfElement(assetConfigurationHeader, "Asser config Header Available", 10);
		isElementDisplayed(assetConfigurationHeader, "Asset configuration");
	}
	
	public void enterAssetName(String assetname) throws Throwable{
		waitForVisibilityOfElement(assetNameField, "asset name", 10);
		setText(assetNameField, assetname, "Asset Name");
	}
	public void enterUnitName(String unitName) throws Throwable{
		By assetUnitName=By.cssSelector("[data-testid='asset-unitName']");
		click(assetUnitName, "assetUnitName");
		waitForPageLoaded();
		By unitNameL=By.xpath("//*[text()="+unitName+"");
        click(unitNameL, "unitName");
	}
	public void clickOnInheritFromAbstractAssetCheckbox() throws Throwable{
		waitForVisibilityOfElement(inheritCheckbox, "asset name", 10);
		click(inheritCheckbox, "inheritCheckbox");
	}
	public void selectAbstractAsset() throws Throwable{
		waitForVisibilityOfElement(selectAsbstractAsset, "selectAsbstractAsset", 10);
		pressTab(selectAsbstractAsset);
		driver.findElement(selectAsbstractAsset).sendKeys(Keys.ENTER);
	}
	public void checkAssetTypeStatus(boolean flag) throws Throwable{
		if(flag){
			driver.findElement(assetTypePlaceholder).isEnabled();
		}else{
			driver.findElement(assetTypePlaceholder).isDisplayed();
		}
		
	}
}
