package seleniumUtilities;


import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;

import common.reports.ReporterConstants;
import io.cucumber.java.Scenario;
import steps.Hooks;


/**
 * Framework level reusable selenium custom methods
 * 
 * @author Sai Kodadala
 *
 */

public class GenericMethods extends BaseRunner {

	SoftAssert softassertion=new SoftAssert();
	public final Logger LOG = Logger.getLogger(GenericMethods.class);
	private static final long DEFAULT_TIMEOUT_SEC = 90;
	private static final int SLEEP_MILLI_SEC = 1000;

	public WebDriverWait wait ;
	ExtentTest step ;

	//set log message
	public void loginfo(String loginfomessage) {
		step=ExtentCucumberAdapter.getCurrentStep();
		step.log(Status.INFO,loginfomessage);
	}


	//set pass message
	public void logpassinfo(String successmessage) {
		step=ExtentCucumberAdapter.getCurrentStep();
		step.log(Status.PASS,successmessage);
	}

	//set failure message
	public void logfailinfo(String failuremessage) {
		step=ExtentCucumberAdapter.getCurrentStep();
		System.out.println("Failure reason ---->> "  + failuremessage);
		step.log(Status.FAIL,failuremessage);
		Assert.fail(failuremessage);
	}




	//Locators for pagination


	/* Action Engine Methods */

	/**
	 * selectDropdownByIndex Selects the option at the given index in the dropdown
	 * specified by the given locator and logs the selection
	 * 
	 * @param locator     of (By) - the specification of the location of the
	 *                    dropdown selector element
	 * @param index       of (int) the index of the option that's being selected
	 *                    from the dropdown Here index starts with Zero(0)
	 * @param locatorName of (String) label, or short description of the dropdown
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean selectDropdownByIndex(By locator, int index, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			Select s = new Select(driver.findElement(locator));
			s.selectByIndex(index);
			flag = true;
			return true;
		} catch (Exception e) {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());			
			throw new RuntimeException(e);
		} 
	}

	/**
	 * selectDropdownByValue Selects the option with the given value in the dropdown
	 * specified by the given locator and logs the selection
	 *
	 * @param locator     of (By)
	 * @param value       of (String) - the 'value' name of the option that's being
	 *                    selected from the dropdown
	 * @param locatorName of (String) - label or short description of the dropdown
	 * @return boolean
	 * @throws Throwable the throwable
	 */

	protected boolean selectDropdownByValue(By locator, String value, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			//Need to add explicit waits
			Select s = new Select(driver.findElement(locator));
			s.selectByValue(value);
			flag = true;
			LOG.info("Successfully selected the value" + locatorName);
			return true;
		} catch (Exception e) {
			logfailinfo("Element is not found " + locatorName);
			//	//	softassertion.fail("Element is not found " + locatorName  + e.getMessage());
			//	//	softassertion.assertAll();
		}
		return flag;
	}

	/**
	 * selectDropdownByVisibleText - Selects the option with the given displayed
	 * name in the dropdown specified by the given locator
	 *
	 * @param locator     of (By)
	 * @param visibleText of (String) - the displayed name of the option that's
	 *                    being selected from the dropdown
	 * @param locatorName of (String) - label or short description of the dropdown
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean selectDropdownByVisibleText(By locator, String visibleText, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			//Need to add explicit waits
			Select s = new Select(driver.findElement(locator));
			s.selectByVisibleText(visibleText.trim());
			flag = true;
			return true;
		} catch (Exception e) {
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName + "    + "  + e.getMessage());
			//	softassertion.assertAll();
		}
		return flag; 
	}

	/**
	 * elementEnabled verifies whether the condition matches to the given String method
	 * using if else statement Method will return true or false depending on the
	 * outcome
	 *
	 * @param condition of (boolean)
	 * @param message   of (String) - Short description of the message
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean elementEnabled(boolean condition, String message) throws Throwable {
		try {
			if(condition == true) {
				//	reporter.SuccessReport("Check Point", message);
			}	
			//	reporter.SuccessReport("Check Point", message);
		} catch (Exception e) {
			logfailinfo("Element is not enabled " + message);
			//	softassertion.fail("Element is not enabled " + message);
			//	softassertion.assertAll();
		}
		return condition;
	}

	/**
	 * elementDisabled verifies whether the condition does not match to the given String
	 * method using if else statement Method will return true or false depending on
	 * the outcome
	 *
	 * @param condition of (boolean)
	 * @param message   of (String) - Short description of the message
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean elementDisabled(boolean condition, String message) throws Throwable {
		try {
			if(condition == false) {
				//	reporter.SuccessReport("Check Point", message);
			}			
		} catch (Exception e) {
			logfailinfo("Element is not disabled " + message);
			//	softassertion.fail("Element is not enabled " + message);
			//	softassertion.assertAll();
		}
		return condition;
	}



	/**
	 * assertElementPresent checks the presence of an element on the page will
	 * assert that the given condition is true if the element is present on the page
	 *
	 * @param by          of (By)
	 * @param locatorName of (String) - Name of the locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean assertElementPresent(By by, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			Assert.assertTrue(isElementPresent(by, locatorName));
			flag = true;
		} catch (Exception e) {
			logfailinfo("Element is not present " + locatorName);
			//	softassertion.fail("Element is not present " + locatorName  + e.getMessage());
			//	softassertion.assertAll();
		} 
		return flag;
	}


	//Wait for the visiblity of element
	protected void waitForVisibilityOfElement(By by,String locatorName,int time) throws Throwable {

		try {
			wait = new WebDriverWait(driver, time);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		} catch (Exception e) {	
			logfailinfo("Element is not visible " + locatorName);
			//	softassertion.fail("Element is not visible " + locatorName  + "   " + e.getMessage());
			//	softassertion.assertAll();
		} 
	}

	//Wait for the visiblity of list of elements
	protected void waitForVisibility_Elements(By by,String locatorName, int time) {

		try {
			wait = new WebDriverWait(driver,time);
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
		}
		catch (Exception e) {
			logfailinfo("List of Elements are not found " + locatorName);
			//	softassertion.fail("List of Elements are not found " + locatorName  + "   " + e.getMessage());
			//	softassertion.assertAll();
		}
	}

	//Wait for the invisiblity of element
	protected void waitForInVisibilityOfElement(By by,String locatorName,int time) throws Throwable {
		LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
		LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
		try {
			wait = new WebDriverWait(driver, time);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
		} catch (Exception e) {
			logfailinfo("Element is visible,suppose to be invisible " + locatorName);
			//	softassertion.fail("Element is visible,suppose to be invisible " + locatorName  + "   " + e.getMessage());
			//	softassertion.assertAll();
		}
	}

	//Wait Element to be clickable
	protected void waitforElementtobeClickable(By by,String locatorName,int time) {
		try {
			wait = new WebDriverWait(driver, time);
			wait.until(ExpectedConditions.elementToBeClickable(by));
		}
		catch (Exception e) {
			logfailinfo("Wait for the element to be click but not found " + locatorName);
			//	softassertion.fail("Wait for the element to be click but not found " + locatorName  + "   " + e.getMessage());		
			//	softassertion.assertAll();
		}
	}

	// Wait Element to be present
	protected void  waitforPresenceofElement(By by,String locatorName,int time) {
		try {
			wait = new WebDriverWait(driver,time);
			wait.until(ExpectedConditions.presenceOfElementLocated(by));
		}
		catch (Exception e) {
			logfailinfo("Wait for the element to be present but not found " + locatorName);
			//	softassertion.fail("Wait for the element to be present but not found " + locatorName  + "   " + e.getMessage());
			//	softassertion.assertAll();
		}
	}

	//Wait for the presence of list of elements
	protected void waitforPresence_Elements(By by,String locatorName,int time) {
		try {
			wait = new WebDriverWait(driver,time);
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(by));
		}
		catch (Exception e) {
			logfailinfo("Wait for the element to be present but not found " + locatorName);
			//	softassertion.fail("Wait for the element to be present but not found " + locatorName  + "   " + e.getMessage());
			//	softassertion.assertAll();
		}
	}

	/**
	 * waitTime - waits the execution time
	 *
	 * @throws Throwable the throwable
	 */
	// TODO
	private void waitTime() throws Throwable {
		String time = ReporterConstants.Timeout;
		long timeValue = Long.parseLong(time);
		Thread.sleep(timeValue);
		LOG.info("Time out value is : " + timeValue);
	}

	/**
	 * getElementsSize returns the size of the list of elements
	 *
	 * @param locator of (By)
	 * @return int
	 */
	protected int getElementsSize(By locator) {
		int a = 0;
		try {
			List<WebElement> rows = driver.findElements(locator);
			a = rows.size();
		} catch (Exception e) {
			logfailinfo("Element is not found " + locator);
			//	softassertion.fail("Element is not found " + locator);
			//	softassertion.assertAll();
		}
		return a;
	}

	/**
	 * assertTextMatching verifies whether actual text using locator and getText
	 * method matches to the text provided
	 *
	 * @param by          of (By)
	 * @param text        of (String)
	 * @param locatorName of (String) - Name of the element/locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean verifyTextMatching(By by, String text, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			String ActualText = getText(by, locatorName).trim();
			LOG.info("ActualText is : " + ActualText);

			if (ActualText.contains(text.trim())) {
				flag = true;
				LOG.info("String comparison with actual text :: " + "actual text is : " + ActualText+ "And expected text is : " + text);

			} else{
				logfailinfo("String comparison with actual text, expected text is not matching " + locatorName);
				//	softassertion.fail("Expected " + text + "actual are not equal"  + ActualText);	
				//	softassertion.assertAll();
			}
		} catch (Exception e) {
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Expected & actual are not match") ;	
			//	softassertion.assertAll();
		} 
		return flag;
	}

	/**
	 * MethodName : refresh browser
	 * @throws Throwable 
	 */
	public void refreshBrowser() throws Throwable{
		driver.navigate().refresh();
		this.waitForPageLoaded();
	}

	/**
	 * assertTextMatchingWithAttribute verifies whether actual text using locator
	 * and getAttribute method and matches to the given text
	 *
	 * @param by          of (By)
	 * @param text        of (String) - Expected Text for comparison
	 * @param locatorName of (String) - Name of the element/locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean assertTextMatchingWithAttribute(By by, String text, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			String ActualText = getTextAttributeByValue(by, locatorName).trim();
			LOG.info("ActualText is" + ActualText);
			if (ActualText.contains(text.trim())) {
				flag = true;
				LOG.info("String comparison with actual text :: " + "actual text is :" + ActualText
						+ "And expected text is : " + text);
			}
			if(!flag){
				logfailinfo("String comparison with actual text and expected text is not matching " + locatorName);
				//	softassertion.fail("Expected " + text + "actual are not equal"  + ActualText);
				//	softassertion.assertAll();
			}
		} catch (Exception e) {
			logfailinfo("Element is not found " + locatorName);
		} 
		return flag;
	}

	/**
	 * verifyTextEquals - Comparing both actual and expected strings
	 *
	 * @param actText of (String)
	 * @param expText of (String)
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean verifyTextEquals(String actText, String expText) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			String ActualText = actText.trim();
			LOG.info("act - " + ActualText);
			LOG.info("exp - " + expText);
			if (ActualText.equalsIgnoreCase(expText.trim())) {
				LOG.info("in if condition");
				flag = true;

			} 
			if(!flag){
				logfailinfo("Expected and actual texts are not equals");
				//	softassertion.fail("Expected " + expText + "actual are not equal"  + ActualText);
				//	softassertion.assertAll();
			}
		} catch (Exception e) {			
			logfailinfo("Exception --> "+ e.getMessage());

		} 
		return flag;
	}

	/**
	 * click - Perform click event on locator with an explicit wait of 30 seconds
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String)
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean click(By locator, String locatorName) throws Throwable {
		boolean status = false;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : click  ::  Locator : " + locatorName);
			waitForVisibilityOfElement(locator, locatorName, 15);
			waitforElementtobeClickable(locator, locatorName, 15);
			driver.findElement(locator).click();
			status = true;
		} catch (Exception e) {
			status = false;
			logfailinfo("Element is not clicked " + locatorName);
			//	softassertion.fail("Element is not clicked " + locatorName);
			//	softassertion.assertAll();
		} 
		return status;
	}

	/**
	 * Status Verification on report
	 * @throws Throwable 
	 */
	public void statusVerification(String message) throws Throwable{
		//	reporter.SuccessReport("********Verification of**** "+message , "Successfully verified: " +message);
	}

	/**
	 * setFocusAndClick using actions class method move to the specific element and
	 * then click on that element
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String)
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean setFocusAndClick(By locator, String locatorName) throws Throwable {
		boolean status = false;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : click  ::  Locator : " + locatorName);
			WebElement element = driver.findElement(locator);
			Actions actions = new Actions(driver);
			actions.moveToElement(element).click().build().perform();
			LOG.info("identified the element to focus :: " + locator);
			status = true;
		} catch (Exception e) {
			status = false;
			LOG.info(e.getMessage());
			logfailinfo("Element is not clicked " + locatorName);
			//	softassertion.fail("Element is not clicked " + locatorName);
			//	softassertion.assertAll();
		}
		return status;
	}


	/**
	 * isElementPresent to determine if an element is present on the page without if
	 * else statement
	 *
	 * @param by          of (By)
	 * @param locatorName of (String) - Name of the element
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean isElementPresent(By by, String locatorName) throws Throwable {
		boolean status;
		try {
			waitTime();
			driver.findElement(by);
			status = true;
		} catch (Exception e) {
			status = false;
			LOG.info(e.getMessage());
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName);
			//	softassertion.assertAll();
		}
		return status;
	}

	/**
	 * isElementNotPresent
	 *
	 * @param by          of (By)
	 * @param locatorName of (String) - Name of the element
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean isElementNotPresent(By by, String locatorName) throws Throwable {
		boolean status = true;
		int count;
		try {
			String time = ReporterConstants.MIN_TIMEOUT;
			int timevalue = Integer.parseInt(time);
			WebDriverWait wait = new WebDriverWait(driver, timevalue);
			//wait.until(ExpectedConditions.presenceOfElementLocated(by));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
			//driver.findElement(by);
			count = driver.findElements(by).size();
			status = false;
			System.out.println("count is "+count);
			if(count>0){
				logfailinfo("Element is not displayed " + locatorName);
				Assert.fail("Element is not displayed " + locatorName);
			}
			//	reporter.SuccessReport("isElementNotPresent : " + locatorName, locatorName + " is not visible");
		} catch (Exception e) {
			status = true;
			LOG.info(e.getMessage());
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName);	
			//	softassertion.assertAll();
		}
		return status;
	}

	/**
	 * moveToElement using actions class method move to the specific element
	 *
	 * @param by          of (By)
	 * @param locatorName of (String) - Name of the element/locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean moveToElement(By by, String locatorName) throws Throwable {
		boolean status = false;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName());
			WebElement element = driver.findElement(by);
			Actions actions = new Actions(driver);
			actions.moveToElement(element);
			actions.build().perform();
			LOG.info("Scroll is performed : " + locatorName);
			status = true;
		} catch (Exception e) {
			e.getMessage();
			logfailinfo("Element is not move/hover " + locatorName);
			//	softassertion.fail("Element is not move/hover " + locatorName);
			//	softassertion.assertAll();
		}
		return status;
	}

	/**
	 * verifyElementDisplayed - Verify whether the element is present or not
	 *
	 * @param by          of (By)
	 * @param locatorName of (String) - Name of the Element
	 * @param expected    true
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean verifyElementDisplayed(By by, String locatorName, boolean expected) throws Throwable {
		boolean status = expected;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			if (expected == true){
				if (driver.findElement(by).isDisplayed()) {
					LOG.info("Element is available :: " + locatorName);
					status = true;
				} else {
					logfailinfo("Element is not displayed " + locatorName);
					//	softassertion.fail("Element is not displayed " + locatorName );
					//	softassertion.assertAll();
				}
			}
		} catch (Exception e) {
			status = false;
			LOG.info(e.getMessage());
		} 

		return status;
	}

	/**
	 * setText - Clear the value from element and Enter the text
	 *
	 * @param locator     of (By)
	 * @param testData    of (String) - Test Data to be entered in element
	 * @param locatorName of (String) -- Name of the locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected void setText(By locator, String testData, String locatorName) throws Throwable {
		boolean status = false;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : Type  ::  Locator : " + locatorName + " :: Data :" + testData);
			LOG.info("Locator is Visible :: " + locator);
			driver.findElement(locator).clear();
			LOG.info("Cleared the existing Locator data : ");
			driver.findElement(locator).sendKeys(testData);
			LOG.info("Set Data in Locator :: " + testData);
			this.waitForPageLoaded();
			status = true;
		} catch (Exception e) {
			status = false;
			logfailinfo("Fail to enter the  text for the element is " + locatorName);
			//	softassertion.fail("Fail to enter the  text for the element is " + locatorName);
			//	softassertion.assertAll();
		} 
	}

	/**
	 * setTextWithoutClear -- Enter the text in element without clearing the
	 * previous value
	 *
	 * @param locator     of (By)
	 * @param testData    of (String) - Test Data to be entered
	 * @param locatorName of (String) - Name of the locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean setTextWithoutClear(By locator, String testData, String locatorName) throws Throwable {
		boolean status;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : Type  ::  Locator : " + locatorName + " :: Data :" + testData);
			driver.findElement(locator).sendKeys(testData);
			LOG.info("Typed the Locator data :: " + testData);
			//		reporter.SuccessReport("Enter text in :: " + locatorName, msgTypeSuccess + "'" + testData + "'");
			status = true;
		} catch (Exception e) {
			status = false;
			LOG.info(e.getMessage());
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName);
			//	softassertion.assertAll();
		}
		return status;
	}

	/**
	 * setTextUsingJSE -- Set Text Using Java Script Executor when send keys doesn't
	 * work
	 *
	 * @param locator     of (By)
	 * @param testData    of (String)
	 * @param locatorName of (String)
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean setTextUsingJSE(By locator, String testData, String locatorName) throws Throwable {
		boolean status;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + locatorName);
			waitTime();
			WebElement searchbox = driver.findElement(locator);
			JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
			myExecutor.executeScript("arguments[0].value=' " + testData + "'; ", searchbox);
			//	reporter.SuccessReport("Enter text in :: " + locatorName, msgTypeSuccess + locatorName);
			status = true;
		} catch (Exception e) {
			status = false;
			LOG.info(e.getMessage());
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName);
			//	softassertion.assertAll();
		}
		return status;
	}

	/**
	 * setTextWithTab - after entering the text it will click on tab to select value
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String) -- Name of the locator
	 * @throws Throwable the throwable
	 */
	protected void setTextWithTab(By locator, String locatorName) throws Throwable {
		boolean status = false;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			//	WebDriverWait wait = new WebDriverWait(driver, 15);
			LOG.info("Waiting for element :");
			//	wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			LOG.info("Locator is Visible :: " + locator);
			driver.findElement(locator).sendKeys(Keys.TAB);
			status = true;
		} catch (Exception e) {
			status = false;
			LOG.info(e.getMessage());
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName);
			//	softassertion.assertAll();
		}
	}

	/**
	 * getPageTitle - Get title of the page
	 *
	 * @return String
	 * @throws Throwable the throwable
	 */
	protected String getPageTitle() throws Throwable {
		String text = driver.getTitle();
		{
			//		reporter.SuccessReport("Title :: ", "Title of the page is :: " + text);
		}
		return text;
	}

	/**
	 * getText -- Get text of the given locator
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String) - Name of the locator
	 * @return String - Returns text from given locator
	 * @throws Throwable the throwable
	 */
	protected String getText(By locator, String locatorName) throws Throwable {
		String text = "";
		boolean flag = false;
		LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
		try {
			waitTime();
			boolean value = isElementDisplayed(locator, locatorName);
			if (value) {
				text = driver.findElement(locator).getText();
				LOG.info("Locator is Visible and text is retrieved :: " + text);
				flag = true;
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		} 
		return text;
	}

	/**
	 * getText -- Get text of the given locator
	 *
	 * @param locator of (By)
	 * @return String - Returns text from given locator
	 * @throws Throwable the throwable
	 */
	protected String getText(By locator) throws Throwable {
		String text = "";
		boolean flag = false;
		LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
		try {
			// waitTime();
			text = driver.findElement(locator).getText();
			LOG.info("Locator is Visible and text is retrieved :: " + text);
			flag = true;
		} catch (Exception e) {
			logfailinfo("Element is not found " + locator);
			//	softassertion.fail("Element is not found " + locator);
			//	softassertion.assertAll();
		}
		return text;
	}

	/**
	 * getTextAttributeByValue -- Get the value of the given locator
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String) -- Name of the locator/element
	 * @return String
	 * @throws Throwable the throwable
	 */

	protected String getTextAttributeByValue(By locator, String locatorName) throws Throwable {
		String text = null;
		boolean flag = false;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName());
			waitTime();
			boolean waitForValue = isElementDisplayed(locator, locatorName);
			if (waitForValue) {
				text = driver.findElement(locator).getAttribute("value");
				if (text.equals("")) {
					LOG.info("Locator is Visible and attribute value is retrieved :: and it is Null");
					flag = false;
				} else {
					LOG.info("Locator is Visible and attribute value is retrieved :: " + text);
					flag = true;
				}
			}
		} catch (Exception e) {
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName);
			//	softassertion.assertAll();
		} 
		return text;
	}

	/**
	 * getAttributeByClass - Get the class of the given locator
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String) - Name of the element
	 * @return String
	 * @throws Throwable the throwable
	 */
	protected String getAttributeByClass(By locator, String locatorName) throws Throwable {
		String text = "";
		boolean flag = false;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName());
			waitTime();
			if (isElementPresent(locator, locatorName)) {
				text = driver.findElement(locator).getAttribute("class");
				LOG.info("Locator is Visible and attribute value is retrieved :: " + text);
				flag = true;
			}
		} catch (Exception e) {
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName);
			//	softassertion.assertAll();
		}
		return text;
	}

	/**
	 * Moves the mouse to the middle of the element. The element is scrolled into
	 * view and its location is calculated using getBoundingClientRect.
	 *
	 * @param locator     : Action to be performed on element
	 * @param locatorName : Meaningful name to the element (Ex:link,menus etc..)
	 */
	protected boolean mouseHover(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Mouse over start :: " + locatorName);
			WebElement mo = driver.findElement(locator);
			new Actions(driver).moveToElement(mo).build().perform();

			flag = true;
			LOG.info("Mouse over End :: " + locatorName);
			return true;
		} catch (Exception e) {
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName);
			//	softassertion.assertAll();
		}
		return flag; 
	}

	/**
	 * MouseHoverJS - Hover the mouse using javascript if actions class is not
	 * working
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String) - Name of the locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean mouseHoverJS(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method :" + getCallerMethodName() + "  ::  Locator : " + locatorName);
			WebElement HoverElement = driver.findElement(locator);
			String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
			((JavascriptExecutor) this.driver).executeScript(mouseOverScript, HoverElement);
			LOG.info("JSmousehover is performed  on :: " + locatorName);
			flag = true;
		} catch (Exception e) {
			logfailinfo("Exception --> "+ e.getMessage());
			//	softassertion.fail("Exception --> "+ e.getMessage());
			//	softassertion.assertAll();
			e.printStackTrace();
			flag = false;
		} 
		return flag;
	}

	/**
	 * clickJS - Wait for the Element and Perform click operation using JavaScript
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String) -- Name of the locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean clickJS(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);

			WebElement element = driver.findElement(locator);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			flag = true;
		} catch (Exception e) {
			logfailinfo("Element is not clicked " + locatorName);
			//	softassertion.fail("Element is not clicked " + locatorName);
			//	softassertion.assertAll();
		} 
		return flag;
	}

	/**
	 * getWebElementList - Get list of elements presented on webpage and return all
	 * elements
	 *
	 * @param by          of (By)
	 * @param locatorName of (String)
	 * @return List<WebElement>
	 * @throws Throwable the throwable
	 */
	protected List<WebElement> getWebElementList(By by, String locatorName) throws Throwable {
		List<WebElement> elements = null;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method :" + getCallerMethodName() + "  ::  Locator : " + locatorName);
			elements = driver.findElements(by);
			LOG.info("Size of List ::" + elements.size());
			for (WebElement element : elements) {
				LOG.info("List value are :: " + element.getText());
			}
		} catch (Exception e) {
			logfailinfo("No elements present to get " + locatorName);
			//	softassertion.fail("No elements present to get " + locatorName);
			//	softassertion.assertAll();
		}
		return elements;
	}

	/**
	 * elementVisibleTime - Time taken to load the element on a page
	 *
	 * @param locator of (By)
	 * @throws Throwable the throwable
	 */
	protected void elementVisibleTime(By locator) throws Throwable {
		float timeTaken;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			long start = System.currentTimeMillis();
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			long stop = System.currentTimeMillis();
			timeTaken = (stop - start) / 1000;
			LOG.info("Took : " + timeTaken + " secs to display the results : ");
			//			reporter.SuccessReport("Total time taken for element visible :: ","Time taken load the element :: " + timeTaken + " seconds");
		} catch (Exception e) {
			e.getMessage();
			logfailinfo("Element is not visible " + locator);
		}
	}

	/**
	 * dragAndDrop -- Moves the mouse to the middle of the element. The element is
	 * scrolled into view and its location is calculated using
	 * getBoundingClientRect.
	 *
	 * @param destinationLocator : Action to be performed on element
	 * @param locatorName        : Meaningful name to the element (Ex:link,menus
	 *                           etc..)
	 */
	protected boolean dragAndDrop(By souceLocator, By destinationLocator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			Actions builder = new Actions(driver);
			WebElement souceElement = driver.findElement(souceLocator);
			WebElement destinationElement = driver.findElement(destinationLocator);
			builder.dragAndDrop(souceElement, destinationElement).build().perform();
			flag = true;
			LOG.info("drag and drop performed ");
			return true;
		} catch (Exception e) {
			logfailinfo("Exception --> "+ e.getMessage());
			throw new RuntimeException(e);
		} 
	}

	/**
	 * getCurrentUrl - Get the current url of the page working on
	 * 
	 * @return url
	 *
	 */
	public String getCurrentUrl() {
		String url = driver.getCurrentUrl();
		return url;
	}

	/**
	 * navigateToURL - Open or redirect to new URL
	 *
	 * @param Url of (String)
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	public boolean navigateToURL(String Url) throws Throwable {
		boolean flag = false;
		try {
			waitTime();
			driver.navigate().to(Url);
			LOG.info("Navigated URL is : " + Url);
			flag = true;
		} catch (Exception e) {
			flag = false;
			logfailinfo("Exception --> "+ e.getMessage());
			//	softassertion.fail("Exception --> "+ e.getMessage());	
			//	softassertion.assertAll();
		} 
		return flag;
	}

	/**
	 * rightClick - Perform action on element using right click through actions
	 * class
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String) - Name of the element
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean rightClick(By locator, String locatorName) throws Throwable {
		boolean status;
		String msgRightClickSuccess = "Successfully Mouse Right Clicked On ";
		String msgRightClickFailure = "Unable To Right Click On ";
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			Actions action = new Actions(driver);
			action.contextClick(driver.findElement(locator)).build().perform();
			//		reporter.SuccessReport("Right Click : " + locatorName, msgRightClickSuccess + locatorName);
			LOG.info("Right click performed  on :: " + locatorName);
			status = true;
		} catch (Exception e) {
			status = false;
			logfailinfo("Exception --> "+ e.getMessage());
			//	softassertion.fail("Exception --> "+ e.getMessage());
			//	softassertion.assertAll();
		}
		return status;
	}

	/**
	 * getCallerClassName
	 *
	 * @return String
	 */
	protected static String getCallerClassName() {
		/*
		 * StackTraceElement[] stElements = Thread.currentThread().getStackTrace();
		 * return stElements[3].getClassName();
		 */

		return " ";
	}

	/**
	 * getCallerMethodName
	 *
	 * @return String
	 */
	protected static String getCallerMethodName() {
		/*
		 * StackTraceElement[] stElements = Thread.currentThread().getStackTrace();
		 * return stElements[3].getMethodName();
		 */
		return " ";
	}

	/**
	 * doubleClick -- Double click the mouse to the middle of the element. The
	 * element is scrolled into view and its location is calculated using
	 * getBoundingClientRect.
	 *
	 * @param locator     : Action to be performed on element
	 * @param locatorName : Meaningful name to the element (Ex:link,menus etc..)
	 */
	protected boolean doubleClick(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Mouse Double Click start :: " + locatorName);
			WebElement mo = driver.findElement(locator);
			new Actions(driver).moveToElement(mo).doubleClick(mo).build().perform();
			flag = true;
			LOG.info("Mouse Double Click :: " + locatorName);
			return true;
		} catch (Exception e) {
			logfailinfo("Element is not clicked " + locatorName);
			//	softassertion.fail("Element is not clicked " + locatorName);
			//	softassertion.assertAll();
		}
		return flag; 
	}

	/**
	 * doubleClickJS -- Double click the mouse to the middle of the element. The
	 * element is scrolled into view and its location is calculated using
	 * getBoundingClientRect.
	 *
	 * @param locator     : Action to be performed on element (Get it from Object
	 *                    repository)
	 * @param locatorName : Meaningful name to the element (Ex:link,menus etc..)
	 */
	protected boolean doubleClickJS(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Mouse Double Click start :: " + locatorName);
			WebElement mo = driver.findElement(locator);
			((JavascriptExecutor) driver).executeScript(
					"var evt = document.createEvent('MouseEvents'); evt.initMouseEvent('dblclick',true, "
							+ "true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null); arguments[0].dispatchEvent(evt);",
							mo);
			flag = true;
			LOG.info("Mouse Double Click :: " + locatorName);
			return true;
		} catch (Exception e) {
			logfailinfo("Element is not clicked " + locatorName);
			throw new RuntimeException(e);
		}
	}

	/**
	 * moveToElementAndClick -- click the mouse to the middle of the element. The
	 * element is scrolled into view and its location is calculated using
	 * getBoundingClientRect.
	 *
	 * @param locator     : Action to be performed on element
	 * @param locatorName : Meaningful name to the element (Ex:link,menus etc..)
	 */
	protected boolean moveToElementAndClick(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Mouse Double Click start :: " + locatorName);
			WebElement mo = driver.findElement(locator);
			new Actions(driver).moveToElement(mo).click().build().perform();
			flag = true;
			LOG.info("Mouse Double Click :: " + locatorName);
			return true;
		} catch (Exception e) {
			logfailinfo("Element is not clicked " + locatorName);
			//	softassertion.fail("Element is not clicked " + locatorName)	;
			//	softassertion.assertAll();
			return false;
		} 
	}

	/**
	 * replaceAll, Function to replace the regular expression values with client
	 * required values
	 *
	 * @param text        of (String)
	 * @param pattern     of (String), regular expression of actual value
	 * @param replaceWith of (String), value to replace the actual
	 * @return : String
	 */
	protected String replaceAll(String text, String pattern, String replaceWith) {
		String flag = null;
		try {
			flag = text.replaceAll(pattern, replaceWith);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}

	/**
	 * subString, Function to get sub string of given actual string text
	 *
	 * @param text       of (String), Actual text
	 * @param startIndex of (int), Start index of sub string
	 * @param endIndex   of (int), end index of sub string
	 * @return : String
	 */
	protected String subString(String text, int startIndex, int endIndex) {
		String flag = null;
		try {
			flag = text.substring(startIndex, endIndex);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}

	/**
	 * getCssValue, Function to get the value of a given CSS property (e.g. width)
	 *
	 * @param locator  of (By)
	 * @param cssValue of (String), CSS property
	 * @return : String
	 */
	protected String getCssValue(By locator, String cssValue) {
		String result = "";
		try {
			result = driver.findElement(locator).getCssValue(cssValue);
		} catch (Exception e) {
			logfailinfo("Exception --> "+ e.getMessage());
		}
		return result;
	}

	/**
	 * getBackGroundColor -- Function to get the background color of a given web
	 * element (e.g. background-color)
	 *
	 * @param locator  of (By)
	 * @param cssValue of (String), CSS property (e.g. background-color)
	 * @return : String
	 */
	protected String getBackGroundColor(By locator, String cssValue) {
		String hexColor = "";
		try {
			String bColor = driver.findElement(locator).getCssValue(cssValue);
			hexColor = Color.fromString(bColor).asHex();
		} catch (Exception ex) {
			logfailinfo("Exception --> "+ ex.getMessage());
		}
		return hexColor;
	}

	/**
	 * getDateTimeStamp -- Get Date and Time in specific format
	 *
	 * @return String
	 */
	/*
	 * protected String getDateTimeStamp() { Date date = new Date();
	 * SimpleDateFormat sdf = new SimpleDateFormat("dd_MMM_yyyy hh mm ss SSS");
	 * String formattedDate = sdf.format(date); suiteStartTime =
	 * formattedDate.replace(":", "_").replace(" ", "_"); return suiteStartTime; }
	 */

	/**
	 * getCurrentDateTime, Function to get current time in client required format
	 *
	 * @param dateTimeFormat of (String), format to get date and time (e.g: h:mm)
	 * @return : String
	 */
	protected String getCurrentDate(String dateTimeFormat) throws Throwable {
		DateFormat dateFormat = new SimpleDateFormat(dateTimeFormat);
		Date date = new Date();
		return dateFormat.format(date);
	}

	/**
	 * getDateTimeFromNow :: Get future time after adding x
	 * minutes/days/minutes/year to current time param :: timeFromNow -- minutes to
	 * be added return ::date throws :: Exception
	 */
	public static String getDateTimeFromNow(String type, int dateTimeFromNow, String format) {
		Calendar cal = Calendar.getInstance();
		Date today = cal.getTime();
		switch (type.toLowerCase()) {
		case "year":
			cal.add(Calendar.YEAR, dateTimeFromNow);
			break;
		case "month":
			cal.add(Calendar.MONTH, dateTimeFromNow);
			break;
		case "date":
			cal.add(Calendar.DATE, dateTimeFromNow);
			break;
		case "minute":
			cal.add(Calendar.MINUTE, dateTimeFromNow);
			break;
		}
		Date desiredDateTime = cal.getTime();
		DateFormat newDate = new SimpleDateFormat(format);
		return newDate.format(desiredDateTime);
	}

	/**
	 * getFutureDateTime, Function to get future date in required format
	 * 
	 * @param dateTimeFormat of (String), format to get date and time (e.g:
	 *                       MM/dd/yyyy)
	 * @param days           of (int), number to get date E.g. 1:Tomorrow date, -1:
	 *                       Yesterday date
	 * @return : String
	 */
	protected String getFutureDateTime(String dateTimeFormat, int days) throws Throwable {
		SimpleDateFormat sdf = new SimpleDateFormat(dateTimeFormat);
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, days);
		Date tomorrow = calendar.getTime();
		return sdf.format(tomorrow);
	}

	/**
	 * getCurrentSystemTime :: Get Current System Time based on timezone param ::
	 * TimeFormat,TimeZone return ::date
	 */
	public static String getCurrentSystemTimeAsPerTimeZone(String format, String timeZone) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
		sdf.format(new Date()).toString();
		return sdf.format(new Date());
	}

	/**
	 * getCountryDateTime, Function to get future or past date in client required
	 * format
	 *
	 * @param dateTimeFormat of (String), format to get date and time (e.g:
	 *                       MM/dd/yyyy)
	 * @param days           of (int), number to get date E.g. 1:Tomorrow date, -1:
	 *                       Yesterday date
	 * @param timeZone       of (String), time format to get date E.g.
	 *                       :America/New_York
	 * @return : String
	 */
	protected String getCountryDateTime(String dateTimeFormat, int days, String timeZone) throws Throwable {
		Calendar calNewYork = Calendar.getInstance();
		calNewYork.add(Calendar.DAY_OF_YEAR, 0);
		Date date = calNewYork.getTime();
		DateFormat formatter = new SimpleDateFormat(dateTimeFormat);
		formatter.setTimeZone(TimeZone.getTimeZone(timeZone));
		return formatter.format(date);
	}



	/**
	 * �* param :: Hashtable with string inputs �* return ::String �* throws ::
	 * throwable �* methodName :: generateRandomNumber �
	 */
	protected static String generateRandomNumber(int length) {
		String randomNumber = "1";
		int retryCount = 1;
		while (retryCount > 0) {
			String number = Double.toString(Math.random());
			number = number.replace(".", "");
			if (number.length() > length) {
				randomNumber = number.substring(0, length);
			} else {
				int remainingLength = length - number.length() + 1;
				randomNumber = generateRandomNumber(remainingLength);
			}
			if (randomNumber.length() < length) {
				retryCount++;
			} else {
				retryCount = 0;
			}
		}
		return randomNumber;
	}

	/**
	 * generateRandomNumber description :: This is used to generate random number
	 * with 8 digit as current Year(YY)and system time
	 * 
	 * @return int
	 * @throws Throwable the throwable
	 */
	protected String generateRandomNumberBasedOnLength(int length) throws Throwable {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmmssSdSMSs");
		String currentdate = sdf.format(date);
		return new StringBuffer().append(currentdate).reverse().substring(0, length);
	}

	/**
	 * getRandomString, Get random String
	 * 
	 * @param noOfCharacters of (int), Number of characters to get randomly
	 * @return String
	 */

	protected String getRandomString(int noOfCharacters) throws IOException {
		return RandomStringUtils.randomAlphabetic(noOfCharacters);
	}

	/**
	 * getAttribute, Function to get the value of a given attribute (e.g. class)
	 *
	 * @param locator       of (By)
	 * @param attributeName of (String)
	 * @return : String
	 */
	protected String getAttribute(By locator, String attributeName) {
		String result = "";
		try {
			result = driver.findElement(locator).getAttribute(attributeName);
		} catch (Exception ex) {
			logfailinfo("Exception --> "+ ex.getMessage());
		}
		return result;
	}

	/**
	 * refreshPage -- Refreshing webpage working on currently
	 */
	protected void refreshPage() throws Throwable {
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName());
			driver.navigate().refresh();
		} catch (Exception e) {
			logfailinfo("Exception --> "+ e.getMessage());
		}
	}

	/**
	 * clearText -- clearData or Clear value from textBox
	 *
	 * @param locator of (By)
	 */
	protected void clearText(By locator) throws Throwable {
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName());
			WebElement element = driver.findElement(locator);
			element.sendKeys(Keys.CONTROL + "a");
			element.sendKeys(Keys.DELETE);
			element.clear();
		} catch (Exception e) {

			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			logfailinfo("Element is not clicked " + locator);
		}
	}

	/**
	 * waitForAlertPresent -- Wait for an alert to be present within the specified
	 * wait time in seconds Note that this does not actually handle the alert just
	 * confirms if it appears or not
	 *
	 * @param waitTime the amount of time to wait for the alert, in seconds
	 *
	 * @return boolean indicating whether the alert was found
	 */
	protected boolean waitForAlertPresent(int waitTime) {
		boolean foundAlert = false;
		try {
			//		final WebDriverWait wait = new WebDriverWait(driver, waitTime);
			//		wait.until(ExpectedConditions.alertIsPresent());
			foundAlert = true;
		} catch (final RuntimeException e) {
			LOG.info("Alert Is Not Present");
			logfailinfo("Exception --> "+ e.getMessage());
		}
		return foundAlert;
	}

	/**
	 * acceptAlert -- > To Accept the Alert, click on OK button from alert with the
	 * help of alerts class
	 */
	protected void acceptAlert() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
		} catch (Exception e) {
			logfailinfo("Exception --> "+ e.getMessage());
		}
	}

	/**
	 * dismissAlert -- > To Dismiss the Alert, click on cancel button from alert
	 * with the help of alerts class
	 */
	protected void dismissAlert() {
		try {			
			driver.switchTo().alert().dismiss();
		} catch (Exception e) {
			e.getMessage();
			logfailinfo("Exception --> "+ e.getMessage());
		}
	}

	/**
	 * findWebElement on the webpage using an explicit wait
	 * 
	 * @param locator     of (By)
	 * @param locatorName of (String)
	 * @return WebElement
	 */
	protected WebElement findWebElement(By locator, String locatorName) throws Throwable {
		WebElement element=null;
		try {
			LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : click  ::  Locator : " + locatorName);
			WebDriverWait wait = new WebDriverWait(driver, 15);
			LOG.info("Locator is Visible :: " + locator);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			element = driver.findElement(locator);
		} catch (Exception e) {
			LOG.info(e.getMessage());
			logfailinfo("Element is not found " + locatorName);
			//	softassertion.fail("Element is not found " + locatorName);
			//	softassertion.assertAll();
		}
		return element;
	}

	/**
	 * checkBoxIsChecked -- Validate Whether Check box is checked or not will return
	 * true or false
	 *
	 * @param by          of (By)
	 * @param locatorName of (String)
	 * @param expected    of (boolean)
	 * @return boolean
	 */
	protected boolean checkBoxIsChecked(By by, String locatorName, boolean expected) throws Throwable {
		boolean status = expected;
		String msgCheckboxisnotChecked = "Checkbox is not Selected";
		try {
			waitTime();
			boolean actualStatus = driver.findElement(by).isSelected();
			status = actualStatus;
		} catch (Exception e) {
			status = false;
			logfailinfo("Element is not checked " + locatorName);
			//	softassertion.fail("Element is not checked " + locatorName);
			//	softassertion.assertAll();
		}
		return status;
	}

	/**
	 * checkBoxIsUnChecked -- Validate Whether Check box is un checked or not will
	 * return true or false
	 *
	 * @param by          of (By)
	 * @param locatorName of (String)
	 * @param expected    of (boolean)
	 * @return boolean
	 */
	protected boolean checkBoxIsUnChecked(By by, String locatorName, boolean expected) throws Throwable {
		boolean status = expected;
		String msgCheckboxisnotChecked = "Checkbox is not Selected";
		try {
			waitTime();
			boolean actualStatus = driver.findElement(by).isSelected();
			status = actualStatus;
		} catch (Exception e) {
			status = true;
			logfailinfo("Element is not checked " + locatorName);
			//	softassertion.fail("Element is not checked " + locatorName);
			//	softassertion.assertAll();
		} 
		return status;
	}

	/**
	 * switchToFrame -- Function to switch to a different frame using locator and an
	 * explicit wait
	 * @throws Throwable 
	 */
	protected void switchToFrame(By locator) throws Throwable {
		LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
		waitForVisibilityOfElement(locator, "Locator",30);
		driver.switchTo().frame(driver.findElement(locator)); 
	}

	/**
	 * Function to switch to a different frame using index value
	 * 
	 * @param index of (int), frame number to switch
	 */
	protected void switchToFrameByIndex(int index) {
		driver.switchTo().frame(index);
	}

	/**
	 * comeOutFromFrame - Get come out of frame
	 */
	protected void comeOutFromFrame() {
		driver.switchTo().defaultContent();
	}

	/**
	 * switchToWindow, Function to switch to latest window
	 */
	protected void switchToWindow() {
		for (String handle : driver.getWindowHandles()) {
			driver.switchTo().window(handle);
		}
	}

	/**
	 * switchToWindow, Function to switch to latest window
	 */
	protected void switchToWindow(String mainWindow) {
		for (String handle : driver.getWindowHandles()) {
			if (handle != mainWindow)
				driver.switchTo().window(handle);
		}
	}

	/**
	 * switchToParentWindow, Function to switch to parent window
	 *
	 * @param handle of (String), window handle to switch
	 */
	protected void switchToParentWindow(String handle) {
		driver.switchTo().window(handle);
	}

	/**
	 * closeWindow, Function to close the currently focused window only
	 */
	protected void closeWindow() {
		driver.close();
	}

	/**
	 * getWindowHandle, Function to get the current window handle of the webpage
	 * working on
	 *
	 * @return : String
	 */
	protected String getWindowHandle() {
		return driver.getWindowHandle();
	}

	/**
	 * scrollToWebElement, Function to scroll to a particular element until in view
	 * using java script executor
	 *
	 * @param element of (By)
	 */
	protected void scrollToWebElement(By element) throws Throwable {
		boolean status = false;
		try {
			if (isElementDisplayed(element, "element")) {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
						driver.findElement(element));
				status = true;
			}
		} catch (Exception e) {
			status = false;
			logfailinfo("Exception --> "+ e.getMessage());
			//	softassertion.fail("Element is not scroll " + element);
			//	softassertion.assertAll();
		} 
	}

	/**
	 * scrollBottom : Function to move the scroll to bottom of the page using java
	 * script executor
	 * 
	 */
	protected void scrollBottom() {
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1500)");
	}

	/**
	 * scrollBottom : Function to move the scroll to bottom of the page using java
	 * script executor
	 * 
	 */
	protected void scrollMiddle() {
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,650)");
	}

	/**
	 * scrollBottom : Function to move the scroll to bottom of the page using java
	 * script executor
	 * 
	 */
	protected void scrollUP() {
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)");
	}

	/**
	 * isElementVisibleOnly
	 *
	 * @param locator     of (By)
	 * @param locatorName of (String)
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean isElementDisplayed(By locator, String locatorName) throws Throwable {
		boolean flag = true;
		int count;
		try {
			LOG.info("Class name :: " + getCallerClassName() + " Method name :: " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			//flag = driver.findElement(locator).isDisplayed();
			count = driver.findElements(locator).size();
			System.out.println("count is "+count);
			if(count<=0){
				logfailinfo("Element is not displayed " + locatorName);
				//	softassertion.fail("Element is not displayed " + locatorName);
				//	softassertion.assertAll();
			}
		} catch (Exception e) {
			flag = false;			
		}
		return flag;
	}

	/**
	 * getYear, Function to get required year e.g: 0-Current year, 1-Next year,
	 *
	 * @param number of (int) Number to get year (e.g: -1,0,1 etc)
	 * @return int
	 * @throws Throwable the throwable
	 */
	protected int getYear(int number) throws Throwable {
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR) + number;
		LOG.info("Year is : " + year);
		return year;
	}

	/**
	 * dateFormatVerification, Function to verify date format by giving actual date
	 *
	 * @param actualDate     of (String) actual date e.g: 21-11-2015
	 * @param formatToVerify of (String) format type e.g: dd-MM-yyyy
	 * @return boolean
	 */
	protected boolean dateFormatVerification(String actualDate, String formatToVerify) {
		boolean flag = false;
		if (actualDate.toLowerCase().contains("am")) {
			flag = formatVerify(actualDate, formatToVerify);
		} else if (actualDate.toLowerCase().contains("pm")) {
			flag = formatVerify(actualDate, formatToVerify);
		} else if (!actualDate.toLowerCase().contains("am") || !actualDate.toLowerCase().contains("pm")) {
			flag = formatVerify(actualDate, formatToVerify);
		}
		return flag;
	}

	/**
	 * formatVerify, Reusable Function to verify date format by giving actual date
	 *
	 * @param actualDate     of (String)e.g: 21-11-2015
	 * @param formatToVerify of (String) type e.g: dd-MM-yyyy
	 * @return : boolean
	 */
	protected boolean formatVerify(String actualDate, String formatToVerify) {
		boolean flag;
		try {
			SimpleDateFormat sdf;
			sdf = new SimpleDateFormat(formatToVerify);
			Date date = sdf.parse(actualDate);
			String formattedDate = sdf.format(date);
			flag = actualDate.equals(formattedDate);
		} catch (Exception ex) {
			flag = false;
			logfailinfo("Exception --> "+ ex.getMessage());
		}
		return flag;
	}

	/**
	 * differenceBetweenTwoDates, Find the difference between two dates
	 *
	 * @param date1
	 * @param date2
	 * @param dateFormat
	 */
	protected long differenceBetweenTwoDates(String date1, String date2, String dateFormat) throws Throwable {
		long diffDays = 0;
		try {
			SimpleDateFormat format = new SimpleDateFormat(dateFormat);
			Date d1 = format.parse(date1);
			Date d2 = format.parse(date2);
			long diff = d2.getTime() - d1.getTime();
			diffDays = diff / (24 * 60 * 60 * 1000) + 1;
		} catch (Exception e) {
			e.getMessage();
		}
		return diffDays;
	}

	/**
	 * convertDateFormatToAnotherDateFormat, Function to convert one date format to
	 * another date format
	 *
	 * @param actualDate        of (String), Actual date (e.g: Dec 5, 2017)
	 * @param sourceFormat      of (String), format of actualDate (e.g: MMM dd,
	 *                          yyyy)
	 * @param destinationFormat of (String), Format what we required (e.g:
	 *                          dd/MM/yyyy)
	 * @return : String
	 */
	protected String convertDateFormatToAnotherDateFormat(String actualDate, String sourceFormat,
			String destinationFormat) throws Throwable {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(sourceFormat);
		SimpleDateFormat sdf = new SimpleDateFormat(destinationFormat);
		Date date = simpleDateFormat.parse(actualDate);
		return sdf.format(date);
	}


	/**
	 * Function to get attribute name from focused element If we use this method it
	 * will return required attribute value of focused element
	 *
	 * @throws Throwable the throwable
	 */
	protected String getAttributeFromFocusedElement(String attributeName) throws Throwable {
		WebElement activeElement = driver.switchTo().activeElement();
		return activeElement.getAttribute(attributeName);
	}

	/**
	 * Function to get value from XML file If we use this method it will return
	 * required value based on tag name
	 *
	 * @param xmlFileName (String) path of the XML file
	 * @param parentTag   (String) Parent tag name
	 * @param childTag    (String) Child tag name
	 */
	protected String readXML(String xmlFileName, String parentTag, String childTag) {
		String tagName = "";
		try {
			File fXmlFile = new File(xmlFileName);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName(parentTag);
			Node nNode;
			Element eElement;
			for (int temp = 0; temp < nList.getLength(); temp++) {
				nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					eElement = (Element) nNode;
					tagName = eElement.getElementsByTagName(childTag).item(0).getTextContent();
				}
			}
		} catch (Exception e) {
		}
		return tagName;
	}

	/**
	 * Function to get check the sessions in multiple tabs If we use this method it
	 * will return required text of highlighted element
	 *
	 * @throws Throwable the throwable
	 */
	protected void openURLInNewTab(String URL) throws Throwable {
		String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL, "t");
		driver.findElement(By.tagName("body")).sendKeys(selectLinkOpeninNewTab);
		driver.get(URL);
	}

	/**
	 * Function to get check the session in a new window
	 *
	 * @throws Throwable the throwable
	 */
	protected void openURLInNewWindow(String URL) throws Throwable {

		((JavascriptExecutor) driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		String OpenNewtab = tabs.get(1);
		if (OpenNewtab != null) {
			//	reporter.SuccessReport("OpenNewtab", "New tab opened");
		}
		driver.get(URL);
	}

	/**
	 * sendKeysActionsEsc - Select Escape key to perform action
	 * 
	 * @param locator
	 */
	protected void sendKeysActionsEsc(By locator) throws Throwable {
		try {
			this.waitForPageLoaded();
			WebElement element = driver.findElement(locator);
			element.sendKeys(Keys.ESCAPE);
		} catch (Exception e) {

		}
	}

	/**
	 * isEnabled - Check whether element is enabled or not
	 * 
	 * @param locator     of (By)
	 * @param locatorName of (String) - Name of the locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean isEnabled(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name :: " + getCallerClassName() + " Method name :: " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			flag = driver.findElement(locator).isEnabled();
		} catch (Exception e) {
			flag = false;
			logfailinfo("Element is not enabled " + locatorName);
			//	softassertion.fail("Element is not enabled " + locatorName);
			//	softassertion.assertAll();
		} 

		return flag;
	}

	/**
	 * isEnabled - Check whether element is enabled or not
	 * 
	 * @param locator of (By)
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean isEnabled(By locator) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name :: " + getCallerClassName() + " Method name :: " + getCallerMethodName());
			flag = driver.findElement(locator).isEnabled();
		} catch (Exception e) {
			flag = false;
			logfailinfo("Element is not enabled " + locator);
			//	softassertion.fail("Element is not enabled " + locator);
			//	softassertion.assertAll();
		}
		return flag;
	}

	/**
	 * getAttributeValue of the element it fetch the value that containing one of
	 * any attribute in the HTML tag
	 * 
	 * @param element       of (WebElement)
	 * @param attributeName (String) - Name of the attribute
	 * @throws Throwable the throwable
	 */

	protected String getAttributeValue(WebElement element, String attributeName) throws Throwable {

		String text = "";
		boolean flag = false;
		LOG.info("Class name" + getCallerClassName() + "Method name : " + getCallerMethodName());
		try {
			text = element.getAttribute(attributeName);
			flag = true;
		} catch (Exception e) {
			logfailinfo("Exception --> "+ e.getMessage());
		} 
		return text;
	}

	/**
	 * returnCheckBoxStatus -- Validate Whether Check box is selected or not
	 *
	 * @param by of (By)
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean returnCheckBoxStatus(By by) throws Throwable {
		boolean actualStatus;
		try {
			waitTime();
			actualStatus = driver.findElement(by).isSelected();

		} catch (Exception e) {
			actualStatus = false;
			logfailinfo("Exception --> "+ e.getMessage());

		}
		return actualStatus;
	}

	/**
	 * getDropDownData -- Get all values from the dropdown
	 * 
	 * @param locator  of (By)
	 * @param dataType (String) - Datatype of dropdown values
	 * @return complete list of dropdown values
	 * @throws Throwable the throwable
	 */

	protected List<String> getDropDownData(By locator, String dataType) {
		boolean flag = false;
		List<String> dropdownData = new ArrayList<String>();
		try {
			Select s = new Select(driver.findElement(locator));
			List<WebElement> allOptions = s.getOptions();
			for (WebElement option : allOptions) {
				String data;
				if (dataType.equalsIgnoreCase("value")) {
					data = option.getAttribute("value");
				} else {
					data = option.getText();
				}
				dropdownData.add(data);
			}
		} catch (Exception e) {
			logfailinfo("Element is not clicked " + locator);
		}
		return dropdownData; 
	}

	/**
	 * getSelectedDropdownOption -- Get "default selected value" from dropdown
	 * 
	 * @param locator of (By)
	 * @return selected item from dropdown
	 */
	protected String getSelectedDropdownOption(By locator) {
		String selectedItem = null;
		try {
			Select select = new Select(driver.findElement(locator));
			WebElement option = select.getFirstSelectedOption();
			selectedItem = option.getText();
		} catch (Exception ex) {
			logfailinfo("Exception --> "+ ex.getMessage());
		}
		return selectedItem; 
	}

	/**
	 * methodName :: javaScriptOpenNewTab return ::void throws :: throwable
	 * description :: to open new tab in chrome
	 */
	protected void javaScriptOpenNewTab() {
		((JavascriptExecutor) driver).executeScript("window.open()");
	}

	/***
	 * getCurrentClassAndMethodNames - To get current class and method names on
	 * report
	 * 
	 * @return get current class and method names
	 */
	protected static String getCurrentClassAndMethodNames() {
		final StackTraceElement e = Thread.currentThread().getStackTrace()[2];
		final String s = e.getClassName();
		return s.substring(s.lastIndexOf('.') + 1, s.length()) + "." + e.getMethodName();
	}

	/**
	 * methodName :: getWebElement return ::element description :: to get webelement
	 */
	protected WebElement getWebElement(final By by) {

		WebElement element = null;

		if (by != null) {
			element = driver.findElement(by);
		} else {
			LOG.info("By instance is null");
		}
		return element;
	}

	/**
	 * Wait until all potential frameworks have finished loading on web pages
	 */
	protected void waitForLoadAll() {	
		waitUntilJQueryReady();
		waitUntilAngularReady();
	}



	/**
	 * Waits for JQuery to be ready, if present
	 */
	public static void waitUntilJQueryReady() {
		// JavascriptExecutor jsExec = (JavascriptExecutor) jsWaitDriver;
		// First check that JQuery is defined on the page. If it is, then wait AJAX
		Boolean jQueryDefined = (Boolean) ((JavascriptExecutor) driver)
				.executeScript("return typeof jQuery != 'undefined'");
		if (jQueryDefined == true) {
			// Pre Wait for stability (Optional)
			sleep(20);
			// Wait JQuery Load
			// waitForJQueryLoad();
			// Post Wait for stability (Optional)
			sleep(20);
		} else {
			// System.out.println("jQuery is not defined on this site!");
		}
	}

	/**
	 * Waits for Angular 1.0 to be ready, if present
	 */
	public static void waitUntilAngularReady() {
		JavascriptExecutor jsExec = (JavascriptExecutor) driver;
		// First check that ANGULAR is defined on the page. If it is, then wait ANGULAR
		Boolean angularUnDefined = (Boolean) jsExec.executeScript("return window.angular === undefined");
		if (!angularUnDefined) {
			Boolean angularInjectorUnDefined = (Boolean) jsExec
					.executeScript("return angular.element(document).injector() === undefined");
			if (!angularInjectorUnDefined) {
				// Pre Wait for stability (Optional)
				sleep(20);
				// Wait Angular Load
				// waitForAngularLoad();
				// Post Wait for stability (Optional)
				sleep(20);
			} else {
				// System.out.println("Angular injector is not defined on this site!");
			}
		} else {
			// System.out.println("Angular is not defined on this site!");
		}
	}

	/**
	 * Wrapper around thread.sleep
	 *
	 * @param milliseconds the number of milliseconds to sleep
	 */
	public static void sleep(Integer milliseconds) {
		long secondsLong = (long) milliseconds;
		try {
			Thread.sleep(secondsLong);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}



	/**
	 * click on enter
	 *
	 * @param locator of (By)
	 */
	protected void clickEnter(By locator) throws Throwable {

		try {
			driver.findElement(locator).sendKeys(Keys.ENTER);

		} catch (Exception e) {
			logfailinfo("Element is not clicked " + locator);
		}
	}



	/**
	 * kendoSelectValueFormDropdown
	 *
//	 * @param By of (By),locatorName,value
	 * @throws Throwable the throwable
	 */
	public void kendoClickValueFormDropdown(By locator, String locatorName, String value) throws Throwable {
		try {
			click(locator, locatorName);
			waitForPageLoaded();
			By byTypeLocator = By.xpath("//li[contains(.,'"+value+"')]");
			click(byTypeLocator, value);			
		} catch (Exception e) {
			logfailinfo("Element is not clicked " + locatorName);
		}

	}

	/**
	 * assertTextNotMatching verifies whether actual text using locator and getText
	 * method matches to the text provided
	 *
	 * @param by          of (By)
//	 * @param text        of (String)
	 * @param locatorName of (String) - Name of the element/locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected void validateCheckPointNotMatch(By by, String expected, String locatorName) throws Throwable {
		boolean flag = false;
		String ActualText="";
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			ActualText = getText(by, locatorName).trim();
			LOG.info("ActualText is : " + ActualText);
			Assert.assertNotEquals(ActualText, expected);
			flag = true;			
		} catch (Exception e) {
			flag = false;
			logfailinfo("expected and actual values are not equal" + ActualText + " " + expected );
			//	softassertion.fail("expected and actual values are not equal");
			//	softassertion.assertAll();
		}
	}

	/**
	 * assertTextMatching verifies whether actual text using locator and getText
	 * method matches to the text provided
	 *
	 * @param by          of (By)
//	 * @param text        of (String)
	 * @param locatorName of (String) - Name of the element/locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected boolean validateCheckPointMatch(By by, String expected, String locatorName) throws Throwable {
		boolean flag = false;
		String ActualText="";
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			//	scrollToWebElement(by);
			ActualText = getText(by, locatorName).trim();
			LOG.info("ActualText is : " + ActualText);
			Assert.assertEquals(ActualText, expected);
			flag = true;			
		} catch (Exception e) {
			flag = false;
			logfailinfo("Expected and actual values are not equal " + expected + " " + ActualText);
			//	softassertion.fail("Expected and actual values are not equal");
			//	softassertion.assertAll();
		}
		return flag;
	}

	/**
	 * validateCheckPointContains verifies whether actual text using locator and getText
	 * method matches to the text provided
	 *
	 * @param by          of (By)
//	 * @param text        of (String)
	 * @param locatorName of (String) - Name of the element/locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected void validateCheckPointContains(By by, String expected, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			LOG.info("Method : " + getCallerMethodName() + "  ::  Locator : " + locatorName);
			String ActualText = getText(by, locatorName).trim();
			LOG.info("ActualText is : " + ActualText);
			if (ActualText.contains(expected)) {				
				softassertion.assertTrue(true);
				//	softassertion.assertAll();
				flag = true;
			} else {				
				softassertion.assertTrue(false);
				//	softassertion.assertAll();
			}

		} catch (Exception e) {
			logfailinfo("Expected & actual values are not equal");
		}

	}

	/**
	 * validateCheckPointEquals verifies actual text and expected text method
	 * matches to the text provided
	 *
//	 * @param By          of (String)
//	 * @param text        of (String)
	 * @param locatorName of (String) - Name of the element/locator
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	protected void validateCheckPointEquals(String actual, String expected, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			LOG.info("Class name : " + getCallerClassName() + "Method name : " + getCallerMethodName());
			Assert.assertEquals(actual, expected);
			flag = true;

		} catch (Exception e) {
			flag = false;
			logfailinfo("Expected and actual are not equal");
			//	softassertion.fail("Expected and actual are not equal" + actual + " " + expected);
			//	softassertion.assertAll();
		}
	}



	/**
	 * getAbsoluteFilePath -- gives the output as absolute file path
	 * work
	 *
	 * @return boolean
	 * @throws Throwable the throwable
	 */
	public String getAbsoluteFilePath() throws Throwable {
		//String rootPath = "";
		String finalPath = "";
		try {
			/*
			 * rootPath = System.getProperty("user.dir").toString(); Path path =
			 * Paths.get(rootPath);
			 * 
			 * String[] arrOfStr = StreamSupport.stream(path.spliterator(),
			 * false).map(Path::toString) .toArray(String[]::new); finalPath =
			 * "C:\\" +arrOfStr[0]+"\\"+arrOfStr[1]+"\\"+"resources\\common\\testData\\pdfs"
			 * ;
			 */

			finalPath = downloadFilepath;

			System.out.println("" + finalPath);
		} catch (Exception e) {
			LOG.info(e.getMessage());
			logfailinfo("Exception --> "+ e.getMessage());
		}
		return finalPath;

	}

	/**
	 *MethodName:validateTextUsingContains
	 * @param actual
	 * @param expected
	 * @throws Throwable
	 */
	public void validateTextUsingContains(String actual,String expected) throws Throwable {

		try {
			//LOG.info("Actual Text: "+actual);
			LOG.info("Expected Text: "+expected);
			actual.contains(expected);

		} catch (Exception e) {
			logfailinfo("Actual and expected values dosen't match");
		}


	}

	/**
	 * CreateRuntimeDirectory
	 * work
	 *
	 * @param 
	 * @param DirectoryName
	 * @param DrivePath
	 * @return 
	 * @throws Throwable the throwable
	 */
	public void CreateRuntimeDirectory(String DirectoryName,String DrivePath) throws Throwable {

		try {
			//String timeStamp = new SimpleDateFormat("yyyy.MM.dd").format(new Date());
			File file = new File(DrivePath + DirectoryName);
			if (!file.exists())
			{
				if (file.mkdir()) System.out.println("Directory is created!");
				else System.out.println("Directory already exists.");
			}

		} catch (Exception e) {
			LOG.info(e.getMessage());
			logfailinfo("Exception --> "+ e.getMessage());
		}


	}

	/**
	 * insertDelimeterIntoNumericString
	 * work
	 *
	 * @param 
	 * @param value    of (int)
	 * @param 
	 * @return 
	 * @throws Throwable the throwable
	 */
	public String insertDelimeterIntoNumericString(int value) throws Throwable {
		String outputStr= "";
		try {
			String stringvalue = Integer.toString(value);
			char [] c = stringvalue.toCharArray();
			if (c.length == 5) {
				StringBuffer str = new StringBuffer(stringvalue);
				str.insert(2,",");
				outputStr = str.toString();
			}else if (c.length == 6) {
				StringBuffer str = new StringBuffer(stringvalue);
				str.insert(3,",");
				outputStr = str.toString();
			}
		} catch (Exception e) {
			LOG.info(e.getMessage());
			logfailinfo("Exception --> "+ e.getMessage());
		}
		return outputStr;


	}

	/**
	 * MethodName: PressTab
	 */
	public void pressTab(By locator){

		try{
			WebElement webElement = driver.findElement(locator);//You can use xpath, ID or name whatever you like
			webElement.sendKeys(Keys.TAB);

		}catch(Exception e)
		{
			LOG.info(e.getMessage());
			logfailinfo("Exception --> "+ e.getMessage());
		}
	}

	/*
====================================================================================
	 */
	/**
	 * write data from csv file based on header names
	 * @param header
	 * @return
	 * @throws CsvValidationException
	 * @throws IOException
	 */
	public void writeCsvFile(String header,String expData) throws CsvValidationException, IOException {			
		int rowCount=0;
		int cellCount=0;		
		String file = System.getProperty("user.dir")+"\\resources\\common\\testdata\\TestFile.csv";	
		String file2 = System.getProperty("user.dir")+"\\resources\\common\\testdata\\TestFile3.csv";	
		CSVReader reader = new CSVReader(new FileReader(file));
		CSVWriter writer = new CSVWriter(new FileWriter(file2));	
		String[] lineInArray;		 
		while ((lineInArray = reader.readNext()) != null) {
			rowCount++;			 
			if(rowCount==1){
				for (String cell : lineInArray) {
					cellCount++;
					cell = cell.replaceAll("\\﻿", "");            	
					if(header.equalsIgnoreCase(cell)){
						System.out.print(cell + "\t");			           		
						break;
					}
				}           	
			}else{       	   		   

				lineInArray[cellCount-1]=expData;
			}

			writer.writeNext(lineInArray);

		}


	}

	/**
	 * read data from csv file based on header names
	 * @param header
	 * @return
	 * @throws CsvValidationException
	 * @throws IOException
	 */
	public String readCsvFile(String header,String fileName) throws CsvValidationException, IOException {		
		String expData="";
		int rowCount=0;
		int cellCount=0;
		boolean flag=false;
		String file = System.getProperty("user.dir")+"\\resources\\movilizer\\TestData\\"+fileName+".csv";		 
		CSVReader reader = new CSVReader(new FileReader(file));	
		String[] lineInArray;
		while ((lineInArray = reader.readNext()) != null) {
			rowCount++;
			if(rowCount==1){
				for (String cell : lineInArray) {
					cellCount++;
					cell = cell.replaceAll("\\﻿", "");            	
					if(header.equalsIgnoreCase(cell)){
						System.out.print(cell + "\t");
						flag=true;
						break;
					}
				}           	
			}else{       	   		   

				expData=lineInArray[cellCount-1];
			}

		}
		return expData;

	}



	public By locator(String dynamictext, String locatorName) throws Throwable {
		By byElement = null;

		try {
			byElement = By.xpath("//div[contains(text(),'" + dynamictext + "')]");
			LOG.info("Method : Type  ::  Locator : " + locatorName);
		} catch (Exception e) {
			//	softassertion.fail("Element is not found " + byElement);
			logfailinfo("Element is not found " + byElement);
			//	softassertion.assertAll();
			//	reporter.failureReport("Element is not found with dynamic text","Element is not found with dynamic text" + locatorName);
		}
		return byElement;
	}


	//click on list box(this method is for only PAGINATION)
	public void clickonListbox() throws Throwable
	{
		By listbox = By.xpath("//div[@role='listbox']");
		waitForVisibilityOfElement(listbox, "Listbox",20);
		clickJS(listbox, "Click on listbox");
		waitForPageLoaded();
	}
	//select itemsper page(this method is for only PAGINATION)
	public void selectItems_perpage(String itemperpage) throws Throwable {
		By itemsperpage = locator(itemperpage, itemperpage);
		waitForVisibilityOfElement(itemsperpage, itemperpage,20);
		clickJS(itemsperpage, "Click on item per page");
	}

	// click on filter icon(this method is for only FILTERING)
	public void clickonfilter() throws Throwable {

		By flitericon = By.xpath("//div[@class='header-bar-item filter-panel-icon']/i");
		waitForVisibilityOfElement(flitericon, "Filter icon",20);
		try {
			waitForPageLoaded();
			//   click(flitericon, "Filter icon");
			setFocusAndClick(flitericon, "Filter icon");
			//	Thread.sleep(8000);
		}
		catch (Exception e) {
			scrollToWebElement(flitericon);
			waitForPageLoaded();
			click(flitericon, "Filter icon");
		}
	}
	// click on caret icon(this method is for only FILTERING)
	public void clickoncaret() throws Throwable {
		By careticon = By.xpath("//i[@class='h-icon global caret-up section-label-icon fitted']");
		waitForVisibilityOfElement(careticon, "Filtertype caret",20);
		try {
			click(careticon, "Filtertype caret");
		}
		catch (Exception e) {
			scrollToWebElement(careticon);
			waitForPageLoaded();
			click(careticon, "Filtertype caret");
		}
	}



	@SuppressWarnings("unchecked")
	public void sorting_isAscending(@SuppressWarnings("rawtypes") ArrayList actualelements,@SuppressWarnings("rawtypes") ArrayList expectedlelements) throws Throwable
	{
		System.out.println("Actual elements are   " +   actualelements);
		System.out.println("Expected elements are " +   expectedlelements);
		if(actualelements.equals(expectedlelements)) {
			//	logpassinfo("Elements are  in ascending,expected elements are  " + expectedlelements +"  " + "Actual elements are" + actualelements); 
		} else {
			logfailinfo("Elements are not in ascending,expected elements are  " + expectedlelements +"  " + "but found" + actualelements);
		}
	}

	@SuppressWarnings("unchecked")
	public void sorting_isDescending(@SuppressWarnings("rawtypes") ArrayList actualelements,@SuppressWarnings("rawtypes") ArrayList expectedelements) throws Throwable
	{
		System.out.println("Actual elements are   " +   actualelements);
		System.out.println("Expected elements are " +   expectedelements);
		if(actualelements.equals( expectedelements)) {
			//	logpassinfo("Elements are  in ascending,expected elements are  " + expectedlelements +"  " + "Actual elements are" + actualelements); 
		} else {
			logfailinfo("Elements are not in descending,expected elements are  " +  expectedelements +"  " + "but found" + actualelements);
		}
	}



	/*  ==================================================================================================  */


	// validating FILTERS
	public void Validate_Filters() throws Throwable
	{

		By table_element=By.xpath("(//tr[@class='p-datatable-row']/td)[1]");
		waitForVisibilityOfElement(table_element,"web table",20);
		clickonfilter();
		waitForPageLoaded();
		clickoncaret();
		waitForPageLoaded();
		By checkboxestoselect =By.xpath("//input[@type='checkbox']/../label");
		//		List<WebElement> checkboxestoselect = driver.findElements(By.xpath("//input[@type='checkbox']/../label"));
		List<WebElement> checkboxes = getWebElementList(checkboxestoselect,"Checkboxes to select for filtering");
		waitforPresence_Elements(checkboxestoselect,"Checkbox to select",20);

		for(int i=0;i<checkboxes.size();i++)
		{	
			waitForPageLoaded();
			String checkboxtext=checkboxes.get(i).getText();
			System.out.println(checkboxtext);
			WebElement element = checkboxes.get(i);
			try
			{
				element.click();	
			}
			catch (Exception e) {
				waitForPageLoaded();
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",element);
				waitForPageLoaded();
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
				//	element.click();
			}
			By table=By.xpath("//tbody[@class='p-datatable-tbody']/tr");
			List<WebElement> talbedata = getWebElementList(table,"Table data");

			for(int j=0;j<talbedata.size();j++)
			{
				//String assetname=driver.findElement(By.xpath("//tbody[@class='p-datatable-tbody']/tr['"+j+"']/td[2]")).getText();
				//System.out.println(assetname);
				//String assettype=driver.findElement(By.xpath("//tbody[@class='p-datatable-tbody']/tr['"+j+"']/td[3]")).getText();
				By type=locator(checkboxtext,"Filter type");
				validateCheckPointEquals(checkboxtext,getText(type),"Validating type of filter");
				waitForPageLoaded();
			}
			By resetfileter=By.xpath("//span[text()='Reset all filters']");
			click(resetfileter,"rest fileter");
		}
	}


	//validating SEARCH
	public void Validate_Search(String entity) throws Throwable
	{
		//locators for search
		waitForPageLoaded();
		By Search=By.xpath("//input[contains(@placeholder,'Search')]");
		waitForVisibilityOfElement(Search,"Search",15);
		By searchitem=locator(entity,"Item to be search");	
		waitForVisibilityOfElement(searchitem,"Search item",15);
		clearText(Search);
		setTextWithoutClear(Search,entity,"Search");
		waitForPageLoaded();
		clickEnter(Search);
		waitForPageLoaded();
		boolean result = isElementDisplayed(searchitem,"Search entity");
		System.out.println("value is " + result);
		if(!result)
		{
			logfailinfo("Search value is not displayed" + searchitem);			
		}
		waitForPageLoaded();
		clearText(Search);
	}

	//old implementation
	@SuppressWarnings("unchecked")
	public void Validate_sorting() throws Throwable
	{

		@SuppressWarnings("rawtypes")
		ArrayList obtainedlist=new ArrayList();
		String value="";
		By colscount=By.xpath("//thead[@class='p-datatable-thead']//th");
		waitForVisibilityOfElement(colscount,"Column count",20);
		int rowscount=getElementsSize(colscount);
		waitForPageLoaded();
		for(int i=1;i<=rowscount-1;i++)
		{
			waitForPageLoaded();
			// click on sort button for ascending order
			By	sortingbutton=By.xpath("//thead[@class='p-datatable-thead']/tr/th["+i+"]//span[2]");
			waitForVisibilityOfElement(sortingbutton,"Sorting button",20);
			driver.findElement(sortingbutton).click();
			//		int columncount=driver.findElements(By.xpath("//tbody[@class='p-datatable-tbody']//tr["+i+"]/td")).size();
			int columncount=driver.findElements(By.xpath("//tbody[@class='p-datatable-tbody']//tr/td["+i+"]")).size();

			obtainedlist.clear();
			for(int j=1;j<=columncount;j++)
			{   
				value=driver.findElement(By.xpath("//tbody[@class='p-datatable-tbody']//tr["+j+"]/td["+i+"]")).getText();
				try
				{
					Integer val = Integer.valueOf(value);
					obtainedlist.add(val);
				}
				catch (Exception ex) {
					obtainedlist.add(value);
				}
				waitForPageLoaded();
			}
			//	sorting_isAscending(obtainedlist);
			// click on sort button for descending order
			sortingbutton=By.xpath("//thead[@class='p-datatable-thead']/tr/th["+i+"]//span[2]");
			waitForVisibilityOfElement(sortingbutton,"Sorting button",20);
			driver.findElement(sortingbutton).click();
			obtainedlist.clear();
			for(int j=1;j<=columncount;j++)
			{
				value=driver.findElement(By.xpath("//tbody[@class='p-datatable-tbody']//tr["+j+"]/td["+i+"]")).getText();
				try
				{
					Integer val = Integer.valueOf(value);
					obtainedlist.add(val);
				}
				catch (Exception ex) {
					obtainedlist.add(value);
				}
				waitForPageLoaded();
			}
			//	sorting_isDescending(obtainedlist);
		}
	}

	public void waitForPageLoaded() throws Throwable {
		this.pageLoader();
		new WebDriverWait(driver, 30).until((ExpectedCondition<Boolean>) wd ->
		((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));

		By loc=By.cssSelector("[class='ui loader-wrap loading-alignments loading']");
		waitForInVisibilityOfElement(loc, "Loader", 60);
	}

	public void pageLoader() throws Throwable{
		By loc=By.cssSelector("[class='ui loader-wrap loading-alignments loading'] [class='ui large text loader loader']");
		waitForInVisibilityOfElement(loc, "Loader", 20);
	}

	//validating PAGINATION	
	public void Validate_Pagination() throws Throwable {

		boolean result;
		//locators for pagination
		By listbox = By.xpath("//div[@role='listbox']");
		By itemsnumber = By.xpath("(//span[@class='bold'])[1]");
		By tablerows = By.xpath("//tbody[@class='p-datatable-tbody']/tr");
		By pagination = By.xpath("//div[contains(@class,'page-btn item-btn ')]");
		By table_element=By.xpath("(//tr[@class='p-datatable-row']/td)[1]");

		waitForVisibilityOfElement(table_element,"web table",20);
		waitForVisibilityOfElement(listbox,"Listbox",20);
		click(listbox, "Click on listbox");
		selectItems_perpage("30 per page");

		// to zoom the page
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("document.body.style.zoom = '88%';");
		waitForVisibilityOfElement(itemsnumber,"Web table is not loaded with in time",25);
		waitForPageLoaded();

		// Validating 1-30
		result=	validateCheckPointMatch(itemsnumber,"1 - 30","30 items per page");
		if(!result) {
			logfailinfo("items per page are not displayed as expected");
			//	softassertion.fail("items per page are not displayed as expected");
			//	softassertion.assertAll();
		}
		validateCheckPointEquals(String.valueOf(getElementsSize(tablerows)),"30","Validationg size of the table");
		//		Assert.assertEquals(String.valueOf(getElementsSize(tablerows)),"30");

		clickonListbox();
		selectItems_perpage("20 per page");
		// Validating 1-20
		result = validateCheckPointMatch(itemsnumber,"1 - 20","20 items per page");
		System.out.println(result);
		if(!result) {
			logfailinfo("items per page are not displayed as expected");
			//	softassertion.fail("items per page are not displayed as expected");
			//	softassertion.assertAll();
		}
		validateCheckPointEquals(String.valueOf(getElementsSize(tablerows)),"20","Validating size of the table");
		//		Assert.assertEquals(String.valueOf(getElementsSize(tablerows)),"20");

		waitForPageLoaded();
		clickonListbox();
		selectItems_perpage("10 per page");
		// Validating 1-10
		result=	validateCheckPointMatch(itemsnumber,"1 - 10","10 items per page");
		System.out.println(result);
		if(!result) {
			logfailinfo("items per page are not displayed as expected");
			//	softassertion.fail("items per page are not displayed as expected");
			//	softassertion.assertAll();
		}
		validateCheckPointEquals(String.valueOf(getElementsSize(tablerows)),"10","Validating size of the table");
		//	Assert.assertEquals(String.valueOf(getElementsSize(tablerows)),"10");
		waitForPageLoaded();
		List<WebElement> paginationvalues = getWebElementList(pagination,"pagination list");
		for (int i = 0; i < paginationvalues.size(); i++) {
			WebElement element = paginationvalues.get(i);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			waitForPageLoaded();
		}
	}

	//click on sort button
	public void clickonsortbutton(String columnname) throws Throwable
	{
		//	Thread.sleep(3000);
		//By sortbtn =By.xpath("//thead[@class='p-datatable-thead']/tr/th["+i+"]//span[2]");
		By sortbtn=By.xpath("//span[text()='"+columnname+"']/../span[2]");
		waitForVisibilityOfElement(sortbtn,"Sorting button",25);			
		click(sortbtn,"Sortbutton");	
		//Thread.sleep(3000);
	}
	@SuppressWarnings("unchecked")
	//New implemenation to sort the column name
	//Validating sorting based on the columnname that we pass as an paramter
	public void Validate_Sorting(String columnname,String ordertype) throws Throwable
	{
		@SuppressWarnings("rawtypes")
		ArrayList obtainedlist=new ArrayList();
		@SuppressWarnings("rawtypes")
		ArrayList tmplist=new ArrayList();
		String value="";
		//Thread.sleep(4000);
		By table_element=By.xpath("(//tr[@class='p-datatable-row']/td)[1]");
		waitForVisibilityOfElement(table_element,"web table",20);

		By coulmns =By.xpath("//thead[@class='p-datatable-thead']//span[1]");
		List<WebElement> elements = getWebElementList(coulmns,"Table Columns");
		int count = elements.size();
		//	System.out.println(count);
		for(int i=0;i<count;i++)
		{
			String text=elements.get(i).getText();
			//System.out.println("text --> " + text);
			if(text.equals(columnname.toUpperCase()))
			{
				i=i+1;
				//	Thread.sleep(2000);
				By data = By.xpath("//tbody[@class='p-datatable-tbody']//tr/td["+i+"]");
				waitforPresence_Elements(data,"data",15);
				List<WebElement> datavalues = getWebElementList(data,"Table Data");
				for(int j=0;j<=datavalues.size()-1;j++)
				{  			
					value=datavalues.get(j).getText();
					//	System.out.println("Data ->> " + value);
					try
					{
						//	Integer val=Integer.valueOf(value);
						String val = String.valueOf(value);
						obtainedlist.add(val);
						tmplist.add(val);
					}
					catch (Exception ex) {
						obtainedlist.add(value);
						tmplist.add(value);
					}	
				}
				tmplist.sort(String.CASE_INSENSITIVE_ORDER);
				//	Thread.sleep(2000);
				if(ordertype.equalsIgnoreCase("Ascending")) {	
					sorting_isAscending(obtainedlist,tmplist);
				}
				if(ordertype.equalsIgnoreCase("Descending")) {
					Collections.reverse(tmplist);
					sorting_isDescending(obtainedlist,tmplist);
				}
			}
		}
	}


}
