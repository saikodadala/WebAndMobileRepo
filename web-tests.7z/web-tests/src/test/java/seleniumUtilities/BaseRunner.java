package seleniumUtilities;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import common.utils.OsUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.sun.tools.xjc.addon.sync.SynchronizedMethodAddOn;

import common.Apiutils.Api;
import common.reports.CReporter;
import common.reports.ConfigFileReadWrite;
import common.reports.ReporterConstants;
import common.reports.TestResult;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.Movilizer.HomePage;
import pages.Movilizer.LoginPage;

/**
 * Driver Script/Base Runner to load/close the configurations before/after each test Run and also configurations to execute in different browsers
 * @author Sai Kodadala
 *
 */
public class BaseRunner {



	List<String> assetids = null;
	List<String> subassetsvalues= null;
	List<String> Taskvalues= null;
	List<String> uservalues= null;
	List<String> devicevalues=null;
	List<String> abstractassetvalues= null;
	List<String> roundtemplatevalues=null;
	String levelid =null;



	public static Logger LOG = Logger.getLogger(BaseRunner.class);
	public static long startTime;

	public static Hashtable<String, String> data = new Hashtable<String, String>();
	public static WebDriver driver = null;

	public ExtentReports extent;
	public static ExtentTest scenarioDef;
	public static ExtentTest features;
	public static String reportLocation="/reports";
	
	public final static int TIMEOUT = 30;
	public final static int PAGE_LOAD_TIMEOUT = 50;
	public static String browserName;
	public static String downloadFilepath;

	public static String landingURL ;
	public static String ApiURL;
	public static String Systemid;

	protected static String OR2_MovilizerURL = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile,"OR2_MovilizerURL");
	protected static String OR_MovilizerURL = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "OR_MovilizerURL");
	protected static String PSR_MovilizerURL = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile,"PSR_MovilizerURL");
	protected static String OR_ApiEndpointURL = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile,"OR_Movilizer_EndpointURL");
	protected static String OR_SystemID = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile,"OR_Movilizer_SystemID");
	protected static String OR2_ApiEndpointURL = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile,"OR2_Movilizer_EndpointURL");
	protected static String OR2_SystemID = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile,"OR2_Movilizer_SystemID");
	protected static String automationName = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "automationName");
	protected static String browser = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "browser");
	protected static String browserVersion = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "browserVersion");
	protected static String environment = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "environment");
	protected static String appName = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "appName");
	protected static String appEnvironment = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "appEnvironment");
	protected static String userName = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile,"Web_UserName");
	protected static String password = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile,"Password");







	/**
	 * Launchbrowser :: Setting webdriver based on Browser which is going to be executed

	 */
	public static void Launchbrowser(String browsertype) throws IOException, InterruptedException {

		switch (browsertype) {
		case "firefox":
		case "ie":
		case "chrome":
			WebDriverManager.chromedriver().setup();
			//	WebDriverManager.chromedriver().browserVersion("90.0.4430.24").setup();

			ChromeOptions chromeOptions = new ChromeOptions();
			// setting up property to suppress the warning
			System.setProperty("webdriver.chrome.silentOutput","true");
			//	chromeOptions.addArguments("--headless", "--disable-gpu", "--window-size=1200,1100","--ignore-certificate-errors","--disable-extensions","--no-sandbox","--disable-dev-shm-usage");
			//	chromeOptions.addArguments("--headless", "--disable-gpu","--ignore-certificate-errors","--disable-extensions","--no-sandbox","--disable-dev-shm-usage");
			driver = new ChromeDriver(chromeOptions);
			driver.manage().window().maximize();			
			break;
		case "edge":
			WebDriverManager.edgedriver().setup();
			System.out.println("Executing in Edge Browser");
			driver = new EdgeDriver();
			driver.manage().window().maximize();
			break;
		}
	}

	//set the environment
	public void setEnvironment(String env)
	{
		if (env.equalsIgnoreCase("or2")) {
			driver.get(OR2_MovilizerURL);
			ApiURL = OR2_ApiEndpointURL;
			Systemid = OR2_SystemID;
		} if (env.equalsIgnoreCase("or")) {
			driver.get(OR_MovilizerURL);
			ApiURL = OR_ApiEndpointURL;
			Systemid = OR_SystemID;
		} if (env.equalsIgnoreCase("psr")) {
			driver.get(PSR_MovilizerURL);
		}	
	}

	//loginto application
	public void logintoApplication(String username,String password) throws Throwable
	{
		LoginPage loginPage=new LoginPage();
		HomePage homePage=new HomePage();

		loginPage.enterUserName(username);
		loginPage.clickSignIn();
		loginPage.enterpassWord(password);
		loginPage.clickSignIn();
		homePage.clickOnMainMenu();
		homePage.clickOnEasyConfig();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		homePage.switchFrame();

		/*
		 * By lvel = By.xpath("//span[text()='Levels Hierarchy']"); GenericMethods
		 * genric=new GenericMethods();
		 * genric.waitForVisibilityOfElement(lvel,"Levehirar",80);
		 */

	}










	//to delete the entities
	public  void deleteEntities(String type,List<String> entity,String token) throws Throwable
	{


		Api api=new Api();
		LoginPage loginPage=new LoginPage();
		//	String token = loginPage.getCookie();;
		System.out.println("Enity --> " + type + " " + entity.size());
		switch (type) 	
		{
		case "Roundtemplate":
			if(!entity.isEmpty())
			{
				//	token=loginPage.getCookie();
				for(int i=1;i<=entity.size();i++)
				{
					api.DeleteRoundtemplate_api(token,entity.get(i-1));
				}
				break;
			}	
		case "Tasks":
			if(!entity.isEmpty())
			{
				//	token=loginPage.getCookie();
				for(int i=1;i<=entity.size();i++)
				{
					api.DeleteTask_api(token,entity.get(i-1));
				}
				break;
			}
		case "SubAssets":
			if(!entity.isEmpty())
			{
				//	token=loginPage.getCookie();
				for(int i=1;i<=entity.size();i++)
				{
					api.DeleteAsset_api(token,entity.get(i-1));
				}
				break;
			}		
		case "Assets":
			if(!entity.isEmpty())
			{
				//	token=loginPage.getCookie();
				for(int i=1;i<=entity.size();i++)
				{
					api.DeleteAsset_api(token,entity.get(i-1));
				}
				break;
			}
		case "AbstractAssets":
			if(!entity.isEmpty())
			{

				for(int i=1;i<=entity.size();i++)
				{
					//	token=loginPage.getCookie();
					api.DeleteAsset_api(token,entity.get(i-1));
				}
				break;
			}
		case "Users":
			if(!entity.isEmpty())
			{
				//	token=loginPage.getCookie();
				for(int i=1;i<=entity.size();i++)
				{
					api.DeleteUser_api(token,entity.get(i-1));
				}
				break;
			}
		case "Devices":
			if(!entity.isEmpty())
			{
				//	token=loginPage.getCookie();
				for(int i=1;i<=entity.size();i++)
				{
					api.DeleteDevice_api(token,entity.get(i-1));
				}
				break;
			}
		case "SubLevelhirarchy":
			if(!entity.isEmpty())
			{
				//	token=loginPage.getCookie();
				for(int i=entity.size()-1;i>=0;i--)
				{
					api.DeleteLevelhirarchy_api(token,entity.get(i));
				}
				break;
			}	
		case "Levelhirarchy":
			if(!entity.isEmpty())
			{
				//	token=loginPage.getCookie();
				for(int i=1;i<=entity.size();i++)
				{
					//	api.getLevelhirarchyId_api(token,BaseClass.name.get(i-1));
					api.DeleteLevelhirarchy_api(token,entity.get(i-1));
				}
				break;
			}
		}
	}


	public void delete(String type) throws Throwable
	{
		Api api=new Api();
		LoginPage loginPage=new LoginPage();
		String token ;

		if(type.equalsIgnoreCase("SubAssets")) {
			//to delete subasset
			for(int i=0;i<BaseClass.Assetids.size();i++)
			{
				token= loginPage.getCookie();
				List<String> subassetids = api.getSubAssets_api(token,BaseClass.Assetids.get(i));
				System.out.println(subassetids.size());
				BaseClass.SubAssetids.clear();
				for(int j=0;j<subassetids.size();j++) {
					System.out.println("Subasset");
					BaseClass.SubAssetids.add(subassetids.get(j));	
				}
				if(subassetids.size()>0) {
					//	deleteEntities("SubAssets",subassetids);
				}
			}
		}

		if(type.equalsIgnoreCase("Assets")) {
			//to delete asset ids
			for(int i=0;i<BaseClass.Levelhirarchyids.size();i++)
			{
				token= loginPage.getCookie();
				System.out.println(BaseClass.Levelhirarchyids.get(i));
				List<String> assetids = api.getAssets_api(token,BaseClass.Levelhirarchyids.get(i));
				System.out.println(assetids.size());
				BaseClass.Assetids.clear();
				for(int j=0;j<assetids.size();j++) {
					BaseClass.Assetids.add(assetids.get(j));	
				}
				if(assetids.size()>0) {
					//		deleteEntities("Assets",assetids);
				}
			}
		}
	}


	@SuppressWarnings("null")
	public Map<String, List<String>> EntityIds(String token) throws MalformedURLException {
		Api api =new Api();
		LoginPage login =new LoginPage();
		//	String token=login.getCookie();
		Map<String,List<String>> entityids=new HashMap<String, List<String>>();
		entityids.clear();

		if(!BaseClass.Hirarchyname.isEmpty()) {
			//	token=login.getCookie();
			levelid=api.getLevelhirarchyId_api(token,BaseClass.Hirarchyname);
			entityids.put("Levelhirarchy",Arrays.asList(levelid));
		}

		if(levelid!= null) {
			String value = api.getSubLevelhirarchyId_api(token,levelid);
			List<String> list = new ArrayList<String>();
			if(value!=null) {
				list.add(value);
				entityids.put("SubLevelhirarchy",list);
				int count=1;
				for(int i=0;i<count;i++) {	
					value=api.getSubLevelhirarchyId_api(token,value);
					System.out.println(value);
					if(value!=null) {
						list.add(value);
						entityids.put("SubLevelhirarchy",list);
						count++;
					}
				}
			}
			else {
				entityids.put("SubLevelhirarchy",list);
			}
		}


		if(levelid!= null) {
			//		token=login.getCookie();
			assetids=api.getAssetIds_api(token,levelid);	
			entityids.put("Assets",assetids);
		}
		if(assetids!=null) {
			//	token = login.getCookie();
			for(int i=0;i<assetids.size();i++)
			{
				String assetid=assetids.get(i);
				subassetsvalues=api.getSubAssetIds_api(token,assetid);
				if(subassetsvalues.size()>0) {
					entityids.put("SubAssets",subassetsvalues);
				}
				else {
					entityids.put("SubAssets",subassetsvalues);
					break;
				}
			}
		}
		if(assetids!=null) {
			//	token = login.getCookie();
			for(int i=0;i<assetids.size();i++)
			{
				String assetid=assetids.get(i);
				Taskvalues=api.getTaskIds_api(token,assetid);
				if(Taskvalues.size()>0) {
					entityids.put("Tasks",Taskvalues);
				}
				else {
					entityids.put("Tasks",Taskvalues);
					break;
				}	
			}
		}
		if(levelid!=null) {
			//	token=login.getCookie();
			uservalues=api.getUserIds_api(token,levelid);
			entityids.put("Users",uservalues);
		}
		if(levelid!=null) {
			//	token=login.getCookie();
			devicevalues=api.getDeviceIds_api(token,levelid);
			entityids.put("Devices",devicevalues);
		}
		if(levelid!=null) {
			//	token=login.getCookie();
			roundtemplatevalues=api.getRoundtemplateIds_api(token,levelid);
			entityids.put("Roundtemplate",roundtemplatevalues);	
		}
		//	token = login.getCookie();
		abstractassetvalues=api.getAbstractsIds_api(token);
		entityids.put("AbstractAssets",abstractassetvalues);
		BaseClass.Hirarchyname.clear();
		return entityids;
	}

	// to get list of enitiy ids
	public List<String> getlist(Map<String,List<String>>map,String entity)
	{
		List<String> values = null;
		for (Map.Entry<String, List<String>> entry : map.entrySet()) {
			String key = entry.getKey();
			if(key.equals(entity)) {
				values=entry.getValue();
				System.out.println("key *** " + key + " is " + values);
				break;
			}
			else
			{
				values=new ArrayList<String>();
			}
		}
		return values;
	}

	/*
	@BeforeSuite(alwaysRun = true)	
	public void timeCal() throws Throwable {

		  System.out.println("Before suites ");
		  TestResult.iSuite_StartTime=System.currentTimeMillis();

	}


	@AfterMethod(alwaysRun = true)
	public void afterClass() {
		try {
			//	startTime = System.currentTimeMillis(); Date date = new Date();
			//	SimpleDateFormat sdf = new SimpleDateFormat("dd_MMM_yyyy hh mm ss SSS");
			//	String formattedDate = sdf.format(date); iSuiteEndTime =formattedDate.replace(":", "_").replace(" ", "_");
		//	System.out.println("Suite time ==============>" + iSuiteEndTime);
			//		reporter.calculateSuiteExecutionTime();
		//	driver.close();
		}catch (Exception e) {
		//	System.out.println("Exception "+e);
		}
	}

	@AfterSuite(alwaysRun = true)
	public void afterSuite() throws Exception {
		try {
			//driver.close();
			//driver.quit();
		}catch (Exception e) {
			System.out.println("Exception "+e);
		}
	}
	 */
}
