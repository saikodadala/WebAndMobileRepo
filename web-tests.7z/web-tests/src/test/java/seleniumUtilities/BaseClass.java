package seleniumUtilities;

import java.util.ArrayList;
import java.util.List;

import common.Apiutils.Api;
import pages.Movilizer.*;


public class BaseClass extends GenericMethods {
	
	//entities
	public static List<String>Levelhirarchyids=new ArrayList<String>();
	public static List<String>SubLevelhirarchyids=new ArrayList<String>();
	public static List<String>Assetids=new ArrayList<String>();
	public static List<String>SubAssetids=new ArrayList<String>();
	public static List<String>AbstractAssetids=new ArrayList<String>();
	public static List<String>Taskids=new ArrayList<String>();
	public static List<String>Roundtemplateids=new ArrayList<String>();
	public static List<String>Userids=new ArrayList<String>();
	public static List<String>Deviceids=new ArrayList<String>();
	public static List<String>Hirarchyname=new ArrayList<String>();
	

    protected LoginPage loginPage = new LoginPage();;
    protected HomePage homePage = new HomePage();
    protected TemplatePage templatePage= new TemplatePage();
    protected AssetsPage assetPage= new AssetsPage();
    protected DevicePage devicePage = new DevicePage();
    protected APIConnection api=new APIConnection();
    protected CommonPage common=new CommonPage();
    protected ManageUsers users=new ManageUsers();
    protected Api apii=new Api();
    protected CreateLevelPage levels=new CreateLevelPage();
    protected AssetConfigurationPage assetConfigurationPage = new AssetConfigurationPage();
    protected AboutEasyConfigPage about = new AboutEasyConfigPage();
    protected AddAbstractAssetPage addAbstract=new AddAbstractAssetPage();
    protected ConfigurationPage configPage=new ConfigurationPage();
    protected AbstractAssetPage abstractAsset=new AbstractAssetPage();
    protected MasterDataPage masterDataPage = new MasterDataPage();
    protected TaskPage taskPage = new TaskPage();
    protected UnitDetailsPage unitDetailsPage=new UnitDetailsPage();


}
