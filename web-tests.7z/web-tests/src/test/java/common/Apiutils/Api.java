package common.Apiutils;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gwt.thirdparty.json.JSONArray;
import com.google.gwt.thirdparty.json.JSONException;
import com.google.gwt.thirdparty.json.JSONObject;
import com.honeywell.movilizer.portalsdk.client.RESTClient;
import com.honeywell.movilizer.portalsdk.client.ir.AssetProvider;
import com.honeywell.movilizer.portalsdk.client.ir.AssetService;
import com.honeywell.movilizer.portalsdk.client.ir.AttachmentService;
import com.honeywell.movilizer.portalsdk.client.ir.DeviceProvider;
import com.honeywell.movilizer.portalsdk.client.ir.DeviceService;
import com.honeywell.movilizer.portalsdk.client.ir.IndexProvider;
import com.honeywell.movilizer.portalsdk.client.ir.IndexService;
import com.honeywell.movilizer.portalsdk.client.ir.LevelProvider;
import com.honeywell.movilizer.portalsdk.client.ir.LevelService;
import com.honeywell.movilizer.portalsdk.client.ir.LimitProvider;
import com.honeywell.movilizer.portalsdk.client.ir.LimitService;
import com.honeywell.movilizer.portalsdk.client.ir.RoundTemplateProvider;
import com.honeywell.movilizer.portalsdk.client.ir.RoundTemplateService;
import com.honeywell.movilizer.portalsdk.client.ir.TaskProvider;
import com.honeywell.movilizer.portalsdk.client.ir.TaskService;
import com.honeywell.movilizer.portalsdk.client.ir.UserProvider;
import com.honeywell.movilizer.portalsdk.client.ir.UserService;
import com.movilizer.portal.sdk.shared.ir.domain.Asset;
import com.movilizer.portal.sdk.shared.ir.domain.Attachment;
import com.movilizer.portal.sdk.shared.ir.domain.Device;
import com.movilizer.portal.sdk.shared.ir.domain.Level;
import com.movilizer.portal.sdk.shared.ir.domain.Limit;
import com.movilizer.portal.sdk.shared.ir.domain.RoundTemplate;
import com.movilizer.portal.sdk.shared.ir.domain.Task;
import com.movilizer.portal.sdk.shared.ir.domain.User;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.paging.Paginator;
import com.movilizer.portal.sdk.shared.ir.domain.structs.StringMap;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import seleniumUtilities.BaseClass;
import seleniumUtilities.GenericMethods;

public class Api extends GenericMethods {





	static IndexService indexservice = null;
	static LevelService levelservice = null;
	static AssetService assetservice = null;
	static TaskService taskservice = null;
	static LimitService limitservice = null;
	static AttachmentService attachmentservice = null;
	static RoundTemplateService roundtemplateservice = null;
	static UserService userservice=null;
	static DeviceService deviceservice=null;

	public Level level;
	public Asset asset;
	public Task task;
	public User user;
	public Limit limit;
	public Attachment attachment;
	public RoundTemplate roundtemplate;
	public String id = "";
	public Device device;

	com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity<Level> entitylevel = null;
	com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity<Boolean> result = null;
	com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity<Asset> entityasset = null;
	com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity<Task> entitytask = null;
	com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity<Limit> entitylimit = null;
	com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity<Attachment> entityattachment = null;
	com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity<RoundTemplate> entityroundtemplate = null;
	com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity<User> entityuser=null;
	com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity<Device> entitydevice = null;

	public void printrequest_payload(Object entity) throws JsonProcessingException
	{

		ObjectMapper objectMapper = new ObjectMapper(); 
		String Json=objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(entity); 
		System.out.println("Request Paylod is -------> " + Json);



	}

	/*	
======================================================================================================	*/

	// Create Level hirarchy with api
	public String createLevelhirarchy_api(String token, String levelhirarchyname) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			levelservice = new LevelProvider(client);
			level = new Level();
			level.setCompact(Systemid, levelhirarchyname, "SITE", "Europe/Berlin");
			printrequest_payload(level);
			entitylevel = levelservice.addTo("Levels", Systemid, level);			
			boolean erroneous=entitylevel.isErroneous();
			if(!erroneous){
				id = entitylevel.getBody().getId();
			}else{				
				logfailinfo("Level hirarchy is not created");
			}
			System.out.println("Levelhirarchy id is **** " + id);			
			System.out.println("Levelhirarchy name is *** " + entitylevel.getBody().getName());
		} catch (Exception e) {	
			logfailinfo("Level hirarchy is not created " + e .getMessage());
		}
		return id;
	}

	/*
	// Update parent levelhirarchy with api
	public String updateParentLevelhirarchy_api(String token, String udpatelevelhirarchyname,String parentlevelid) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			levelservice = new LevelProvider(client);
			level = new Level();
			level.setCompactUpdatelevelhirarchy(Systemid, udpatelevelhirarchyname, "SITE", "Europe/Berlin",parentlevelid);
			entitylevel = levelservice.updateTo("Levels",Systemid, level);
			id = entitylevel.getBody().getId();
			System.out.println("Update parent level hirarchy is" + udpatelevelhirarchyname);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			logfailinfo("Levelhirarchy Update is failed" + e.getMessage());
		}
		return id ;
	}

	 */
	// Create sub Level with api
	public String createSublevel_api(String token,String sublevelname,String levelhirarcyid) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL,token);
			levelservice = new LevelProvider(client);
			level = new Level();
			level.setCompact(levelhirarcyid, sublevelname, "SITE", "Europe/Berlin");
			entitylevel = levelservice.addTo("Levels", levelhirarcyid, level);
			boolean erroneous=entitylevel.isErroneous();
			if(!erroneous){
				id = entitylevel.getBody().getId();
			}else{				
				logfailinfo("Sublevel is not created");
			}
			System.out.println("Sublevel id is *** " + id);
			System.out.println("Sublevel name is *** " + entitylevel.getBody().getName());
			//	reporter.SuccessReport("SubLevel hirarachy create with api", "SubLevel hirarachy is " + sublevelname);
		} catch (Exception e) {
			//	reporter.failureReport("Sublevel create", "SubLevel create is failed " + entitylevel.getBody());
			//	reporter.failureReport("SubLevel  create", "SubLevel create is failed" + e.getMessage());
			logfailinfo("SubLevel create is failed" + e.getMessage());
		}
		return id;
	}
	/*
	// Update Sub levelhirarchy with api
	public String updateSubLevelhirarchy_api(String token, String udpatesublevelhirarchyname, String parentlevelid,
			String sublevelid) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			levelservice = new LevelProvider(client);
			level = new Level();
			level.setCompactUpdatelevelhirarchy(sublevelid, udpatesublevelhirarchyname, "SITE","Europe/Berlin", parentlevelid);
			entitylevel = levelservice.updateTo("Levels", parentlevelid, level);
			id = entitylevel.getBody().getId();
			System.out.println("Update sublevelname is " +  udpatesublevelhirarchyname);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			logfailinfo("SubLevel hirarchy Update is failed" + e.getMessage());
		}
		return id;
	}
	 */

	// Delete Level hirarchy with api
	public void DeleteLevelhirarchy_api(String token, String levelhirarchyid) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL,token);
			levelservice = new LevelProvider(client);
			result= levelservice.delete(levelhirarchyid);
			if(result.isErroneous())
			{
				System.out.println("Level hirarchy is failed to delete");
				logfailinfo("Level hirarchy is failed to delete " + result.getBody());				
			}
		} catch (Exception e) {
			logfailinfo("Level hirarchy delete is failed " + e.getMessage());
		}
	}

	// create asset with api
	public String createAsset_api(String token, String levelid, String assetname, String assettype, String assetmode)
			throws Throwable {
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			assetservice = new AssetProvider(client);
			LinkedHashSet<String> assetmodes = new LinkedHashSet<String>();
			assetmodes.add(assetmode);
			asset = new Asset();
			asset.setModes(assetmodes);
			asset.setCompact(levelid, assetname, " ", " "," ","false", "1", assettype);
			//printrequest_payload(asset);
			entityasset=assetservice.addTo("Levels", levelid, asset);
			boolean erroneous=entityasset.isErroneous();
			if(!erroneous){
				id = entityasset.getBody().getId();
			}else{				
				logfailinfo("Asset is not created");
			}
			System.out.println("Asset id is *** " + id);
			System.out.println("Asset Name is" + entityasset.getBody().getName());
		} catch (Exception e) {
			logfailinfo("Asset create is failed" + e.getMessage());
		}
		return id;
	}

	// Get Asset details with api
	public List<String> getAssets_api(String token,String levelid)
	{
		List<String>entityids=new ArrayList<String>();
		SharedResponseEntity<StringMap> res = null;
		HashMap<String, String> dataMap = null;
		try {
			//	res =indexservice.get("Assets", "name", "parentId", "ba5064084dd45adbc1900d0d47baa08");
			RESTClient client = new RESTClient(ApiURL, token);
			indexservice= new IndexProvider(client);
			res =indexservice.get("Assets", "name", "parentId",levelid);
			StringMap body = res.getBody();
			dataMap = body.getBackingMap();
			//System.out.println(body.getBackingMap());
			for (String key : dataMap.keySet()) 
			{ 
				String value = dataMap.get(key);
				entityids.add(value);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
			logfailinfo("Exception --> " + e.getMessage());
		}
		return entityids;
	}

	// Get SubAsset details with api
	public List<String> getSubAssets_api(String token, String Assetid)
	{
		List<String>entityids=new ArrayList<String>();
		SharedResponseEntity<StringMap> res = null;
		HashMap<String, String> dataMap = null;
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			indexservice= new IndexProvider(client);
			res =indexservice.get("Assets","name", "parentId",Assetid);
			StringMap body = res.getBody();
			dataMap = body.getBackingMap();
			for (String key : dataMap.keySet()) 
			{ 
				String value = dataMap.get(key);
				entityids.add(value);
			}
		} catch (Exception e) {
			logfailinfo("Exception --> " + e.getMessage());
		}
		return entityids;
	}

	/*
	// 
	public String getdetails(String token, String levelid) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			levelservice = new LevelProvider(client);
			level = new Level();
			// Request URL: https://or.test.dev.movilizer.cloud/ui/portal-sdk/services
			//		/asset/listBy/LhasR/Levels/50f04e964114e4a82fd1f8be7c24f5d
			//		?timeRangeStart=-9223372036854775808&offset=0&timeRangeEnd=9223372036854775807&limit=2147483647
			levelservice.listBy("LhasR","Levels","50f04e964114e4a82fd1f8be7c24f5d",0,0,0L,0L);
			levelservice
			id = entitylevel.getBody().getId();
			System.out.println("Levelhirarchy id is **** " + id);
			System.out.println("Levelhirarchy name is *** " + entitylevel.getBody().getName());
		} catch (Exception e) {	
			logfailinfo("Level hirarchy is not created " + e .getMessage());
		}
		return id;
	}

	 */


	//create Abstract asset with api
	public String createAbstractasset_api(String token,String abstractassetname,String abstractassettype,String abstractassetmode) throws Throwable
	{
		try {
			RESTClient client = new RESTClient(ApiURL,token);
			assetservice = new AssetProvider(client);
			LinkedHashSet<String>abstractassetmodes=new LinkedHashSet<String>();
			abstractassetmodes.add(abstractassetmode);
			asset= new Asset();    
			asset.setModes(abstractassetmodes);
			asset.setCompact(Systemid, abstractassetname,"","","","false","1",abstractassettype);			
			entityasset= assetservice.addTo("Levels",Systemid,asset);
			boolean erroneous=entityasset.isErroneous();
			if(!erroneous){
				id = entityasset.getBody().getId();
			}else{				
				logfailinfo("Abstract asset is not created");
			}
			System.out.println("Abstractasset id is **** " + id);
			System.out.println("Abstractasset Name is" + entityasset.getBody().getName());
		} catch (Exception e) {
			logfailinfo("Abstractasset create is failed" + e.getMessage());
			logfailinfo("Abstractasset create is failed" + e.getCause());
		}
		return id;
	}



	/*
	// Update asset with api
	public String updateAsset_api(String token, String levelid, String updateassetname, String assetid)
			throws Throwable {
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			assetservice = new AssetProvider(client);
			asset = new Asset();
			asset.setCompactUpdateAsset(levelid, updateassetname, null, null, null, null,"1", "Pumps", assetid);
			entityasset = assetservice.updateTo("Levels", levelid, asset);
			id = entityasset.getBody().getId();
			System.out.println("update Asset id is " + id);
			System.out.println("update Asset Name is" + entityasset.getBody().getName());
		} catch (Exception e) {
			logfailinfo("Asset update is failed" + e.getMessage());
		}
		return id;
	}
	 */
	// create sub asset with api
	public String createSubAsset_api(String token, String assetid, String subassetname, String assettype,String assetmode) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			assetservice = new AssetProvider(client);
			asset = new Asset();
			LinkedHashSet<String> assetmodes = new LinkedHashSet<String>();
			assetmodes.add(assetmode);
			asset.setModes(assetmodes);
			asset.setCompact(assetid, subassetname, null, null, null, null,"1", assettype);
			entityasset = assetservice.addTo("Assets", assetid, asset);
			boolean erroneous=entityasset.isErroneous();
			if(!erroneous){
				id = entityasset.getBody().getId();
			}else{				
				logfailinfo("Sub Asset is not created");
			}
			System.out.println("sub Asset id is " + id);
			System.out.println("sub Asset Name is" + entityasset.getBody().getName());
		} catch (Exception e) {
			logfailinfo("SubAsset create is failed" + e.getMessage());
		}
		return id;
	}

	/*
	// update sub asset with api
	public String updateSubAsset_api(String token, String assetid, String updatesubassetname, String subassetid)
			throws Throwable {
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			assetservice = new AssetProvider(client);
			asset = new Asset();
			asset.setCompactUpdateAsset(assetid, updatesubassetname, null, null, null, null, "1", "Machines",subassetid);
			entityasset = assetservice.updateTo("Assets", assetid, asset);
			id = entityasset.getBody().getId();
			System.out.println("update sub Asset id is " + id);
			System.out.println("update subAsset Name is" + entityasset.getBody().getName());
		} catch (Exception e) {
			logfailinfo("SubAsset update is failed" + e.getMessage());
		}
		return id;
	}
	 */
	// Delet asset with api
	public void DeleteAsset_api(String token, String assetid) throws Throwable {
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			assetservice = new AssetProvider(client);
			SharedResponseEntity<Asset> entityresult = assetservice.delete(assetid);
			if(entityresult.isErroneous())
			{
				System.out.println("Asset is failed to delete ");
				logfailinfo("Asset is failed to delete " + result);				
			}
		} catch (Exception e) {
			logfailinfo("Asset delete is failed" + e.getMessage());
		}
	}

	// create task with api with out limit
	public String createTask_api(String token, String assetid, String taskname, String tasktype) throws Throwable {
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			taskservice = new TaskProvider(client);
			task = new Task();
			//		task.setCompact(assetid, taskname, tasktype, " ", " ", " ", " ", "false", "1","2");
			//	printrequest_payload(task);
			SharedResponseEntity<List<Task>> entitytaskresult = taskservice.addTo("Assets", assetid, task);
			boolean erroneous=entitytaskresult.isErroneous();
			if(!erroneous){
				System.out.println("The list is " + entitytaskresult.getBody());
				id = entitytaskresult.getBody().get(0).getId();
			}else{				
				logfailinfo("Task is not created");
			}
			System.out.println("Task id is *** " + id);
		} catch (Exception e) {
			logfailinfo("Task create is failed" + e.getMessage());
		}
		return id;
	}

	public String getdetails(String token) throws Throwable {
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			taskservice = new TaskProvider(client);
			task = new Task();
			//	task.setCompact(assetid, taskname, tasktype, " ", " ", " ", " ", "false", "1","2");
			//	printrequest_payload(task);
			//			SharedResponseEntity<Paginator<List<Task>>> entitytask1 = taskservice.listBy("LhasR","Assets","1a6d59f6ed44deeba0082ef49b7f7c7",0,0,0,0);
			id = entitytask.getBody().getId();
			System.out.println("Task id is *** " + id);
		} catch (Exception e) {
			logfailinfo("Task create is failed" + e.getMessage());
		}
		return id;
	}

	// create task with api with limit
	public String createTask_api(String token, String assetid,String taskname,String limitname,String assetmode,String position,String saptag,String dcstag,String backendid,String category)
			throws Throwable {
		LinkedHashSet<String> values = new LinkedHashSet<String>(Arrays.asList("Done", "InProgress", "Completed"));
		LinkedHashSet<String> assetmodes = new LinkedHashSet<String>();
		assetmodes.add(assetmode);
		LinkedHashSet<Limit>  limits = new LinkedHashSet<Limit>();
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			taskservice = new TaskProvider(client);
			task = new Task();
			limit = new Limit();
			limit.setName(limitname);
			limit.setCompact("","high","10","","","");
			//limits.add(limit);
			task.setValues(values);
			task.setModes(assetmodes);
			task.setPosition(position);
			task.setCompact(assetid, taskname,"Checkbox"," ",saptag,dcstag," ","false",backendid);
			printrequest_payload(task);
			entitytask = taskservice.addRecursive(task);
			boolean erroneous=entitytask.isErroneous();
			if(!erroneous){
				id = entitytask.getBody().getId();
			}else{				
				logfailinfo("Task is not created");
			}
			System.out.println("Task id is *** " + id);
		} catch (Exception e) {
			logfailinfo("Task create is failed" + e.getMessage());
		}
		return id;
	}
	/*
	// update task with api
	public String updateTask_api(String token, String assetid, String updatetaskname, String taskid) throws Throwable {
		// String url1="https://or.test.dev.movilizer.cloud";
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			taskservice = new TaskProvider(client);
			task = new Task();
			task.setCompactUpdateTask(assetid, updatetaskname, "High", null, null, null, null, "false", null, taskid);
			entitytask = taskservice.updateTo("Assets", assetid, task);
			id = entityasset.getBody().getId();
		} catch (Exception e) {
			logfailinfo("Task update is failed" + e.getMessage());
		}
		return id;
	}
	 */
	// Delete task with api
	public void DeleteTask_api(String token, String taskid) throws Throwable {
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			taskservice = new TaskProvider(client);
			result = taskservice.delete(taskid);
			if(result.isErroneous())
			{
				System.out.println("Task is failed to delete");
				logfailinfo("Task is failed to delete " + result.getBody());				
			}
		} catch (Exception e) {
			logfailinfo("Task delete is failed" + e.getMessage());
		}
	}

	// create limit with api
	public String createLimit_api(String token, String taskid, String limitname) throws Throwable {
		// String url1="https://or.test.dev.movilizer.cloud";
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			limitservice = new LimitProvider(client);
			limit = new Limit();
			//		limit.setCompact("","high","Average","", "", "",limitname);
			entitylimit = limitservice.addTo("Tasks", taskid, limit);
			id = entitylimit.getBody().getId();
			System.out.println("Limit id *** " + id);

		} catch (Exception e) {
			logfailinfo("Limit create is failed" + e.getMessage());
		}
		return id;
	}
	/*
	// update limit with api
	public String updateLimit_api(String token, String taskid, String updatelimitname, String limitid)
			throws Throwable {
		// String url1="https://or.test.dev.movilizer.cloud";
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			limitservice = new LimitProvider(client);
			limit = new Limit();
			limit.setCompactUpdatelimit(taskid, "high","20", "", "", "", updatelimitname, limitid);
			entitylimit = limitservice.updateTo("Tasks", taskid, limit);
			id = entitylimit.getBody().getId();
			System.out.println("update limit id is*** " + id);
			System.out.println("update limit Name is" + entitylimit.getBody().getName());
		} catch (Exception e) {
			logfailinfo("Limit update is failed" + e.getMessage());
		}
		return id;
	}
	 */
	// Delete limit with api
	public void DeleteLimit_api(String token, String limitid) throws Throwable {
		// String url1="https://or.test.dev.movilizer.cloud";
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			limitservice = new LimitProvider(client);
			limit = new Limit();
			result = limitservice.delete(limitid);
			if(result.isErroneous())
			{
				System.out.println("Limit is failed to delete ");
				logfailinfo("Limit is failed to delete " + result.getBody());				
			}
		} catch (Exception e) {
			logfailinfo("Limit delete is failed" + e.getMessage());
		}

	}

	// Create Round template with api
	public String createRoundtemplate_api(String token, String levelid, String roundtemplatename, String assetid,
			String taskid, String graceperiodvalue, String category) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			roundtemplateservice = new RoundTemplateProvider(client);
			roundtemplate = new RoundTemplate();
			LinkedHashSet<String> assetvalue = new LinkedHashSet<String>();
			assetvalue.add(assetid);
			LinkedHashSet<String> taskvalue = new LinkedHashSet<String>();
			taskvalue.add(taskid);
			//			roundtemplate.setCompact(levelid, roundtemplatename, graceperiodvalue, assetvalue, taskvalue, category);
			roundtemplate.setAssetIds(assetvalue);
			roundtemplate.setTaskIds(taskvalue);
			roundtemplate.setCategory(category);
			roundtemplate.setCompact(levelid, roundtemplatename, graceperiodvalue);
			entityroundtemplate = roundtemplateservice.addTo("Levels", levelid, roundtemplate);
			printrequest_payload(entityroundtemplate);
			boolean erroneous=entityroundtemplate.isErroneous();
			if(!erroneous){
				id = entityroundtemplate.getBody().getId();
			}else{				
				logfailinfo("Roundtemplate is not created");
			}
			System.out.println("Roundtemplate id is ***" + id);
			System.out.println("Roundtemplate name is" + entityroundtemplate.getBody().getName());
		} catch (Exception e) {
			logfailinfo("Roundtemplate create is failed" + e.getMessage());
		}
		return id;
	}

	// Delete roundtemplate with api
	public void DeleteRoundtemplate_api(String token, String roundtemplateid) throws Throwable {
		try {
			RESTClient client = new RESTClient(ApiURL, token);
			roundtemplateservice = new RoundTemplateProvider(client);
			roundtemplate = new RoundTemplate();
			result = roundtemplateservice.delete(roundtemplateid);
			if(result.isErroneous())
			{
				System.out.println("Round template failed to delete ");
				logfailinfo("Roundtemplate is failed to delete " + result.getBody());				
			}

		} catch (Exception e) {
			logfailinfo("Roundtemplate delete is failed" + e.getMessage());

		}

	}

	// create user with api
	public String createUser_api(String token, String levelid, String username, String employeeid) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			userservice = new UserProvider(client);
			user = new User();
			user.setCompact(levelid, username, "1", employeeid);
			entityuser = userservice.addTo("Levels", levelid, user);		
			boolean erroneous=entityuser.isErroneous();
			if(!erroneous){
				id = entityuser.getBody().getId();
			}else{				
				logfailinfo("User is not created");
			}
			System.out.println("User id is" + id);
			System.out.println("User Name is" + entityuser.getBody().getName());

		} catch (Exception e) {
			logfailinfo("User create is failed" + e.getMessage());
		}
		return id;
	}

	// Delete user with api
	public void DeleteUser_api(String token, String userid) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			userservice = new UserProvider(client);
			result = userservice.delete(userid);
			if(result.isErroneous())
			{    
				System.out.println("User is failed to delete");
				logfailinfo("User is failed to delete " + result.getBody());				
			}

		} catch (Exception e) {
			logfailinfo("user delete is failed " + e.getMessage());

		}

	}



	// uploading an attachment image/video
	// public String createAttachment_api(String token,String assetid,String
	// attachmentname,String attachmenttype) throws Throwable
	// {
	//
	// try {
	//
	// if(attachmenttype.equals("image")) {
	// String currentDir =
	// System.getProperty("user.dir")+"\\resources\\common\\testdata\\movilizer.jpg";
	// File file=new File(currentDir);
	// @SuppressWarnings("resource")
	// FileInputStream fileInputStreamReader = new FileInputStream(file);
	// byte[] bytes = fileInputStreamReader.readAllBytes();
	// String encodevalue = Base64.getEncoder().encodeToString(bytes);
	// RESTClient client = new RESTClient(ApiURL,token);
	// attachmentservice = new AttachmentProvider(client);
	// attachment= new Attachment();
	// attachment.setCompact(attachmentname,encodevalue,"image/png");
	// }
	//
	// if(attachmenttype.equals("video")) {
	// String currentDir =
	// System.getProperty("user.dir")+"\\resources\\common\\testdata\\video.mp4";
	// File file=new File(currentDir);
	// @SuppressWarnings("resource")
	// FileInputStream fileInputStreamReader = new FileInputStream(file);
	// byte[] bytes = fileInputStreamReader.readAllBytes();
	// String encodevalue = Base64.getEncoder().encodeToString(bytes);
	// RESTClient client = new RESTClient(ApiURL,token);
	// attachmentservice = new AttachmentProvider(client);
	// attachment= new Attachment();
	// attachment.setCompact(attachmentname,encodevalue,"video/mp4");
	// }
	// entityattachment= attachmentservice.addTo("Assets",assetid,attachment);
	// attachmentid= entityattachment.getBody().getId();
	// System.out.println("Attachment id is" + attachmentid);
	//
	// } catch (Exception e) {
	// reporter.failureReport("Attachment upload","Attachment upload is failed "
	// + entityattachment.getBody());
	// reporter.failureReport("Attachment upload","Attachment upload is failed"
	// + e.getMessage());
	// }
	// return attachmentid;
	//// try {
	////
	//// if(attachmenttype.equals("image")) {
	//// String currentDir =
	// System.getProperty("user.dir")+"\\resources\\common\\testdata\\movilizer.jpg";
	//// File file=new File(currentDir);
	//// @SuppressWarnings("resource")
	//// FileInputStream fileInputStreamReader = new FileInputStream(file);
	//// byte[] bytes = fileInputStreamReader.readAllBytes();
	//// String encodevalue = Base64.getEncoder().encodeToString(bytes);
	//// RESTClient client = new RESTClient(ApiURL,token);
	//// attachmentservice = new AttachmentProvider(client);
	//// attachment= new Attachment();
	//// attachment.setCompact(attachmentname,encodevalue,"image/png");
	//// }
	////
	//// if(attachmenttype.equals("video")) {
	//// String currentDir =
	// System.getProperty("user.dir")+"\\resources\\common\\testdata\\video.mp4";
	//// File file=new File(currentDir);
	//// @SuppressWarnings("resource")
	//// FileInputStream fileInputStreamReader = new FileInputStream(file);
	//// byte[] bytes = fileInputStreamReader.readAllBytes();
	//// String encodevalue = Base64.getEncoder().encodeToString(bytes);
	//// RESTClient client = new RESTClient(ApiURL,token);
	//// attachmentservice = new AttachmentProvider(client);
	//// attachment= new Attachment();
	//// attachment.setCompact(attachmentname,encodevalue,"video/mp4");
	//// }
	//// entityattachment= attachmentservice.addTo("Assets",assetid,attachment);
	//// attachmentid= entityattachment.getBody().getId();
	//// System.out.println("Attachment id is" + attachmentid);
	////
	//// } catch (Exception e) {
	//// // TODO Auto-generated catch block
	//// reporter.failureReport("Attachment upload","Attachment upload is failed
	// " + entityattachment.getBody());
	//// reporter.failureReport("Attachment upload","Attachment upload is
	// failed" + e.getMessage());
	//// }
	//// return attachmentid;
	// // return null ;
	// }



	// create device with api
	public String createDevice_api(String token, String levelid, String devicename, String deviceaddress, String type) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			deviceservice = new DeviceProvider(client);
			device = new Device();
			device.setCompact(levelid, devicename, deviceaddress, type);
			entitydevice = deviceservice.addTo("Levels", levelid, device);			
			boolean erroneous=entitydevice.isErroneous();
			if(!erroneous){
				id = entitydevice.getBody().getId();
			}else{				
				logfailinfo("Device is not created");
			}
			System.out.println("Device id is " + id);
			System.out.println("Device Name is " + entitydevice.getBody().getName());
		} catch (Exception e) {
			// TODO Auto-generated catch block

		}
		return id;
	}

	// Delete Device with api
	public void DeleteDevice_api(String token, String deviceid) throws Throwable {

		try {
			RESTClient client = new RESTClient(ApiURL, token);
			deviceservice = new DeviceProvider(client);
			result = deviceservice.delete(deviceid);
			if(result.isErroneous())
			{
				System.out.println("Device is failed to delete");
				logfailinfo("Device is failed to delete " + result.getBody());				
			}
		} catch (Exception e) {
			//	reporter.failureReport("delete device","device delete is failed " + e.getMessage());
		}
	}

	//get levelhirarchy ids
	public String getLevelhirarchyId_api(String token,List<String> levelhirarchyname)
	{
		String value="";
		SharedResponseEntity<StringMap> res = null;
		HashMap<String, String> dataMap = null;
		List<String>values = new ArrayList<String>();
		try {
			RESTClient client = new RESTClient(ApiURL,token);
			indexservice= new IndexProvider(client);
			res=indexservice.get("Levels","name","parentId",Systemid);
			StringMap body = res.getBody();
			dataMap = body.getBackingMap();
			for (String key : dataMap.keySet()) 
			{ 
				if(key.equals(levelhirarchyname.get(0))) {
					value = dataMap.get(key);
					System.out.println("Level id is ***** " + value);
					break;
				}
			}
		} catch (Exception e) {
			logfailinfo("Exception --> " + e.getMessage());
		}
		return value;
	}	
	//get Asset ids
	public List<String> getAssetIds_api(String token,String levelid) throws MalformedURLException
	{
		SharedResponseEntity<Paginator<List<Asset>>> res = null;
		//	Paginator<List<Asset>> body;
		List<String>values = new ArrayList<String>();
		String value="";
		RESTClient client = new RESTClient(ApiURL,token);
		assetservice= new AssetProvider(client);
		if(!(levelid == null) || levelid.equals("") || levelid.isEmpty()) {
			res = assetservice.listBy("LhasR","Levels",levelid,0,100,Long.MIN_VALUE,Long.MAX_VALUE);
			ListIterator<Asset> it = res.getBody().getResult().listIterator();
			while (it.hasNext()) {
				Asset asset = it.next();
				value = asset.getId();
				values.add(value);
				System.out.println("Asset id   **** " + value);
				System.out.println("Asset Name **** " + asset.getName());
			}
		}
		return values;
	}
	//get SubAsset ids
	public List<String> getSubAssetIds_api(String token,String assetid)
	{
		SharedResponseEntity<Paginator<List<Asset>>> res = null;
		Paginator<List<Asset>> body;
		List<String>values = new ArrayList<String>();
		String value="";
		try {
			RESTClient client = new RESTClient(ApiURL,token);
			assetservice= new AssetProvider(client);
			if(!(assetid == null) || assetid.equals("") || assetid.isEmpty()) {
				res = assetservice.listBy("LhasR","Assets",assetid,0,100,Long.MIN_VALUE,Long.MAX_VALUE);
				ListIterator<Asset> it = res.getBody().getResult().listIterator();
				while (it.hasNext()) {
					Asset asset = it.next();
					value = asset.getId();
					values.add(value);
					System.out.println("SubAsset id   **** " + value);
					System.out.println("SubAsset Name **** " + asset.getName());
				}
			}
		} catch (Exception e) {
			logfailinfo("Exception --> " + e.getMessage());
		}
		return values;
	}	

	//get Task ids
	public List<String> getTaskIds_api(String token,String assetid)
	{
		SharedResponseEntity<Paginator<List<Task>>> res = null;
		Paginator<List<Task>> body;
		List<String>values = new ArrayList<String>();
		String value="";
		try {
			RESTClient client = new RESTClient(ApiURL,token);
			taskservice= new TaskProvider(client);
			if(!(assetid == null) || assetid.equals("") || assetid.isEmpty()) {
				res = taskservice.listBy("LhasR","Assets",assetid,0,100,Long.MIN_VALUE,Long.MAX_VALUE);
				body = res.getBody();
				ListIterator<Task> it = body.getResult().listIterator();
				while (it.hasNext()) {
					Task task = it.next();
					value = task.getId();
					values.add(value);
					System.out.println("Task id   **** " + value);
					System.out.println("Task Name **** " + task.getName());
				}
			}
		} catch (Exception e) {
			logfailinfo("Exception --> " + e.getMessage());
		}
		return values;
	}	


	//get User ids
	public List<String> getUserIds_api(String token,String levelid)
	{
		SharedResponseEntity<Paginator<List<User>>> res = null;
		Paginator<List<User>> body;
		List<String>values = new ArrayList<String>();
		String value="";
		try {
			RESTClient client = new RESTClient(ApiURL,token);
			userservice= new UserProvider(client);
			if(!(levelid == null) || levelid.equals("") || levelid.isEmpty()) {
				res = userservice.listBy("LhasR","Levels",levelid,0,100,Long.MIN_VALUE,Long.MAX_VALUE);
				body = res.getBody();
				ListIterator<User> it = body.getResult().listIterator();
				while (it.hasNext()) {
					User user = it.next();
					value = user.getId();
					values.add(value);
					System.out.println("User id   **** " + value);
					System.out.println("User Name **** " + user.getName());
				}
			}
		} catch (Exception e) {
			logfailinfo("Exception --> " + e.getMessage());
		}
		return values;
	}

	//get Device ids
	public List<String> getDeviceIds_api(String token,String levelid)
	{
		SharedResponseEntity<Paginator<List<Device>>> res = null;
		Paginator<List<Device>> body;
		List<String>values = new ArrayList<String>();
		String value="";
		try {
			RESTClient client = new RESTClient(ApiURL,token);
			deviceservice= new DeviceProvider(client);
			if(!(levelid == null) || levelid.equals("") || levelid.isEmpty()) {
				res = deviceservice.listBy("LhasR","Levels",levelid,0,100,Long.MIN_VALUE,Long.MAX_VALUE);
				body = res.getBody();
				System.out.println(body);
				ListIterator<Device> it = body.getResult().listIterator();
				System.out.println(it);
				while (it.hasNext()) {
					Device device = it.next();
					value = device.getId();
					values.add(value);
					System.out.println("Device id   **** " + value);
					System.out.println("Device Name **** " + device.getName());
				}
			}
		} catch (Exception e) {
			logfailinfo("Exception --> " + e.getMessage());
		}
		return values;
	}

	//get Roundtemplate ids
	public List<String> getRoundtemplateIds_api(String token,String levelid)
	{
		SharedResponseEntity<Paginator<List<RoundTemplate>>> res = null;
		Paginator<List<RoundTemplate>> body;
		List<String>values = new ArrayList<String>();
		String value="";
		try {
			RESTClient client = new RESTClient(ApiURL,token);
			roundtemplateservice= new RoundTemplateProvider(client);
			if(!(levelid == null) || levelid.equals("") || levelid.isEmpty()) {
				res = roundtemplateservice.listBy("LhasR","Levels",levelid,0,100,Long.MIN_VALUE,Long.MAX_VALUE);
				body = res.getBody();
				ListIterator<RoundTemplate> it = body.getResult().listIterator();
				while (it.hasNext()) {
					RoundTemplate roundtemplate = it.next();
					value = roundtemplate.getId();
					values.add(value);
					System.out.println("Roundtemplate id   **** " + value);
					System.out.println("Roundtemplate name **** " + roundtemplate.getName());
				}
			}
		} catch (Exception e) {
			logfailinfo("Exception --> " + e.getMessage());
		}
		return values;
	}

	//get Abstract ids
	public List<String> getAbstractsIds_api(String token)
	{
		String value="";
		SharedResponseEntity<Paginator<List<Asset>>> res = null;
		Paginator<List<Asset>> body;
		List<String>values = new ArrayList<String>();
		try {
			RESTClient client = new RESTClient(ApiURL,token);
			assetservice= new AssetProvider(client);
			res=assetservice.listBy("LhasR","Levels",Systemid,0,100,Long.MIN_VALUE,Long.MAX_VALUE);
			ListIterator<Asset> it = res.getBody().getResult().listIterator();
			while (it.hasNext()) {
				Asset abstractasset = it.next();
				value = abstractasset.getId();
				values.add(value);
				System.out.println("Abstractasset id   **** " + value);
				System.out.println("Abstractasset name **** " + abstractasset.getName());
			}
		} catch (Exception e) {
			logfailinfo("Exception --> " + e.getMessage());
		}
		return values;
	}

	//get sublevelhirarchy ids
//	public String getSubLevelhirarchyId_api(String token,String parentlevelhirarchyid)
//	{
//		String value=null;
//		SharedResponseEntity<StringMap> res = null;
//		HashMap<String, String> dataMap = null;
//		try {
//			RESTClient client = new RESTClient(ApiURL,token);
//			indexservice= new IndexProvider(client);
//			res=indexservice.get("Levels","name","parentId",parentlevelhirarchyid);
//			StringMap body = res.getBody();
//			dataMap = body.getBackingMap();
//			for (String key : dataMap.keySet()) 
//			{ 
//				value = dataMap.get(key);
//				System.out.println(value);
//			}
//		} catch (Exception e) {
//			logfailinfo("Exception --> " + e.getMessage());
//		}
//		return value;
//	}
	//get sublevelhirarchy ids
	public String getSubLevelhirarchyId_api(String token,String parentlevelhirarchyid)
	{
	String value=null;
	SharedResponseEntity<StringMap> res = null;
	HashMap<String, String> dataMap = null;
	try {
	RESTClient client = new RESTClient(ApiURL,token);
	indexservice= new IndexProvider(client);
	res=indexservice.get("Levels","name","parentId",parentlevelhirarchyid);
	// StringMap body = res.getBody();
	dataMap = res.getBody().getBackingMap();
	for (String key : dataMap.keySet())
	{
	value = dataMap.get(key);
	System.out.println(value);
	}
	} catch (Exception e) {
	logfailinfo("Exception --> " + e.getMessage());
	}
	return value;
	}

	public String getMobileToken() throws JSONException{
		Response res=RestAssured.given().header("Content-Type","application/x-www-form-urlencoded")
				.formParam("grant_type", "client_credentials")
				.formParam("scope", "profile email groups offline_access")
				.formParam("client_secret", "407f0461-0ff7-4544-ad7c-204460801c2d")
				.formParam("client_id", "auto-e2e-service-account")
				.when().post("https://idp.test.dev.movilizer.cloud/auth/realms/or2/protocol/openid-connect/token");
		String token=res.asString();
		JSONObject json = new JSONObject(token);
		String result=(String) json.get("access_token");
		System.out.println("Token"+json.get("access_token"));
		return result;
	}

}