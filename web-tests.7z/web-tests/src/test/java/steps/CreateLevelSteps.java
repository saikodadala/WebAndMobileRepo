package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import pages.Movilizer.CreateLevelPage;
import seleniumUtilities.BaseClass;

public class CreateLevelSteps extends BaseClass {

    public String Levelhirachyname = "AddLevelhirachy" + System.currentTimeMillis();
    String token = loginPage.getCookie();
    String levelid = "";
    String levelName = "";
    String newLevelName = "";

    @When("^hover on Enterprise level and click on Create Level$")
    public void hover_on_Enterprise_level_and_click_on_Create_Level() throws Throwable {
        refreshBrowser();
        levels.swtichToFrame();
        assetPage.mouseOverOnEnterprise();
        homePage.clickOnEnterpriseThreeDots();
        homePage.clickOnCreateLevel();
    }

    @Then("^User hover on Enterprise level and click on the dots$")
    public void user_hover_on_Enterprise_level_and_click_on_the_dots() throws Throwable {
        assetPage.mouseOverOnEnterprise();
        homePage.clickOnEnterpriseThreeDots();

    }

    @Then("^I should be able to click on Create Level$")
    public void i_should_be_able_to_click_on_Create_Level() throws Throwable {
        homePage.clickOnCreateLevel();

    }

    @Then("^User should be able to see and click on Create Level option$")
    public void user_should_be_able_to_see_and_click_on_Create_Level_option() throws Throwable {
        homePage.clickOnCreateLevel();
    }


    @When("^enter the Level Name as \"([^\"]*)\"$")
    public void enter_the_level_name(String LevelName) throws Throwable {
        homePage.setLevelName(Levelhirachyname);
        Hirarchyname.clear();
        Hirarchyname.add(Levelhirachyname);
    }


    @Then("^select the TimeZone as \"([^\"]*)\"$")
    public void select_the_TimeZone_as(String arg1) throws Throwable {
        levels.enterTimeZone(arg1);
    }


    @Then("^click on Submit button$")
    public void click_on_Submit_button() throws Throwable {
        levels.clickSubmitButton();
    }

    @Then("^level creation successfully message is displayed$")
    public void level_creation_successfully_message_is_displayed() throws Throwable {
        levels.verifyLevelCreationMSG();
    }

    @Then("^User should be able to verify Asset Hierarchy & Tasks in enabled$")
    public void user_should_be_able_to_verify_Asset_Hierarchy_Tasks_in_enabled() throws Throwable {
        levels.swtichToFrame();
        levels.verifyAssetHierarchyTasksEnabled();
    }

    @Then("^User should be able to verify Enterprise option and enabled$")
    public void user_should_be_able_to_verify_Enterprise_option_and_enabled() throws Throwable {
        levels.enterpriseHeading();
    }


    @Then("^User should see the level hierarchy heading$")
    public void user_should_see_the_level_hierarchy_heading() throws Throwable {
        levels.getPageHeading_verify();

    }

    @Then("^User should see the message \"([^\"]*)\"$")
    public void user_verify_the_message(String arg1) throws Throwable {
        levels.getEnterpriseGeneralMSG_Verify();
        driver.switchTo().defaultContent();
    }


    @When("^I click on the created level \"([^\"]*)\"$")
    public void i_click_on_the_created_level(String LevelName) throws Throwable {
        levels.clickOnCreatedLevel(LevelName);

    }

    @When("^hover on the created level$")
    public void hover_on_the_created_level() throws Throwable {
        levels.hoverOnCreatedLevel();
    }

    @When("^click on (\\d+) dots$")
    public void click_on_dots(int arg1) throws Throwable {
        levels.clickOnthreeDotsCreatedLevel();

    }

    @When("^click on Edit Level$")
    public void click_on_Edit_Level() throws Throwable {
        levels.clickOnEditLevel();
    }

    @When("^add the new level name \"([^\"]*)\"$")
    public void add_the_new_level_name(String NewLevelName) throws Throwable {
        newLevelName = Levelhirachyname;
        levels.clearTextLevelName();
        levels.enterLevelName(newLevelName);
        Hirarchyname.clear();
        Hirarchyname.add(Levelhirachyname);


    }


    @Then("^level edited successfully message is displayed$")
    public void level_edited_successfully_message_is_displayed() throws Throwable {
        levels.getLevelGeneralMSG_Verify();
    }

    @Then("^click on Delete Level$")
    public void click_on_Delete_Level() throws Throwable {
        levels.clickOnDeleteLevel();
    }


    @Then("^click on Confirm button$")
    public void click_on_Confirm_button() throws Throwable {
        levels.clickConfirmButton();

    }

    @Then("^level deleted successfully message is displayed$")
    public void level_deleted_successfully_message_is_displayed() throws Throwable {
        levels.getDelLevelMSG_Verify();
        Hirarchyname.clear();
    }

    @When("^click on Explorer View$")
    public void click_on_Explorer_View() throws Throwable {
        refreshBrowser();
        levels.swtichToFrame();
        levels.clickOnExplorerView();

    }

    @When("^hover on the heading LEVEL-(\\d+)$")
    public void hover_on_the_heading_LEVEL(int arg1) throws Throwable {
        levels.hoverOnLevelHeading();
    }

    @When("^click on Create Level$")
    public void click_on_Create_Level() throws Throwable {
        homePage.clickOnCreateLevel();

    }

    @Then("^hover on the explorer view created level \"([^\"]*)\"$")
    public void hover_on_the_explorer_view_created_level(String levelname) throws Throwable {
        levels.hoverExplorerViewCreatedLevel(levelName);

    }

    @Then("^click on (\\d+) dots of the created level$")
    public void click_on_dots_of_the_created_level(int arg1) throws Throwable {
        levels.click3DotsCreatedLevel();
    }


    @Then("^click on View Details button$")
    public void click_on_View_Details_button() throws Throwable {
        levels.clickViewDetailsButton();

    }

    @Then("^click on (\\d+) dots from hierarchy view$")
    public void click_on_dots_from_hierarchy_view(int arg1) throws Throwable {
        levels.clickLevelHierarhyView();
    }

    @When("^I click on created level \"([^\"]*)\"$")
    public void i_click_on_created_level(String levelhirarchy) throws Throwable {
        levelhirarchy = Levelhirachyname;
        System.out.println(levelhirarchy);


    }

    @When("^click on Search icon & enter the \"([^\"]*)\"$")
    public void click_on_Search_icon_enter_the(String levelname) throws Throwable {
        levels.clickSearchBox();
        levels.enterLevelnameSearchBox(levelName);

    }

    @When("^click on Search icon & enter the random \"([^\"]*)\"$")
    public void click_on_Search_icon_enter_the_random(String level) throws Throwable {
        levels.clickSearchBox();
        levels.enterLevelnameSearchBox(level);

    }

    @Then("^level name \"([^\"]*)\" search results should be displayed$")
    public void level_name_search_results_should_be_displayed(String levelname) throws Throwable {
        levels.verifysearchResults(levelName);

    }


    @Then("^create (\\d+) levels \"([^\"]*)\" \"([^\"]*)\"$")
    public void create_levels_with_validation(int arg1, String levelName, String timeZone) throws Throwable {
        for (int i = 1; i < arg1; i++) {
            levels.hoverOnCreatedLevel();
            levels.click3DotsCreatedLevel();
            homePage.clickOnCreateLevel();
            levels.levelNameRandGenerator(levelName);
            levels.enterTimeZone(timeZone);
            levels.clickSubmitButton();
            levels.verifyLevelCreationMSG();
        }
    }

    @Then("^ensure that (\\d+) levels are created$")
    public void ensure_that_levels_are_created(int arg1) throws Throwable {
        levels.verifyCreatedLevelsCount(arg1);
    }

    @Then("^ensure (\\d+) levels are created$")
    public void ensure_levels_are_created(int arg1) throws Throwable {
        levels.verifyCreatedExplorerLevelsCount(arg1);
    }

    @Then("^hover on created level :\"([^\"]*)\" and click on three dots$")
    public void hover_on_created_level_and_click_on_three_dots(String levelName) throws Throwable {
        levels.hoverOnCreatedLevel();
        levels.click3DotsCreatedLevel();

    }


    @When("^create (\\d+) levels \"([^\"]*)\" \"([^\"]*)\" in Explore View$")
    public void create_levels_in_Explore_View(int arg1, String levelName, String timeZone) throws Throwable {

        String levelnamelatest = levels.generateLevelRandom(levelName);
        String levelname1 = "";
        for (int i = 0; i < arg1; i++) {

            if (i == 0) {
                levels.searchCreatedLevel(i);
                levels.enterLevelNameonExplorerView(Levelhirachyname, i);
                levels.hoverOnTheCreatedLevel(Levelhirachyname);
                common.waitForPageLoaded();
                levels.click3DotsCreatedLevel();
                homePage.clickOnCreateLevel();
            } else if (i == 1) {
                levels.searchCreatedLevel(i);
                levels.enterLevelNameonExplorerView(levelname1, i);
                levels.hoverOnTheCreatedLevel(levelname1);
                common.waitForPageLoaded();
                levels.click3DotsCreatedLevel();
                homePage.clickOnCreateLevel();
            } else {
                levels.hoverOnTheCreatedLevel(levelname1);
                common.waitForPageLoaded();
                levels.click3DotsCreatedLevel();
                homePage.clickOnCreateLevel();
            }
            homePage.enterLevelName(levelnamelatest);
            levels.enterTimeZone(timeZone);
            levels.clickSubmitButton();
            common.waitForPageLoaded();
            levels.verifyLevelCreationMSG();
            levelname1 = levelnamelatest;
            levelnamelatest = levels.generateLevelRandom(levelName);
        }


    }

    @Then("^Asset Hierarchy & Tasks are enabled$")
    public void Asset_Hierarchy_Tasks_in_enabled() throws Throwable {
        levels.swtichToFrame();
        levels.verifyAssetHierarchyTasksEnabled();
    }

    @Then("^Enterprise level is selected and enabled$")
    public void Enterprise_option_and_enabled() throws Throwable {
        levels.enterpriseHeading();
    }

    @Then("^level hierarchy section header is \"([^\"]*)\"$")
    public void level_hierarchy_selection_header_is(String text) throws Throwable {
        levels.getPageHeading_verify();

    }

    @Then("^message \"([^\"]*)\" on right section$")
    public void message_on_right_section(String arg1) throws Throwable {
        levels.getEnterpriseGeneralMSG_Verify();
        driver.switchTo().defaultContent();
    }

    @When("^updated level is displayed in the hierarchy View$")
    public void updated_level_is_displayed_in_the_hierarchy_view() throws Throwable {
        levels.verifyRecordDisplay(levelName + newLevelName);

    }

    @When("^updated level is displayed in hierarchy View$")
    public void updated_level_is_displayed_in_hierarchy_view() throws Throwable {
        levels.verifyRecordDisplay(newLevelName);

    }

    @Then("^level name \"([^\"]*)\" search results are empty$")
    public void level_name_search_results_are_empty(String levelname) throws Throwable {
        levels.verifysearch_Results(levelname);

    }


    @Given("^site level is created and selected for level$")
    public void site_level_is_created_and_selected_for_level() throws Throwable {
        levelid = apii.createLevelhirarchy_api(token, Levelhirachyname);
        Hirarchyname.clear();
        Hirarchyname.add(Levelhirachyname);
        refreshBrowser();
        common.invisibleOfHoneywellLogo();
        users.selectlevelhirarchy_User(Levelhirachyname);
    }

    @Given("^site level \"([^\"]*)\" is created with api$")
    public void site_level_is_created_with_api(String levelname) throws Throwable {
        levelName = Levelhirachyname;
        levelid = apii.createLevelhirarchy_api(token, Levelhirachyname);
        Hirarchyname.clear();
        Hirarchyname.add(Levelhirachyname);
    }


    @When("create {int} levels {string} {string} {string} {string} {string}")
    public void create_levels(Integer arg1, String levelName, String timeZone, String emailId, String deviceName, String deviceType) throws Throwable {

        for (int i = 1; i < arg1; i++) {

            levels.clickOnAssetHierarchyAndTasks();
            levels.hoverOnCreatedLevel();
            levels.click3DotsCreatedLevel();
            homePage.clickOnCreateLevel();
            levels.levelNameRandGenerator(levelName);
            levels.enterTimeZone(timeZone);
            levels.clickSubmitButton();
            levels.verifyLevelCreationMSG();
            homePage.clickOnManageDevices();
            homePage.activeItem();
            devicePage.clickOnAddNewDeviceBtn();
            emailId=emailId+ RandomStringUtils.randomAlphanumeric(3).toLowerCase()+"@gmail.com";
            deviceName=deviceName+RandomStringUtils.randomAlphanumeric(3).toLowerCase();
            devicePage.enterDetails(emailId, deviceName);
            devicePage.chooseOption(deviceType);
            devicePage.clickOnAddDeviceBtn();
            devicePage.verifySuccessAlert();
            devicePage.verifyDeviceName(deviceName);

        }

    }

}










