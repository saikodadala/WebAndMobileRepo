package steps;

import seleniumUtilities.BaseClass;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AbstractAssetSteps extends BaseClass {

	List<String> ids = new ArrayList<String>();
	List<String> entityname = new ArrayList<String>();
	// fetch the token from the Ui after login
	String token = loginPage.getCookie();
	public String abstractassetid = "";
	static String assetname = "";
	static String AssetName = "AddAsset" + System.currentTimeMillis();
	static String abstracttaskname = "";
	static String AbstractTaskName = "AbstractTask" + System.currentTimeMillis();
	public String abstracttaskid = "";
	public String Levelhirachyname="AddLevelhirachy"+System.currentTimeMillis();
	public String levelid="";
	String levelname="";
	public String abstractName ="Abstractasset"+System.currentTimeMillis();
	public String asset="Asset"+System.currentTimeMillis();


	@Then("^configuration header message is displayed$")
	public void configuration_header_message_is_displayed() throws Throwable {
		abstractAsset.verifyConfigurationHeader();
	}

	@Then("^meta language header is displayed$")
	public void meta_language_header_is_displayed() throws Throwable {
		abstractAsset.verifyMetaLanguageHeader();
	}

	@Then("^search abstract asset textbox is displayed$")
	public void search_abstract_asset_textbox_is_displayed() throws Throwable {
		abstractAsset.verifyAbstractAssetSearchBox();
	}

	@Then("^abstract asset total is displayed$")
	public void abstract_asset_total_is_displayed() throws Throwable {
		abstractAsset.verifyAbstractAssetTotal();
	}

	@Then("^page dropdown is displayed$")
	public void page_dropdown_is_displayed() throws Throwable {
		abstractAsset.verifyPageDropdown();
	}

	@Then("^add abstract asset button at top of the table is displayed$")
	public void add_abstract_asset_button_at_top_of_the_table_is_displayed() throws Throwable {
		abstractAsset.verifyImportPadding("Export List");
		abstractAsset.verifyImportPadding("Import List");
		abstractAsset.verifyImportPadding("Get Template");
		abstractAsset.verifyAddAbstractAssetButton();
	}

	@Then("^filter icon is displayed$")
	public void verify_filter_icon_is_displayed() throws Throwable {
		abstractAsset.verifyFilterIcon();
	}

	@Then("^data table is displayed$")
	public void verify_data_table_is_displayed() throws Throwable {
		abstractAsset.verifyDataTable();
	}

	@Then("^pagenation info is displayed$")
	public void pagenation_info_is_displayed() throws Throwable {
		abstractAsset.verifyPagenationInfo();
	}

	@Then("^page navigation is displayed$")
	public void page_navigation_is_displayed() throws Throwable {
		abstractAsset.verifyPagenavigation();
	}

	@Then("^create abstract with api$")
	public void create_abstract_with_api() throws Throwable {

	}

	@When("^click on created abstract asset$")
	public void click_on_created_abstract_asset() throws Throwable {
		abstractAsset.clickOnFirstRecord();
	}

	@Then("^page details are displayed with created data$")
	public void page_details_are_displayed_with_created_data() throws Throwable {
		abstractAsset.verifyAbstractAssetDetailsPage();
	}

	@When("^click on abstract asset$")
	public void click_on_abstract_asset() throws Throwable {
		configPage.clickon_AbstractAssets();

	}

	@Then("^user lands on the Abstract Assets Page\\.$")
	public void user_lands_on_the_Abstract_Assets_Page() throws Throwable {
		waitForPageLoaded();
		String headerMessage = "Abstract Assets";
		configPage.verifyHeaderMessage(headerMessage);
		// configPage.Export_isDispalyed(); Validation here is invalid
	}

	@Then("^click on ADD Abstract ASSET button$")
	public void click_on_ADD_Abstract_ASSET_button() throws Throwable {
		configPage.clickon_AddAbstractAssetsbtn();
	}

	@When("^enter abstract asset details: \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void enter_abstract_asset_details(String userName, String employeeId, String arg3, String password,
			String arg5, String arg6, String arg7, String arg8) throws Throwable {
		String text = getRandomString(10);
		addAbstract.enterBackendID(text);
		addAbstract.enterAssetName(text);
		addAbstract.enterCategory(text);
		addAbstract.enterCriticality(text);
		addAbstract.enterAssetType(text);
		addAbstract.enterModes(text);
		addAbstract.enterContact(text);
		addAbstract.enterOwnerOrg(text);
	}

	// @When("^click on submit button$")
	// public void click_on_submit_button() throws Throwable {
	// addAbstract.clickSubmitbtn();
	//
	// }

	@Then("^enter the Backend ID as \"([^\"]*)\"$")
	public void enter_the_Backend_ID_as(String arg1) throws Throwable {
		addAbstract.enterBackendID(arg1);

	}

	@Then("^enter the Asset Name as \"([^\"]*)\"$")
	public void enter_the_Asset_Name_as(String arg1) throws Throwable {
		assetname = AssetName;
		addAbstract.enterAssetName(assetname);

	}

	@Then("^enter the Category as \"([^\"]*)\"$")
	public void enter_the_Category_as(String arg1) throws Throwable {
		addAbstract.enterCategory(arg1);
	}

	@Then("^enter the Criticality as \"([^\"]*)\"$")
	public void enter_the_Criticality_as(String arg1) throws Throwable {
		addAbstract.enterCriticality(arg1);
	}

	@Then("^enter the Type as \"([^\"]*)\"$")
	public void enter_the_Type_as(String arg1) throws Throwable {
		addAbstract.enterAssetType(arg1);
	}

	@Then("^enter the Modes as \"([^\"]*)\"$")
	public void enter_the_Modes_as(String arg1) throws Throwable {
		addAbstract.enterModes(arg1);
	}

	@Then("^enter the Contact as \"([^\"]*)\"$")
	public void i_enter_the_Contact_as(String arg1) throws Throwable {
		addAbstract.enterContact(arg1);
	}

	@Then("^enter the Owner Organization as \"([^\"]*)\"$")
	public void enter_the_Owner_Organization_as(String arg1) throws Throwable {
		addAbstract.enterOwnerOrg(arg1);
	}

	@Then("^click on Add New Row button from Additional information$")
	public void click_on_Add_New_Row_button_from_Additional_information() throws Throwable {
		// addAbstract.clickAddNewRowbtn();
		System.out.println("******clickedAddNewRowbtn********");
	}

	@Then("^enter the Headline as \"([^\"]*)\"$")
	public void enter_the_Headline_as(String arg1) throws Throwable {
		addAbstract.enterAddInfoHeadline(arg1);
	}

	@Then("^enter the Description as \"([^\"]*)\"$")
	public void enter_the_Description_as(String arg1) throws Throwable {
		addAbstract.enterAddinfoDescription(arg1);
	}

	@Then("^click on Add Link button from Additional information$")
	public void click_on_Add_Link_button_from_Additional_information() throws Throwable {
		addAbstract.clickAddLinkbtn();
		addAbstract.clickAddNewRowbtn();
	}

	@Then("^enter the Link Description as \"([^\"]*)\"$")
	public void enter_the_Link_Description_as(String arg1) throws Throwable {
		addAbstract.enterLinkDescription(arg1);
	}

	@Then("^enter the Link as \"([^\"]*)\"$")
	public void enter_the_Link_as(String arg1) throws Throwable {
		addAbstract.enterLink(arg1);

	}

	@Then("^success alert is displayed for Abstract asset \"([^\"]*)\"$")
	public void success_alert_is_displayed_for_Abstract_asset(String arg1) throws Throwable {
		addAbstract.verifySuccessAlert(arg1);
	}

	@Then("^assetName Mandatory error message is displayed$")
	public void assetName_Mandatory_error_message_is_displayed() throws Throwable {
		addAbstract.verifyAssetNameMandyErrormsg();
	}

	@Then("^assetType mandatory error message is displayed$")
	public void assetType_mandatory_error_message_is_displayed() throws Throwable {
		addAbstract.verifyAssetTypeMandyErrormsg();
	}

	@Then("^enter value as \"([^\"]*)\" in search Abstract Asset$")
	public void enter_value_as_in_search_Abstract_Asset(String arg1) throws Throwable {
		configPage.searchAbstractAssets(assetname);
	}

	@Then("^enter value \"([^\"]*)\" in search Abstract Asset$")
	public void enter_value_in_search_Abstract_Asset(String arg1) throws Throwable {
		// refreshBrowser();
		// common.selectSideMenuOption("Configuration");
		// configPage.clickon_AbstractAssets();
		// String headerMessage="Abstract Assets";
		// configPage.verifyHeaderMessage(headerMessage);
		waitForPageLoaded();
		configPage.Export_isDispalyed();
		configPage.searchAbstractAssets(assetname);
	}

	@Then("^Abstract Asset is created as \"([^\"]*)\" and displayed in the Abstract Asset Page$")
	public void Abstract_Asset_is_created_as_and_displayed_in_the_Abstract_Asset_Page(String arg1) throws Throwable {
		configPage.VerifyAbstractAssetName(assetname);
	}

	@Then("^Abstract Asset is not deleted as \"([^\"]*)\" and displayed in the Abstract Asset Page$")
	public void Abstract_Asset_is_not_deleted_as_and_displayed_in_the_Abstract_Asset_Page(String arg1)
			throws Throwable {
		configPage.VerifyAbstractAssetName(assetname);
	}

	@Then("^clicked on Cancel button$")
	public void clicked_on_Cancel_button() throws Throwable {
		addAbstract.clickCancelbtn();
	}

	@Then("^abstract Asset is Not created as \"([^\"]*)\" and Not displayed in the Abstract Asset Page$")
	public void abstract_Asset_is_Not_created_as_and_Not_displayed_in_the_Abstract_Asset_Page(String arg1)
			throws Throwable {
		configPage.VerifyAbstractAssetNameNotfound(arg1);
	}

	@Then("^abstract Asset is deleted and Not displayed in the Abstract Asset Page$")
	public void abstract_Asset_is_deleted_and_Not_displayed_in_the_Abstract_Asset_Page() throws Throwable {
		configPage.VerifyAbstractAssetNameNotfound("");
	}

	@Then("^error message is displayed because Backend ID :\"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_is_displayed_because_Backend_ID_is_more_than_characters(String backendId, int count)
			throws Throwable {
		String text = getRandomString(count + 1);
		addAbstract.enterBackendID(text);
		String expErrorMessage = "AbstractAssetBackendID Maximum length 128 is exceeded";
		abstractAsset.validateErrorMessage("Backend ID", expErrorMessage);
	}

	@Then("^error message is displayed because Asset Name :\"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_is_displayed_because_Asset_Name_is_more_than_characters(String assetname, int count)
			throws Throwable {
		String text = getRandomString(count + 1);
		addAbstract.enterAssetName(text);
		String expErrorMessage = "Asset name Maximum length 128 is exceeded";
		abstractAsset.validateErrorMessage("Asset Name", expErrorMessage);
	}

	@Then("^error message is displayed because Category :\"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_is_displayed_because_Category_is_more_than_characters(String category, int count)
			throws Throwable {
		String text = getRandomString(count + 1);
		addAbstract.enterCategory(text);
		String expErrorMessage = "AbstractAssetCategory Maximum length 128 is exceeded";
		// abstractAsset.validateErrorMessage("Category",expErrorMessage);
	}

	@Then("^error message is displayed because Criticality :\"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_is_displayed_because_Criticality_is_more_than_characters(String criticality, int count)
			throws Throwable {
		String text = getRandomString(count + 1);
		addAbstract.enterCriticality(text);
		String expErrorMessage = "AbstractAssetCriticality Maximum length 128 is exceeded";
		// abstractAsset.validateErrorMessage("Criticality",expErrorMessage);
	}

	@Then("^error message is displayed because Type :\"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_is_displayed_because_Type_is_more_than_characters(String type, int count)
			throws Throwable {
		String text = getRandomString(count + 1);
		addAbstract.enterAssetType(text);
		String expErrorMessage = "Asset type Maximum length 32 is exceeded";
		abstractAsset.validateErrorMessage("Type", expErrorMessage);
	}

	@Then("^error message is displayed because Modes :\"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_is_displayed_because_Modes_is_more_than_characters(String modes, int count)
			throws Throwable {
		String text = getRandomString(count + 1);
		addAbstract.enterModes(text);
		String expErrorMessage = "Maximum length 32 exceeded for individual mode";
		abstractAsset.validateErrorMessage("Modes", expErrorMessage);
	}

	@Then("^error message is displayed because Contact :\"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_is_displayed_because_Contact_is_more_than_characters(String contact, int count)
			throws Throwable {
		String text = getRandomString(count + 1);
		addAbstract.enterContact(text);
		String expErrorMessage = "AbstractAssetContact Maximum length 128 is exceeded";
		abstractAsset.validateErrorMessage("Contact", expErrorMessage);
	}

	@Then("^error message is displayed because Owner Organization :\"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_is_displayed_because_Owner_Organization_is_more_than_characters(String OwnerOrganization,
			int count) throws Throwable {
		String text = getRandomString(count + 1);
		addAbstract.enterOwnerOrg(text);
		String expErrorMessage = "AbstractAssetOwnerOrganization Maximum length 128 is exceeded";
		abstractAsset.validateErrorMessage("Owner Organization", expErrorMessage);
	}

	@Given("^create Abstractassets with different asset types&modes with api \"([^\"]*)\" in Abstractassetspage$")
	public void create_Abstractassets_with_different_asset_types_modes_with_api_in_Abstractassetspage(
			String abstractassetname) throws Throwable {
		ArrayList<String> abstractasset_type = new ArrayList<String>(
				Arrays.asList("Machines", "Boilers", "Systems", "Engines", "Devices"));
		ArrayList<String> abstractassetmode = new ArrayList<String>(
				Arrays.asList("Good", "Average", "Medium", "Low", "High"));
		for (int i = 1; i <= abstractasset_type.size(); i++) {
			abstractassetname = "Abstractasset" + generateRandomNumber(4);
			abstractassetid = apii.createAbstractasset_api(token, abstractassetname, abstractasset_type.get(i - 1),
					abstractassetmode.get(i - 1));
			ids.add(abstractassetid);
			entityname.add(abstractassetname);
		}
	}

	@Then("^sorting results are displayed in Abstractassetpage$")
	public void sorting_results_are_displayed_in_Abstractassetpage() throws Throwable {
		Validate_sorting();
	}

	@Then("^search results are displayed in Abstractassetpage$")
	public void search_results_are_displayed_in_Abstractassetpage() throws Throwable {
		for (int i = 1; i <= entityname.size(); i++) {
			String entitytosearch = entityname.get(i - 1);
			Validate_Search(entitytosearch);
		}
	}

	@Then("^filters results are displayed in Abstractassetpage$")
	public void filters_results_are_displayed_in_Abstractassetpage() throws Throwable {
		Validate_Filters();
	}

	@When("^delete \"([^\"]*)\" with api in AbstractAssetpage$")
	public void delete_with_api_in_AbstractAssetpage(String type) throws Throwable {
		for (int i = 1; i <= ids.size(); i++) {
			apii.DeleteAsset_api(token, ids.get(i - 1));
		}
	}

	@When("^click on configuration$")
	public void click_on_configuration() throws Throwable {

		abstractAsset.clickonConfiguration();
	}

	@When("^perform \"([^\"]*)\" action on created abstract asset$")
	public void perform_action_on_created_abstract_asset(String arg1) throws Throwable {
		common.verifyTableAbstractAssetThreeDots();
		common.verifyMoreActions();
		abstractAsset.clickOnThreeDots();
		abstractAsset.clickOnRecordAction(arg1);
	}

	@Given("^create abstract asset \"([^\"]*)\" with api$")
	public void create_abstract_asset_with_api(String abstractassetname) throws Throwable {
		assetname = abstractassetname + AssetName;
		AbstractAssetids.clear();
		abstractassetid = apii.createAbstractasset_api(token, assetname, "Type", "Mode");
		ids.add(abstractassetid);
		AbstractAssetids.add(abstractassetid);
	}

	@When("^create (\\d+) abstract asset items with api for pagination in AbstractAssetspage$")
	public void create_Asset_items_with_api_for_pagination_in_Assetspage(int nooftimes) throws Throwable {

		for (int i = 0; i < nooftimes; i++) {
			assetname = AssetName;
			AbstractAssetids.clear();
			abstractassetid = apii.createAbstractasset_api(token, assetname, "Type", "Mode");
			ids.add(abstractassetid);
			AbstractAssetids.add(abstractassetid);
		}
	}

	@Then("^click on ADD Abstractasset button$")
	public void click_on_AddAbstract_ASSET_button() throws Throwable {
		configPage.clickon_Add_AbstractAssetsbutton();
	}

	@When("^click on the created abstract asset$")
	public void click_on_abstractasset() throws Throwable {

		abstractAsset.clickon_firstAbstractAsset();
	}

	@Then("^the empty message for abstract tasks is displayed \"([^\"]*)\"$")
	public void i_verify_the_empty_abstracttasks(String arg1) throws Throwable {
		abstractAsset.verifyAbstractTasksEmptyMessage(arg1);
	}

	@Then("^the factory image for no abstract tasks is displayed$")
	public void i_verify_the_factory_image_for_no_abstractTasks() throws Throwable {
		abstractAsset.verifyNoTasksImg();
	}

	@Then("^portal user clicks on Add New Task button$")
	public void add_abstarctTask_button() throws Throwable {
		abstractAsset.clickOnAddNewTaskBtn();
	}

	@Given("^create abstract task \"([^\"]*)\" with api$")
	public void create_abstract_task_with_api(String abstracttaskname) throws Throwable {
		Taskids.clear();
		entityname.clear();
		abstracttaskname = AbstractTaskName;
		String TaskName = RandomStringUtils.random(10, true, true) + "Task";
		String limitname = "limit" + System.currentTimeMillis();
		String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid = RandomStringUtils.random(10, false, true) + "backendid";
		String category = RandomStringUtils.random(10, true, true) + "category";
		abstracttaskid = apii.createTask_api(token, abstractassetid, AbstractTaskName, limitname, "Good", "2", saptag,
				dcstag, backendid, category);
		// Taskids.add(taskid);
		// taskname=TaskName;
		ids.add(abstractassetid);
		entityname.add(abstracttaskname);
	}

	@Given("^abstract asset is created$")
	public void abstract_asset_is_created() throws Throwable {
		// abstract asset creation
		assetname = "AbstractAsset" + AssetName;
		AbstractAssetids.clear();
		abstractassetid = apii.createAbstractasset_api(token, assetname, "Type", "Mode");
		ids.add(abstractassetid);
		AbstractAssetids.add(abstractassetid);
	}

	@When("^Portal user selects the created abstract asset$")
	public void portal_user_selects_the_created_abstract_asset() throws Throwable {
		configPage.clickon_AbstractAssets();
		waitForPageLoaded();
		String headerMessage = "Abstract Assets";
		configPage.verifyHeaderMessage(headerMessage);
		waitForPageLoaded();
		configPage.Export_isDispalyed();
		configPage.searchAbstractAssets(assetname);
		abstractAsset.clickon_firstAbstractAsset();

	}

	@When("^open abstract asset task create view for task type checkBox, dropdown, text or date$")
	public void open__abstract_asset_task_create_view_for_task_type_checkbox_dropdown_text_or_date() throws Throwable {
		abstractAsset.clickOnAddNewTaskBtn();
	}

	@Given("^level \"([^\"]*)\" and abstract asset \"([^\"]*)\" of type \"([^\"]*)\" are created$")
	public void level_something_and_abstract_asset_something_of_type_something_are_created(String level,String abstractassetname, String abstractassettype)	throws Throwable {
		//		Create level with api
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		levelname=Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token,levelname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);		

		//		Create abstract asset with api
		assetname = abstractassetname + AssetName;
		AbstractAssetids.clear();
		abstractassetid = apii.createAbstractasset_api(token, assetname, "Type", "Mode");
		ids.add(abstractassetid);
		AbstractAssetids.add(abstractassetid);

		//		Create abstract task with api
		Taskids.clear();
		entityname.clear();
		abstracttaskname = AbstractTaskName;
		String limitname = "limit" + System.currentTimeMillis();
		String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid = RandomStringUtils.random(10, false, true) + "backendid";
		String category = RandomStringUtils.random(10, true, true) + "category";
		abstracttaskid = apii.createTask_api(token, abstractassetid, AbstractTaskName, limitname, "Good", "2", saptag,
				dcstag, backendid, category);
		ids.add(abstractassetid);
		entityname.add(abstracttaskname);

	}

	@When("^user navigates to the created level asset creation screen$")
	public void user_navigates_to_the_created_level_asset_creation_screen() throws Throwable {
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		common.waitForPageLoaded();		
		assetConfigurationPage.selectlevelhirachy(levelname);
		assetConfigurationPage.clickADDAssetBtn();
	}

	@And("^fills in valid asset mandatory details \"([^\"]*)\" and \"([^\"]*)\"$")
	public void fills_in_valid_asset_mandatory_details_something_and_something(String physicalassetname,String physicalassettype) throws Throwable {
		physicalassetname = "Asset"+System.currentTimeMillis();
		assetConfigurationPage.enterAssetDetails(physicalassetname);
		entityname.add(physicalassetname);
	}

	@And("^selects to inherit from \"([^\"]*)\"$")
	public void selects_to_inherit_from_something(String abstractassetname) throws Throwable {
		assetConfigurationPage.clickOnInheritFromAbstractAssetCheckbox();
	}

	@Then("^\"([^\"]*)\" is disabled$")
	public void something_is_disabled(String physicalassettype) throws Throwable {
		assetConfigurationPage.checkAssetTypeStatus(false);
	}

	@And("^entered value is \"([^\"]*)\"$")
	public void entered_value_is_something(String abstractassettype) throws Throwable {
		assetConfigurationPage.selectAbstractAsset();
	}

	@When("^unchecking inheritance checkbox$")
	public void unchecking_inheritance_checkbox() throws Throwable {
		assetConfigurationPage.clickOnInheritFromAbstractAssetCheckbox();
	}

	@Then("^\"([^\"]*)\" is editable \"([^\"]*)\" is asset or subasset$")
	public void something_is_editable_something_is_asset_or_subasset(String physicalassettype, String asset) throws Throwable {
		assetConfigurationPage.checkAssetTypeStatus(true);
	}



	@Given("abstract asset with data {string},{string},{string},{string},{string},{string},{string},{string} is created")
	public void abstract_asset_with_data_is_created(String abstractassetname,String abstractassettype,String abstractassetmode,String saptag,String dcstag,String backendid,String contact,String owner) throws Throwable {

		//	Create abstract asset with api
		abstractassetname=abstractName;
		apii.asset.setSAPTag("saptag"+System.currentTimeMillis());
		apii.asset.setDCSTag("dcstag"+System.currentTimeMillis());
		HashMap<String,String>attachedprops=new HashMap<String,String>();
		attachedprops.put("ownerOrganization",owner+System.currentTimeMillis());
		attachedprops.put("contact",contact+System.currentTimeMillis());
		apii.createAbstractasset_api(token,abstractassetname,abstractassettype,abstractassetmode);

	}

	@Given("hierarchy level\"Level\" is created")
	public void hierarchy_level_level_is_created() throws Throwable {

		//Create level with api
		Hirarchyname.clear();
		levelname=Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token,levelname);
		Hirarchyname.add(Levelhirachyname);	
	}
	@When("portal user creates asset in level with valid mandatory data {string} that inherits abstract asset")
	public void portal_user_creates_asset_in_level_with_valid_mandatory_data_that_inherits_abstract_asset(String assetname) throws Throwable {


		assetname="Asset"+System.currentTimeMillis();
		addAbstract.clickonAssethirarchtasks();
		assetConfigurationPage.selectlevelhirachy(Levelhirachyname);
		assetConfigurationPage.clickADDAssetBtn();
		addAbstract.enterAssetname(assetname);
		assetConfigurationPage.clickOnInheritFromAbstractAssetCheckbox();
		addAbstract.selectAbstractasset(abstractName);

	}
	@Then("Extends ID and Asset Type fields are filled and non editable")
	public void extends_id_and_asset_type_fields_are_filled_and_non_editable() {

		addAbstract.isenabled();

	}
	@Then("asset is successfully created")
	public void asset_is_successfully_created() throws Throwable {

		assetConfigurationPage.clickOnsubmitBtn();
		addAbstract.verifysuccessmessage();
	}




	@Given("abstract asset with task are created")
	public void abstract_asset_with_task_are_created() throws Throwable {

		String	abstractassetname=abstractName;
		String  abstractassettype="Assettype";
		String  abstractassetmode="AssetMode";
		// create abstract asset
		abstractassetid=apii.createAbstractasset_api(token,abstractassetname,abstractassettype,abstractassetmode);	
		abstracttaskname = AbstractTaskName;
		String limitname = "limit" + System.currentTimeMillis();
		String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid = RandomStringUtils.random(10, false, true) + "backendid";
		String category = RandomStringUtils.random(10, true, true) + "category";
		// create abstract task
		abstracttaskid = apii.createTask_api(token,abstractassetid,AbstractTaskName,limitname,"Good","2",saptag,dcstag,backendid,category);



	}



	@Given("physical asset that inherits abstract asset is created")
	public void physical_asset_that_inherits_abstract_asset_is_created() throws Throwable {


		addAbstract.clickonAssethirarchtasks();
		assetConfigurationPage.selectlevelhirachy(Levelhirachyname);
		assetConfigurationPage.clickADDAssetBtn();
		addAbstract.enterAssetname(asset);
		assetConfigurationPage.clickOnInheritFromAbstractAssetCheckbox();
		addAbstract.selectAbstractasset(abstractName);
		assetConfigurationPage.clickOnsubmitBtn();
		addAbstract.verifysuccessmessage();

	}



	@When("portal user selects created physical asset")
	public void portal_user_selects_created_physical_asset() throws Throwable {
		//temporary change
		//	addAbstract.clickonAssethirarchtasks();
		//temporary change
		//		assetConfigurationPage.selectlevelhirachy(Levelhirachyname);
		addAbstract.clickonAsset(asset);

	}
	@Then("all inherited tasks are correctly displayed")
	public void all_inherited_tasks_are_correctly_displayed() throws Throwable {

		addAbstract.clickonTask();
		taskPage.verifyTaskDataTable();

	}
	@When("click on task More actions")
	public void click_on_task_more_actions() throws Throwable {

		addAbstract.clickonMoreActions();

	}
	@Then("available option is Extend")
	public void available_option_is_extend() throws Throwable {

		addAbstract.extendoptiondisplayed();

	}
	@When("click on extend option")
	public void click_on_extend_option() throws Throwable {

		addAbstract.clickonextend();

	}


	@Then("{string},{string},{string} are prefilled from abstract task and non editable")
	public void are_prefilled_from_abstract_task_and_non_editable(String string, String string2, String string3) throws Throwable {

		addAbstract.is_enabled();
	}




	@Then("{string} are prefilled from abstract task and editable")
	public void are_prefilled_from_abstract_task_and_editable(String string) {

	}





	@When("changing all editable fields")
	public void changing_all_editable_fields() throws Throwable {

		taskPage.enterTaskName("Updatetaskname"+System.currentTimeMillis());
		taskPage.clickonNext();
		taskPage.clickonNext();

	}
	@When("save task")
	public void save_task() throws Throwable {

		taskPage.clickonsaveBtn();

	}
	@Then("task is saved successfully")
	public void task_is_saved_successfully() throws Throwable {

		taskPage.verifyTaskSuccessAlert("Addition");

	}
	@Then("inherited is changed to extended")
	public void inherited_is_changed_to_extended() throws Throwable {

		addAbstract.validate_Extended();

	}

















}
