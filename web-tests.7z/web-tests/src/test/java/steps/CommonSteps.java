package steps;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import seleniumUtilities.BaseClass;

public class CommonSteps extends BaseClass{
	public String Levelhirachyname="AddLevelhirachy"+System.currentTimeMillis();
	public String userName="User"+System.currentTimeMillis();
	String levelid="";
	String token=loginPage.getCookie();		
	public String UserName="AddUser"+System.currentTimeMillis();
	public String userid="";
	
		
	@When("^select side menu item \"([^\"]*)\"$")
	public void select_side_menu_item(String option) throws Throwable {
	    common.selectSideMenuOption(option);
	}
	
	
	@When("^select Level hirarchy \"([^\"]*)\"$")
	public void select_Level_hirarchy(String levelhirarchy) throws Throwable {
		levelhirarchy=Levelhirachyname;
		waitForPageLoaded();
		templatePage.selectlevelhirarchy_Rountemplate("AddLevelhirachy1620363920086");

	}
	
	@When("^create Level \"([^\"]*)\" for user with api$")
	public void create_Level_for_user_with_api(String levelname) throws Throwable {
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		levelname=Levelhirachyname;
		levelid=apii.createLevelhirarchy_api(token, levelname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
	}
	
	@When("^select Level hirarchy \"([^\"]*)\" from user$")
	public void select_Level_hirarchy_from_Round_template(String levelhirarchy) throws Throwable {
		levelhirarchy=Levelhirachyname;
		waitForPageLoaded();
		templatePage.selectlevelhirarchy_Rountemplate(Levelhirachyname);

	}

	
	
	@Then("^delete user \"([^\"]*)\" with api$")
	public void delete_user_with_api(String userId) throws Throwable {
		if(userId.equalsIgnoreCase("user")){
			apii.DeleteUser_api(token, userid);
		}else{
			apii.DeleteUser_api(token, userId);
		}
		
	}
	@Then("^delete user record with api$")
	public void delete_user_record_with_api() throws Throwable {	
		userid=users.userRecord;
		apii.DeleteUser_api(token, "EMP-1234");
		
	}
	@When("^delete user Levelhirachy with api$")
	public void delete_user_Levelhirachy_with_api() throws Throwable {
		apii.DeleteLevelhirarchy_api(token,levelid);

	}
	
	@Then("^verify deleted user \"([^\"]*)\" in user table$")
	public void verify_deleted_user_in_user_table(String user) throws Throwable {
		users.verifyUserTable(user);
	}
	
	@When("^delete device \"([^\"]*)\" with api$")
	public void delete_device_with_api(String devicename) throws Throwable {
		apii.DeleteDevice_api(token,devicename);
	}
	
	@When("^user navigate to user management section$")
	public void user_navigate_to_user_management_section() throws Throwable {
		common.selectSideMenuOption("User");
	}
	
	@Then("^left arrow < disabled for pagination$")
	public void ensure_left_arrow_disabled_for_pagination() throws Throwable {
		common.arrowDisableState();
		
	}
	@Then("^left arrow < enabled for pagination$")
	public void ensure_left_arrow_enabled_for_pagination() throws Throwable {
		common.arrowEnableState();
		
	}
	@Then("^right arrow > enabled for pagination$")
	public void ensure_right_arrow_enabled_for_pagination() throws Throwable {
		common.arrowEnableState();
		
	}
	@Then("^right arrow > disabled for pagination$")
	public void ensure_right_arrow_disabled_for_pagination() throws Throwable {
		common.arrowDisableState();
		
	}
	@When("^validate (\\d+) pages are displayed with (\\d+) records first, (\\d+) records second$")
	public void validate_pages_are_displayed_with_records_first_records_second(int pageCount,int page1,int page2) throws Throwable {
		
		common.waitForPageLoaded();		
		common.validate20RecordPagination(String.valueOf(page1), String.valueOf(page2));
		
	}
	
	@Then("^(\\d+) pages are displayed with each (\\d+) records$")
	public void pages_are_displayed_with_each_records(int a,int perPage) throws Throwable {
		common.waitForPageLoaded();
		common.validatePagination(String.valueOf(perPage));
		
	}
	@Then("^only one page with all (\\d+) records is displayed$")
	public void only_one_page_with_all_records_is_displayed(int perPage) throws Throwable {
		common.waitForPageLoaded();
		common.validatePagination(String.valueOf(perPage));
		
	}
	@Then("^arrows should be disabled$")
	public void arrows_should_be_disabled() throws Throwable {
		common.arrowDisableState();
		
	}
	
	@When("^change to (\\d+) per page$")
	public void change_to_per_page(int perPage) throws Throwable {
	
		common.selectNumberOfPages(String.valueOf(perPage));
		
	}
	@Then("^default (\\d+) per page is displayed$")
	public void default_per_page_is_displayed(int perPage) throws Throwable {
		common.waitForPageLoaded();
		common.validatePagination(String.valueOf(perPage));
		
	}
}
