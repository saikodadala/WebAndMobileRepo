package steps;

import common.reports.ConfigFileReadWrite;
import common.reports.ReporterConstants;
//import cucumber.api.DataTable;
import  io.cucumber.java.en.And;
import  io.cucumber.java.en.Given;
import  io.cucumber.java.en.Then;
import  io.cucumber.java.en.When;

import org.openqa.selenium.By;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import seleniumUtilities.BaseClass;

import java.util.List;

public class MovilizerHomeSteps extends BaseClass {

    String userName = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "Web_UserName");
    String password = ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "Password");
    String appEnvironment=ConfigFileReadWrite.read(ReporterConstants.configMovilizerFile, "appEnvironment");
    

    
    @When("^login with valid Admin credentials$")
    @And("^click on Login button$")
    public void click_on_Login() throws Throwable {
    	if(appEnvironment.equalsIgnoreCase("or2")){
    		loginPage.enterUserName(userName);
            loginPage.clickSignIn();
            loginPage.enterpassWord(password);
            loginPage.clickSignIn();
    	}else if(appEnvironment.equalsIgnoreCase("or")){
            loginPage.enterUserName(userName);
            loginPage.clickSignIn();
            loginPage.enterpassWord(password);
            loginPage.clickSignIn();
    	}
    	        
    }

    
    @When("^select category \"([^\"]*)\"$")
    public void select_category(String arg1) throws Throwable {
        homePage.clickOnMainMenu();
        homePage.clickOnEasyConfig();
        homePage.switchFrame();
    }
    
    @When("^select category as \"([^\"]*)\"$")
    public void select_category1(String arg1) throws Throwable {
    	comeOutFromFrame();
        homePage.clickOnMainMenu();
        homePage.clickOnEasyConfig();
    }

    @When("^select side menu item round template$")
    public void select_side_menu_item_round_template() throws Throwable {  
    	refreshBrowser();
        homePage.clickOnRoundTemplate();
    }
    
    @When("^select side menu item manage devices$")
    public void select_side_menu_item_manage_devices() throws Throwable {    	
        homePage.clickOnManageDevices();
    }
    
    @When("^movilizer platform logo is displayed$")
    public void movilizer_platform_category_is_displayed() throws Throwable {
    	homePage.movilizerPlatform();
    }
    
    @Then("^Enterprise level is displayed$")
    public void enterprise_level_is_displayed() throws Throwable {
    	levels.enterpriseHeading();
    }

    @Then("^manage devices is active$")
    public void manage_devices_is_active() throws Throwable {
        homePage.activeItem();
    }
}
