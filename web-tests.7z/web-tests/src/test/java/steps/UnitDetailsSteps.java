package steps;

import common.reports.ConfigFileReadWrite;
import common.reports.ReporterConstants;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import seleniumUtilities.BaseClass;

import java.util.ArrayList;
import java.util.List;

public class UnitDetailsSteps extends BaseClass {

	public String Levelhirachyname = "AddLevelhirachy" + System.currentTimeMillis();
	List<String> entityname = new ArrayList<String>();
	String token = loginPage.getCookie();
	String levelid = "";
	String expectedUnitName = "";
	String levelName = "";
	String unitname="";

	@Given("^navigating to EasyConfig Configuration section at Enterprise level$")
	public void navigating_to_easyconfig_configuration_section_at_enterprise_level() throws Throwable {
		unitDetailsPage.clickon_UnitDetailsLink();
	}

	@Given("^unit name \"([^\"]*)\" is created$")
	public void unit_name_is_created() throws Throwable {
		//========= Creation of unit name, need to replace with api======================
		waitForPageLoaded();
		expectedUnitName = "unit name 1";
		unitDetailsPage.verifyUnitNameHeader();
		unitDetailsPage.clickonEditLink();
		waitForPageLoaded();
		unitDetailsPage.verifyAddHereHeader();
		unitDetailsPage.enterUnitNames("unit name 1");
		unitDetailsPage.verifyCancelButton();
		unitDetailsPage.verifySaveButton();
		unitDetailsPage.clickOnSaveButton();
		refreshBrowser();
		waitForPageLoaded();
		common.selectSideMenuOption("Asset hierarchy&Tasks");
		//===============================
	}
	
	@Given("^unit name and level are created$")
	public void unitname_and_level_are_created() throws Throwable {
		//========= Creation of unit name, need to replace with api======================
		waitForPageLoaded();
		expectedUnitName = "unit name 1";
		unitDetailsPage.verifyUnitNameHeader();
		unitDetailsPage.clickonEditLink();
		waitForPageLoaded();
		unitDetailsPage.verifyAddHereHeader();
		unitDetailsPage.enterUnitNames("unit name 1");
		unitDetailsPage.verifyCancelButton();
		unitDetailsPage.verifySaveButton();
		unitDetailsPage.clickOnSaveButton();
		refreshBrowser();
		waitForPageLoaded();
		common.selectSideMenuOption("Asset hierarchy&Tasks");
		//===============================
		//Create level==== with created unit name ===========
		levels.clickOnthreeDotsAtEnterPriseLevel();
		homePage.clickOnCreateLevel();
		levels.clearTextLevelName();
		levels.enterLevelName(Levelhirachyname);
		Hirarchyname.clear();
		Hirarchyname.add(Levelhirachyname);
		levels.enterTimeZone("Asia/Kolkata");
		unitDetailsPage.enterUnitName(expectedUnitName);
		levels.clickSubmitButton();
		//==================================================
	}

	@When("^user creates level by filling \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void create_level_with_created_unit_name(String level, String timezone, String unitname) throws Throwable {
		levels.clickOnthreeDotsAtEnterPriseLevel();
		homePage.clickOnCreateLevel();
		levels.clearTextLevelName();
		levels.enterLevelName(Levelhirachyname);
		Hirarchyname.clear();
		Hirarchyname.add(Levelhirachyname);
		levels.enterTimeZone(timezone);
		unitDetailsPage.enterUnitName(expectedUnitName);
		levels.clickSubmitButton();
	}
	@When("^navigating to created level$")
	public void navigate_to_created_level(String unitname) throws Throwable {
		assetConfigurationPage.clickADDAssetBtn();
		String assetnm = "Asset" + System.currentTimeMillis();
		assetConfigurationPage.enterAssetName(assetnm);
		entityname.add(assetnm);
		assetConfigurationPage.enterUnitName(unitname);
		levels.clickSubmitButton();
	}

	@When("^creating asset with mandatory fields and selecting created unit name$")
	public void createAssetWithCreateUnitName() throws Throwable {
		assetConfigurationPage.clickADDAssetBtn();
		String assetnm = "Asset" + System.currentTimeMillis();
		assetConfigurationPage.enterAssetName(assetnm);
		entityname.add(assetnm);
		assetConfigurationPage.enterUnitName(expectedUnitName);
		levels.clickSubmitButton();
	}

	@Then("^asset created successfully$")
	public void asset_created_successfully(String unitname) throws Throwable {
		assetConfigurationPage.verifySuccessAlert("Addition");
	}

	@When("^editing unit details to \"([^\"]*)\"$")
	public void editing_unit_details_to_something(String strArg1) throws Throwable {
		waitForPageLoaded();
		expectedUnitName = strArg1;
		unitDetailsPage.verifyUnitNameHeader();
		unitDetailsPage.clickonEditLink();
		waitForPageLoaded();
		unitDetailsPage.verifyAddHereHeader();
		unitDetailsPage.enterUnitNames(strArg1);
		unitDetailsPage.verifyCancelButton();
		unitDetailsPage.verifySaveButton();
		unitDetailsPage.clickOnSaveButton();
	}

	@Then("^unit details are successfully created$")
	public void unit_details_are_successfully_created() throws Throwable {
		unitDetailsPage.verifyConfirmationPopupHeader();
		unitDetailsPage.verifyConfirmationInstructionMessage();
		unitDetailsPage.verifyConfirmationFlag("NO");
		unitDetailsPage.verifyConfirmationFlag("YES");
		unitDetailsPage.clickOnConfirmationFlag("YES");
		unitDetailsPage.verifySuccessMessage();
	}

	@Given("^level \"([^\"]*)\" is created$")
	public void level_something_is_created(String levelname) throws Throwable {
		levelName = Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token, Levelhirachyname);
		Hirarchyname.clear();
		Hirarchyname.add(Levelhirachyname);
		System.out.print(levelName);
	}

	@Then("^Unit Details section is available$")
	public void unit_details_section_is_available() throws Throwable {
		waitForPageLoaded();
		unitDetailsPage.verifyUnitNameHeader();
		// unitDetailsPage.verifyUnitNameTextBox();
	}

	@When("^selecting level hierarchy \"([^\"]*)\"$")
	public void selecting_level_hierarchy_something(String levelname) throws Throwable {
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		users.selectlevelhirarchy_User(levelName);
		common.selectSideMenuOption("Configuration");
	}

	@Then("^Unit Details section should not be available$")
	public void unit_details_section_should_not_be_available() throws Throwable {
		unitDetailsPage.verifyUnitDetailsSection();
	}

	@Given("^unit details \"([^\"]*)\" are created$")
	public void unit_details_something_are_created(String strArg1) throws Throwable {
		// Need to use api
		expectedUnitName = strArg1;
		unitDetailsPage.clickon_UnitDetailsLink();
		unitDetailsPage.clickonEditLink();
		unitDetailsPage.enterUnitNames(strArg1);
		unitDetailsPage.clickOnSaveButton();
		unitDetailsPage.clickOnConfirmationFlag("YES");
		unitDetailsPage.verifySuccessMessage();
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		waitForPageLoaded();
		common.selectSideMenuOption("Configuration");

	}

	@Then("^unit details are successfully edited/deleted$")
	public void unit_details_are_successfully_editeddeleted() throws Throwable {
		unitDetailsPage.verifyConfirmationPopupHeader();
		unitDetailsPage.verifyConfirmationInstructionMessage();
		unitDetailsPage.verifyConfirmationFlag("NO");
		unitDetailsPage.verifyConfirmationFlag("YES");
		unitDetailsPage.clickOnConfirmationFlag("YES");
		unitDetailsPage.verifySuccessMessage();
	}

	@And("^editing unit details to a text with 1025 chars$")
	public void editing_unit_details_to_a_text_with_1025_chars() throws Throwable {
		String strArg1 = getRandomString(1025);
		expectedUnitName = strArg1;
		unitDetailsPage.clickonEditLink();
		unitDetailsPage.enterUnitNames(strArg1);
		unitDetailsPage.clickOnSaveButton();
		unitDetailsPage.clickOnConfirmationFlag("YES");
	}

	@Then("^portal-sdk error message is displayed$")
	public void portalsdk_error_message_is_displayed() throws Throwable {
		unitDetailsPage.verifyPortSDKErrorMessage();
		waitForPageLoaded();
	}

	@And("^unit details is not created$")
	public void unit_details_is_not_created() throws Throwable {
		unitDetailsPage.validateUnitName(expectedUnitName);
	}

	@When("^editing unit details to non continuous text$")
	public void editing_unit_details_to_non_continuous_text() throws Throwable {
		String strArg1 = "Unit Names should" + "                          " + "                    "
				+ "                   be in a continous line.";
		expectedUnitName = strArg1;
		unitDetailsPage.clickonEditLink();
		unitDetailsPage.enterUnitNames(strArg1);
		unitDetailsPage.clickOnSaveButton();
	}

	@Then("^\"([^\"]*)\" error message is displayed$")
	public void something_error_message_is_displayed(String strArg1) throws Throwable {
		unitDetailsPage.verifyNonContinousErrorMessage(strArg1);
		unitDetailsPage.clickOnCancelButton();
	}

	@And("^unit name is not created$")
	public void unit_name_is_not_created() throws Throwable {
		unitDetailsPage.validateUnitName(expectedUnitName);
	}

}
