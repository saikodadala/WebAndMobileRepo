package steps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import common.reports.ConfigFileReadWrite;
import common.reports.ReporterConstants;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import seleniumUtilities.BaseClass;

public class AssetConfigurationSteps extends BaseClass {



	List<String>entityname=new ArrayList<String>();
	List<String>entitysubassetname=new ArrayList<String>();

	public String Levelhirachyname="AddLevelhirachy"+System.currentTimeMillis();
	public String Assetname="Asset"+System.currentTimeMillis();
	public String SubAssetname="SubAsset"+System.currentTimeMillis();
	public String levelid="";
	public String assetid="";
	public String subassetid="";

	String token=loginPage.getCookie();

	@Then("^the empty message is displayed \"([^\"]*)\"$")
	public void i_verify_the_empty_message(String arg1) throws Throwable {
		assetConfigurationPage.verifyEmptyMessage(arg1);
	}

	@Then("^the factory image for no assets is displayed$")
	public void i_verify_the_factory_image_for_no_assets() throws Throwable {
		assetConfigurationPage.verifyEmptyImg();
	}

	@When("^click on submit button$")
	public void i_click_on_submit_button() throws Throwable {
		assetConfigurationPage.clickOnsubmitBtn();
	}

	@When("^click on cancel button$")
	public void i_click_on_cancel_button() throws Throwable {
		assetConfigurationPage.clickCancel();
	}

	@Then("^the mandatory error messages are displayed$")
	public void i_verify_the_mandatory_error_messages() throws Throwable {
		assetConfigurationPage.verifybothemptyvalues();
	}

	@Then("^portal user click on ADD ASSET button$")
	public void i_click_on_ADD_ASSET_button() throws Throwable {
		assetConfigurationPage.clickADDAssetBtn();
	}

	@When("^fill details on add asset page$")
	public void i_enter_details_on_add_asset_page() throws Throwable {
		//String assetnm = readCsvFile("assetname","AssetDetails");
		String assetnm = "Asset"+System.currentTimeMillis();
		assetConfigurationPage.enterAssetDetails(assetnm);
		entityname.add(assetnm);
	}

	@Then("^success alert is displayed for asset \"([^\"]*)\"$")
	public void i_verify_success_alert_for_asset(String arg1) throws Throwable {
		assetConfigurationPage.verifySuccessAlert(arg1);
	}

	@When("^click on ellipse icon$")
	public void i_click_on_ellipse_icon() throws Throwable {
		assetConfigurationPage.clickEllipse();
	}

	@And("^select the subasset$")
	@When("^click on search result$")
	public void i_click_on_search_result() throws Throwable {
		assetConfigurationPage.selectsearch_result();
	}

	@When("^asset details page is displayed$")
	public void i_verify_asset_details_page() throws Throwable {
		assetConfigurationPage.verifyassetDetailsPage();
	}

	@Then("^click on \"([^\"]*)\" link$")
	public void i_click_on_button(String arg1) throws Throwable {
		assetConfigurationPage.clickOnEditIcon(arg1);
	}

	@Then("^check asset page details$")
	public void checkAssetPageDetails() throws Throwable {
		assetConfigurationPage.verifyassetDetailsPage();
	}

	@When("^fill details on edit asset page$")
	public void i_enter_details_on_edit_asset_page() throws Throwable {
		By refreshLoader=By.cssSelector("[class='ui loader-wrap loading-alignments loading']");
		waitForInVisibilityOfElement(refreshLoader, "Waiting for invisibility of Loader", 10);
		waitForPageLoaded();
		String editassetname = "editedAsset"+System.currentTimeMillis();
		assetConfigurationPage.editDetails(editassetname);
		entityname.add(editassetname);
	}

	@When("^click on \"([^\"]*)\" tab$")
	public void i_click_on_tab(String arg1) throws Throwable {
		assetConfigurationPage.clickOnTab(arg1);
	}

	@When("^click on \"([^\"]*)\" icon$")
	public void i_click_on_icon(String arg1) throws Throwable {
		assetConfigurationPage.clickOnIcon(arg1);
	}

	@Given("^create Level hirarchy with api \"([^\"]*)\" for Assets$")
	public void create_Level_hirarchy_with_api_for_Assets(String levelname) throws Throwable {
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		levelname=Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token,levelname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		common.waitForPageLoaded();

	}
	@When("^create Asset with api \"([^\"]*)\" in Assetspage$")
	public void create_Asset_with_api_in_Assetspage(String assetname) throws Throwable {
		Assetids.clear();
		assetname=Assetname;
		assetid=apii.createAsset_api(token,levelid,assetname,"Machines","Average");
		Assetids.add(assetid);
		entityname.add(assetname);
	}

	@When("^create Assets with different asset types&modes with api \"([^\"]*)\" in Assetspage$")
	public void create_Assets_with_different_asset_types_modes_with_api_in_Assetspage(String assetname) throws Throwable {
		Assetids.clear();
		entityname.clear();
		ArrayList<String>asset_type = new ArrayList<String>(Arrays.asList("Machines","Boilers","Systems","Engines","Devices"));
		ArrayList<String>assetmode=new  ArrayList<String>(Arrays.asList("Good","Average","Medium","Low","High"));
		for(int i=1;i<=asset_type.size();i++)
		{

			assetname=RandomStringUtils.random(10,true,true)+"Asset";
			assetid=apii.createAsset_api(token,levelid,assetname,asset_type.get(i-1),assetmode.get(i-1));		
			Assetids.add(assetid);
			entityname.add(assetname);
		}	
	}

	@When("^create SubAssets with different asset types&modes with api \"([^\"]*)\" in Assetspage$")
	public void create_SubAssets_with_different_asset_types_modes_with_api_in_Assetspage(String subassetname) throws Throwable {
		SubAssetids.clear();
		entityname.clear();
		ArrayList<String>subasset_type = new ArrayList<String>(Arrays.asList("Machines","Boilers","Systems","Engines","Devices"));
		ArrayList<String>subassetmode=new  ArrayList<String>(Arrays.asList("Good","Average","Medium","Low","High"));
		for(int i=1;i<=subasset_type.size();i++)
		{

			subassetname=RandomStringUtils.random(10,true,true)+"SubAsset";
			subassetid=apii.createSubAsset_api(token, assetid, subassetname, subasset_type.get(i-1),subassetmode.get(i-1));
			entityname.add(subassetname);
			SubAssetids.add(subassetid);
		}	
	}

	@When("^create (\\d+) Asset items with api for pagination in Assetspage$")
	public void create_Asset_items_with_api_for_pagination_in_Assetspage(int nooftimes) throws Throwable {
		Assetids.clear();
		for(int i=0;i<nooftimes;i++)
		{
			String assetid=apii.createAsset_api(token,levelid,Assetname+getRandomString(4),"Machines","Good");
			Assetids.add(assetid);
		}
	}

	@When("^select Level hirarchy \"([^\"]*)\" from AssetHirarchy menu$")
	public void select_Level_hirarchy_from_AssetHirarchy_menu(String levelname) throws Throwable {

		levelname=Levelhirachyname;
		assetConfigurationPage.selectlevelhirachy(levelname);
	}

	@When("^click on Asset$")
	public void click_on_Asset() throws Throwable {
		assetConfigurationPage.clickonAsset();
		common.waitForPageLoaded();
	}

	@When("^click on SubAsset$")
	public void click_on_SubAsset() throws Throwable {
		scrollBottom();
		common.waitForPageLoaded();
		assetConfigurationPage.clickonSubAsset();
		common.waitForPageLoaded();
	}

	@Then("^verify sorting in Assetspage$")
	public void verify_sorting_in_Assetspage() throws Throwable {
		Validate_Sorting("Asset Name","Ascending");
	}

	@And("^search the updated Asset in Global search$")
	@And("^search the created Asset in Global search$")
	@Then("^verify search in Assetspage$")
	public void verify_search_in_Assetspage() throws Throwable {
		for(int i=1;i<=entityname.size();i++)
		{
			String entitytosearch=entityname.get(i-1);
			Validate_Search(entitytosearch);
		}
	}
	@Then("^verify filters in Assets page$")
	public void verify_filters_in_Assets_page() throws Throwable {
		Validate_Filters();
	}

	@Then("^verify sorting in SubAssetspage$")
	public void verify_sorting_in_SubAssetspage() throws Throwable {

		Validate_Sorting("Asset Type","Ascending");

	}

	@Then("^verify search in SubAssetspage$")
	public void verify_search_in_SubAssetspage() throws Throwable {
		for(int i=1;i<=entityname.size();i++)
		{
			String entitytosearch=entityname.get(i-1);
			Validate_Search(entitytosearch);
		}
	}

	@Then("^verify filters in SubAssets page$")
	public void verify_filters_in_SubAssets_page() throws Throwable {
		Validate_Filters();
	}

	@When("^create (\\d+) SubAsset items with api for pagination in Assetspage$")
	public void create_SubAsset_items_with_api_for_pagination_in_Assetspage(int nooftimes) throws Throwable {
		SubAssetids.clear();
		for(int i=0;i<nooftimes;i++)
		{
			subassetid=apii.createSubAsset_api(token,assetid,SubAssetname+getRandomString(9),"Machines","Good");
			SubAssetids.add(subassetid);
		}
	}


	@Then("^verify showhide functionality$")
	public void verify_showhide_functionality_in_Assetspage() throws Throwable {
		common.validate_ShowHide();
	}

	@When("^fill the details of assetmode , assettype with \"([^\"]*)\" for \"([^\"]*)\"$")
	public void fill_the_details_of_assetmode_assettype_with(String arg1,String arg2) throws Throwable {
		assetConfigurationPage.enterDetails(arg1,arg2);
	}

	@Then("^fill the details of assetname,backendid,criticality,contact,owner,locationID and description with \"([^\"]*)\" for \"([^\"]*)\"$")
	public void fill_the_details_of_assetname_backendid_criticality_contact_owner_locationID_and_description_with(String arg1,String arg2) throws Throwable {
		assetConfigurationPage.enterDetails(arg1,arg2);
	}

	@Then("^fill the details of location with \"([^\"]*)\" for \"([^\"]*)\"$")
	public void fill_the_details_of_location_with(String arg1,String arg2) throws Throwable {
		assetConfigurationPage.enterDetails(arg1,arg2);
	}

	@Then("^fill the identication code with \"([^\"]*)\" for \"([^\"]*)\"$")
	public void fill_the_identification_code_with(String arg1,String arg2) throws Throwable {
		assetConfigurationPage.enterDetails(arg1,arg2);
	}

	@Then("^fill the details of saptag, dcstag, historiantag and fieldtag with \"([^\"]*)\" for \"([^\"]*)\"$")
	public void fill_the_details_of_saptag_dcstag_historiantag_and_fieldtag_with(String arg1,String arg2) throws Throwable {
		assetConfigurationPage.enterDetails(arg1,arg2);
	}

	@Then("^error message is displayed for \"([^\"]*)\" as \"([^\"]*)\"$")
	public void error_message_is_displayed_for_as(String fieldname, String errormsg) throws Throwable {
		assetConfigurationPage.verifybothinvalid(fieldname,errormsg);
	}

	@Then("^Deleted asset is not visisble in assset table$")
	public void deleted_asset_is_not_visisble_in_subassset_table() throws Throwable {
		assetConfigurationPage.verifyTable();
	}

	@Then("^Deleted subasset is not visisble in subassset table$")
	public void deleted_subasset_is_not_visisble_in_subassset_table() throws Throwable {
		assetConfigurationPage.verifysubassetTable();
	}

	@When("^create SubAsset with api \"([^\"]*)\" in Assetspage$")
	public void create_subAsset_with_api_in_Assetspage(String subassetname) throws Throwable {
		SubAssetids.clear();
		subassetname="SubAsset"+generateRandomNumber(4);
		subassetid=apii.createSubAsset_api(token,assetid,subassetname,"Machines","Good");
		entityname.add(subassetname);		
		SubAssetids.add(subassetid);
	}

	@When("^click on Tasks tab$")
	public void click_on_Taskstab() throws Throwable {
		scrollBottom();
		assetConfigurationPage.clickonTasks();
	}

	@When("^portal user clicks on created Asset \"([^\"]*)\"$")
	public void open_created_device(String action) throws Throwable {
		common.verifyTableAbstractAssetThreeDots();
		common.verifyMoreActions();
		assetConfigurationPage.clickEllipse();

	}

	@Then("^updated record is displayed on tabular data$")
	public void verify_updated_assetname_in_table() throws Throwable {
		for(int i=1;i<=entityname.size();i++)
		{
			String entitytosearch=entityname.get(i-1);
			assetConfigurationPage.verifyDeviceType(entitytosearch);
		}
	}

	@Then("^created record is displayed on tabular data$")
	public void verify_created_assetname_in_table() throws Throwable {
		for(int i=1;i<=entityname.size();i++)
		{
			String entitytosearch=entityname.get(i-1);
			assetConfigurationPage.verifyDeviceType(entitytosearch);
		}
	}

	@When("^fill details on add subasset page$")
	public void i_enter_details_on_add_subasset_page() throws Throwable {
		//String assetnm = readCsvFile("assetname","AssetDetails")+System.currentTimeMillis();
		String assetnm = "subasset"+System.currentTimeMillis();
		assetConfigurationPage.entersubAssetDetails(assetnm);
	}

	@And("^edited subasset is visisble in subassset table$")
	@And("^subasset is visisble in subassset table$")
	public void verify_search_SubAssetpage() throws Throwable {
		for(int i=1;i<=entitysubassetname.size();i++)
		{
			String entitytosearch=entitysubassetname.get(i-1);
			Validate_Search(entitytosearch);
		}
	}

	@Then("^the empty message for attachments is displayed \"([^\"]*)\"$")
	public void i_verify_the_empty_attachments(String arg1) throws Throwable {
		assetConfigurationPage.verifyDocsEmptyMessage(arg1);
	}

	@Then("^the factory image for no attachments is displayed$")
	public void i_verify_the_factory_image_for_no_attachments() throws Throwable {
		assetConfigurationPage.verifyNoDocsImg();
	}

	@Then("^add attachments popup window is displayed$")
	public void i_verify_Attachments_popup_window() throws Throwable {
		assetConfigurationPage.verifyAttachemntsBrowsepopupmsg();
	}

	@And("^select the subasset ellipse$")
	public void subasset_ellipse() throws Throwable {
		assetConfigurationPage.clickOnEllipse();
	}


	@When("click on sort button for {string} column")
	public void click_on_sort_button_for_column(String columnname) throws Throwable {

		clickonsortbutton(columnname);
	}

	@Then("{string} column should be in Ascending order")
	public void column_should_be_in_ascending_order(String columnname) throws Throwable {

		Validate_Sorting(columnname,"Ascending");
	}

	@Then("{string} column should be in Descending order")
	public void column_should_be_in_descending_order(String columnname) throws Throwable {

		Validate_Sorting(columnname,"Descending");
	}

	@When("^click on three dots at column level$")
	public void click_on_three_dots_at_column_level() throws Throwable {
		common.clickOnThreeDots();
	}

	@When("^select column names$")
	public void select_column_names() throws Throwable {
		common.selectAllCoumns();
	}

	@Then("^selected columns are available in the table$")
	public void selected_columns_are_available_in_the_table() throws Throwable {
		common.selectedColumnsAvailableInTheTable();
	}

	@Then("^asset configuration page is displayed$")
	public void asser_configpage_is_displayed() throws Throwable {
		assetConfigurationPage.verifyAssetConfigurationHeader();
		scrollBottom();
		assetConfigurationPage.clickonTasks();
	}
	
	@When("^Level hirarchy \"([^\"]*)\" is selected$")
	public void Level_hirarchy_is_selected(String levelname) throws Throwable {

		levelname = Levelhirachyname;
		assetConfigurationPage.selectlevelhirachy(levelname);
	}
	
	
}