package steps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import seleniumUtilities.BaseClass;

public class TaskSteps extends BaseClass {

	List<String> entityname = new ArrayList<String>();
	public String levelid = "";
	public String assetid = "";
	public String taskid = "";

	public String Levelhirachyname = "AddLevelhirachy" + System.currentTimeMillis();
	public String Assetname = "Asset" + System.currentTimeMillis();
	public String Taskname = "Task" + System.currentTimeMillis();
	static String taskname = "";

	// fetch the token from the Ui after login
	String token = loginPage.getCookie();

	@Given("create Level hirarchy with api {string} for Task")
	public void create_level_hirarchy_with_api_for_task(String levelname) throws Throwable {
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		levelname = Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token, levelname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		common.waitForPageLoaded();
	}

	@Given("create Asset with api {string} for Taskpage")
	public void create_asset_with_api_for_taskpage(String assetname) throws Throwable {
		Assetids.clear();
		assetname = Assetname;
		assetid = apii.createAsset_api(token, levelid, assetname, "Machines", "Average");
		Assetids.add(assetid);
		entityname.add(assetname);

	}

	@And("^create (\\d+) Task item with api in Taskpage$")
	@Given("^create (\\d+) Task items with api for pagination in Taskpage$")
	public void create_Task_items_with_api_for_pagination_in_Taskpage(int nooftimes) throws Throwable {
		Taskids.clear();
		// ArrayList<String>poistion = new
		// ArrayList<String>(Arrays.asList("2","1","3","4","5"));
		// ArrayList<String>assetmode=new
		// ArrayList<String>(Arrays.asList("Good","Average","Medium","Low","High"));
		for (int i = 1; i <= nooftimes; i++) {
			String TaskName = RandomStringUtils.random(10, true, true) + "Task";
			String limitname = "limit" + System.currentTimeMillis();
			String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
			String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
			String backendid = RandomStringUtils.random(10, false, true) + "backendid";
			String category = RandomStringUtils.random(10, true, true) + "category";
			taskid = apii.createTask_api(token, assetid, TaskName, limitname, "Good", "2", saptag, dcstag, backendid,
					category);
			Taskids.add(taskid);
			taskname = TaskName;
		}
	}

	@Then("^verify pagination in Taskpage$")
	public void verify_pagination_in_Taskpage() throws Throwable {
		Validate_Pagination();
	}

	@Given("^create Task with different types&modes with api \"([^\"]*)\" in Taskpage$")
	public void create_Task_with_different_types_modes_with_api_in_Taskpage(String taskname) throws Throwable {

		Taskids.clear();
		entityname.clear();
		ArrayList<String> poistion = new ArrayList<String>(Arrays.asList("2", "1", "3", "4", "5"));
		ArrayList<String> assetmode = new ArrayList<String>(Arrays.asList("Good", "Average", "Medium", "Low", "High"));
		for (int i = 1; i <= assetmode.size(); i++) {

			taskname = RandomStringUtils.random(10, true, true) + "Task";
			String limitname = "limit" + System.currentTimeMillis();
			String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
			String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
			String backendid = RandomStringUtils.random(10, false, true) + "backendid";
			String category = RandomStringUtils.random(10, true, true) + "category";
			taskid = apii.createTask_api(token, assetid, taskname, limitname, assetmode.get(i - 1), poistion.get(i - 1),
					saptag, dcstag, backendid, category);
			Taskids.add(taskid);
			entityname.add(taskname);
		}
	}

	@Then("^verify search in Taskpage$")
	public void verify_search_in_Taskpage() throws Throwable {

		for (int i = 1; i <= entityname.size(); i++) {
			String entitytosearch = entityname.get(i - 1);
			Validate_Search(entitytosearch);
		}
	}

	@Then("^verify filters in Task page$")
	public void verify_filters_in_Task_page() throws Throwable {
		Validate_Filters();
	}

	@Then("^navigating to \"([^\"]*)\" for created Level$")
	@When("select Level hirarchy {string} from AssetHirarchy menu for Task")
	public void select_level_hirarchy_from_asset_hirarchy_menu_for_task(String levelname) throws Throwable {
		levelname = Levelhirachyname;
		taskPage.selectlevelhirachy(levelname);
	}

	@When("click on Task")
	public void click_on_task() throws Throwable {
		scrollBottom();
		taskPage.clickonTask();
	}

	@Then("^enter the task Position as \"([^\"]*)\"$")
	public void enter_task_Criticality(String arg1) throws Throwable {
		taskPage.enterTaskPosition(arg1);
	}

	@Then("^enter the task Name as \"([^\"]*)\"$")
	public void enter_the_task_Name_as(String arg1) throws Throwable {
		taskname = Taskname;
		taskPage.enterTaskName(taskname);
	}

	@Then("^enter the task Type as \"([^\"]*)\"$")
	public void enter_the_Type_as(String arg1) throws Throwable {
		taskPage.chooseTaskType(arg1);
	}

	@When("^click on Next button$")
	public void click_on_Next() throws Throwable {
		taskPage.clickonNext();
	}

	@When("^click on Reset button$")
	public void click_on_Reset() throws Throwable {
		taskPage.clickonReset();
	}

	@Then("^enter the Limit Value as \"([^\"]*)\"$")
	public void enter_LimitValue(String arg1) throws Throwable {
		taskPage.enterLimitValue(arg1);
	}

	@Then("^enter the Limit Name as \"([^\"]*)\"$")
	public void enter_the_Limit_Name_as(String limitname) throws Throwable {
		limitname = "Limit" + System.currentTimeMillis();
		taskPage.enterLimitName(limitname);
	}

	@Then("^enter the Limit Type as \"([^\"]*)\"$")
	public void enter_the_LimitType_as(String arg1) throws Throwable {
		taskPage.chooseTaskType(arg1);
	}

	@When("^click on Add Limit button$")
	public void click_on_AddLimitBtn() throws Throwable {
		taskPage.clickonAddLimitBtn();
	}

	@When("^click on Save button$")
	public void click_on_saveBtn() throws Throwable {
		taskPage.clickonsaveBtn();
	}

	@Then("^success alert is displayed for Task \"([^\"]*)\"$")
	public void success_alert_is_displayed_for_task(String type) throws Throwable {
		taskPage.verifyTaskSuccessAlert(type);
	}

	@Then("^the taskname mandatory error message is displayed$")
	public void taskname_mandatory_error_message() throws Throwable {
		taskPage.verifyTaskMandatoryMsg();
	}

	@Then("^the task position mandatory error message is displayed$")
	public void taskposition_mandatory_error_message() throws Throwable {
		taskPage.verifyTaskPositionMandatoryMsg();
	}

	@Then("^the task type mandatory error message is displayed$")
	public void tasktype_mandatory_error_message() throws Throwable {
		taskPage.verifyTaskTypeMandatoryMsg();
	}

	@Then("^Tasks Global Search is displayed$")
	public void tasks_globalsearch_is_displayed() throws Throwable {
		taskPage.verifyTasksSearchBox();
	}

	@Then("^task total is displayed$")
	public void tasks_total_is_displayed() throws Throwable {
		taskPage.verifyTasksTotal();
	}

	@Then("^task page dropdown is displayed$")
	public void page_dropdown_is_displayed() throws Throwable {
		taskPage.verifyTaskPageDropdown();
	}

	@Then("^task data table is displayed$")
	public void task_data_table_is_displayed() throws Throwable {
		taskPage.verifyTaskDataTable();
	}

	@Then("^error message is displayed for task position as \"([^\"]*)\"$")
	public void invalidlength_taskposition(String arg1) throws Throwable {
		taskPage.verifyinvalidCharlengthtaskPosition(arg1);
	}

	@Then("^error message is displayed for task name as \"([^\"]*)\"$")
	public void invalidlength_taskname(String arg1) throws Throwable {
		taskPage.verifyinvalidCharlengthtaskName(arg1);
	}

	@Then("^error message is displayed for task backendid as \"([^\"]*)\"$")
	public void invalidlength_taskbackendid(String arg1) throws Throwable {
		taskPage.verifyinvalidCharlengthtaskBckID(arg1);
	}

	@When("^enter task name with \"([^\"]*)\" for \"([^\"]*)\"$")
	public void fill_the_details_of_taskname_with(String arg1, String arg2) throws Throwable {
		taskPage.enterTaskInvalidDetails(arg1, arg2);
	}

	@When("^enter task position with \"([^\"]*)\" for \"([^\"]*)\"$")
	public void fill_the_details_of_taskposition_with(String arg1, String arg2) throws Throwable {
		taskPage.enterTaskInvalidDetails(arg1, arg2);
	}

	@When("^enter task backend id with \"([^\"]*)\" for \"([^\"]*)\"$")
	public void fill_the_details_of_taskbackendID(String arg1, String arg2) throws Throwable {
		taskPage.enterTaskBCKendInvalidDetails(arg1, arg2);
	}

	@Then("^task page is displayed$")
	public void task_page_is_displayed() throws Throwable {
		taskPage.verifyTaskPage();
	}

	@Then("^enter value as \"([^\"]*)\" in Task Global Search$")
	public void enter_value_as_in_Task_GlobalSearch(String arg1) throws Throwable {
		taskPage.searchTask(taskname);
	}

	@Then("^created task \"([^\"]*)\" is displayed on Task Data Table$")
	public void verified_on_Task_DataTable(String arg1) throws Throwable {
		taskPage.verifyTaskName(taskname);
	}

	@Then("^click on cross icon on create task page$")
	public void crossicon_task() throws Throwable {
		taskPage.clicktaskcrossicon();
	}

	@Then("^close window is displayed$")
	public void closewindow_task() throws Throwable {
		taskPage.closewindowpopup();
	}

	@Then("^click on confirm button$")
	public void click_ConfirmBtn() throws Throwable {
		taskPage.clickConfirmButton();
	}

	@And("^created task is displayed in data table$")
	@Then("^first record appears on task data table$")
	public void first_recordOfTask() throws Throwable {
		taskPage.waittilltaskappears();
	}

	@When("^perform \"([^\"]*)\" action on created task$")
	public void perform_action_on_created_task(String arg1) throws Throwable {
		common.verifyTableAbstractAssetThreeDots();
		common.verifyMoreActions();
		taskPage.clickOnTaskEllipse();
		taskPage.clickOnRecordAction(arg1);
	}

	@Then("^Delete Task window is displayed$")
	public void deletewindow_task() throws Throwable {
		taskPage.deletetaskwindowpopup();
	}

	@Then("^first record disappears on task data table$")
	public void first_recordOfTaskDisappear() throws Throwable {
		taskPage.waittilltaskdisappears();
	}

	@Then("^active limit section is displayed$")
	public void active_limitsection_displayed() throws Throwable {
		taskPage.verifyLimitsSection();
	}

	@Then("^active support content section is displayed$")
	public void active_supportivecontentsection_displayed() throws Throwable {
		taskPage.verifySupportiveContentSection();
	}

	@Then("^pagenation Info is displayed$")
	public void pagenation_Info_is_displayed() throws Throwable {
		taskPage.verifyPagenationInfo();
	}

	@Given("level {string} with asset {string} are created")
	public void level_with_asset_are_created(String levelname, String assetname) throws Throwable {

		Hirarchyname.clear();
		levelname = Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token, levelname);
		Hirarchyname.add(levelname);
		assetname = Assetname;
		assetid = apii.createAsset_api(token, levelid, assetname, "Machines", "Average");
		Assetids.add(assetid);
		entityname.add(assetname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		common.waitForPageLoaded();

	}

	@When("navigating to Assethirarchy & task section of created level")
	public void navigating_to_assethirarchy_task_section_of_created_level() throws Throwable {

		taskPage.selectlevelhirachy(Levelhirachyname);
		assetConfigurationPage.clickonAsset();
		common.waitForPageLoaded();
	}

	@When("creating task of type {string} with valid inputs {string},{string},{string},{string},{string}")
	public void creating_task_of_type_with_valid_inputs(String tasktype, String taskname, String numericvalue,
			String predefinedvalue, String limitname, String limittype) throws Throwable {

		taskname = Taskname;
		limitname = "Limit" + System.currentTimeMillis();
		taskPage.creattask_differentype(tasktype, taskname, numericvalue, predefinedvalue, limitname, limittype);
	}

	@When("creating task of type {string} with valid inputs {string},{string},{string},{string},{string},{string}")
	public void creating_task_of_type_with_valid_inputs(String tasktype, String taskname, String numericvalue,
			String date, String predefinedvalue, String limitname, String limittype) throws Throwable {

		taskname = Taskname;
		limitname = "Limit" + System.currentTimeMillis();
		taskPage.creattask_differentype(tasktype, taskname, numericvalue, date, predefinedvalue, limitname, limittype);
	}

	@Then("task creation is successful")
	public void task_creation_is_successful() throws Throwable {

		taskPage.verifytasksuccess();
	}

	@Given("^Level hierarchy with asset are created$")
	public void level_hierarchy_with_asset_are_created() throws Throwable {
		// Level creation
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		String levelname = Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token, levelname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		common.waitForPageLoaded();

		// Asset creation
		Assetids.clear();
		String assetname = Assetname;
		assetid = apii.createAsset_api(token, levelid, assetname, "Machines", "Average");
		Assetids.add(assetid);
		entityname.add(assetname);

		// Select level
		levelname = Levelhirachyname;
		taskPage.selectlevelhirachy(levelname);
	}

	@When("^Portal user selects the created asset$")
	public void portal_user_selects_the_created_asset() throws Throwable {
		assetConfigurationPage.clickonAsset();
		common.waitForPageLoaded();
	}

	@When("^open task create view for task type checkBox, dropdown, text or date$")
	public void open_task_create_view_for_task_type_checkbox_dropdown_text_or_date() throws Throwable {
		assetConfigurationPage.clickOnIcon("Add Task");
	}

	@Then("^task formula field should be disabled$")
	public void task_formula_field_should_be_disabled() throws Throwable {

		ArrayList<String> task_type = new ArrayList<String>(Arrays.asList("Dropdown", "Checkbox", "Text", "Date"));
		for (int i = 1; i <= task_type.size(); i++) {
			taskPage.chooseTaskType(task_type.get(i - 1));
			taskPage.clickConfirmButton();
			taskPage.verifyFormulaTextBox();
		}

	}

	@Given("^Level hierarchy with asset,task are created$")
	public void level_hierarchy_with_asset_task_are_created() throws Throwable {
		// Level creation
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		String levelname = Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token, levelname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		common.waitForPageLoaded();

		// Asset creation
		Assetids.clear();
		String assetname = Assetname;
		assetid = apii.createAsset_api(token, levelid, assetname, "Machines", "Average");
		Assetids.add(assetid);
		entityname.add(assetname);

		// Task creation
		Taskids.clear();
		String TaskName = RandomStringUtils.random(10, true, true) + "Task";
		String limitname = "limit" + System.currentTimeMillis();
		String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid = RandomStringUtils.random(10, false, true) + "backendid";
		String category = RandomStringUtils.random(10, true, true) + "category";
		taskid = apii.createTask_api(token, assetid, TaskName, limitname, "Good", "2", saptag, dcstag, backendid,
				category);
		Taskids.add(taskid);
		taskname = TaskName;

		// Select level
		levelname = Levelhirachyname;
		taskPage.selectlevelhirachy(levelname);
	}

	@When("^Portal user selects the created asset,task$")
	public void portal_user_selects_the_created_asset_task() throws Throwable {
		assetConfigurationPage.clickonAsset();
		waitForPageLoaded();

	}

	@When("^open task edit view for task type checkBox, dropdown, text or date$")
	public void open_task_edit_view_for_task_type_checkbox_dropdown_text_or_date() throws Throwable {
		waitForPageLoaded();
		taskPage.clickOnTaskEllipse();
		taskPage.clickOnRecordAction("Edit");
	}

	@When("create Task with all mandatory & non mandatory fields with valid inputs {string},{string},{string},{string}")
	public void create_task_with_all_mandatory_non_mandatory_fields_with_valid_inputs(String tasktype,
			String limitname, String type, String value)
					throws Throwable {
		
		String description=readCsvFile("description", "TaskTestData");
		String backendid=readCsvFile("backendid", "TaskTestData");
		String locationid=readCsvFile("locationid", "TaskTestData");
		String locationgps=readCsvFile("locationgps", "TaskTestData");
		String locationdescription=readCsvFile("locationdescription", "TaskTestData");
		String saptag=readCsvFile("saptag", "TaskTestData");
		String dcstag=readCsvFile("dcstag", "TaskTestData");
		String historiantag=readCsvFile("historiantag", "TaskTestData");
		String filedtag=readCsvFile("fieldtag", "TaskTestData");
		String positionRandom = generateRandomNumber(2);
		String cause=readCsvFile("cause", "TaskTestData");
		String consequence=readCsvFile("consequence", "TaskTestData");
		String action=readCsvFile("action", "TaskTestData");		
		scrollBottom();
		taskPage.clickonTasks();
		taskPage.verifyTaskDataTable();
		taskPage.clickontaskicon();
		taskPage.verifyTaskPage();
		taskPage.enterprimaryinformation(taskname, description, backendid, positionRandom, tasktype);
		taskPage.enterlocationdetails(locationid, locationgps, locationdescription);
		taskPage.entertagdetails(saptag, dcstag, historiantag, filedtag);
		taskPage.enteradditinalinformation();
		taskPage.clickonNext();
		taskPage.enterlimitdetails(limitname, type, value, cause, consequence, action);

	}


	@And("^creating task of type Numeric with valid mandatory fields \"([^\"]*)\"$")
	public void creating_task_of_type_numeric_with_valid_mandatory_fields(String tasktype) throws Throwable {
		scrollBottom();
		String taskName=readCsvFile("taskname", "TaskTestData");
		String description=readCsvFile("description", "TaskTestData");
		String backendid=readCsvFile("backendid", "TaskTestData");
		String locationid=readCsvFile("locationid", "TaskTestData");
		String locationgps=readCsvFile("locationgps", "TaskTestData");
		String locationdescription=readCsvFile("locationdescription", "TaskTestData");
		String saptag=readCsvFile("saptag", "TaskTestData");
		String dcstag=readCsvFile("dcstag", "TaskTestData");
		String historiantag=readCsvFile("historiantag", "TaskTestData");
		String fieldtag=readCsvFile("fieldtag", "TaskTestData");
		System.out.println(taskName);
		String positionRandom = generateRandomNumber(2);
		taskPage.clickonTasks();
		taskPage.verifyTaskDataTable();
		taskPage.clickontaskicon();
		taskPage.verifyTaskPage();
		taskPage.enterprimaryinformation(taskname, description, backendid, positionRandom, tasktype);
		taskPage.enterlocationdetails(locationid, locationgps, locationdescription);
		taskPage.entertagdetails(saptag, dcstag, historiantag, fieldtag);
		taskPage.enteradditinalinformation();
		taskPage.clickonNext();
	}

	@When("^filling valid low and high limits \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void filling_valid_low_and_high_limits( String typeLow,String typeHigh, String lowValue,String highValue) throws Throwable {
		String limitname=readCsvFile("limitname", "TaskTestData");
		String cause=readCsvFile("cause", "TaskTestData");
		String consequence=readCsvFile("consequence", "TaskTestData");
		String action=readCsvFile("action", "TaskTestData");
		String backendId=readCsvFile("backendId", "TaskTestData");
		taskPage.enterlimit_details(limitname, typeLow, lowValue, cause, consequence, action,backendId);
		taskPage.enterlimit_details(limitname, typeHigh, highValue, cause, consequence, action,backendId);
	}

	@And("^filling invalid low and high limits \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void filling_invalid_low_and_high_limits( String typeLow,String typeHigh, String lowValue,String highValue) throws Throwable {
		String limitname=readCsvFile("limitname", "TaskTestData");
		String cause=readCsvFile("cause", "TaskTestData");
		String consequence=readCsvFile("consequence", "TaskTestData");
		String action=readCsvFile("action", "TaskTestData");
		String backendId=readCsvFile("backendId", "TaskTestData");
		taskPage.enterlimit_details(limitname, typeLow, lowValue, cause, consequence, action,backendId);
		taskPage.enterlimit_details(limitname, typeHigh, highValue, cause, consequence, action,backendId);
	}

	@Then("^task with limits are correctly created \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void task_with_limits_are_correctly_created(String typeLow,String typeHigh, String lowValue,String highValue) throws Throwable {
		taskPage.verifyTaskLimits(typeLow, lowValue);
		taskPage.verifyTaskLimits(typeHigh, highValue);
	}


	@Then("^error message is displayed \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void error_message_is_displayed(String limitname, String typeLow,String typeHigh,String lowValue1,String highValue1, String cause, String consequence, String action,String lowValue,String lowValue2,String lowValue3,String lowValue4,String highValue2,String highValue3,String highValue4) throws Throwable {
		taskPage.enterlimit_details(limitname, typeHigh,lowValue1, cause, consequence, action,"");
		taskPage.verifyTaskErrorMessage("Limit low cannot be greater than Limit high");
		taskPage.enterlimit_details(limitname, typeLow, highValue1, cause, consequence, action,"");
		taskPage.verifyTaskErrorMessage("Limit high cannot be lesser than Limit low");
		taskPage.enterlimit_details(limitname, typeLow, lowValue, cause, consequence, action,"");
		taskPage.verifyTaskErrorMessage("Limit low and Limit high values should be different");
		taskPage.enterlimit_details(limitname, typeLow, lowValue2, cause, consequence, action,"");
		taskPage.verifyTaskErrorMessage("Limit low and Limit high values should be different");
		taskPage.enterlimit_details(limitname, typeLow, lowValue3, cause, consequence, action,"");
		taskPage.verifyTaskErrorMessage("Limit low and Limit high values should be different");
		taskPage.enterlimit_details(limitname, typeLow, lowValue4, cause, consequence, action,"");
		taskPage.verifyTaskErrorMessage("Limit low and Limit high values should be different");
		taskPage.enterlimit_details(limitname, typeHigh, highValue2, cause, consequence, action,"");
		taskPage.verifyTaskErrorMessage("Limit low and Limit high values should be different");
		taskPage.enterlimit_details(limitname, typeHigh, highValue3, cause, consequence, action,"");
		taskPage.verifyTaskErrorMessage("Limit low and Limit high values should be different");
		taskPage.enterlimit_details(limitname, typeHigh, highValue4, cause, consequence, action,"");
		taskPage.verifyTaskErrorMessage("Limit low and Limit high values should be different");
	}

	@When("^filling limit \"([^\"]*)\" more than 16 chars$")
	public void filling_limit_something_more_than_16_chars(String type) throws Throwable {
		String value = generateRandomNumber(17);
		if(type.equalsIgnoreCase("High")){
			taskPage.clickOnDiscard();
		}
		taskPage.enterlimit_details("Limit", type, value, "", "", "","");
	}

	@Then("^error message: \"([^\"]*)\" is displayed$")
	public void error_message_something_is_displayed(String message) throws Throwable {
		taskPage.verifyTaskErrorMessage(message);
		waitForPageLoaded();
	}

	@When("^filling validation step as negative$")
	public void filling_validation_step_as_negative() throws Throwable {
		taskPage.clickOnDiscard();
		taskPage.enterlimit_details("Limit", "Validation", "-1000;1000;-1", "", "", "","");
	}

	@When("^filling validation limit as char$")
	public void filling_validation_limit_as_char() throws Throwable {
		taskPage.clickOnDiscard();
		taskPage.enterlimit_details("Limit", "Validation", "xyz", "", "", "","");
	}
	@When("^filling validation step as char$")
	public void filling_validation_step_as_char() throws Throwable {
		taskPage.clickOnDiscard();
		taskPage.enterlimit_details("Limit", "Validation", "-1000;1000;xyz", "", "", "","");
	}
	@When("^create validation limit and try to create another validation limit$")
	public void filling_validation_limit_and_try_to_create_another_valiation_limit() throws Throwable {		
		taskPage.enterlimit_details("Limit", "Validation", "-1000;1000;100", "", "", "","");
		taskPage.enterlimit_details("Limit", "Validation", "-100;100;10", "", "", "","");
	}

	@When("^filling low limit as lower than validation limit$")
	public void filling_low_limit_as_lower_than_validation_limit() throws Throwable {
		taskPage.enterlimit_details("Limit", "Low", "-101", "", "", "","");
	}

	@When("^filling high limit as higher than validation limit$")
	public void filling_high_limit_as_higher_than_validation_limit() throws Throwable {
		taskPage.enterlimit_details("Limit", "High", "1001", "", "", "","");
	}
	@When("creating task of type {string} with valid inputs {string},{string},{string},{string},{string},{string},{string},{string},{string}")
	public void creating_task_of_type_with_valid_inputs(String tasktype, String taskname, String numericvalue,String date,
			String value1, String limitname1, String limittype1,String value2, String limitname2, String limittype2) throws Throwable {
		taskname = Taskname;
		limitname1 = "Limit1" + System.currentTimeMillis();
		limitname2 = "Limit2" + System.currentTimeMillis();
		taskPage.creattask_withLimit(tasktype, taskname, numericvalue,date, value1, limitname1, limittype1, value2, limitname2, limittype2);
	}
	@When("creating task of type {string} {string},{string},{string} with Invalid limit details {string},{string},{string},{string},{string},{string}")
	public void creating_task_of_type_with_invalid_limit_details(String tasktype, String taskname, String numericvalue,String date,
			String value,String limittype, String limitname,String value2,String limittype2,String limitname2) throws Throwable {
		limitname = "Limit1" + System.currentTimeMillis();
		limitname2 = "Limit2" + System.currentTimeMillis();
		scrollBottom();
		taskPage.clickonTasks();
		taskPage.verifyTaskDataTable();
		taskPage.clickontaskicon();
		taskPage.verifyTaskPage();
		taskPage.enterTaskName(taskname);
		taskPage.enterTaskPosition(numericvalue);
		taskPage.chooseTaskType(tasktype);
		taskPage.enterpredefinedvalue_Date(date);
		taskPage.clickonNext();
		taskPage.verifyLimitsSection();
		taskPage.enterLimitName(limitname);
		taskPage.chooseTaskType(limittype);
		taskPage.clickondropdownicon();
		taskPage.selectlimitvalue_as(value);
		taskPage.clickonAddLimitBtn();
		taskPage.enterLimitName(limitname2);
		taskPage.chooseTaskType(limittype2);
		taskPage.clickondropdownicon();
		taskPage.selectlimitvalue_as(value2);
		taskPage.clickonAddLimitBtn();
	}
	@Then("error message {string}")
	public void error_message(String errormessage) throws Throwable {

		locator(errormessage,"Validate error message");
	}
	@When("creating task of type {string} with valid inputs {string},{string},{string},{string},{string},{string},{string},{string},{string},{string},{string},{string}")
	public void creating_task_of_type_with_valid_inputs(String tasktype, String taskname, String numericvalue,String date,
			String value1, String limitname1, String limittype1,String value2, String limitname2, String limittype2,String value3, String limitname3, String limittype3) throws Throwable {
		taskname = Taskname;
		limitname1 = "Limit1" + System.currentTimeMillis();
		limitname2 = "Limit2" + System.currentTimeMillis();
		limitname3 = "Limit3" + System.currentTimeMillis();
		scrollBottom();
		taskPage.clickonTasks();
		taskPage.verifyTaskDataTable();
		taskPage.clickontaskicon();
		taskPage.verifyTaskPage();
		taskPage.enterTaskName(taskname);
		taskPage.enterTaskPosition(numericvalue);
		taskPage.chooseTaskType(tasktype);
		taskPage.enterpredefinedvalue_Date(date);
		taskPage.clickonNext();
		taskPage.verifyLimitsSection();
		taskPage.enterLimitName(limitname1);
		taskPage.chooseTaskType(limittype1);
		taskPage.clickondropdownicon();
		taskPage.selectlimitvalue_as(value1);
		taskPage.clickonAddLimitBtn();

		taskPage.enterLimitName(limitname2);
		taskPage.chooseTaskType(limittype2);
		taskPage.clickondropdownicon();
		taskPage.selectlimitvalue_as(value2);
		taskPage.clickonAddLimitBtn();

		taskPage.enterLimitName(limitname3);
		taskPage.chooseTaskType(limittype3);
		taskPage.clickondropdownicon();
		taskPage.selectlimitvalue_as(value3);
		taskPage.clickonAddLimitBtn();

	}
	@Given("^level, asset and 2 tasks \"([^\"]*)\" \"([^\"]*)\" type numeric are created$")
	public void level_asset_and_2_tasks_type_numeric_are_created(String taskname1, String taskname2) throws Throwable {
		Hirarchyname.clear();
		String levelname = Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token, levelname);
		Hirarchyname.add(levelname);

		String assetname = Assetname;
		assetid = apii.createAsset_api(token, levelid, assetname, "Machines", "Average");
		Assetids.add(assetid);
		entityname.add(assetname);

		// Task1 creation
		Taskids.clear();
		String TaskName = RandomStringUtils.random(10, true, true) + "Task";
		String limitname = "limit" + System.currentTimeMillis();
		String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid = RandomStringUtils.random(10, false, true) + "backendid";
		String category = RandomStringUtils.random(10, true, true) + "category";
		taskid = apii.createTask_api(token, assetid, TaskName, limitname, "Good", "2", saptag, dcstag, backendid,
				category);
		Taskids.add(taskid);
		taskname = TaskName;

		// Task1 creation
		String TaskName1 = RandomStringUtils.random(10, true, true) + "Task";
		String limitname1 = "limit" + System.currentTimeMillis();
		String saptag1 = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag1 = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid1 = RandomStringUtils.random(10, false, true) + "backendid";
		String category1 = RandomStringUtils.random(10, true, true) + "category";
		String taskid1 = apii.createTask_api(token, assetid, TaskName1, limitname1, "Good", "2", saptag1, dcstag1,
				backendid1, category1);
		Taskids.add(taskid1);
		taskname = TaskName;

		// Select level
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		common.waitForPageLoaded();
		levelname = Levelhirachyname;
		taskPage.selectlevelhirachy(levelname);
	}

	@When("^navigating to \"([^\"]*)\" limit section$")
	public void navigating_to_limit_section(String taskname2) throws Throwable {
		assetConfigurationPage.clickonAsset();
		common.waitForPageLoaded();
		taskPage.clickonTasks();
		taskPage.clickOnTaskEllipse();
		taskPage.clickOnRecordAction("Edit");
		taskPage.clickonNext();
	}
	@And("^creating valid low limit with condition \"([^\"]*)\"$")
	public void creating_valid_low_limit_with_condition(String taskname1) throws Throwable {
		taskPage.verifyLimitsSection();
		String limitname=readCsvFile("limitname", "ConditionalTaskTestData");
		String type=readCsvFile("type", "ConditionalTaskTestData");
		String predefinedvalue=readCsvFile("predefinedvalue", "ConditionalTaskTestData");
		String causevalue=readCsvFile("causevalue", "ConditionalTaskTestData");
		String conseq=readCsvFile("conseq", "ConditionalTaskTestData");
		String action=readCsvFile("action", "ConditionalTaskTestData");		
		taskPage.enterConditionalimitdetails(limitname, type,predefinedvalue , causevalue,conseq ,action, taskname1);
	}
	@And("^saving the changes$")
	public void saving_the_changes() throws Throwable {
		taskPage.verifytasksuccess();
	}

	@Then("^task is correctly created \"([^\"]*)\"$")
	public void task_is_correctly_created(String taskName) throws Throwable {
		taskname=taskName;
		taskPage.verifyTaskDetailsPage(taskname);
	}

	@And("^task details are displaying all changed limit data$")
	public void task_details_are_displaying_all_changed_limit_data() throws Throwable {
		taskPage.verifyConditionaTaskLimitsDetailsPage(taskname);
	}

	@And("^\"([^\"]*)\" has limit condition on \"([^\"]*)\"$")
	public void something_has_limit_condition_on(String taskname1, String taskname2) throws Throwable {
		assetConfigurationPage.clickonAsset();
		common.waitForPageLoaded();
		taskPage.searchTask(taskname1);
		taskPage.verifyTaskName(taskname1);
		taskPage.clickonTasks();
		taskPage.clickOnTaskEllipse();
		taskPage.clickOnRecordAction("Edit");
		taskPage.clickonNext();
		taskPage.verifyLimitsSection();
		String limitname=readCsvFile("limitname", "ConditionalTaskTestData");
		String type=readCsvFile("type", "ConditionalTaskTestData");
		String predefinedvalue=readCsvFile("predefinedvalue", "ConditionalTaskTestData");
		String causevalue=readCsvFile("causevalue", "ConditionalTaskTestData");
		String conseq=readCsvFile("conseq", "ConditionalTaskTestData");
		String action=readCsvFile("action", "ConditionalTaskTestData");	
		taskPage.enterConditionalimitdetails(limitname,type,predefinedvalue,causevalue,conseq,action, taskname2);
		taskPage.clickonBackArrowPointer();

	}
	@Then("^limit cannot be saved$")
    public void limit_cannot_be_saved() throws Throwable {
        taskPage.verifyLimitsSection();
    }
	@And("^\"([^\"]*)\" low limit has condition on \"([^\"]*)\"$")
    public void something_low_limit_has_condition_on(String taskname2, String taskname1) throws Throwable {
		assetConfigurationPage.clickonAsset();
		common.waitForPageLoaded();
		taskPage.searchTask(taskname2);
		taskPage.verifyTaskName(taskname2);
		taskPage.clickonTasks();
		taskPage.clickOnTaskEllipse();
		taskPage.clickOnRecordAction("Edit");
		taskPage.clickonNext();
    }
	@And("^editing created limit$")
    public void editing_created_limit() throws Throwable {
		taskPage.verifyLimitsSection();
		taskPage.clickonLimitEdit();
    }
	@And("^uncheck condition on \"([^\"]*)\"$")
    public void uncheck_condition_on(String taskname1) throws Throwable {
		taskPage.uncheckConditionalTask(taskname1);
    }

	

}
