package steps;

import io.cucumber.java.en.When;
import seleniumUtilities.BaseClass;


public class AssetsSteps extends BaseClass {
   
	@When("^create (\\d+) level tree hierarchy$")
	public void create_level_tree_hierarchy(int numberOfLevels) throws Throwable {
		assetPage.mouseOverOnEnterprise();
		homePage.clickOnEnterpriseThreeDots();	
		homePage.clickOnCreateLevel();
		homePage.enterLevelName("Level1");
		homePage.enterTimeZone("Asia/Kolkata");
		homePage.clickOnSubmit();
	}


}
