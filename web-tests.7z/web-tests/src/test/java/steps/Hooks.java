package steps;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import common.Apiutils.Api;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import pages.Movilizer.LoginPage;
import seleniumUtilities.BaseClass;
import seleniumUtilities.BaseRunner;

public class Hooks extends BaseRunner {

	@Before
	public void beforehook(Scenario scenario) {

		try {
			Launchbrowser(browser);
			setEnvironment(appEnvironment);
			System.out.println("SCENARIO Started ************* " + scenario.getName().toUpperCase());
			logintoApplication(userName, password);

		} catch (Throwable th) {
			LOG.error("Failed to launch the browser", th);
		}
	}

	/*
	 * public String getBase64Screenshot() throws IOException { String screenshotdir
	 * = System.getProperty("user.dir")+"/Cucumber/reports/screenshots/"; String
	 * Base64StringOfScreenshot=""; File src = ((TakesScreenshot)
	 * driver).getScreenshotAs(OutputType.FILE);
	 * 
	 * Date date = new Date(); SimpleDateFormat sdf = new
	 * SimpleDateFormat("ddMMYYYY_HHmmss"); String sDate = sdf.format(date);
	 * FileUtils.copyFile(src, new File(screenshotdir + "image_" + sDate + ".png"));
	 * 
	 * byte[] fileContent = FileUtils.readFileToByteArray(src);
	 * Base64StringOfScreenshot = "data:image/png;base64," +
	 * Base64.getEncoder().encodeToString(fileContent); return
	 * Base64StringOfScreenshot; }
	 */

	@After(order = 0)
	public void afterhook(Scenario scenario) throws Throwable {


		if (scenario.isFailed()) {

			// take screenshot:
			String screenshotName = scenario.getName().replaceAll(" ", "_");
			byte[] sourcePath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			scenario.attach(sourcePath, "image/png", screenshotName);
			// String imagepath = getBase64Screenshot();
			// ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(imagepath);
			// scenario.log("Scrrenshot attached");
		}
		System.out.println("SCENARIO End ********** " +  scenario.getName().toUpperCase());
		// close the browser
		driver.close();
	}
	@After(order = 1)
	public void teardown() throws Throwable {

		LoginPage login=new LoginPage();
		String token=login.getCookie();

		//New Implmenetation to delete entites
		Map<String,List<String>> entitymap=EntityIds(token);
//		deleteEntities("Roundtemplate",getlist(entitymap,"Roundtemplate"),token); 
		deleteEntities("Tasks",getlist(entitymap,"Tasks"),token);
		deleteEntities("SubAssets",getlist(entitymap,"SubAssets"),token);
		deleteEntities("Assets",getlist(entitymap,"Assets"),token);
		deleteEntities("AbstractAssets",getlist(entitymap,"AbstractAssets"),token);
		deleteEntities("Users",getlist(entitymap,"Users"),token);
		deleteEntities("Devices",getlist(entitymap,"Devices"),token);
		deleteEntities("SubLevelhirarchy",getlist(entitymap,"SubLevelhirarchy"),token);
		deleteEntities("Levelhirarchy",getlist(entitymap,"Levelhirarchy"),token);
		System.out.println("AfterHook **** executed");
	}

	/*
	System.out.println("Assets" + getlist(entitymap,"Assets"));
	System.out.println("SubAssets" + getlist(entitymap,"SubAssets"));
	System.out.println("Tasks" + getlist(entitymap,"Tasks"));
	System.out.println("Users" +getlist(entitymap,"Users"));
	System.out.println("Levelhirarchy" + getlist(entitymap,"Levelhirarchy"));
	System.out.println("AbstractAssets" + getlist(entitymap,"AbstractAssets"));
	System.out.println("Roundtemplate" + getlist(entitymap,"Roundtemplate"));
	System.out.println("Device" + getlist(entitymap,"Devices"));
	 */
	//old
	//deleteEntities("Roundtemplate",Roundtemplateids); 
	//delet formulas 
	//delet  limit 
	//delte attachment 
	//		deleteEntities("Task",BaseClass.Taskids); 
	//old  impementation to delete entities
	/*
		deleteEntities("SubAssets",BaseClass.SubAssetids);
		deleteEntities("Assets",BaseClass.Assetids);
	 */
	//		delete("SubAssets"); 
	//		delete("Assets");
	//		deleteEntities("AbstractAsset",BaseClass.AbstractAssetids);
	//		deleteEntities("Users",BaseClass.Userids);
	//		deleteEntities("Devices",BaseClass.Deviceids); 
	//delete issue 
	//deltee configuration
	//		deleteEntities("SubLevelhirarchy",BaseClass.SubLevelhirarchyids);
	//		deleteEntities("Levelhirarchy",BaseClass.name);



}