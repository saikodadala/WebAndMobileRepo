
package steps;


import common.reports.ConfigFileReadWrite;
import common.reports.ReporterConstants;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import seleniumUtilities.BaseClass;

import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;



public class DeviceSteps extends BaseClass {

	String levelid = "";
	String token = loginPage.getCookie();
	public String Levelhirachyname = "AB" + System.currentTimeMillis();
	public String emailId = "";
	public String devicenamen = "";
	public String devicename = "";
	public String deviceid = "";
	public String DeviceEmail = "email" + System.currentTimeMillis() + "@mail.com";
	public String DeviceName = "Device" + System.currentTimeMillis();
	public String devicetype = "";
	public String phonenum = "";
	public String sublevelID = "";
	public String sublevelname = "SB" + System.currentTimeMillis();
	public String levelIDcreated = "";
	public String LevelNameCreated = "";
	private By enterpriseLevel=By.xpath("//*[text()='Please select a level to view records']");


	@When("^select user level$")
	public void select_user_level() throws Throwable {
		templatePage.clickOnTemplateLevel1();
	}


	@Then("^portal user clicks on Add device button$")
	public void add_device_button() throws Throwable {
		devicePage.clickOnAddNewDeviceBtn();
	}

	@Then("^fill email as \"([^\"]*)\" and devicename as \"([^\"]*)\"$")
	public void i_enter_details_on_add_device_page_email_as_and_devicename_as(String email, String device) throws Throwable {
		emailId = email + RandomStringUtils.randomAlphanumeric(3).toLowerCase() + "@gmail.com";
		devicename = device + RandomStringUtils.randomAlphanumeric(3).toLowerCase();
		devicePage.enterDetails(emailId, devicename);
	}

	@When("^change devicetype as \"([^\"]*)\"$")
	@Then("^select devicetype as \"([^\"]*)\"$")
	public void i_select_devicetype_as(String arg1) throws Throwable {
		devicePage.chooseOption(arg1);
	}

	@And("^successful message is displayed$")
	public void i_verify_success_alert() throws Throwable {
		devicePage.verifySuccessAlert();
	}

	@Then("^portal user click on add new device button$")
	public void i_click_on_add_new_device_button() throws Throwable {
		devicePage.clickOnAddDeviceBtn();
	}

	@Then("^invalid error messages are displayed$")
	public void i_verify_error_message_for_both() throws Throwable {
		devicePage.verifybothinvalid();
	}

	@Then("^empty error messages are displayed$")
	public void i_verify_error_message_for_both_empty_values() throws Throwable {
		devicePage.verifybothemptyvalues();
	}

	@Then("^error message is displayed for invalid length of device as \"([^\"]*)\"$")
	public void i_verify_error_message_for_invalid_length_of_device_name_as(String arg1) throws Throwable {
		devicePage.verifyinvalidNameLength(arg1);
	}

	@Then("^error message is displayed for invalid length of email as \"([^\"]*)\"$")
	public void i_verify_error_message_for_invalid_length_of_email_as(String arg1) throws Throwable {
		devicePage.verifyinvalidEmailLength(arg1);
	}

	@Then("^error message is displayed as \"([^\"]*)\"$")
	public void i_verify_error_message_as(String arg1) throws Throwable {
		devicePage.verifylowerCaseEmail(arg1);
	}

	@When("^enter \"([^\"]*)\" in search devices$")
	public void i_enter_value_as_in_search_devices(String arg1) throws Throwable {
		devicePage.searchDevices(arg1);
	}

	@Then("^confirms the device deletion$")
	public void i_click_on_Delete_icon_of_the_device() throws Throwable {
		devicePage.clickOnDeleteIcon();
	}

	@And("^success message is displayed after deletion$")
	public void i_verify_delete_alert_message() throws Throwable {
		devicePage.verifyDeleteAlert();
	}

	@Then("^portal user click on Importlist$")
	public void i_click_on_Importlist_icon() throws Throwable {
		devicePage.clickOnImportlistIcon();
	}

	@Then("^the imported devices are downloaded$")
	public void i_click_on_Exportlist_icon() throws Throwable {
		devicePage.clickOnExportlistIcon();
	}

	@Then("^Importlist popup window is displayed$")
	public void i_verify_Importlist_popup_messages() throws Throwable {
		devicePage.verifyBrowserPopupmsg();
	}

	@Then("^portal user imports valid excel \"([^\"]*)\" file$")
	public void i_enter_value_as_in_textbox(String arg1) throws Throwable {
		devicePage.importFile(arg1);
	}

	@Then("^success pop up message is displayed$")
	public void i_verify_success_popup_messages() throws Throwable {
		devicePage.verifySuccessMsg();
	}

	@Then("^I click on edit icon$")
	public void i_click_on_edit_icon() throws Throwable {
		devicePage.clickOnEditIcon();
	}

	@Then("^click on confirm and submit button$")
	public void i_enter_details_of_the_device_to_edit() throws Throwable {
		devicePage.clickOnConfirmAndSubmit();
	}

	@Then("^I verify table row count with total count$")
	public void i_verify_table_row_count_with_total_count() throws Throwable {
		devicePage.verifyTablecount();
	}

	@Then("^created device \"([^\"]*)\" is displayed on tabular data$")
	public void verify_created_user_in_user_table(String devicenm) throws Throwable {
		devicePage.verifyDeviceName(devicename);
	}

	@Then("^updated device \"([^\"]*)\" is displayed on tabular data$")
	public void verify_updated_user_in_user_table(String devicetype) throws Throwable {
		devicePage.verifyDeviceType(devicetype);
	}

	@When("^portal user clicks on created device \"([^\"]*)\"$")
	public void open_created_device(String action) throws Throwable {
		users.clickOnThreeDots(action);
		users.clickOnRecordAction(action);
	}

	@Then("^deleted device is not displayed on device table$")
	public void deleted_device_is_not_displayed_on_device_table() throws Throwable {
		devicePage.verifyDeviceTable();
	}

	@Then("^site level is created and selected$")
	public void site_level_is_created_and_selected() throws Throwable {
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		levelid = apii.createLevelhirarchy_api(token, Levelhirachyname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		driver.switchTo().defaultContent();
		common.waitForPageLoaded();
		By mainFrame = By.cssSelector("[class='gwt-Frame']");
		switchToFrame(mainFrame);
		devicePage.selectlevelhirarchy_device(Levelhirachyname);
	}

	@When("^empty message for Devices \"([^\"]*)\" is displayed$")
	public void empty_device_message(String error) throws Throwable {
		devicePage.verifyEmptyDevices(error);
	}

	@Then("^Device configuration header is displayed$")
	public void device_configurationHeader() throws Throwable {
		devicePage.verifyDeviceHeader();
	}

	@Then("^the factory image for no devices is displayed$")
	public void i_verify_the_factory_image_for_no_devices() throws Throwable {
		devicePage.verifyImg();
	}

	@Then("^level name is displayed on breadcrumb$")
	public void levelname_on_breadcrumb() throws Throwable {
		devicePage.verifyBreadcrumb(Levelhirachyname);
	}

	@Then("^UI labels are displayed on device configuration page$")
	public void uiLabel_devicepage() throws Throwable {
		devicePage.verifyUIlabels();
	}

	@Then("^Failed dialog box is displayed$")
	public void failed_popup_messages() throws Throwable {
		devicePage.verifyFailedMsg();
	}

	@Then("^errors are downloaded$")
	public void i_click_on_DownloadErrors() throws Throwable {
		devicePage.clickOnDownloadErrors();
	}

	@Then("^site level is created$")
	public void site_level_is_created() throws Throwable {
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		levelid = apii.createLevelhirarchy_api(token, Levelhirachyname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();//This wait time is to refresh the page after the api creation
		driver.switchTo().defaultContent();
		common.waitForPageLoaded();
		By mainFrame = By.cssSelector("[class='gwt-Frame']");
		switchToFrame(mainFrame);
	}

	@Then("^site level is selected$")
	public void site_level_is_selected() throws Throwable {
		devicePage.selectlevelhirarchy_device(Levelhirachyname);
	}

	@Then("^Device configuration header is not displayed$")
	public void noDevice_configurationHeader() throws Throwable {
		devicePage.verifyNoDeviceHeader();
	}

	@When("^Enterprise message \"([^\"]*)\" is displayed$")
	public void enterprise_device_message(String error) throws Throwable {
		devicePage.selectEnterpriseDevices(error);
	}

	@When("^create (\\d+) set of devices with api$")
	public void create_Devices_with_api(int nooftimes) throws Throwable {
		Deviceids.clear();
		for (int i = 0; i < nooftimes; i++) {
			//Thread.sleep(1500);
			deviceid = apii.createDevice_api(token, levelid, DeviceName + getRandomString(2), DeviceEmail + getRandomString(2), "phone");
			Deviceids.add(deviceid);
			deviceid = apii.createDevice_api(token, levelid, DeviceName + getRandomString(2), DeviceEmail + getRandomString(2), "tablet");
			Deviceids.add(deviceid);
			deviceid = apii.createDevice_api(token, levelid, DeviceName + getRandomString(2), DeviceEmail + getRandomString(2), "iw");
			Deviceids.add(deviceid);
		}

	}

	@When("^displayed records with filtered option$")
	public void validate_devicetype_filter() throws Throwable {
		devicePage.ValidateFilterTypes(devicetype);
	}

	@When("^create device \"([^\"]*)\" with api$")
	public void create_device_with_api(String devicename) throws Throwable {
		Deviceids.clear();
		devicename = DeviceName;
		deviceid = apii.createDevice_api(token, levelid, devicename, DeviceEmail, "phone");
		Deviceids.add(deviceid);
	}

	@Then("^fill invalid details email as \"([^\"]*)\" and devicename as \"([^\"]*)\"$")
	public void invalid_details_on_add_device_page_email_as_and_devicename_as(String email, String device) throws Throwable {
		devicePage.enterDetails(email, device);
	}

	@When("^select device type as \"([^\"]*)\"$")
	public void select_devicetype(String choosedevicetype) throws Throwable {
		devicePage.selectDeviceType(choosedevicetype);
		devicetype = choosedevicetype;
	}

	@When("^click on device type dropdown$")
	public void devicetype_dropdown() throws Throwable {
		devicePage.clickdevicetypeDropdown();
	}

	@Then("^pagination on devices page$")
	public void pagination_on_devicess_page() throws Throwable {
		devicePage.Verify_Pagination_Devices();
	}

	@Then("^fill invalid details : email as \"([^\"]*)\" and devicename as \"([^\"]*)\"$")
	public void fill_invaliddetails_on_add_device_page_email_as_and_devicename_as(String email, String device) throws Throwable {
		devicePage.enterDetails(email, device);
	}

	@Then("^error message for invalid phone number is displayed as \"([^\"]*)\"$")
	public void i_verify_invalidphoneerror_message_as(String arg1) throws Throwable {
		devicePage.verifyInvalidPhonenumber(arg1);
	}

	@Then("^fill invalid details : phonenumber as \"([^\"]*)\" and devicename as \"([^\"]*)\"$")
	public void fill_invalidphonenum_on_add_device_page_email_as_and_devicename_as(String phn, String device) throws Throwable {
		phn = phn + System.currentTimeMillis();
		devicePage.enterDetails(phn, device);
	}


	@Then("^A new level is created$")
	public void A_new_level_is_created() throws Throwable {
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		levelid = apii.createLevelhirarchy_api(token, Levelhirachyname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		common.waitForPageLoaded();

	}


	@Given("I go ahead to create {int} set of Sub-levels with api")
	public void i_go_ahead_to_create_set_of_sub_levels_with_api(Integer noOfTimes) throws Throwable {

		for (int i = 1; i <= noOfTimes; i++) {
			if (i == 1) {
				sublevelID = apii.createSublevel_api(token, sublevelname, levelid);
				Levelhirarchyids.add(sublevelID);
			} else {
				sublevelID = apii.createSublevel_api(token, sublevelname, sublevelID);
				System.out.println(sublevelID);
			}

		}

	}



	@Given("I create {int} devices {string} {string} {string} at each level, sublevel, verify them")
	public void i_create_devices_at_each_level_sublevel_verify_them(Integer noOfTimes, String email, String devicename, String devicetype) throws Throwable {
		for (int i = 1; i <=noOfTimes ; i++) {
			if (i == 1) {

				driver.switchTo().defaultContent();
				By mainFrame = By.cssSelector("[class='gwt-Frame']");
				switchToFrame(mainFrame);
				waitforPresenceofElement(enterpriseLevel, "Enterprise level message", 10);
				waitForPageLoaded();
				By selectlevlhirarchy = By.xpath("//div[text()='" + Levelhirachyname + "']");
				List<WebElement> list = driver.findElements(By.cssSelector("[class='loader-content'] [class='content']"));
				for(int j=0;j<list.size();j++){
					if(isElementPresent(selectlevlhirarchy, "Level")){
						setFocusAndClick(selectlevlhirarchy, "Select levelhirarchyfrom round template");
						break;
					}else{
						((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",list.get(i));
					}
				}


				homePage.clickOnManageDevices();
				homePage.activeItem();
				devicePage.clickOnAddNewDeviceBtn();
				emailId = email + RandomStringUtils.randomAlphanumeric(3).toLowerCase() + "@gmail.com";
				devicenamen = devicename + RandomStringUtils.randomAlphanumeric(3).toLowerCase();
				devicePage.enterDetails(emailId, devicenamen);
				devicePage.chooseOption(devicetype);
				devicePage.clickOnAddDeviceBtn();
				devicePage.verifySuccessAlert();
				waitForPageLoaded();
				By Sublevel = By.xpath("(//*[contains(text(),'SB')])[1]");
				waitForVisibilityOfElement(Sublevel,"SubLevel",15);
				click(Sublevel, "levelid");


			}
			else {
				waitForPageLoaded();
				homePage.activeItem();
				devicePage.clickOnAddNewDeviceBtn();
				emailId = email + RandomStringUtils.randomAlphanumeric(3).toLowerCase() + "@gmail.com";
				devicenamen = devicename + RandomStringUtils.randomAlphanumeric(3).toLowerCase();
				devicePage.enterDetails(emailId, devicenamen);
				devicePage.chooseOption(devicetype);
				devicePage.clickOnAddDeviceBtn();
				devicePage.verifySuccessAlert();
				By Sublevel = By.xpath("(//*[contains(text(),'SB')])[2]");
				waitForVisibilityOfElement(Sublevel,"SubLevel",15);
				click(Sublevel, "levelid");

			}



		}


	}


	@Given("I create, edit {int} devices {string} {string} {string} {string} at each level, sublevel, verify them")
	public void i_create_edit_devices_at_each_level_sublevel_verify_them(Integer noOfTimes, String email, String devicename, String devicetype, String newdevicetype) throws Throwable {
		for (int i = 1; i <=noOfTimes ; i++) {
			if (i == 1) {

				driver.switchTo().defaultContent();
				By mainFrame = By.cssSelector("[class='gwt-Frame']");
				switchToFrame(mainFrame);
				waitforPresenceofElement(enterpriseLevel, "Enterprise level message", 10);
				waitForPageLoaded();
				By selectlevlhirarchy = By.xpath("//div[text()='" + Levelhirachyname + "']");
				List<WebElement> list = driver.findElements(By.cssSelector("[class='loader-content'] [class='content']"));
				for(int j=0;j<list.size();j++){
					if(isElementPresent(selectlevlhirarchy, "Level")){
						setFocusAndClick(selectlevlhirarchy, "Select levelhirarchyfrom round template");
						break;
					}else{
						((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",list.get(i));
					}
				}


				homePage.clickOnManageDevices();
				homePage.activeItem();
				devicePage.clickOnAddNewDeviceBtn();
				emailId = email + RandomStringUtils.randomAlphanumeric(3).toLowerCase() + "@gmail.com";
				devicenamen = devicename + RandomStringUtils.randomAlphanumeric(3).toLowerCase();
				devicePage.enterDetails(emailId, devicenamen);
				devicePage.chooseOption(devicetype);
				devicePage.clickOnAddDeviceBtn();
				devicePage.verifySuccessAlert();

				By loadingIcon=By.cssSelector("[class='ui loader-wrap loading-alignments loading']");
				waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
				By locator=By.cssSelector("[class='popup-pointer']");
				waitForVisibilityOfElement(locator, "Three Dots",15);
				List<WebElement> elems=driver.findElements(locator);
				elems.get(0).click();
				By editAction = By.xpath("//*[text()='Edit']");
				waitForVisibilityOfElement(editAction, "Edit", 15);
				click(editAction, "Edit");
				devicePage.chooseOption(newdevicetype);
				devicePage.clickOnConfirmAndSubmit();
				devicePage.verifySuccessAlert();
				devicePage.verifyDeviceType(newdevicetype);
				waitForPageLoaded();
				By Sublevel = By.xpath("(//*[contains(text(),'SB')])[1]");
				waitForVisibilityOfElement(Sublevel,"SubLevel",15);
				click(Sublevel, "levelid");


			}
			else {
				waitForPageLoaded();
				homePage.activeItem();
				devicePage.clickOnAddNewDeviceBtn();
				emailId = email + RandomStringUtils.randomAlphanumeric(3).toLowerCase() + "@gmail.com";
				devicenamen = devicename + RandomStringUtils.randomAlphanumeric(3).toLowerCase();
				devicePage.enterDetails(emailId, devicenamen);
				devicePage.chooseOption(devicetype);
				devicePage.clickOnAddDeviceBtn();
				devicePage.verifySuccessAlert();

				By loadingIcon=By.cssSelector("[class='ui loader-wrap loading-alignments loading']");
				waitForInVisibilityOfElement(loadingIcon, "Waiting for invisibility of Loader", 10);
				By locator=By.cssSelector("[class='popup-pointer']");
				waitForVisibilityOfElement(locator, "Three Dots",15);
				List<WebElement> elems=driver.findElements(locator);
				elems.get(0).click();
				By editAction = By.xpath("//*[text()='Edit']");
				waitForVisibilityOfElement(editAction, "Edit", 15);
				click(editAction, "Edit");
				devicePage.chooseOption(newdevicetype);
				devicePage.clickOnConfirmAndSubmit();
				devicePage.verifySuccessAlert();
				devicePage.verifyDeviceType(newdevicetype);
				By Sublevel = By.xpath("(//*[contains(text(),'SB')])[2]");
				waitForVisibilityOfElement(Sublevel,"SubLevel",15);
				click(Sublevel, "levelid");
				//System.out.println("ADARSHHHHH"+i);

			}



		}


	}


	@Given("I create,delete {int} devices {string} {string} {string} {string} at each level, sublevel, verify them")
	public void i_create_delete_devices_at_each_level_sublevel_verify_them(Integer noOfTimes, String email, String devicename, String devicetype, String action) throws Throwable {
		for (int i = 1; i <=noOfTimes ; i++) {
			if (i == 1) {

				driver.switchTo().defaultContent();
				By mainFrame = By.cssSelector("[class='gwt-Frame']");
				switchToFrame(mainFrame);
				waitforPresenceofElement(enterpriseLevel, "Enterprise level message", 10);
				waitForPageLoaded();
				By selectlevlhirarchy = By.xpath("//div[text()='" + Levelhirachyname + "']");
				List<WebElement> list = driver.findElements(By.cssSelector("[class='loader-content'] [class='content']"));
				for(int j=0;j<list.size();j++){
					if(isElementPresent(selectlevlhirarchy, "Level")){
						setFocusAndClick(selectlevlhirarchy, "Select levelhirarchyfrom round template");
						break;
					}else{
						((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",list.get(i));
					}
				}


				homePage.clickOnManageDevices();
				homePage.activeItem();
				devicePage.clickOnAddNewDeviceBtn();
				emailId = email + RandomStringUtils.randomAlphanumeric(3).toLowerCase() + "@gmail.com";
				devicenamen = devicename + RandomStringUtils.randomAlphanumeric(3).toLowerCase();
				devicePage.enterDetails(emailId, devicenamen);
				devicePage.chooseOption(devicetype);
				devicePage.clickOnAddDeviceBtn();
				devicePage.verifySuccessAlert();
				waitForPageLoaded();


				users.clickOnThreeDots(action);
				users.clickOnRecordAction(action);
				devicePage.clickOnDeleteIcon();
				devicePage.verifyDeleteAlert();
				devicePage.verifyDeviceTable();
				waitForPageLoaded();




				By Sublevel = By.xpath("(//*[contains(text(),'SB')])[1]");
				waitForVisibilityOfElement(Sublevel,"SubLevel",15);
				click(Sublevel, "levelid");


			}
			else {
				waitForPageLoaded();
				homePage.activeItem();
				devicePage.clickOnAddNewDeviceBtn();
				emailId = email + RandomStringUtils.randomAlphanumeric(3).toLowerCase() + "@gmail.com";
				devicenamen = devicename + RandomStringUtils.randomAlphanumeric(3).toLowerCase();
				devicePage.enterDetails(emailId, devicenamen);
				devicePage.chooseOption(devicetype);
				devicePage.clickOnAddDeviceBtn();
				devicePage.verifySuccessAlert();

				users.clickOnThreeDots(action);
				users.clickOnRecordAction(action);
				devicePage.clickOnDeleteIcon();
				devicePage.verifyDeleteAlert();
				devicePage.verifyDeviceTable();
				waitForPageLoaded();

				By Sublevel = By.xpath("(//*[contains(text(),'SB')])[2]");
				waitForVisibilityOfElement(Sublevel,"SubLevel",15);
				click(Sublevel, "levelid");

			}



		}


	}












}