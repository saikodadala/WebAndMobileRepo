package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import seleniumUtilities.BaseClass;

public class ConfigurationSteps extends BaseClass {

	public String Levelhirachyname = "AddLevelhirachy" + System.currentTimeMillis();
	String token = loginPage.getCookie();
	public String criticality = "";
	public String associatedEmail = "";
	public String levelid = "";

	@When("admin user navigates to Enterprise level Rounds Configuration section")
	public void admin_user_navigates_to_enterprise_level_rounds_configuration_section() throws Throwable {

		configPage.Clickonconfiguration();

	}

	@Then("dropdown for selection scheduling days from {int} to {int} is available")
	public void dropdown_for_selection_scheduling_days_from_to_is_available(Integer int1, Integer int2)
			throws Throwable {

		configPage.clickonrounds();
		configPage.ScheduleRounds();
		configPage.clickonnofofdays_dropdown();
		configPage.noofdays();
	}

	@Then("user can successfully change scheduling days to any value between {int} to {int}")
	public void user_can_successfully_change_scheduling_days_to_any_value_between_to(Integer int1, Integer int2)
			throws Throwable {

		configPage.selectoption();
		configPage.successmessage();
	}

	@Given("levelhirarchy {string} is created")
	public void levelhirarchy_is_created(String levelname) throws Throwable {

		// Hirarchyname.clear();
		// levelname = Levelhirachyname;
		// apii.createLevelhirarchy_api(token,levelname);
		// Hirarchyname.add(levelname);
	}

	@When("admin user is on Configuration section")
	public void admin_user_is_on_configuration_section() throws Throwable {

		configPage.selectlevelhirachy("AddLevelhirachy1625210686982");
		configPage.Clickonconfiguration();

	}

	@Then("Round Scheduling days configuration under Rounds section is available on Enterprise level")
	public void round_scheduling_days_configuration_under_rounds_section_is_available_on_enterprise_level()
			throws Throwable {

		configPage.clickonrounds();
		configPage.Scheduledays_isVisible();

	}

	@Then("not available on hierarchy level")
	public void not_available_on_hierarchy_level() throws Throwable {
		configPage.navigateto_EnterpriseLevel();
		configPage.clickonrounds();
		configPage.ScheduledaysisVisible();

	}

	@Given("^task configuration is enabled at enterprise level$")
	public void task_configuration_is_enabled_at_enterprise_level() throws Throwable {
		common.selectSideMenuOption("Configuration");
		common.clickOnTasksAndAssetsOption();
	}

	@When("^admin user navigates to Enterprise level Tasks and Assets section of Configuration section$")
	public void admin_user_navigates_to_enterprise_level_tasks_and_assets_section_of_configuration_section()
			throws Throwable {
		configPage.clickTaskConfiguarationStatus();
	}

	@And("^creates Task criticality \"([^\"]*)\"$")
	public void creates_task_criticality_something(String strArg1) throws Throwable {
		configPage.clickOnTaskConfiguarationExpand();
		configPage.clickOnAddTaskCriticality();
		criticality = strArg1 + generateRandomNumber(3);
		configPage.enterTaskCriticality(criticality);
		configPage.clickOnSaveTaskCriticality();
	}

	@Then("^task criticality is successfully created and displayed in Task configuration section$")
	public void task_criticality_is_successfully_created_and_displayed_in_task_configuration_section()
			throws Throwable {
		configPage.verifyTaskCriticalityCreated(criticality);
	}

	@And("^task criticality is created$")
	public void task_criticality_is_created() throws Throwable {
		// Need to api call to create task criticality
		configPage.clickOnTaskConfiguarationExpand();
		configPage.clickOnAddTaskCriticality();
		criticality = "high" + generateRandomNumber(3);
		configPage.enterTaskCriticality(criticality);
		configPage.clickOnSaveTaskCriticality();
	}

	@And("^edits Task criticality$")
	public void edits_task_criticality() throws Throwable {
		configPage.editTaskCriticality(criticality);
		criticality = "high" + generateRandomNumber(3);
		configPage.enterTaskCriticality(criticality);
		configPage.clickOnSaveTaskCriticality();
	}

	@Then("^task criticality is successfully updated and displayed in Task configuration section$")
	public void task_criticality_is_successfully_updated_and_displayed_in_task_configuration_section()
			throws Throwable {
		configPage.verifyTaskCriticalityCreated(criticality);
	}

	@And("^deletes Task criticality$")
	public void deletes_task_criticality() throws Throwable {
		configPage.deleteTaskCriticality(criticality);
	}

	@Then("^task criticality deletion is successful$")
	public void task_criticality_deletion_is_successful() throws Throwable {
		configPage.verifyTaskCriticalityDeleted(criticality);
	}

	@And("^adds email association to the created task criticality$")
	public void adds_email_association_to_the_created_task_criticality() throws Throwable {
		associatedEmail = "TaskAssociatedemail" + generateRandomNumber(3) + "@gmail.com";
		configPage.editAssociatedEmailsTaskCriticality();
		configPage.enterAssociatedEmailsTaskCriticality(associatedEmail);
		configPage.saveAssociatedEmailsTaskCriticality();
	}

	@Then("^task configuration is successful saved$")
	public void task_configuration_is_successful_saved() throws Throwable {
		configPage.verifyTaskCriticalityAssociatedEmail(associatedEmail);
	}

	@Given("^a level is created$")
	public void a_level_is_created() throws Throwable {
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		String levelname = Levelhirachyname;
		levelid = apii.createLevelhirarchy_api(token, levelname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		common.waitForPageLoaded();
	}

	@And("^clicks on the Task Configuration toggle button$")
	public void clicks_on_the_task_configuration_toggle_button() throws Throwable {
		configPage.clickTaskConfiguarationStatus();
	}

	@Then("^status is switched successfully on Enterprise level$")
	public void status_is_switched_successfully_on_enterprise_level() throws Throwable {
		configPage.verifyUserAtEnterpriseLevel();
	}

	@And("^adds valid emails to criticality in Email setup section$")
	public void adds_valid_emails_to_criticality_in_email_setup_section() throws Throwable {
		associatedEmail = "TaskAssociatedemail" + generateRandomNumber(3) + "@gmail.com";
		configPage.editAssociatedEmailsTaskCriticality();
		configPage.enterAssociatedEmailsTaskCriticality(associatedEmail);
		configPage.saveAssociatedEmailsTaskCriticality();
	}

	@Then("^task email setup is saved successfully$")
	public void task_email_setup_is_saved_successfully() throws Throwable {
		configPage.verifyTaskCriticalityAssociatedEmail(associatedEmail);
	}

	@When("^admin users deletes valid email$")
	public void admin_users_deletes_valid_email() throws Throwable {		
		configPage.deleteTasksAssociatedMail(associatedEmail);		
	}

	@And("^adds invalid emails to criticality in Email setup section$")
	public void adds_invalid_emails_to_criticality_in_email_setup_section() throws Throwable {
		associatedEmail = "email@$@#@#$@#$" + generateRandomNumber(3) + "@gmail.com";
		configPage.editAssociatedEmailsTaskCriticality();
		configPage.enterAssociatedEmailsTaskCriticality(associatedEmail);
		configPage.saveAssociatedEmailsTaskCriticality();
	}

	@Then("^invalid email gets cleared automatically$")
	public void invalid_email_gets_cleared_automatically() throws Throwable {
		configPage.verifyTaskCriticalityAssociatedEmail(associatedEmail);
	}
}
