package steps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import seleniumUtilities.BaseClass;

public class TemplateSteps extends BaseClass {

	public String Levelhirachyname = "AddLevelhirachy" + System.currentTimeMillis();
	public String Updatelevelhirachyname = "LevelhirachyUpdate" + System.currentTimeMillis();
	public String Sublevelname = "Sublevel" + System.currentTimeMillis();
	public String Updatesublevelname = "SublevelUpdate" + System.currentTimeMillis();

	public String Assetname = "Asset" + System.currentTimeMillis();
	public String UpdateAssetname = "UpdateAsset" + System.currentTimeMillis();
	public String Subassetname = "SubAsset" + System.currentTimeMillis();
	public String UpdateSubassetname = "UpdateSubAsset" + System.currentTimeMillis();
	public String Taskname = "AddTask" + System.currentTimeMillis();
	public String Roundetemplatname = "Roundtemplate" + System.currentTimeMillis();
	public String Limitname = "Limit" + System.currentTimeMillis();
	public String advancedRoundTemplateName="AdvRoundtemplate" + System.currentTimeMillis();
	
	String levelid = "";
	String assetid = "";
	String subassetid = "";
	String sublevelid = "";
	String taskid = "";
	String roundtemplateid = "";
	String token = loginPage.getCookie();
	String masterkeyValue = "";
	private By mainFrame = By.cssSelector("[class='gwt-Frame']");

	List<String> ids = new ArrayList<String>();
	List<String> entityname = new ArrayList<String>();

	@When("^click on round template level(\\d+)$")
	public void click_on_round_template_level(int arg1) throws Throwable {
		templatePage.clickOnTemplateLevel1();
		templatePage.clickOnRoundTemplateButton();
		templatePage.clickOnLevel2();
		templatePage.clickOnLevel3();
		templatePage.clickOnLevel4();
		templatePage.clickOnNextButton();
		templatePage.selectAsset();
		templatePage.clickOnNextButton();
		templatePage.selectTask();
		templatePage.clickOnNextButton();
		templatePage.enterRoundTemplateName();
		templatePage.enterGracePeroid();
		templatePage.clickOnCreateButton();
	}

	@When("^create Level hirarchy \"([^\"]*)\" with api$")
	public void create_Level_hirarchy_with_api(String levelname) throws Throwable {
		Levelhirarchyids.clear();
		levelname = Levelhirachyname;
		Hirarchyname.clear();
		Hirarchyname.add(Levelhirachyname);
		levelid = apii.createLevelhirarchy_api(token, levelname);
		Levelhirarchyids.add(levelid);
	}

	@When("^create Sublevel hirarchy \"([^\"]*)\" with api$")
	public void create_Sublevel_hirarchy_with_api(String sublevel) throws Throwable {
		sublevel = Sublevelname;
		Levelhirarchyids.clear();
		sublevelid = apii.createSublevel_api(token, sublevel, levelid);
		levelid = sublevelid;
		Levelhirarchyids.add(levelid);
	}

	@When("^create Sublevel \"([^\"]*)\" with api$")
	public void create_Sublevel_with_api(String sublevel) throws Throwable {
		sublevel = Sublevelname;
		sublevelid = apii.createSublevel_api(token, sublevel, levelid);
	}

	//
	@When("^create Assets \"([^\"]*)\" Subassets \"([^\"]*)\" with api$")
	public void create_Assets_Subassets_with_api(String assetname, String subassetname) throws Throwable {
		assetname = Assetname;
		subassetname = Subassetname;
		assetid = apii.createAsset_api(token, levelid, assetname, "Machines", "Good");
		subassetid = apii.createSubAsset_api(token, assetid, subassetname, "Boilers", "Good");
		Assetids.add(assetid);
		entityname.add(assetname);
		SubAssetids.add(subassetid);
		entityname.add(subassetname);
	}

	@When("^create Assets \"([^\"]*)\" with api$")
	public void create_Assets_with_api(String assetname) throws Throwable {
		assetname = Assetname;
		assetid = apii.createAsset_api(token, levelid, assetname, "Machines", "Good");
	}

	@When("^create Subassets \"([^\"]*)\" with api$")
	public void create_Subassets_with_api(String subassetname) throws Throwable {
		subassetname = Subassetname;
		subassetid = apii.createSubAsset_api(token, assetid, subassetname, "Machines", "Good");
	}

	//
	@When("^create Task for asset \"([^\"]*)\" with api$")
	public void create_Task_for_asset_with_api(String taskname) throws Throwable {
		String poistion = "2";
		String assetmode = "Good";
		String taskname1 = Taskname;
		String limitname = "limit" + System.currentTimeMillis();
		String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid = RandomStringUtils.random(10, false, true) + "backendid";
		String category = RandomStringUtils.random(10, true, true) + "category";
		taskid = apii.createTask_api(token, assetid, taskname1, limitname, assetmode, poistion, saptag, dcstag,
				backendid, category);
		Taskids.add(taskid);
		entityname.add(taskname1);
	}

	@When("^create Task for subasset \"([^\"]*)\" with api$")
	public void create_Task_for_subasset_with_api(String taskname) throws Throwable {
		String poistion = "2";
		String assetmode = "Good";
		taskname = Taskname;
		String limitname = "limit" + System.currentTimeMillis();
		String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid = RandomStringUtils.random(10, false, true) + "backendid";
		String category = RandomStringUtils.random(10, true, true) + "category";
		taskid = apii.createTask_api(token, assetid, taskname, limitname, assetmode, poistion, saptag, dcstag,
				backendid, category);
		Taskids.add(taskid);
		entityname.add(taskname);
	}

	@When("^Delete Sublevel \"([^\"]*)\" with api$")
	public void delete_Sublevel_with_api() throws Throwable {
		apii.DeleteLevelhirarchy_api(token, sublevelid);
	}

	@When("^Delete Task,Subassets,Asset,Levelhirarchy with api$")
	public void delete_Task_Subassets_Asset_Levelhirarchy_with_api() throws Throwable {
		apii.DeleteTask_api(token, taskid);
		apii.DeleteAsset_api(token, subassetid);
		apii.DeleteAsset_api(token, assetid);
		apii.DeleteLevelhirarchy_api(token, levelid);
	}

	@When("^delete Levelhirachy with api$")
	public void delete_Levelhirachy_with_api() throws Throwable {
		apii.DeleteLevelhirarchy_api(token, levelid);

	}

	@Then("^message is displayed \"([^\"]*)\"if no level has been selected to create round template$")
	public void message_is_displayeif_no_level_has_been_selected_to_create_round_template(String expectedmsg)
			throws Throwable {
		templatePage.verifymsg_iflevelnotselected(expectedmsg);

	}

	@When("^select Level hirarchy \"([^\"]*)\" from Round template$")
	public void select_Level_hirarchy_from_Round_template(String levelhirarchy) throws Throwable {
		levelhirarchy = Levelhirachyname;
		templatePage.selectlevelhirarchy_Rountemplate(levelhirarchy);
	}

	@Then("^messsage is displayed \"([^\"]*)\"$")
	public void message_is_displayed(String expectedtext) throws Throwable {
		templatePage.verify_msg_No_templateaddedyet(expectedtext);
	}

	@Then("^header is displayed \"([^\"]*)\"$")
	public void header_is_displayed(String expectedheadrname) throws Throwable {
		templatePage.verify_header(expectedheadrname);
	}

	@Then("^bread crumb is displayed \"([^\"]*)\"$")
	public void bread_crumb_is_displayed(String levelname) throws Throwable {
		levelname = Levelhirachyname;
		templatePage.verify_breadcrumb(levelname);
	}

	@Then("^add round template button is enabled$")
	public void add_round_template_button_is_enabled() throws Throwable {
		templatePage.verify_Addroundtemplate_Displayed();
	}

	@Then("^check add round template button count$")
	public void check_add_round_template_button_count() throws Throwable {
		templatePage.verify_Addroundtemplate_Count();
	}

	@When("^click on Add Round template$")
	public void click_on_Add_Round_template() throws Throwable {
		templatePage.clickon_Addroundtemplate();
	}

	@When("^click on \"([^\"]*)\"$")
	public void click_on_(String roundTemplate) throws Throwable {
		templatePage.clickon_roundtemplate();
	}

	@Then("^level hierarchy is: \"([^\"]*)\"$")
	public void level_hierarchy_is(String levelname) throws Throwable {
		levelname = Levelhirachyname;
		templatePage.levelhirarchy_isDispalyed(levelname);
	}

	@When("^click on Next$")
	public void click_on_Next() throws Throwable {
		templatePage.clickOnNextButton();
	}

	@Then("^asset is:\"([^\"]*)\" created for levels selected$")
	public void asset_is_created_for_levels_selected(String assetname) throws Throwable {
		assetname = Assetname;
		templatePage.assets_isDispalyed(assetname);

	}

	@When("^click on checkbox,Add selected$")
	public void click_on_checkbox_Add_selected() throws Throwable {
		templatePage.clickbox();
		templatePage.clickonAddselected();
	}

	@Then("^task is:\"([^\"]*)\" created for asset$")
	public void task_is_created_for_asset(String task_name) throws Throwable {
		templatePage.handlePopAlertContinue();
		task_name = Taskname;
		templatePage.assets_isDispalyed(task_name);

	}

	@When("^enter Round template name \"([^\"]*)\"$")
	public void enter_Round_template_name(String roundtemplatename) throws Throwable {
		roundtemplatename = Roundetemplatname;
		waitForPageLoaded();
		templatePage.Enter_Roundtemplate(roundtemplatename);
		entityname.add(roundtemplatename);
	}

	@When("^enter Grace period value \"([^\"]*)\"$")
	public void enter_Grace_period_value(String graceperiodvalue) throws Throwable {
		templatePage.Enter_Graceperiod(graceperiodvalue);
	}

	@When("^click on create$")
	public void click_on_create() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		templatePage.clickOnCreateButton();
	}

	@Then("^round template \"([^\"]*)\" is created successfully$")
	public void round_template_is_created_successfully(String roundtemplatename) throws Throwable {
		roundtemplatename = Roundetemplatname;
		templatePage.verify_Roundtemplatecreated(roundtemplatename);
	}

	@Then("^select all available levels at step(\\d+)$")
	public void select_all_available_levels_at_step(int arg1) throws Throwable {
		templatePage.levelSelection("AVAILABLE LEVELS");
		templatePage.levelSelection("AVAILABLE SUB LEVELS - 1");
	}

	@Then("^verify active menu padding containers \"([^\"]*)\"$")
	public void verify_active_menu_padding_containers(String step) throws Throwable {
		templatePage.verifyCurrentActivePadding(step);
	}

	@Then("^verify header message$")
	public void verify_header_message() throws Throwable {
		String headerMessage = "Pick & Choose assets or sub assets from";
		templatePage.verifyHeaderMessage(headerMessage);
	}

	@Then("^verify \"([^\"]*)\" table is available$")
	public void verify_table_is_available(String table) throws Throwable {
		templatePage.tableAvailabity(table);
	}

	@Then("^if no records available \"([^\"]*)\" table$")
	public void if_no_records_available_table(String message) throws Throwable {
		templatePage.noRecordsAvailableInTable(message);
	}

	@Then("^back button displayed$")
	public void back_button_displayed() throws Throwable {
		templatePage.verifyIsBackButtonAvailable();
	}

	@When("^search assets$")
	public void search_assets() throws Throwable {
		templatePage.enterAssetNameInSearchBox();
	}

	@Then("^verify available assets displayed in the table$")
	public void verify_available_assets_displayed_in_the_table() throws Throwable {
		templatePage.verifyRecordsDisplayedInTheTable("");
	}

	@Then("^filter count is displayed$")
	public void filter_count_is_displayed() throws Throwable {
		templatePage.verifyFilterCount();
	}

	@Then("^Clear search assets textbox$")
	public void clear_search_assets_textbox() throws Throwable {
		templatePage.clearAssetSearchBox();
	}

	@When("^select all columns$")
	public void select_all_columns() throws Throwable {

		templatePage.selectAllColumns("Asset Mode");
		templatePage.selectAllColumns("Criticality");
		templatePage.selectAllColumns("Level Name");
	}

	@When("^click on filter icon$")
	public void click_on_filter_icon() throws Throwable {

		templatePage.clickOnFilterIcon();
	}

	@Then("^displayed records with filtered \"([^\"]*)\"$")
	public void displayed_records_with_filtered(String arg1) throws Throwable {
		templatePage.verifyRecordsDisplayedInTheTable(arg1);
	}

	@Then("^records are displayed with filtered \"([^\"]*)\"$")
	public void records_are_displayed_with_filtered(String arg1) throws Throwable {
		templatePage.verifyRecordsDisplayedInTheTable(arg1);
	}

	@When("^filter with \"([^\"]*)\"$")
	public void filter_with(String option) throws Throwable {
		templatePage.filterWithAssetNameStep2(option);
		templatePage.selectFilterItems(option);
	}

	@When("^filter record with \"([^\"]*)\"$")
	public void filter_record_with(String option) throws Throwable {
		templatePage.selectFilterItems(option);
	}

	@When("^click on reset all filters$")
	public void click_on_reset_all_filters() throws Throwable {
		templatePage.clickOnResetAllFiltersLink();
	}

	@When("^select Level hirarchy \"([^\"]*)\" from Assethirarchy menu$")
	public void select_Level_hirarchy_from_Assethirarchy_menu(String levelname) throws Throwable {
		waitForPageLoaded();
		waitForVisibilityOfElement(mainFrame, "mainFrame", 10);
		switchToFrame(mainFrame);
		levelname = Levelhirachyname;
		templatePage.selectlevelhirarchy(levelname);
	}

	@When("^create (\\d+) Roundtemplate items with api for pagination$")
	public void create_Roundtemplate_items_with_api_for_pagination(int nooftimes) throws Throwable {
		for (int i = 0; i < nooftimes; i++) {
			roundtemplateid = apii.createRoundtemplate_api(token, levelid, Roundetemplatname + getRandomString(5),
					assetid, taskid, "10", "High");

			Roundtemplateids.add(roundtemplateid);
			System.out.println(i);

		}

	}

	@When("^create Asset \"([^\"]*)\" with api$")
	public void create_Asset_with_api(String arg1) throws Throwable {
		assetid = apii.createAsset_api(token, levelid, Assetname, "Boilers", "Good");

	}

	@When("^delete Asset with api$")
	public void delete_Asset_with_api() throws Throwable {
		apii.DeleteAsset_api(token, assetid);
	}

	@When("^create Roundtemplate \"([^\"]*)\" with differentypes with api$")
	public void create_Roundtemplate_with_differentypes_with_api(String roundtemplatename) throws Throwable {

		List<String> category_type = new ArrayList<String>(Arrays.asList("High", "Medium", "Low", "Average", "Good"));
		// List<Long> graceperiod = new
		// ArrayList<Long>(Arrays.asList(40L,20L,10L,8L,50L));
		List<Long> graceperiod = new ArrayList<Long>(Arrays.asList(20L, 30L, 25L, 15L, 9L));
		for (int i = 1; i <= category_type.size(); i++) {
			roundtemplatename = "Roundtemplate" + generateRandomNumber(4);
			roundtemplateid = apii.createRoundtemplate_api(token, levelid, roundtemplatename, assetid, taskid,
					graceperiod.get(i - 1).toString(), category_type.get(i - 1));
			ids.add(roundtemplateid);
			entityname.add(roundtemplatename);
		}
	}

	@Then("^pagination in Roundtemplatepage$")
	public void pagination_in_Roundtemplatepage() throws Throwable {
		templatePage.Verify_Pagination_Roundtemplate();

	}

	@Then("^filters in Roundtemplate page$")
	public void filters_in_Roundtemplate_page() throws Throwable {
		templatePage.Filters_Roundtemplate();
	}

	@Then("^search results are displayed$")
	public void search_results_are_displayed() throws Throwable {
		for (int i = 1; i <= entityname.size(); i++) {
			String entitytosearch = entityname.get(i - 1);

			Validate_Search(entitytosearch);
		}
	}

	@Then("^sorting function is working correctly$")
	public void sorting_function_is_working_correctly() throws Throwable {
		Validate_sorting();
	}

	@When("^delete \"([^\"]*)\" items\" with api$")
	public void delete_items_with_api(String type) throws Throwable {
		if (type.equals("Asset")) {
			for (int i = 1; i <= ids.size(); i++) {
				apii.DeleteAsset_api(token, ids.get(i - 1));
			}
		}
		if (type.equals("Roundtemplate")) {
			for (int i = 1; i <= ids.size(); i++) {
				apii.DeleteRoundtemplate_api(token, ids.get(i - 1));
			}
		}
	}

	@Then("^verify filters in Tasks page$")
	public void verify_filters_in_Tasks_page() throws Throwable {
		Validate_Filters();
	}

	@When("^create level$")
	public void create_level() throws Throwable {
		templatePage.clickOnCreateLevel();
	}

	@When("^enter Category \"([^\"]*)\"$")
	public void enter_Category(String catvalue) throws Throwable {
		templatePage.enterCategory(catvalue);
	}

	@Then("^category error messsage displayed because \"([^\"]*)\"$")
	public void category_error_message_displayed_because(String expectedtext) throws Throwable {
		templatePage.verify_errormsg(expectedtext);
	}

	@Then("^checking UUID functionality from Round template$")
	public void checking_UUID_functionality_from_Round_template() throws Throwable {
		masterkeyValue = templatePage.mouseHoverOnTemplateName();
	}

	@When("^displayed round template UUID with the master data$")
	public void displayed_round_template_UUID_with_the_master_data() throws Throwable {
		masterDataPage.clickOnMasterData(masterkeyValue);
	}

	@Then("^mandatory pop-up displayed as \"([^\"]*)\"$")
	public void i_verify_error_message_as(String arg1) throws Throwable {
		templatePage.mandatory_Popupmsg(arg1);
	}

	@When("^create Roundtemplate \"([^\"]*)\" with api$")
	public void create_Roundtemplate_with_api(String roundtemplatename) throws Throwable {

		roundtemplatename = "Roundtemplate" + generateRandomNumber(4);
		roundtemplateid = apii.createRoundtemplate_api(token, levelid, roundtemplatename, assetid, taskid, "30",
				"Medium");
		ids.add(roundtemplateid);
		entityname.add(roundtemplatename);

	}

	@Given("^round template with assets and tasks is created in a level$")
	public void round_template_with_assets_and_tasks_is_created_in_a_level() throws Throwable {
		// Level creation
		Levelhirarchyids.clear();
		String levelname = Levelhirachyname;
		Hirarchyname.clear();
		Hirarchyname.add(Levelhirachyname);
		levelid = apii.createLevelhirarchy_api(token, levelname);
		Levelhirarchyids.add(levelid);

		// Asset creation
		assetid = apii.createAsset_api(token, levelid, Assetname, "Boilers", "Good");

		// Task creation
		String poistion = "2";
		String assetmode = "Good";
		String taskname1 = Taskname;
		String limitname = "limit" + System.currentTimeMillis();
		String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid = RandomStringUtils.random(10, false, true) + "backendid";
		String category = RandomStringUtils.random(10, true, true) + "category";
		taskid = apii.createTask_api(token, assetid, taskname1, limitname, assetmode, poistion, saptag, dcstag,
				backendid, category);
		Taskids.add(taskid);
		entityname.add(taskname1);

		// Round template creation
		String roundtemplatename = "Roundtemplate" + generateRandomNumber(4);
		roundtemplateid = apii.createRoundtemplate_api(token, levelid, roundtemplatename, assetid, taskid, "30",
				"Medium");
		ids.add(roundtemplateid);
		entityname.add(roundtemplatename);
	}

	@When("^Portal user is creating a new one from the existing template in the same level$")
	public void portal_user_is_creating_a_new_one_from_the_existing_template_in_the_same_level() throws Throwable {
		refreshBrowser();
		homePage.clickOnRoundTemplate();

		String levelhirarchy = Levelhirachyname;
		templatePage.selectlevelhirarchy_Rountemplate(levelhirarchy);

		// click on created round template
		templatePage.clickOnCreatedRTRecord();

		templatePage.clickOnNewRoundTemplateFromThisLink();
	}

	@Then("^assets and tasks of the existing template are listed$")
	public void assets_and_tasks_of_the_existing_template_are_listed() throws Throwable {
		String assetname = Assetname;
		templatePage.assets_isDispalyed(assetname);

		templatePage.clickOnNextButton();
		String task_name = Taskname;
		templatePage.assets_isDispalyed(task_name);

		templatePage.clickOnNextButton();
		String roundtemplatename = Roundetemplatname;
		waitForPageLoaded();
		templatePage.Enter_Roundtemplate(roundtemplatename);
		entityname.add(roundtemplatename);

		templatePage.Enter_Graceperiod("10");
		templatePage.clickOnCreateButton();
	}

	@Then("^creation of the new round template from the existing without any changes is successful$")
	public void creation_of_the_new_round_template_from_the_existing_without_any_changes_is_successful()
			throws Throwable {
		String roundtemplatename = Roundetemplatname;
		templatePage.verify_Roundtemplatecreated(roundtemplatename);
	}
	@Given("^\"([^\"]*)\" is created$")
    public void level_is_created(String level) throws Throwable {
		String levelname = Levelhirachyname;
		Hirarchyname.clear();
		Hirarchyname.add(Levelhirachyname);
		levelid = apii.createLevelhirarchy_api(token, levelname);
		Levelhirarchyids.add(levelid);
    }
	
	@When("^\"([^\"]*)\" with \"([^\"]*)\" are created in \"([^\"]*)\"$")
    public void asset_with_tasks_are_created_in_level(String asset, String tasks, String level) throws Throwable {
		// Asset creation
		assetid = apii.createAsset_api(token, levelid, Assetname, "Boilers", "Good");
		Assetids.add(assetid);
		entityname.add(Assetname);
		// Task creation
		String poistion = "2";
		String assetmode = "Good";
		String taskname1 = Taskname;
		String limitname = "limit" + System.currentTimeMillis();
		String saptag = RandomStringUtils.random(10, true, true) + "Saptag";
		String dcstag = RandomStringUtils.random(10, true, true) + "dcstag";
		String backendid = RandomStringUtils.random(10, false, true) + "backendid";
		String category = RandomStringUtils.random(10, true, true) + "category";
		taskid = apii.createTask_api(token, assetid, taskname1, limitname, assetmode, poistion, saptag, dcstag,
				backendid, category);
		Taskids.add(taskid);
		entityname.add(taskname1);

    }
	@When("^user creates advance Template \"([^\"]*)\" with one \"([^\"]*)\" which contains the \"([^\"]*)\" and its tasks$")
    public void user_creates_advance_template_something_with_one_something_which_contains_the_something_and_its_tasks(String advtemplate, String activityset, String asset) throws Throwable {
		
		String advancedRTName=advancedRoundTemplateName;
		templatePage.clickon_Addroundtemplate();
		templatePage.clickonAdvancedRoundtemplate();
		templatePage.clickOnNextButton();
		templatePage.clickonAddActivitySet();
		templatePage.enterAddActivitySet();
		common.clickADDAssetBtn();
		templatePage.clickonAssetCheckBox();
		templatePage.clickonSelectAsset();
		templatePage.clickonCheckList();
		templatePage.clickonAssetCheckBox();
		templatePage.clickonSelectTask();
		templatePage.clickOnNextButton();
		templatePage.enterAdvancedRTName(advancedRTName);
		templatePage.clickonSaveAndNext();
    }
	
	@Then("^advance Template is successfully created$")
    public void advance_template_is_successfully_created() throws Throwable {
        templatePage.verify_Roundtemplatecreated(advancedRoundTemplateName+"Advanced Round Template");
        templatePage.clickOnNextButton();
    }


}
