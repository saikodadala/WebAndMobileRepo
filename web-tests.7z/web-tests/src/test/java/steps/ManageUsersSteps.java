package steps;

import java.util.ArrayList;
import java.util.List;

import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import seleniumUtilities.BaseClass;

public class ManageUsersSteps extends BaseClass {

	static String employeeId = "";
	String levelid = "";
	String token = loginPage.getCookie();
	public String Levelhirachyname = "AddLevelhirachy" + System.currentTimeMillis();
	public String userName = "User" + System.currentTimeMillis();
	public String UserName = "AddUser" + System.currentTimeMillis();
	public String userid = "";
	public String emailId = "";
	List<String> ids = new ArrayList<String>();
	List<String> levelNames = new ArrayList<String>();
	List<String> usersList = new ArrayList<String>();

	@Given("^navigate to the movilizer portal$")
	public void navigate_to_the_movilizer_portal() throws Throwable {
		// String value=readCsvFile("Level1");
		// System.out.print(value);
	}

	@When("^click on add user$")
	public void click_on_add_user() throws Throwable {
		users.clickOnAddUserButton();
	}

	@When("^fill user details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void fill_user_details(String empId, String email, String user, String password) throws Throwable {
		employeeId = empId + System.currentTimeMillis();
		users.enterUserDetails("Enter Employee ID", employeeId);
		users.enterUserDetails("Enter Email ID", email);
		users.enterUserDetails("Enter User Name", user);
		users.enterUserDetails("Enter Password", password);
	}

	@When("^check Add User model pop-up$")
	public void checkAddUserModelPopup() throws Throwable {
		users.addUserPopValiations();
	}

	@When("^click on Add User button$")
	public void click_on_Add_User_button() throws Throwable {
		users.clickOnAddUserButton();
	}

	@Then("^create (\\d+) levels and users \"([^\"]*)\" \"([^\"]*)\"$")
	public void create_levels_and_users(int arg1, String levelName, String timeZone) throws Throwable {

		for (int i = 1; i < arg1; i++) {
			if (i > 1) {
				common.selectSideMenuOption("Asset hierarchy&Tasks");
			}
			levels.hoverOnCreatedLevel();
			levels.click3DotsCreatedLevel();
			homePage.clickOnCreateLevel();
			levels.levelNameRandGenerator(levelName);
			levels.enterTimeZone(timeZone);
			levels.clickSubmitButton();
			levels.verifyLevelCreationMSG();
			common.selectSideMenuOption("User");
			users.clickOnAddUserButton();
			users.addUserPopValiations();
			employeeId = "EOO43O6" + System.currentTimeMillis();
			users.enterUserDetails("Enter Employee ID", employeeId);
			users.enterUserDetails("Enter Email ID", "test@test.com");
			users.enterUserDetails("Enter User Name", "User");
			users.enterUserDetails("Enter Password", password);
			users.clickOnAddUserButton();
			users.verifySuccessMessage("User Added/Updated Successfully");
			users.verifyEmployeeId(employeeId);
		}
	}

	@When("^update user details and click on edit User button$")
	public void update_user_details_and_click_on_edit_User_button() throws Throwable {

		users.clickOnConfirmAndSubmit();
	}

	@When("^open created user \"([^\"]*)\"$")
	public void open_created_user(String action) throws Throwable {
		users.clickOnThreeDots(employeeId);
		users.clickOnRecordAction(action);
	}

	@When("^update user details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void update_user_details(String email, String user, String password) throws Throwable {
		emailId = System.currentTimeMillis() + email;
		users.enterUserDetails("Enter Email ID", emailId);
		users.enterUserDetails("Enter User Name", user);
		users.enterUserDetails("Enter Password", password);
	}

	@When("^click on edit User button$")
	public void click_on_edit_User_button() throws Throwable {
		users.clickOnConfirmAndSubmit();
	}

	@When("^\"([^\"]*)\" on delete action$")
	public void on_delete_action(String action) throws Throwable {
		users.clickOnDeleteUserAction(action);
	}

	@Then("^verify error message if user name : \"([^\"]*)\" is more than (\\d+) characters$")
	public void verify_error_message_if_user_name_is_more_than_characters(String userName, int charCount)
			throws Throwable {
		users.enterUserDetails("Enter User Name", userName);
		String expErrorMessage = "Employee name cannot be more than 32 characters";
		users.validateErrorMessage("User Name", expErrorMessage);
	}

	@Then("^verify error message if employee id : \"([^\"]*)\" is more than (\\d+) characters$")
	public void verify_error_message_if_employee_id_is_more_than_characters(String employeeId, int charCount)
			throws Throwable {
		users.enterUserDetails("Enter Employee ID", employeeId);
		String expErrorMessage = "Employee id cannot be more than 64 characters";
		users.validateErrorMessage("Employee ID", expErrorMessage);
	}

	@Then("^verify error message if \"([^\"]*)\" is invalid$")
	public void verify_error_message_if_is_invalid(String emailId) throws Throwable {
		users.enterUserDetails("Enter Email ID", emailId);
		String expErrorMessage = "Invalid Email ID";
		users.validateErrorMessage("Email ID", expErrorMessage);
	}

	@Then("^verify error message if email id: \"([^\"]*)\" is more than (\\d+) characters$")
	public void verify_error_message_if_email_id_is_more_than_characters(String emailId, int charCount)
			throws Throwable {
		users.enterUserDetails("Enter Email ID", emailId);
		String expErrorMessage = "Email ID cannot be more than 128 characters";
		users.validateErrorMessage("Email ID", expErrorMessage);
	}

	@Then("^verify error message if password : \"([^\"]*)\" is more than (\\d+) characters$")
	public void verify_error_message_if_password_is_more_than_characters(String password, int charCount)
			throws Throwable {
		users.enterUserDetails("Enter Password", password);
		String expErrorMessage = "Password cannot be more than 32 characters";
		users.validateErrorMessage("Password", expErrorMessage);
	}

	@Then("^verify global search \"([^\"]*)\"$")
	public void verify_global_search(String text) throws Throwable {
		users.enterEmployeeIdInSearchBox(text);
		users.verifyManageUserGlobalSearch(text);
	}

	@Then("^verify user landing page attributes$")
	public void verify_user_landing_page_attributes() throws Throwable {
		users.verifyLandingPageAttributes("Export List");
		users.verifyLandingPageAttributes("Import List");
		users.verifyLandingPageAttributes("Get Template");
	}

	@Then("^verify error message if user name is empty$")
	public void verify_error_message_if_user_name_is_empty() throws Throwable {
		users.validateEmptyFieldErrorMessage("Please enter user name");
	}

	@Then("^verify error message if employee id is empty$")
	public void verify_error_message_if_employee_id_is_empty() throws Throwable {
		users.validateEmptyFieldErrorMessage("Please enter employee id");
	}

	@Then("^verify error message if email id is empty$")
	public void verify_error_message_if_email_id_is_empty() throws Throwable {
		users.validateEmptyFieldErrorMessage("Please enter email id");
	}

	@Then("^verify error message if password is empty$")
	public void verify_error_message_if_password_is_empty() throws Throwable {
		users.validateEmptyFieldErrorMessage("Please enter password");
	}

	@Then("^verify success alert$")
	public void verify_success_alert() throws Throwable {
		users.verifySuccessMessage("User Added/Updated Successfully");
	}

	@Then("^verify created user \"([^\"]*)\" in user table$")
	public void verify_created_user_in_user_table(String empId) throws Throwable {
		users.verifyEmployeeId(empId);

	}

	@Then("^verify updated user \"([^\"]*)\" in user table$")
	public void verify_updated_user_in_user_table(String user) throws Throwable {
		users.verifyUser(user);
	}

	@Then("^success alert message should shown \"([^\"]*)\"$")
	public void success_alert_message_should_shown(String message) throws Throwable {
		users.verifySuccessMessage(message);
	}

	@Then("^created user \"([^\"]*)\" is displayed in user table$")
	public void created_user_is_displayed_in_user_table(String arg1) throws Throwable {
		users.verifyEmployeeId(employeeId);
	}

	@When("^perform \"([^\"]*)\" action on created user$")
	public void perform_action_on_created_user(String action) throws Throwable {
		users.clickOnThreeDots("id");
		users.clickOnRecordAction(action);
	}

	@When("^\"([^\"]*)\" delete action$")
	public void delete_action(String action) throws Throwable {
		users.clickOnDeleteUserAction(action);
	}

	@Then("^deleted user \"([^\"]*)\" should not available in user table$")
	public void deleted_user_should_not_available_in_user_table(String user) throws Throwable {
		users.verifyUserTable(user);
	}

	@When("^enter user details: \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void enter_user_details(String userName, String employeeId, String arg3, String password) throws Throwable {
		users.enterUserDetails("Enter User Name", userName);
		users.enterUserDetails("Enter Employee ID", employeeId);
		users.enterUserDetails("Enter Password", password);
	}

	@Then("^error message should shown if employee id : \"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_should_shown_if_employee_id_is_more_than_characters(String employeeId, int charCount)
			throws Throwable {
		String expErrorMessage = "Employee id cannot be more than 64 characters";
		users.validateErrorMessage("Employee ID", expErrorMessage);
	}

	@Then("^error message should shown if \"([^\"]*)\" is invalid$")
	public void error_message_should_shown_if_is_invalid(String emailId) throws Throwable {
		users.enterUserDetails("Enter Email ID", emailId);
		String expErrorMessage = "Invalid Email ID";
		users.validateErrorMessage("Email ID", expErrorMessage);
	}

	@Then("^error message should shown if email id: \"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_should_shown_if_email_id_is_more_than_characters(String emailId, int charCount)
			throws Throwable {
		users.enterUserDetails("Enter Email ID", emailId);
		String expErrorMessage = "Email ID cannot be more than 128 characters";
		users.validateErrorMessage("Email ID", expErrorMessage);
	}

	@Then("^error message should shown if password : \"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_should_shown_if_password_is_more_than_characters(String password, int charCount)
			throws Throwable {
		String expErrorMessage = "Password cannot be more than 32 characters";
		users.validateErrorMessage("Password", expErrorMessage);
	}

	@Then("^error message should shown if user name : \"([^\"]*)\" is more than (\\d+) characters$")
	public void error_message_should_shown_if_user_name_is_more_than_characters(String userName, int charCount)
			throws Throwable {
		String expErrorMessage = "Employee name cannot be more than 32 characters";
		users.validateErrorMessage("User Name", expErrorMessage);
	}

	@Given("^site level is created and selected for user$")
	public void site_level_is_created_and_selected_for_user() throws Throwable {
		Levelhirarchyids.clear();
		Hirarchyname.clear();
		levelid = apii.createLevelhirarchy_api(token, Levelhirachyname);
		Levelhirarchyids.add(levelid);
		Hirarchyname.add(Levelhirachyname);
		refreshBrowser();
		common.invisibleOfHoneywellLogo();
		users.selectlevelhirarchy_User(Levelhirachyname);
	}

	@When("^create User \"([^\"]*)\" with api$")
	public void create_User_with_api(String username) throws Throwable {
		username = UserName;
		employeeId = username;
		Userids.clear();
		userid = apii.createUser_api(token, levelid, username, username);
		Userids.add(userid);
	}

	@When("^create (\\d+) users with api$")
	public void create_Roundtemplate_items_with_api(int nooftimes) throws Throwable {
		Userids.clear();
		for (int i = 0; i < nooftimes; i++) {
			userid = apii.createUser_api(token, levelid, UserName + getRandomString(10),
					UserName + getRandomString(10));
			Userids.add(userid);
		}

	}

	@Then("^global search \"([^\"]*)\",results should get display$")
	public void global_search_results_should_get_display(String text) throws Throwable {
		users.enterEmployeeIdInSearchBox(employeeId);
		users.verifyManageUserGlobalSearch(employeeId);
	}

	@Then("^global search with: \"([^\"]*)\"$")
	public void global_search(String text) throws Throwable {
		users.enterEmployeeIdInSearchBox(employeeId);
	}

	@Then("^global search with \"([^\"]*)\"$")
	public void global_search_with(String text) throws Throwable {
		users.enterEmployeeIdInSearchBox(text);
	}

	@Then("^results is displayed with: \"([^\"]*)\"$")
	public void results_is_displayed(String text) throws Throwable {
		users.verifyManageUserGlobalSearch(employeeId);
	}

	@Then("^results is displayed with \"([^\"]*)\"$")
	public void results_is_displayed_with(String text) throws Throwable {
		users.verifyManageUserGlobalSearch(text);
	}

	@Then("^global search \"([^\"]*)\",results should not get display$")
	public void global_search_results_should_not_get_display(String text) throws Throwable {
		users.enterEmployeeIdInSearchBox(text);
		users.verifyManageUserGlobalSearch(text);
	}

	@Then("^ensure \"([^\"]*)\" message is display in the table$")
	public void ensure_message_is_display_in_the_table(String text) throws Throwable {
		users.verifyManageUserGlobalSearch(text);
	}

	@Then("^user landing page attributes should get display$")
	public void user_landing_page_attributes_should_get_display() throws Throwable {
		users.verifyLandingPageAttributes("Export List");
		users.verifyLandingPageAttributes("Import List");
		users.verifyLandingPageAttributes("Get Template");
	}

	@Then("^error message should shown because user name is empty$")
	public void error_message_should_shown_because_user_name_is_empty() throws Throwable {
		users.validateEmptyFieldErrorMessage("Please enter user name");
	}

	@Then("^error message should shown because employee id is empty$")
	public void error_message_should_shown_because_employee_id_is_empty() throws Throwable {
		users.validateEmptyFieldErrorMessage("Please enter employee id");
	}

	@Then("^error message should shown because email id is empty$")
	public void error_message_should_shown_because_email_id_is_empty() throws Throwable {
		users.validateEmptyFieldErrorMessage("Please enter email id");
	}

	@Then("^error message should shown because password is empty$")
	public void error_message_should_shown_because_password_is_empty() throws Throwable {
		users.validateEmptyFieldErrorMessage("Please enter password");
	}
	
	@When("^create (\\d+) users for each level with api$")
    public void create_10_users_for_each_level(int nooftimes) throws Throwable {
		refreshBrowser();
		common.selectSideMenuOption("User");
		for (int i = 0; i < levelNames.size(); i++) {	
			common.selectSideMenuOption("User");
			common.invisibleOfHoneywellLogo();
			users.selectlevelhirarchy_User(levelNames.get(i));
			waitForPageLoaded();
			users.verifyEmployeeId(usersList.get(i));			
			waitForPageLoaded();
		}
    }
	
	@Then("^ensure that one users are created each level$")
    public void ensure_that_10_users_are_created() throws Throwable {
		refreshBrowser();
		common.selectSideMenuOption("User");
		for (int i = 0; i < levelNames.size(); i++) {	
			common.selectSideMenuOption("User");
			common.invisibleOfHoneywellLogo();
			users.selectlevelhirarchy_User(levelNames.get(i));	
			waitForPageLoaded();
			users.verifyEmployeeId(usersList.get(i));			
			waitForPageLoaded();
		}
    }
	
	@And("^update (\\d+) users and ensure that all are updated$")
    public void update_10_users_and_ensure_that_all_are_updated(int nooftimes) throws Throwable {
		refreshBrowser();
		common.selectSideMenuOption("User");
		for (int i = 0; i < levelNames.size(); i++) {	
			common.selectSideMenuOption("User");
			common.invisibleOfHoneywellLogo();
			users.selectlevelhirarchy_User(levelNames.get(i));
			
			users.clickOnThreeDots("id");
			users.clickOnRecordAction("Edit");
			
			emailId = System.currentTimeMillis() + "test@test.com";
			users.enterUserDetails("Enter Email ID", emailId);
			users.enterUserDetails("Enter User Name", "user1"+i);
			users.enterUserDetails("Enter Password", password);
			
			users.clickOnConfirmAndSubmit();

			waitForPageLoaded();
			waitForPageLoaded();
		}

    }
	
	@And("^delete (\\d+) users and ensure that all users are deleted$")
    public void delete_10_users_and_ensure_that_all_are_updated(int nooftimes) throws Throwable {
		refreshBrowser();
		common.selectSideMenuOption("User");
		for (int i = 0; i < levelNames.size(); i++) {	
			common.selectSideMenuOption("User");
			common.invisibleOfHoneywellLogo();
			users.selectlevelhirarchy_User(levelNames.get(i));
			
			users.clickOnThreeDots("id");
			users.clickOnRecordAction("Delete");			
			users.clickOnDeleteUserAction("Confirm");

			waitForPageLoaded();
			waitForPageLoaded();
		}

    }

	@When("^create (\\d+) levels with api$")
	public void create_10_levelsusers_with_api(int nooftimes) throws Throwable {
		Userids.clear();
		Levelhirarchyids.clear();
		Hirarchyname.clear();		
		String levelID = "";
		for (int i = 0; i < nooftimes; i++) {
			if (i == 0) {
				levelid = apii.createLevelhirarchy_api(token, Levelhirachyname);
				Levelhirarchyids.add(levelid);
				Hirarchyname.add(Levelhirachyname);
				levelNames.add(Levelhirachyname);
				levelID = levelid;
			} else {
				levelid = apii.createSublevel_api(token, Levelhirachyname, levelID);
				Levelhirarchyids.add(levelid);
				Hirarchyname.add(Levelhirachyname);
				levelNames.add(Levelhirachyname);
				levelID = levelid;
			}
			userid = apii.createUser_api(token, levelID, UserName + getRandomString(10),
					UserName + getRandomString(10));
			Userids.add(userid);
			usersList.add(userid);
		}
		System.out.print("tets");
	}

}
