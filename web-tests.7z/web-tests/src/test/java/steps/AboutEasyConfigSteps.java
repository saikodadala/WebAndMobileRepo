package steps;


import common.reports.ConfigFileReadWrite;
import common.reports.ReporterConstants;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import seleniumUtilities.BaseClass;

import java.util.List;

public class AboutEasyConfigSteps extends BaseClass {

    @Given("^user at the \"([^\"]*)\" Level$")
    public void user_at_the_something_level(String levelHeading) throws Throwable {
    	refreshBrowser();
    	waitForPageLoaded();
    	driver.switchTo().defaultContent();    	
        about.verifyLevelHeading(levelHeading);
    }

    @When("^click on About Easyconfig from left tree$")
    public void click_on_about_easyconfig_from_left_tree() throws Throwable {
        about.clickAboutEasyConfigIcon();


    }

    @Then("^the Build Information Details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void the_Build_Information_Details(String heading1, String heading2, String heading3, String heading4, String heading5, String heading6) throws Throwable {
        about.buildInfo(heading1,heading2,heading3,heading4,heading5,heading6);

    }

}


