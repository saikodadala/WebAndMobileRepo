$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("AboutEasyConfig.feature");
formatter.feature({
  "line": 2,
  "name": "About EasyConfig - Validation of Build information",
  "description": "Description: The purpose of this feature is to test the Build Information in the About EasyConfig Page",
  "id": "about-easyconfig---validation-of-build-information",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@AboutEasyConfig"
    }
  ]
});
formatter.before({
  "duration": 10285622,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "User has to login to the Movilizer Web Portal",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "navigate to the movilizer portal",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "click on Login button",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "select category \"EasyConfig\"",
  "keyword": "And "
});
formatter.match({
  "location": "ManageUsersSteps.navigate_to_the_movilizer_portal()"
});
formatter.result({
  "duration": 98586146,
  "status": "passed"
});
formatter.match({
  "location": "MovilizerHomeSteps.click_on_Login()"
});
formatter.result({
  "duration": 25544970151,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "EasyConfig",
      "offset": 17
    }
  ],
  "location": "MovilizerHomeSteps.select_category(String)"
});
formatter.result({
  "duration": 18231847812,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Validate the Easy Config Build Information",
  "description": "",
  "id": "about-easyconfig---validation-of-build-information;validate-the-easy-config-build-information",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 10,
      "name": "@BuildInfo"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "I am at the \"Enterprise\" Level",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "I click on About Easyconfig from left tree",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "I verify the Build Information Details \"Build Version\" \"Asset and Task Template\" \"User Template\" \"Device Template\" \"Language Set Template\" \"V01\"",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Enterprise",
      "offset": 13
    }
  ],
  "location": "AboutEasyConfigSteps.i_am_at_the_something_level(String)"
});
formatter.result({
  "duration": 1167403762,
  "status": "passed"
});
formatter.match({
  "location": "AboutEasyConfigSteps.i_click_on_about_easyconfig_from_left_tree()"
});
formatter.result({
  "duration": 9177779400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Build Version",
      "offset": 40
    },
    {
      "val": "Asset and Task Template",
      "offset": 56
    },
    {
      "val": "User Template",
      "offset": 82
    },
    {
      "val": "Device Template",
      "offset": 98
    },
    {
      "val": "Language Set Template",
      "offset": 116
    },
    {
      "val": "V01",
      "offset": 140
    }
  ],
  "location": "AboutEasyConfigSteps.i_verify_the_Build_Information_Details(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 550313816,
  "status": "passed"
});
formatter.after({
  "duration": 4804075,
  "status": "passed"
});
});