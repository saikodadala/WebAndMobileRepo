package com.honeywell.movilizer.portalsdk.client.ir;

import com.honeywell.movilizer.portalsdk.client.RESTClient;
import com.movilizer.portal.sdk.shared.ir.domain.Asset;
import com.movilizer.portal.sdk.shared.ir.domain.Level;
import com.movilizer.portal.sdk.shared.ir.domain.Task;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.paging.Paginator;
import com.movilizer.portal.sdk.shared.ir.domain.structs.StringMap;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

public class IndexServiceTest {
    public static final String PARENT_ID = "20002";
    static TaskService t = null;
    static AssetService as = null;
    static IndexService p = null;
    static LevelService l = null;

    @BeforeClass
    static void beforeAll() {
        String token = "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MjY3NzE0MTUsImlhdCI6MTYyNjc3MTExNSwiaXNzIjoiIiwianRpIjoiOTEyZTI1OTctOWUzMS00MTY2LWIxMjEtZGFmZTVlMWU2Mjk2IiwidWlmIjoiZXlKaGRXUWlPaUpuWVhSbGQyRjVJaXdpWlcxaGFXd2lPaUp2Y2w4eU1EQXdNa0J0YjNacGJHbDZaWEl1WTI5dElpd2laVzFoYVd4ZmRtVnlhV1pwWldRaU9uUnlkV1VzSW1WNGNDSTZNVFl5TmpjM01UUXhOU3dpWm1GdGFXeDVYMjVoYldVaU9pSXlNREF3TWlJc0ltZHBkbVZ1WDI1aGJXVWlPaUp2Y2lJc0ltbGhkQ0k2TVRZeU5qYzNNVEV4TlN3aWFYTnpJam9pYUhSMGNITTZMeTl2Y2k1MFpYTjBMbVJsZGk1dGIzWnBiR2w2WlhJdVkyeHZkV1F2WVhWMGFDSXNJbXh2WTJGc1pTSTZJbVZ1SWl3aWJtRnRaU0k2SW05eUlESXdNREF5SWl3aWMzVmlJam9pTlRoaE4yTTRaRFl0WXpnME15MDBPRGRpTFRrMU5UWXRabVUwTXpJeFl6bGlOamRtSWl3aWMzbHpkR1Z0WDJsa0lqb3lNREF3TVgwPSJ9.8anisSmdzXs2sUojGJc_6eVh2rE0d_3UMTHzU1FC5NR7BuEr2unqgxd0wuBwt8llTClykkpx3E9bwy5xheUdbg";
        try {
            RESTClient client = new RESTClient("https://or.test.dev.movilizer.cloud", token);
            p = new IndexProvider(client);
            l = new LevelProvider(client);
            t = new TaskProvider(client);
            as = new AssetProvider(client);
        } catch (MalformedURLException e) {
            Assert.fail("Error creating IndexProvider", e);
            return;
        }
        Assert.assertNotNull(p);
        Assert.assertNotNull(l);
        Assert.assertNotNull(t);
    }

//    @Test
//    void testGetEntry() {
//
//    }

    @Test
    void testGet() {
        SharedResponseEntity<StringMap> res = null;
        try {
            res = p.get("Levels", "name", "parentId", "20002");
        } catch (Exception e) {
            e.printStackTrace();
//            Assert.fail("Failed when executing get: ", e);
        }
        Assert.assertNotNull(res);
        Assert.assertTrue(!res.isErroneous());
        Assert.assertTrue(!res.getBody().getBackingMap().entrySet().isEmpty());

    }

    @Test
    void testGetAssets() {
        SharedResponseEntity<StringMap> res = null;
        try {
            res = p.get("Assets", "name", "parentId", "ba5064084dd45adbc1900d0d47baa08");
            final StringMap body = res.getBody();
            final HashMap<String, String> tcMap = body.getBackingMap();
            for (String key : tcMap.keySet()) {
                String value = tcMap.get(key);
                System.out.println(value);
            }
//            System.out.println(res.getBody().get("result"));
        } catch (Exception e) {
            e.printStackTrace();
//            Assert.fail("Failed when executing get: ", e);
        }
        Assert.assertNotNull(res);
        Assert.assertTrue(!res.isErroneous());
        Assert.assertTrue(!res.getBody().getBackingMap().entrySet().isEmpty());

    }


//    @Test
//    void testGetTasks() {
//        SharedResponseEntity<StringMap> res = null;
//        try {
//            res = p.get("Tasks", "id", "parentId", "157bd52b5ac4cd9aad0143cfd195151");
//
//            final StringMap body = res.getBody();
//            final HashMap<String, String> tcMap = body.getBackingMap();
//            for (String key : tcMap.keySet()) {
//                String value = tcMap.get(key);
//                System.out.println(value);
//            }
////            System.out.println(res.getBody().get("result"));
//        } catch (Exception e) {
//            e.printStackTrace();
//            Assert.fail("Failed when executing get: ", e);
//        }
//        Assert.assertNotNull(res);
//        Assert.assertTrue(!res.isErroneous());
//        Assert.assertTrue(!res.getBody().getBackingMap().entrySet().isEmpty());
//
//    }


    @Test
    void testGetTasksLhasR() {
        SharedResponseEntity<Paginator<List<Task>>> res = null;
        try {
            res = t.listBy("LhasR", "Assets", "0e4ba885f2a4626a390b83a7a1a014b", 0, 100, Long.MIN_VALUE, Long.MAX_VALUE);
            final Paginator<List<Task>> body;
            body = res.getBody();
            ListIterator<Task> it = body.getResult().listIterator();
            while (it.hasNext()) {
                Task task = it.next();
                String value = task.getId();
                System.out.println(value);
            }
//            System.out.println(res.getBody().get("result"));
        } catch (Exception e) {
            e.printStackTrace();
//            Assert.fail("Failed when executing get: ", e);
        }
        Assert.assertNotNull(res);
        Assert.assertTrue(!res.isErroneous());
//        Assert.assertTrue(!res.getBody().getBackingMap().entrySet().isEmpty());

    }

//    @Test
//    void testAddLevel() {
//        SharedResponseEntity<Level> resl = null;
//        Level la = new Level();
//        la.setCompact(null, "TestCreateHierarchy", "SITE", "Europe/Berlin");
//        try {
//            resl = l.addTo("Levels", PARENT_ID, la);
//        } catch (Exception e) {
//            e.printStackTrace();
//            Assert.fail("Failed when executing get: ", e);
//        }
//        Assert.assertNotNull(resl);
//        Assert.assertTrue(!resl.isErroneous());
//
//    }

}
