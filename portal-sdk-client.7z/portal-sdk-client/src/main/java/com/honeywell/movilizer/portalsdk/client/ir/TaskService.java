/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import java.util.List;

import com.movilizer.portal.sdk.shared.ir.domain.Task;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.paging.Paginator;

@Path("task")
public interface TaskService extends IEntityService {

  // provided an id, returns a Task object
  @GET
  @Path("get/{id}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Task> get(@PathParam("id") String id);

  @GET
  @Path("listBy/{relationType}/{leftPool}/{leftId}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Paginator<List<Task>>> listBy(
      @PathParam("relationType") String relationType,
      @PathParam("leftPool") String leftPool,
      @PathParam("leftId") String leftId,
      @QueryParam(value = "offset") int offset,
      @QueryParam(value = "limit") int limit,
      @QueryParam(value = "timeRangeStart") long timeRangeStart,
      @QueryParam(value = "timeRangeEnd") long timeRangeEnd);

  @GET
  @Path("listByPoolByGroupByPage/{pool}/{group}/offset:{start}/limit:{limit}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<List<Task>> listByPoolByGroupByPage(
      @PathParam("pool") String poolName,
      @PathParam("group") String group,
      @PathParam("start") long start,
      @PathParam("limit") int limit);

  @POST
  @Path("addTo/{parentPool}/{parentId}")
  @Consumes(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<List<Task>> addTo(
      @PathParam("parentPool") String parentPool,
      @PathParam("parentId") String parentId,
      Task entity);

  @Path("updateTo/{parentPool}/{parentId}")
  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Task> updateTo(
      @PathParam("parentPool") String parentPool,
      @PathParam("parentId") String parentId,
      Task entity);

  // provided an id returns true if deletion was successful
  @DELETE
  @Path("delete/{id}")
  public SharedResponseEntity<Boolean> delete(
      @PathParam("id") String id);

  @POST
  @Path("addmany")
  @Consumes(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<List<Task>> addMany(List<Task> tasks);

  @DELETE
  @Path("deletemany")
  public SharedResponseEntity<List<Boolean>> deleteMany(
      List<String> ids);

  @POST
  @Path("addrecursive")
  @Consumes(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Task> addRecursive(Task task);

  @DELETE
  @Path("deleterecursive/{id}")
  public SharedResponseEntity<Boolean> deleteRecursive(
      @PathParam("id") String id);
}
