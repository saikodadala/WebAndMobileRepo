package com.honeywell.movilizer.portalsdk.client.ir;

import com.google.common.reflect.TypeToken;
import com.honeywell.movilizer.portalsdk.client.BaseProvider;
import com.honeywell.movilizer.portalsdk.client.RESTClient;
import com.movilizer.portal.sdk.shared.ir.domain.Config;
import com.movilizer.portal.sdk.shared.ir.domain.Level;
import com.movilizer.portal.sdk.shared.ir.domain.PropertySnapshot;
import com.movilizer.portal.sdk.shared.ir.domain.common.Relation;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.paging.Paginator;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

public class LevelProvider extends BaseProvider implements LevelService {
	public LevelProvider(RESTClient client) throws MalformedURLException {
		super(client);
	}

	@Override
	public SharedResponseEntity<Level> addTo(String parentPool, String parentId, Level entity) {
		return doOp(entity, new TypeToken<SharedResponseEntity<Level>>() {
		}.getType(),
				"addTo",
				new Object[]{parentPool, parentId,entity});
	}

	@Override
	public SharedResponseEntity<Level> get(String id) {
		return doOp(null, new TypeToken<SharedResponseEntity<Level>>() {
		}.getType(),
				"get",
				new Object[]{id});
	}

	@Override
	public SharedResponseEntity<Paginator<List<Level>>> listBy(String relationType, String leftPool, String leftId, int offset, int limit, long timeRangeStart, long timeRangeEnd) {
		return null;
	}

	@Override
	public SharedResponseEntity<List<Level>> listByPoolByGroupByPage(String poolName, String group, long start, int limit) {
		return null;
	}

	public SharedResponseEntity<List<Level>> listBy(String parentPool, String parentId) throws Exception {
		return doOp(null, new TypeToken<SharedResponseEntity<List<Level>>>() {
		}.getType(),
				"listBy",
				new Object[]{parentPool, parentId});
	}

	public SharedResponseEntity<List<Level>> listRootLevels() throws Exception {
		return doOp(null, new TypeToken<SharedResponseEntity<List<Level>>>() {
		}.getType(),
				"listRootLevels",
				new Object[]{});
	}

	@Override
	public SharedResponseEntity<Level> updateTo(String parentPool, String parentId, Level entity) {
		return doOp(entity, new TypeToken<SharedResponseEntity<Level>>() {
		}.getType(),
				"updateTo",
				new Object[]{parentPool, parentId});
	}

	@Override
	public SharedResponseEntity<Boolean> delete(String id) {
		return doOp(null, new TypeToken<SharedResponseEntity<Boolean>>() {
		}.getType(),
				"delete",
				new Object[]{id});
	}

	@Override
	public SharedResponseEntity<List<Level>> addMany(List<Level> levels) {
		return doOp(levels, new TypeToken<SharedResponseEntity<List<Level>>>() {
		}.getType(),
				"addMany",
				new Object[]{});
	}

	@Override
	public SharedResponseEntity<List<Boolean>> deleteMany(List<String> ids) {
		return doOp(ids, new TypeToken<SharedResponseEntity<List<Boolean>>>() {
		}.getType(),
				"deleteMany",
				new Object[]{});
	}
	/*
    @Override
    public SharedResponseEntity<ArrayList<PropertySnapshot>> listPropertySnapshots(String id) {
        return doOp(null, new TypeToken<SharedResponseEntity<ArrayList<PropertySnapshot>>>() {
                }.getType(),
                "listPropertySnapshots",
                new Object[]{id});
    }

    @Override
    public SharedResponseEntity<ArrayList<Relation>> listRelations(String id) {
        return doOp(null, new TypeToken<SharedResponseEntity<ArrayList<Relation>>>() {
                }.getType(),
                "listRelations",
                new Object[]{id});
    }

    @Override
    public SharedResponseEntity<ArrayList<Relation>> listRelationsByChildPool(String id, String childPool) {
        return doOp(null, new TypeToken<SharedResponseEntity<ArrayList<Relation>>>() {
                }.getType(),
                "listRelationsByChildPool",
                new Object[]{id, childPool});
    }

    @Override
    public SharedResponseEntity<Config> addConfig(String id, Config config) {
        return doOp(config, new TypeToken<SharedResponseEntity<Config>>() {
                }.getType(),
                "addConfig",
                new Object[]{id});
    }
	 */
}
