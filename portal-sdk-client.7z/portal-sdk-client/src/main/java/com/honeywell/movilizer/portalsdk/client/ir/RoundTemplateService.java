/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import java.util.List;

import com.movilizer.portal.sdk.shared.ir.domain.RoundTemplate;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.paging.Paginator;

@Path("roundtemplate")
public interface RoundTemplateService extends IEntityService {

  // provided an id, returns a RoundTemplate object
  @GET
  @Path("get/{id}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<RoundTemplate> get(
      @PathParam("id") String id);

  @GET
  @Path("listBy/{relationType}/{leftPool}/{leftId}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Paginator<List<RoundTemplate>>> listBy(
      @PathParam("relationType") String relationType,
      @PathParam("leftPool") String leftPool,
      @PathParam("leftId") String leftId,
      @QueryParam(value = "offset") int offset,
      @QueryParam(value = "limit") int limit,
      @QueryParam(value = "timeRangeStart") long timeRangeStart,
      @QueryParam(value = "timeRangeEnd") long timeRangeEnd);

  @GET
  @Path("listByPoolByGroupByPage/{pool}/{group}/offset:{start}/limit:{limit}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Paginator<List<RoundTemplate>>> listByPoolByGroupByPage(
      @PathParam("pool") String poolName,
      @PathParam("group") String group,
      @PathParam("start") long start,
      @PathParam("limit") int limit);

  @POST
  @Path("addTo/{parentPool}/{parentId}")
  @Consumes(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<RoundTemplate> addTo(
      @PathParam("parentPool") String parentPool,
      @PathParam("parentId") String parentId,
      RoundTemplate entity);

  @Path("updateTo/{parentPool}/{parentId}")
  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<RoundTemplate> updateTo(
      @PathParam("parentPool") String parentPool,
      @PathParam("parentId") String parentId,
      RoundTemplate entity);

  // provided an id returns true if deletion was successful
  @DELETE
  @Path("delete/{id}")
  public SharedResponseEntity<Boolean> delete(
      @PathParam("id") String id);

  @POST
  @Path("addmany")
  @Consumes(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<List<RoundTemplate>> addMany(
      List<RoundTemplate> roundTemplates);

  @DELETE
  @Path("deletemany")
  public SharedResponseEntity<List<Boolean>> deleteMany(
      List<String> ids);

  @POST
  @Path("addrecursive")
  @Consumes(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<RoundTemplate> addRecursive(
      RoundTemplate roundTemplate);
}
