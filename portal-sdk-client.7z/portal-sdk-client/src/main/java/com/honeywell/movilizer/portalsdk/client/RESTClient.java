package com.honeywell.movilizer.portalsdk.client;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hc.client5.http.ClientProtocolException;
import org.apache.hc.client5.http.classic.methods.HttpUriRequestBase;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.cookie.BasicCookieStore;
import org.apache.hc.client5.http.cookie.Cookie;
import org.apache.hc.client5.http.cookie.CookieStore;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.cookie.BasicClientCookie;
import org.apache.hc.core5.http.ClassicHttpResponse;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.HttpStatus;
import org.apache.hc.core5.http.ParseException;
import org.apache.hc.core5.http.io.HttpClientResponseHandler;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.util.Timeout;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class RESTClient {
    public static final String UI_PORTAL_SDK_SERVICES = "/ui/portal-sdk/services";
    private final Log log = LogFactory.getLog(RESTClient.class);

    private final String endpoint;
    private final String authToken;
    final RequestConfig defaultRequestConfig;
    final CookieStore cookieStore;


    public RESTClient(String endpoint, String authToken) throws MalformedURLException {
        this.endpoint = endpoint;
        this.authToken = authToken;
        this.cookieStore = new BasicCookieStore();

        this.defaultRequestConfig = RequestConfig.custom()
                .setConnectionRequestTimeout(Timeout.ofSeconds(60))
                .setConnectTimeout(Timeout.ofSeconds(60))
                .build();

        // Set auth cookie, further this can be enchaced with setting default Auth headers,
        // when backend supports other type of authentication
        URL eURL = new URL(endpoint);
        BasicClientCookie authCookie = new BasicClientCookie("auth", authToken);
        authCookie.setDomain(eURL.getHost());
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.HOUR_OF_DAY, 1);
        authCookie.setExpiryDate(calendar.getTime());
        authCookie.setPath("/");
        authCookie.setSecure(true);

        this.cookieStore.addCookie(authCookie);
    }

    String executeRequest(HttpUriRequestBase req) throws Exception {
        try (final CloseableHttpClient httpclient = HttpClients.custom()
                .setDefaultCookieStore(cookieStore).build()) {

            final RequestConfig requestConfig = RequestConfig.copy(defaultRequestConfig).build();
            req.setConfig(requestConfig);

            log.debug("Executing request " + req.getMethod() + " " + req.getUri());

            // Create a custom response handler
            final HttpClientResponseHandler<String> responseHandler = new HttpClientResponseHandler<String>() {

                @Override
                public String handleResponse(
                        final ClassicHttpResponse response) throws IOException {
                    final int status = response.getCode();
                    if (status >= HttpStatus.SC_SUCCESS && status < HttpStatus.SC_REDIRECTION) {
                        final HttpEntity entity = response.getEntity();
                        try {
                            final List<Cookie> cookies = cookieStore.getCookies();
                            if (cookies.isEmpty()) {
                                log.debug("No cookies set");
                            } else {
                                for (int i = 0; i < cookies.size(); i++) {
                                    Cookie cookie = cookies.get(i);
                                    if (cookie.getName().equals("auth") && !cookie.getValue().equals(authToken)) {
                                        log.debug("New auth cookie has been set");
                                    }
                                }
                            }
                            return entity != null ? EntityUtils.toString(entity) : null;
                        } catch (final ParseException ex) {
                            throw new ClientProtocolException(ex);
                        }
                    } else {
                        String body = null;
                        try {
                            final HttpEntity entity = response.getEntity();
                            body = entity != null ? EntityUtils.toString(entity) : null;
                        } catch (final ParseException ex) {
                        }
                        throw new ClientProtocolException("Unexpected response status: " + status + " body: " + body);
                    }
                }

            };
            final String responseBody = httpclient.execute(req, responseHandler);
            log.debug("Executed request " + req.getMethod() + " " + req.getUri() + " Result: " + responseBody);
            return responseBody;
        }
    }

    String getURL(String url) {
        return this.endpoint + url;
    }

    public String getFullUrl(String servicePath, Class c, Method m, String methodPath, Object[] params) {
        return UI_PORTAL_SDK_SERVICES + "/" + servicePath + "/" + PUtil.replaceParams(c, m, methodPath, params);
    }
}
