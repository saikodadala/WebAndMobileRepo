package com.honeywell.movilizer.portalsdk.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hc.client5.http.classic.methods.HttpDelete;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.classic.methods.HttpPut;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.io.entity.StringEntity;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.Path;
import java.lang.reflect.Method;
import java.lang.reflect.Type;

public class BaseProvider {
	private final Log log = LogFactory.getLog(BaseProvider.class);
	private final RESTClient client;
	protected final Gson gson;

	public BaseProvider(RESTClient client) {
		this.client = client;
		this.gson = new GsonBuilder()
				.setPrettyPrinting()
				.create();
	}

	protected SharedResponseEntity doOp(Object entity, Type respType, String methodName, Object[] params) throws RuntimeException {
		Class[] methodParams = new Class[params.length];
		// Case when apis are defined with callback end the end
		// will be used for return param
//			Class[] methodParams = new Class[params.length  + ( entity != null ? 1 : 0)];
		for (int i = 0; i < params.length; i++) {
			methodParams[i] = params[i].getClass();
		}
		// Case when apis are defined with callback end the end
		// will be used for return param
//			if (entity != null) {
//				methodParams[params.length] = entity.getClass();
//			}
		return doOp(entity, respType, methodName, params, methodParams);
	}

	protected SharedResponseEntity doOp(Object entity, Type respType, String methodName, Object[] params, Class[] methodParams) throws RuntimeException {
		try {
			Class c = this.getClass();
			Class[] ifs = c.getInterfaces();
			if (ifs.length > 0) {
				c = ifs[0];
			}
			Path pathServiceAnno = (Path) c.getAnnotation(Path.class);
			if (pathServiceAnno == null) {
				throw new Exception("Cannot fetch path segment in class " + this.getClass().getName());
			}
			String servicePath = pathServiceAnno.value();
			System.out.println("service path=" + servicePath);


			Method m = c.getMethod(methodName, methodParams);
			Path pathMethodAnno = m.getAnnotation(Path.class);
			String methodPath = pathMethodAnno.value();
			String op = PUtil.getHTTPMethod(m);

			String url = client.getFullUrl(servicePath, c, m, methodPath, params);

			log.debug("Executing " + op + " " + url + " " + servicePath);
			System.out.println("Path url is " +  op + " " + url + " " + servicePath);
			String result = "";
			if (op == HttpMethod.POST) {
				result = doPost(url, entity);
			} else if (op == HttpMethod.DELETE) {
				result = doDelete(url, entity);
			} else if (op == HttpMethod.GET) {
				result = doGet(url);
			} else if (op == HttpMethod.PUT) {
				result = doPut(url, entity); 
			}  
			
			else {
				throw new Exception("Operation " + op + " is not supported");
			}
			try {
				log.debug("-> " + result);
				//System.out.println("Response is  ******* " + result);
				return gson.fromJson(result, respType);
			} catch (Throwable th) {
				log.error("Failed to parse result: " + result, th);
				throw th;
			}
		} catch (Throwable th) {
			log.error("Failed to execute operation", th);
			throw new RuntimeException(th);
		}
	}

	protected String doGet(String url) throws Exception {
		return client.executeRequest(new HttpGet(client.getURL(url)));
	}

	protected String doPost(String url, Object requestObj) throws Exception {
		HttpPost req = new HttpPost(client.getURL(url));
		HttpEntity stringEntity = new StringEntity(gson.toJson(requestObj), ContentType.APPLICATION_JSON);
		req.setEntity(stringEntity);
		return client.executeRequest(req);
	}
	protected String doPut(String url, Object requestObj) throws Exception {
		HttpPut req = new HttpPut(client.getURL(url));
		HttpEntity stringEntity = new StringEntity(gson.toJson(requestObj), ContentType.APPLICATION_JSON);
		req.setEntity(stringEntity);
		return client.executeRequest(req);
	}
	protected String doDelete(String url, Object requestObj) throws Exception {
		HttpDelete req = new HttpDelete(client.getURL(url));
		if (requestObj != null) {
			HttpEntity stringEntity = new StringEntity(gson.toJson(requestObj), ContentType.APPLICATION_JSON);
			req.setEntity(stringEntity);
		}
		return client.executeRequest(req);
	}
}
