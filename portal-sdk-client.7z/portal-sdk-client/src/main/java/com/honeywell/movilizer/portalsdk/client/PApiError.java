package com.honeywell.movilizer.portalsdk.client;

public class PApiError {
    private String message;
    private String debugMessage;
    private String stacktrace;
    private String code;

    public String getMessage() {
        return message;
    }

    public String getDebugMessage() {
        return debugMessage;
    }

    public String getStacktrace() {
        return stacktrace;
    }

    public String getCode() {
        return code;
    }
}
