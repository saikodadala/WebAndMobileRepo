package com.honeywell.movilizer.portalsdk.client.ir;

import com.google.common.reflect.TypeToken;
import com.honeywell.movilizer.portalsdk.client.BaseProvider;
import com.honeywell.movilizer.portalsdk.client.RESTClient;
import com.movilizer.portal.sdk.shared.ir.domain.Config;
import com.movilizer.portal.sdk.shared.ir.domain.Limit;
import com.movilizer.portal.sdk.shared.ir.domain.PropertySnapshot;
import com.movilizer.portal.sdk.shared.ir.domain.Task;
import com.movilizer.portal.sdk.shared.ir.domain.User;
import com.movilizer.portal.sdk.shared.ir.domain.common.Relation;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.paging.Paginator;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

public class UserProvider extends BaseProvider implements UserService {
	public UserProvider(RESTClient client) throws MalformedURLException {
		super(client);
	}

	@Override
	public SharedResponseEntity<User> get(String id) {
		return doOp(null, new TypeToken<SharedResponseEntity<User>>() {
		}.getType(),
				"get",
				new Object[]{id});
	}

	@Override
	public SharedResponseEntity<Paginator<List<User>>> listBy(String relationType, String leftPool, String leftId, int offset, int limit, long timeRangeStart, long timeRangeEnd) {
		return doOp("User", new TypeToken<SharedResponseEntity<Paginator<List<User>>>>() {
		}.getType(),
				"listBy",
				new Object[]{relationType, leftPool, leftId, offset, limit, timeRangeStart, timeRangeEnd},
				new Class[]{String.class, String.class, String.class, int.class, int.class, long.class, long.class});

	}

	@Override
	public SharedResponseEntity<Paginator<List<User>>> listByPoolByGroupByPage(String poolName, String group, long start, int limit) {
		return null;
	}

	public SharedResponseEntity<List<User>> listBy(String parentPool, String parentId) throws Exception {
		return doOp(null, new TypeToken<SharedResponseEntity<List<User>>>() {
		}.getType(),
				"listBy",
				new Object[]{parentPool, parentId});
	}

	@Override
	public SharedResponseEntity<User> addTo(String parentPool, String parentId, User entity) {
		return doOp(entity, new TypeToken<SharedResponseEntity<User>>() {
		}.getType(),
				"addTo",
				new Object[]{parentPool, parentId,entity});
	}

	@Override
	public SharedResponseEntity<User> updateTo(String parentPool, String parentId, User entity) {
		return doOp(entity, new TypeToken<SharedResponseEntity<User>>() {
		}.getType(),
				"updateTo",
				new Object[]{parentPool, parentId});
	}

	@Override
	public SharedResponseEntity<Boolean> delete(String id) {
		return doOp(null, new TypeToken<SharedResponseEntity<Boolean>>() {
		}.getType(),
				"delete",
				new Object[]{id});
	}

	@Override
	public SharedResponseEntity<List<User>> addMany(List<User> users) {
		return doOp(users, new TypeToken<SharedResponseEntity<List<User>>>() {
		}.getType(),
				"addMany",
				new Object[]{});
	}

	@Override
	public SharedResponseEntity<List<Boolean>> deleteMany(List<String> ids) {
		return doOp(ids, new TypeToken<SharedResponseEntity<List<Boolean>>>() {
		}.getType(),
				"deleteMany",
				new Object[]{});
	}
	/*
	@Override
	public SharedResponseEntity<ArrayList<PropertySnapshot>> listPropertySnapshots(String id) {
		return doOp(null, new TypeToken<SharedResponseEntity<ArrayList<PropertySnapshot>>>() {
		}.getType(),
				"listPropertySnapshots",
				new Object[]{id});
	}

	@Override
	public SharedResponseEntity<ArrayList<Relation>> listRelations(String id) {
		return doOp(null, new TypeToken<SharedResponseEntity<ArrayList<Relation>>>() {
		}.getType(),
				"listRelations",
				new Object[]{id});
	}

	@Override
	public SharedResponseEntity<ArrayList<Relation>> listRelationsByChildPool(String id, String childPool) {
		return doOp(null, new TypeToken<SharedResponseEntity<ArrayList<Relation>>>() {
		}.getType(),
				"listRelationsByChildPool",
				new Object[]{id, childPool});
	}

	@Override
	public SharedResponseEntity<Config> addConfig(String id, Config config) {
		return doOp(config, new TypeToken<SharedResponseEntity<Config>>() {
		}.getType(),
				"addConfig",
				new Object[]{id});
	}
	 */
}
