package com.honeywell.movilizer.portalsdk.client.ir;

public interface RestService {
}
