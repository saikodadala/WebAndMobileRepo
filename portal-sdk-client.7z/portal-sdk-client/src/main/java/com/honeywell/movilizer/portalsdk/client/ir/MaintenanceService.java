/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import java.util.LinkedHashSet;

import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.extensions.DeletionParameterExtension;
import com.movilizer.portal.sdk.shared.ir.domain.extensions.UserControlParameterExtension;

@Path("maintenance")
public interface MaintenanceService extends RestService {

  @PUT
  @Path("lockCustomerUsers")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> lockCustomerUsers(
      UserControlParameterExtension userControlParameterExtension);

  @PUT
  @Path("unlockCustomerUsers")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> unlockCustomerUsers(
      UserControlParameterExtension userControlParameterExtension);

  @DELETE
  @Path("deleteCustomer/{force}/{simulateOnly}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> deleteCustomer(
      @PathParam("force") boolean force,
      @PathParam("simulateOnly") boolean simulateOnly,
      DeletionParameterExtension deletionParameterExtension);

  @DELETE
  @Path("deleteCustomerRelations/{force}/{simulateOnly}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> deleteCustomerRelations(
      @PathParam("force") boolean force,
      @PathParam("simulateOnly") boolean simulateOnly,
      DeletionParameterExtension deletionParameterExtension);

  @DELETE
  @Path("deleteCustomerMasterdata/{force}/{simulateOnly}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> deleteCustomerMasterdata(
      @PathParam("force") boolean force,
      @PathParam("simulateOnly") boolean simulateOnly,
      DeletionParameterExtension deletionParameterExtension);

  @DELETE
  @Path("deleteCustomerMovelets/{force}/{simulateOnly}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> deleteCustomerMovelets(
      @PathParam("force") boolean force,
      @PathParam("simulateOnly") boolean simulateOnly,
      DeletionParameterExtension deletionParameterExtension);

  @DELETE
  @Path("deleteCustomerScripts/{force}/{simulateOnly}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> deleteCustomerScripts(
      @PathParam("force") boolean force,
      @PathParam("simulateOnly") boolean simulateOnly,
      DeletionParameterExtension deletionParameterExtension);

  @DELETE
  @Path("deleteCustomerPlanningBoardIndexes/{force}/{simulateOnly}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> deleteCustomerPlanningBoardIndexes(
      @PathParam("force") boolean force,
      @PathParam("simulateOnly") boolean simulateOnly,
      DeletionParameterExtension deletionParameterExtension);

  @DELETE
  @Path("deleteCustomerAclGroups/{force}/{simulateOnly}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> deleteCustomerAclGroups(
      @PathParam("force") boolean force,
      @PathParam("simulateOnly") boolean simulateOnly,
      DeletionParameterExtension deletionParameterExtension);

  @GET
  @Path("getLogByTag/{operationIdentifier}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<LinkedHashSet<String>> getLogByTag(
      @PathParam("operationIdentifier") String operationIdentifier);

  @Path("getLogByTagByRange/{operationIdentifier}/{timeRangeStart}/{timeRangeEnd}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<LinkedHashSet<String>> getLogByTagByRange(
      @PathParam("operationIdentifier") String operationIdentifier,
      @PathParam("timeRangeStart") long timeRangeStart,
      @PathParam("timeRangeEnd") long timeRangeEnd);

  @Path("getLogByTagByPage/{operationIdentifier}/{offset}/{limit}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<LinkedHashSet<String>> getLogByTagByPage(
      @PathParam("operationIdentifier") String operationIdentifier,
      @PathParam("offset") int offset,
      @PathParam("limit") int limit);

  @Path(
      "getLogByTagByRangeAndPage/{operationIdentifier}/{timeRangeStart}/{timeRangeEnd}/{offset}/{limit}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<LinkedHashSet<String>> getLogByTagByRangeAndPage(
      @PathParam("operationIdentifier") String operationIdentifier,
      @PathParam("timeRangeStart") long timeRangeStart,
      @PathParam("timeRangeEnd") long timeRangeEnd,
      @PathParam("offset") int offset,
      @PathParam("limit") int limit);

  @GET
  @Path("getStatus/{operationIdentifier}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> getStatus(
      @PathParam("operationIdentifier") String operationIdentifier);
}
