/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import java.util.List;

import com.movilizer.portal.sdk.shared.ir.domain.User;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.paging.Paginator;

@Path("user")
public interface UserService extends IEntityService {

  // provided an id, returns a User object
  @GET
  @Path("get/{id}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<User> get(@PathParam("id") String id);

  @GET
  @Path("listBy/{relationType}/{leftPool}/{leftId}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Paginator<List<User>>> listBy(
      @PathParam("relationType") String relationType,
      @PathParam("leftPool") String leftPool,
      @PathParam("leftId") String leftId,
      @QueryParam(value = "offset") int offset,
      @QueryParam(value = "limit") int limit,
      @QueryParam(value = "timeRangeStart") long timeRangeStart,
      @QueryParam(value = "timeRangeEnd") long timeRangeEnd);

  @GET
  @Path("listByPoolByGroupByPage/{pool}/{group}/offset:{start}/limit:{limit}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Paginator<List<User>>> listByPoolByGroupByPage(
      @PathParam("pool") String poolName,
      @PathParam("group") String group,
      @PathParam("start") long start,
      @PathParam("limit") int limit);

  @Path("addTo/{parentPool}/{parentId}")
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<User> addTo(
      @PathParam("parentPool") String parentPool,
      @PathParam("parentId") String parentId,
      User entity);

  @Path("updateTo/{parentPool}/{parentId}")
  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<User> updateTo(
      @PathParam("parentPool") String parentPool,
      @PathParam("parentId") String parentId,
      User entity);

  // provided an id returns true if deletion was successful
  @DELETE
  @Path("delete/{id}")
  public SharedResponseEntity<Boolean> delete(
      @PathParam("id") String id);

  @POST
  @Path("addmany")
  @Consumes(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<List<User>> addMany(List<User> users);

  @DELETE
  @Path("deletemany")
  public SharedResponseEntity<List<Boolean>> deleteMany(
      List<String> ids);
}
