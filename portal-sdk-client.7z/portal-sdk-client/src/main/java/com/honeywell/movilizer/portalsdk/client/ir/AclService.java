/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.structs.StringMap;

@Path("acl")
public interface AclService extends RestService {

  /** * POSSIBLE VALUES */
  @Path("actions/{acoType}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<StringMap> getActions(
      @PathParam("acoType") String acoType);

  @Path("actions/{acoType}/{actionName}")
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> addAction(
      @PathParam("acoType") String acoType,
      @PathParam("actionName") String actionName);

  @Path("actions/{acoType}/{actionId}")
  @DELETE
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> deleteAction(
      @PathParam("acoType") String acoType,
      @PathParam("actionId") String actionId);

  /** GROUPS */
  @Path("groups")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<StringMap> getGroups();

  @Path("groups/{groupName}")
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> addGroup(
      @PathParam("groupName") String groupName);

  @Path("groups/{groupId}")
  @DELETE
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> deleteGroup(
      @PathParam("groupId") String groupId);

  /** * Group Permissions */
  @Path("groups/permissions/{groupId}/{acoType}/{aco}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<StringMap> getGroupPermissions(
      @PathParam("groupId") String groupId,
      @PathParam("acoType") String acoType,
      @PathParam("aco") String aco);

  @Path("groups/permissions/{groupId}/{acoType}/{aco}")
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> addGroupPermission(
      @PathParam("groupId") String groupId,
      @PathParam("acoType") String acoType,
      @PathParam("aco") String aco,
      List<String> actions);

  @Path("groups/permissions/{groupId}/{aco}/{action}")
  @DELETE
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> deleteGroupPermission(
      @PathParam("groupId") String groupId,
      @PathParam("aco") String aco,
      @PathParam("action") String action);

  @Path("groups/permissions/{groupId}/{aco}")
  @DELETE
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> deleteAllGroupPermissions(
      @PathParam("groupId") String groupId,
      @PathParam("aco") String aco);

  @Path("groups/permissions/check/{groupId}/{aco}/{action}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> checkGroupPermission(
      @PathParam("groupId") String groupId,
      @PathParam("aco") String aco,
      @PathParam("action") String action);

  /** AROs */
  @Path("aros/{aro}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<StringMap> getGroupsOfAro(
      @PathParam("aro") String aro);

  @Path("aros/{aro}/{groupId}")
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> addAroToGroup(
      @PathParam("aro") String aro,
      @PathParam("groupId") String groupId);

  @Path("aros/{aro}/{groupId}")
  @DELETE
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> removeAroFromGroup(
      @PathParam("aro") String aro,
      @PathParam("groupId") String groupId);

  @Path("aros/permissions/check/{aro}/{aco}/{action}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> checkAroPermission(
      @PathParam("aro") String aro,
      @PathParam("aco") String aco,
      @PathParam("action") String action);

  @Path("aros/permissions/{aro}/{acoType}/{aco}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<StringMap> getAroPermissions(
      @PathParam("aro") String aro,
      @PathParam("acoType") String acoType,
      @PathParam("aco") String aco);
}
