/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;

@Path("admin")
public interface AdminService extends RestService {

  @Path("setBenchmarkingEnabled/{enabled}")
  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> setBenchmarkingEnabled(
      @PathParam("enabled") boolean enabled);

  @Path("setLoggingEnabled/{enabled}")
  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> setLoggingEnabled(
      @PathParam("enabled") boolean enabled);

  @Path("setMonitoringMessagesEnabled/{enabled}")
  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> setMonitoringMessagesEnabled(
      @PathParam("enabled") boolean enabled);
}
