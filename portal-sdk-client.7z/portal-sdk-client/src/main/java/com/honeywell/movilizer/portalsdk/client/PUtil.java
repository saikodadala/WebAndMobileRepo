package com.honeywell.movilizer.portalsdk.client;

import javax.ws.rs.*;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class PUtil {

    public static String replaceParams(Class c, Method m, String methodPath, Object[] params) {
        Parameter[] paramMeta = m.getParameters();
        String newPath = methodPath;
        for (int i = 0; i < params.length; i++) {
            PathParam anno = paramMeta[i].getAnnotation(PathParam.class);
            if (anno == null) {
                continue;
            }
            String paramName = anno.value();
            String expr = "{" + paramName + "}";
            String newVal = params[i] != null ? params[i].toString() : "";
            System.out.println("replacing " + expr + " with " + newVal);
            newPath = newPath.replace(expr, newVal);
        }
        return newPath;
    }

    public static String getHTTPMethod(Method m) throws IllegalArgumentException {
        HttpMethod opAnno = m.getAnnotation(HttpMethod.class);
        if (opAnno != null) {
            return opAnno.value();
        }
        if (m.getAnnotation(POST.class) != null) {
            return HttpMethod.POST;
        }
        if (m.getAnnotation(GET.class) != null) {
            return HttpMethod.GET;
        }
        if (m.getAnnotation(DELETE.class) != null) {
            return HttpMethod.DELETE;
        }
        if (m.getAnnotation(PUT.class) != null) {
            return HttpMethod.PUT;
        }
        if (m.getAnnotation(PATCH.class) != null) {
            return HttpMethod.PATCH;
        }
        throw new IllegalArgumentException("No HTTP method annotation on method " + m.getName());
    }
}
