/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

public interface IEntityService extends RestService {
  // remove all methods from this interface as they were not used in EasyConfig. We will retain the
  // interface for future use purpose.
}
