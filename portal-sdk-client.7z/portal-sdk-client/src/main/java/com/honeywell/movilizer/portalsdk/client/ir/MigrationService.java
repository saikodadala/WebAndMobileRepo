/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import java.util.LinkedHashSet;

import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;

@Path("migration")
public interface MigrationService extends RestService {

  @PUT
  @Path("migrate/{fromVersionToVersion}/{force}/{simulateOnly}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> migrate(
      @PathParam("fromVersionToVersion") String fromVersionToVersion,
      @PathParam("force") boolean forceMigration,
      @PathParam("simulateOnly") boolean simulateOnly);

  @GET
  @Path("getlog")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<LinkedHashSet<String>> getLog();

  @GET
  @Path("getLogByTag/{fromVersionToVersion}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<LinkedHashSet<String>> getLogByTag(
      @PathParam("fromVersionToVersion") String fromVersionToVersion);

  @Path("getLogByTagByRange/{fromVersionToVersion}/{timeRangeStart}/{timeRangeEnd}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<LinkedHashSet<String>> getLogByTagByRange(
      @PathParam("fromVersionToVersion") String fromVersionToVersion,
      @PathParam("timeRangeStart") long timeRangeStart,
      @PathParam("timeRangeEnd") long timeRangeEnd);

  @Path("getLogByTagByPage/{fromVersionToVersion}/{offset}/{limit}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<LinkedHashSet<String>> getLogByTagByPage(
      @PathParam("fromVersionToVersion") String fromVersionToVersion,
      @PathParam("offset") int offset,
      @PathParam("limit") int limit);

  @Path(
      "getLogByTagByRangeAndPage/{fromVersionToVersion}/{timeRangeStart}/{timeRangeEnd}/{offset}/{limit}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<LinkedHashSet<String>> getLogByTagByRangeAndPage(
      @PathParam("fromVersionToVersion") String fromVersionToVersion,
      @PathParam("timeRangeStart") long timeRangeStart,
      @PathParam("timeRangeEnd") long timeRangeEnd,
      @PathParam("offset") int offset,
      @PathParam("limit") int limit);

  @PUT
  @Path("unlockSystem/{fromVersionToVersion}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> unlockSystem(
      @PathParam("fromVersionToVersion") String fromVersionToVersion);

  @GET
  @Path("getStatus/{fromVersionToVersion}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> getStatus(
      @PathParam("fromVersionToVersion") String fromVersionToVersion);
}
