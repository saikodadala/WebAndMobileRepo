/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.structs.StringMap;

@Path("index")
public interface IndexService extends RestService {

  /**
   * Example: A level has a name and we want an index for that. We also specify, that not all Level
   * names should end up in the same index. Instead, we want the index to be grouped by the level's
   * parent id. To set this up, we need the following annotation in the Level
   * entity: @Index(property = "name", groupByProperty = "parentId") In order to get all level names
   * for the parent level with id 12345, we can call get("Levels","name","parentId","12345"). This
   * will return an index containing all level names of all levels with parentId 12345. The level
   * names will be the keys in the index, the level's id will be the value.
   *
   * @param pool the pool for which the index exists
   * @param property the property of the entity that got indexed
   * @param groupByProperty group by what property
   * @param groupByPropertyValue group by what value
   * @return the full index
   */
  @Path("get/{pool}/{propertyName}/{groupByProperty}/{groupByPropertyValue}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<StringMap> get(
      @PathParam("pool") String pool,
      @PathParam("propertyName") String property,
      @PathParam("groupByProperty") String groupByProperty,
      @PathParam("groupByPropertyValue") String groupByPropertyValue);

  @Path("get/{pool}/{propertyName}/{groupByProperty}/{groupByPropertyValue}/{key}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<String> getEntry(
      @PathParam("pool") String pool,
      @PathParam("propertyName") String property,
      @PathParam("groupByProperty") String groupByProperty,
      @PathParam("groupByPropertyValue") String groupByPropertyValue,
      @PathParam("key") String key);
}
