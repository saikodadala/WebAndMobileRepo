package com.honeywell.movilizer.portalsdk.client.ir;

import com.google.common.reflect.TypeToken;
import com.honeywell.movilizer.portalsdk.client.BaseProvider;
import com.honeywell.movilizer.portalsdk.client.RESTClient;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.structs.StringMap;

import java.net.MalformedURLException;

public class IndexProvider extends BaseProvider implements IndexService {
    public IndexProvider(RESTClient client) throws MalformedURLException {
        super(client);
    }

    @Override
    public SharedResponseEntity<StringMap> get(String pool, String property, String groupByProperty, String groupByPropertyValue) {
        return doOp(null, new TypeToken<SharedResponseEntity<StringMap>>() {
                }.getType(),
                "get",
                new Object[]{pool, property, groupByProperty, groupByPropertyValue});

    }

    @Override
    public SharedResponseEntity<String> getEntry(String pool, String property, String groupByProperty, String groupByPropertyValue, String key) {
        return doOp(null, new TypeToken<SharedResponseEntity<String>>() {
                }.getType(),
                "getEntry",
                new Object[]{pool, property, groupByProperty, groupByPropertyValue});
    }
}
