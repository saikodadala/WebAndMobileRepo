/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 26.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import java.util.List;

import com.movilizer.portal.sdk.shared.ir.domain.Schedule;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.paging.Paginator;

@Path("schedule")
public interface ScheduleService extends IEntityService {
  // provided an id, returns a Schedule object
  @GET
  @Path("get/{id}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Schedule> get(
      @PathParam("id") String id);

  @GET
  @Path("listBy/{relationType}/{leftPool}/{leftId}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Paginator<List<Schedule>>> listBy(
      @PathParam("relationType") String relationType,
      @PathParam("leftPool") String leftPool,
      @PathParam("leftId") String leftId,
      @QueryParam(value = "offset") int offset,
      @QueryParam(value = "limit") int limit,
      @QueryParam(value = "timeRangeStart") long timeRangeStart,
      @QueryParam(value = "timeRangeEnd") long timeRangeEnd);

  @GET
  @Path("listByPoolByGroupByPage/{pool}/{group}/offset:{start}/limit:{limit}")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<List<Schedule>> listByPoolByGroupByPage(
      @PathParam("pool") String poolName,
      @PathParam("group") String group,
      @PathParam("start") long start,
      @PathParam("limit") int limit);

  // provided an id returns true if deletion was successful
  @DELETE
  @Path("delete/{id}")
  public SharedResponseEntity<Boolean> delete(
      @PathParam("id") String id);

  // http://mydomain.com/portal-sdk/services/assets/addTo/Levels/123456
  @Path("addTo/{parentPool}/{parentId}")
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Schedule> addTo(
      @PathParam("parentPool") String parentPool,
      @PathParam("parentId") String parentId,
      Schedule entity);

  // http://mydomain.com/portal-sdk/services/assets/updateTo/Levels/123456
  /*Updates an entity while at the same time re-attaching it to a new */
  @Path("updateTo/{parentPool}/{parentId}")
  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Schedule> updateTo(
      @PathParam("parentPool") String parentPool,
      @PathParam("parentId") String parentId,
      Schedule entity);

  @POST
  @Path("addmany")
  @Consumes(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<List<Schedule>> addMany(
      List<Schedule> schedules);

  @DELETE
  @Path("deletemany")
  public SharedResponseEntity<List<Boolean>> deleteMany(
      List<String> ids);
}
