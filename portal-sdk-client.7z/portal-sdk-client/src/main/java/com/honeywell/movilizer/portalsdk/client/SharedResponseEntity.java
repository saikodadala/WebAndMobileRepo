package com.honeywell.movilizer.portalsdk.client;

public class SharedResponseEntity<T> {
    private T body;
    private boolean erroneous;
    private PApiError error;

    public T getBody() {
        return body;
    }

    public boolean isErroneous() {
        return erroneous;
    }

    public PApiError getError() {
        return error;
    }
}
