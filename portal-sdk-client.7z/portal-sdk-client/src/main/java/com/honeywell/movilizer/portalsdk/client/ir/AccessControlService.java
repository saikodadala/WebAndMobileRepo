/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.honeywell.movilizer.portalsdk.client.ir;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.structs.AccessControl;

@Path("access")
public interface AccessControlService extends RestService {

  @GET
  @Path("get")
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Boolean> get();
}
