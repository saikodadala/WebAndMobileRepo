package com.honeywell.movilizer.portalsdk.client.ir;

import java.util.ArrayList;
import java.util.List;

import com.google.common.reflect.TypeToken;
import com.honeywell.movilizer.portalsdk.client.BaseProvider;
import com.honeywell.movilizer.portalsdk.client.RESTClient;
import com.movilizer.portal.sdk.shared.ir.domain.Config;
import com.movilizer.portal.sdk.shared.ir.domain.PropertySnapshot;
import com.movilizer.portal.sdk.shared.ir.domain.common.Relation;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.paging.Paginator;

public class ConfigProvider extends BaseProvider implements ConfigService{

	public ConfigProvider(RESTClient client) {
		super(client);
		// TODO Auto-generated constructor stub
	}
	/*
	@Override
	public SharedResponseEntity<ArrayList<PropertySnapshot>> listPropertySnapshots(String id) {
		return doOp(null, new TypeToken<SharedResponseEntity<ArrayList<PropertySnapshot>>>() {
		}.getType(),
				"listPropertySnapshots",
				new Object[]{id});
	}

	@Override
	public SharedResponseEntity<ArrayList<Relation>> listRelations(String id) {
		return doOp(null, new TypeToken<SharedResponseEntity<ArrayList<Relation>>>() {
		}.getType(),
				"listRelations",
				new Object[]{id});
	}

	@Override
	public SharedResponseEntity<ArrayList<Relation>> listRelationsByChildPool(String id, String childPool) {
		return doOp(null, new TypeToken<SharedResponseEntity<ArrayList<Relation>>>() {
		}.getType(),
				"listRelationsByChildPool",
				new Object[]{id, childPool});
	}

	@Override
	public SharedResponseEntity<Config> addConfig(String id, Config config) {
		return doOp(config, new TypeToken<SharedResponseEntity<Config>>() {
		}.getType(),
				"addConfig",
				new Object[]{id});
	}

	 */
	@Override
	public SharedResponseEntity<Config> get(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SharedResponseEntity<Config> listBy(String relationType, String leftPool, String leftId, int offset, int limit, long timeRangeStart, long timeRangeEnd) {
		return null;
	}

	@Override
	public SharedResponseEntity<List<Config>> listByPoolByGroupByPage(String poolName, String group, long start, int limit) {
		return null;
	}

	public SharedResponseEntity<ArrayList<Config>> listBy(String parentPool, String parentId) throws Exception {
		return doOp(null, new TypeToken<SharedResponseEntity<List<Config>>>() {
		}.getType(),
				"listBy",
				new Object[]{parentPool, parentId});
	}

	@Override
	public SharedResponseEntity<Config> addTo(String parentPool, String parentId, Config entity) {
		return doOp(entity, new TypeToken<SharedResponseEntity<Config>>() {
		}.getType(),
				"addTo",
				new Object[]{parentPool, parentId,entity});
	}

	@Override
	public SharedResponseEntity<Config> updateTo(String parentPool, String parentId, Config entity) {
		return doOp(entity, new TypeToken<SharedResponseEntity<Config>>() {
		}.getType(),
				"updateTo",
				new Object[]{parentPool, parentId});
	}

	@Override
	public SharedResponseEntity<Boolean> delete(String id) {
		return doOp(null, new TypeToken<SharedResponseEntity<Boolean>>() {
		}.getType(),
				"delete",
				new Object[]{id});
	}

	@Override
	public SharedResponseEntity<List<Boolean>> deleteMany(List<String> ids) {
		return doOp(ids, new TypeToken<SharedResponseEntity<List<Boolean>>>() {
		}.getType(),
				"deleteMany",
				new Object[]{});
	}

	@Override
	public SharedResponseEntity<List<Config>> addMany(List<Config> configs) {
		// TODO Auto-generated method stub
		return null;
	}

}
