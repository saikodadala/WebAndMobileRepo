package com.movilizer.portal.sdk.shared.ir.domain.core;

import com.movilizer.portal.sdk.shared.ir.domain.common.Validateable;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;
import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.structs")
public class AppGroup implements Validateable {

  public static final String PARTITION_KEY_ENTITY_TO_APP_GROUP = "EntityToAppGroupMapping";
  public static final String APPGROUP_DELIMITER = ";";

  private String id;
  private String description;
  private String validTillDate;
  private String timeToLive;
  private String password;
  private String passwordType;

  public String getId() {
    return id;
  }

  @JsIgnore
  public void setId(String id) {
    this.id = id;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getValidTillDate() {
    return validTillDate;
  }

  public void setValidTillDate(String validTillDate) {
    this.validTillDate = validTillDate;
  }

  public String getTimeToLive() {
    return timeToLive;
  }

  public void setTimeToLive(String timeToLive) {
    this.timeToLive = timeToLive;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getPasswordType() {
    return passwordType;
  }

  public void setPasswordType(String passwordType) {
    this.passwordType = passwordType;
  }

  @Override
  public ValidationResult validate() {
    ValidationResult validationResult = new ValidationResult();
    ValidationUtils.validateStringProperty(
        validationResult, "description", description, true, ValidationUtils.XXXL_1024);
    ValidationUtils.validateIntegerProperty(
        validationResult, "validTillDate", validTillDate, false, 0L, Long.MAX_VALUE, null);
    ValidationUtils.validateStringProperty(
        validationResult, "password", password, false, ValidationUtils.L_128);
    ValidationUtils.validateStringProperty(
        validationResult, "passwordType", passwordType, false, ValidationUtils.M_64);
    return validationResult;
  }
}
