/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp;

import java.util.HashMap;
import java.util.Map;

public class SdkRequest {

  private long systemId;
  private Map<String, Object> attributes;
  private Map<String, Object> values;

  public long getSystemId() {
    return systemId;
  }

  public void setSystemId(long systemId) {
    this.systemId = systemId;
  }

  public Map<String, Object> getAttributes() {
    return attributes;
  }

  public void setAttributes(Map<String, Object> attributes) {
    this.attributes = attributes;
  }

  public void addAttribute(String key, Object value) {
    if (this.attributes == null) {
      this.attributes = new HashMap<>();
    }
    this.attributes.put(key, value);
  }

  public Object getAttribute(String key) {
    if (this.attributes != null) {
      return this.attributes.get(key);
    }
    return null;
  }

  public Map<String, Object> getValues() {
    return values;
  }

  public void setValues(Map<String, Object> values) {
    this.values = values;
  }

  public void addValue(String key, Object value) {
    if (this.values == null) {
      this.values = new HashMap<>();
    }
    this.values.put(key, value);
  }

  /**
   * returns the value of the key or null if the value do not exists
   *
   * @param key
   * @return
   */
  public Object getValue(String key) {
    if (this.values != null) {
      return this.values.get(key);
    }
    return null;
  }
}
