/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.i18n;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jsinterop.annotations.JsType;

/**
 * a locale holding all localizations
 *
 * @author Marcus Schumacher
 */
@JsType(namespace = "mov.sdk")
public class LocaleDSP implements Serializable {
  private static final long serialVersionUID = -1003828384360090749L;
  private List<LocalizationDSP> localizations = null;
  private List<LocalizationDSP> dblocalizations = null;

  public LocaleDSP() {}

  /**
   * generate the map of this locale
   *
   * @return
   */
  public Map<String, Object> toMap() {
    final Map<String, Object> map = new HashMap<String, Object>();
    if (this.localizations != null) {
      for (final LocalizationDSP localization : localizations) {
        localization.fillMap(map);
      }
    }
    return map;
  }

  /**
   * load the locale info from the db map
   *
   * @param map
   * @return
   */
  public static LocaleDSP fromMap(final Map<String, Object> map) {
    if (map == null) {
      return null;
    }
    LocaleDSP dsp = new LocaleDSP();
    for (final String key : map.keySet()) {
      if (key.startsWith(LocalizationDSP.FIELD_NAME)) {

        final LocalizationDSP localization = new LocalizationDSP();
        localization.putValues(map.get(key));
        localization.setSource("DB");
        dsp.addDBLocalization(localization);
      }
    }
    return dsp;
  }

  /**
   * add a new {@link LocalizationDSP}
   *
   * @param localization
   */
  public void addLocalization(final LocalizationDSP localization) {
    if (this.localizations == null) {
      this.localizations = new ArrayList<>();
    }
    this.localizations.add(localization);
  }

  /**
   * add a new {@link LocalizationDSP}
   *
   * @param localization
   */
  public void addDBLocalization(final LocalizationDSP localization) {
    if (this.dblocalizations == null) {
      this.dblocalizations = new ArrayList<>();
    }
    this.dblocalizations.add(localization);
  }

  /**
   * get all {@link LocalizationDSP}s
   *
   * @return
   */
  public List<LocalizationDSP> getLocalizations() {
    return this.localizations;
  }

  /**
   * set all {@link LocalizationDSP}s
   *
   * @param localizations
   */
  public void setLocalizations(final List<LocalizationDSP> localizations) {
    this.localizations = localizations;
  }

  /** @return the dblocalizations */
  public List<LocalizationDSP> getDblocalizations() {
    return dblocalizations;
  }

  /** @param dblocalizations the dblocalizations to set */
  public void setDblocalizations(List<LocalizationDSP> dblocalizations) {
    this.dblocalizations = dblocalizations;
  }

  @Override
  public String toString() {
    return "LocaleDSP [localizations="
        + localizations
        + ", dblocalizations="
        + dblocalizations
        + "]";
  }
}
