/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.relay;

import java.io.Serializable;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.relay")
public class RelayResponse implements Serializable {

  private static final long serialVersionUID = 1L;
  private int status;
  private String statusMessage;
  private long statusTimestamp;
  private String statusSource;
  private String statusValue;
  private String statusRecallId;

  public RelayResponse() {}

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  public String getStatusMessage() {
    return statusMessage;
  }

  public void setStatusMessage(String statusMessage) {
    this.statusMessage = statusMessage;
  }

  public long getStatusTimestamp() {
    return statusTimestamp;
  }

  public void setStatusTimestamp(long statusTimestamp) {
    this.statusTimestamp = statusTimestamp;
  }

  public String getStatusSource() {
    return statusSource;
  }

  public void setStatusSource(String statusSource) {
    this.statusSource = statusSource;
  }

  public String getStatusValue() {
    return statusValue;
  }

  public void setStatusValue(String statusValue) {
    this.statusValue = statusValue;
  }

  public String getStatusRecallId() {
    return statusRecallId;
  }

  public void setStatusRecallId(String statusRecallId) {
    this.statusRecallId = statusRecallId;
  }
}
