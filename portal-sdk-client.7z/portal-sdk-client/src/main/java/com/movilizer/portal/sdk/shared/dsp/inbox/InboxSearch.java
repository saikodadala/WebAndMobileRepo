/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.io.Serializable;
import java.util.HashMap;

import com.movilizer.portal.sdk.shared.paging.ResultPagination;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.inbox")
public class InboxSearch extends ResultPagination implements Serializable {

  private static final long serialVersionUID = 1L;
  private long fromDate = -1;
  private long tillDate = -1;
  private long systemId = -1;
  private int status = -1;
  private String source = null;
  private HashMap<String, String> predicates;

  public long getFromDate() {
    return this.fromDate;
  }

  public void setFromDate(long from) {
    this.fromDate = from;
  }

  public long getTillDate() {
    return this.tillDate;
  }

  public void setTillDate(long till) {
    this.tillDate = till;
  }

  public void setSystemId(long systemId) {
    this.systemId = systemId;
  }

  public long getSystemId() {
    return this.systemId;
  }

  public int getStatus() {
    return this.status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  public String getSource() {
    return this.source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public HashMap<String, String> getPredicates() {
    return this.predicates;
  }

  public String getPredicateValue(String key) {
    return this.predicates.get(key);
  }

  public void addPredicate(String key, String value) {
    if (this.predicates == null) {
      this.predicates = new HashMap<>();
    }
    if (value != null) {
      this.predicates.put(key, value);
    }
  }
}
