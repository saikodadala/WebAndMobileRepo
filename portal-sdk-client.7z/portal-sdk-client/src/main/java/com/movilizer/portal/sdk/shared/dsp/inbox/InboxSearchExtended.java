/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.util.ArrayList;
import java.util.List;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.inbox")
public class InboxSearchExtended extends InboxSearch {

  private static final long serialVersionUID = 1L;
  private String multiPredicateField;
  private List<String> multiPredicateValues;

  public String getMultiPredicateField() {
    return multiPredicateField;
  }

  public void setMultiPredicateField(String multiPredicateField) {
    this.multiPredicateField = multiPredicateField;
  }

  public List<String> getMultiPredicateValues() {
    return multiPredicateValues;
  }

  public void setMultiPredicateValues(List<String> multiPredicateValues) {
    this.multiPredicateValues = multiPredicateValues;
  }

  public void addMultiPredicateValue(String value) {
    if (this.multiPredicateValues == null) this.multiPredicateValues = new ArrayList<>();
    this.multiPredicateValues.add(value + "");
  }
}
