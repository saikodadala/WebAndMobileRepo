/*
 * Copyright (c) 2015-2021 Honeywell International Inc.
 * @date 04.02.2021
 */
package com.movilizer.portal.sdk.shared.ir.domain.constants;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.constants")
public class DataTypes {
  // Generic task types
  public static final String DATATYPE_BOOLEAN = "bool";
  public static final String DATATYPE_INTEGER = "int";
  public static final String DATATYPE_FLOAT = "float";
  public static final String DATATYPE_STRING = "string";
  public static final String DATATYPE_BINARY = "binary";
}
