/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.client.util;

public class LanguageUtil {

  public static final native String getBrowserLanguage() /*-{
	return navigator.language;
}-*/;
}
