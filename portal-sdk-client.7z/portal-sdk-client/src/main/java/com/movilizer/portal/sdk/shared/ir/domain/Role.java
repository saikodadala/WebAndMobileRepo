/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Role extends AbstractEntity {

  public static final String POOL_NAME = "Roles";

  private String name;
  private String permission;

  @Override
  public String poolName() {
    return Role.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPermission() {
    return this.permission;
  }

  public void setPermission(String permission) {
    this.permission = permission;
  }

  public void setCompact(String name, String permission) {
    this.name = name;
    this.permission = permission;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    ValidationUtils.validateStringProperty(res, "name", name, true, ValidationUtils.L_128);

    // MOVOR-5025
    ValidationUtils.validateIntegerProperty(res, "permission", this.permission, null);

    return res;
  }
}
