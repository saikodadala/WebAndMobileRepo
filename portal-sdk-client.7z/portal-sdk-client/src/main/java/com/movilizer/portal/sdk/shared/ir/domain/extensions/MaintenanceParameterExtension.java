package com.movilizer.portal.sdk.shared.ir.domain.extensions;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.extensions")
public abstract class MaintenanceParameterExtension {
  // Extension point for further maintenance options
}
