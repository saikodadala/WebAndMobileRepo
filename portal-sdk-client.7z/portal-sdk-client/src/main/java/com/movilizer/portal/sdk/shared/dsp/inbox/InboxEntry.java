/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.io.Serializable;
import java.util.HashMap;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.inbox")
public class InboxEntry implements Serializable {
  /**
   * !!Careful with getter renaming, Refer InboxEntryMixinAnnotations on how the csv export
   * references the fields
   */
  private static final long serialVersionUID = 1L;

  private String uuid;
  private long recordTime;
  private int status;
  private String statusMessage;
  private String statusValue;
  private String statusSource;
  private String recallId;
  private long systemId;

  private HashMap<String, Object> entryValues;
  private HashMap<String, String> targetStatus;

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  public long getRecordTime() {
    return recordTime;
  }

  public void setRecordTime(long recordTime) {
    this.recordTime = recordTime;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  public String getStatusMessage() {
    return statusMessage;
  }

  public void setStatusMessage(String statusMessage) {
    this.statusMessage = statusMessage;
  }

  public String getRecallId() {
    return this.recallId;
  }

  public void setRecallId(String recallID) {
    this.recallId = recallID;
  }

  public String getStatusValue() {
    return statusValue;
  }

  public void setStatusValue(String statusValue) {
    this.statusValue = statusValue;
  }

  public String getStatusSource() {
    return statusSource;
  }

  public void setStatusSource(String statusSource) {
    this.statusSource = statusSource;
  }

  public HashMap<String, String> getTargetStatus() {
    return targetStatus;
  }

  public void setTargetStatus(HashMap<String, String> targetStatus) {
    this.targetStatus = targetStatus;
  }

  public void addTargetStatus(String target, String status) {

    if (this.targetStatus == null) {
      this.targetStatus = new HashMap<String, String>();
    }
    if (status != null) {
      this.targetStatus.put(target, status);
    }
  }

  public HashMap<String, Object> getEntryValues() {
    return entryValues;
  }

  public void setEntryValues(HashMap<String, Object> entryValues) {
    this.entryValues = entryValues;
  }

  public void addEntryValue(String key, Object value) {

    if (this.entryValues == null) {
      this.entryValues = new HashMap<String, Object>();
    }
    if (value != null) {
      this.entryValues.put(key, value);
    }
  }

  public long getSystemId() {
    return systemId;
  }

  public void setSystemId(long systemId) {
    this.systemId = systemId;
  }
}
