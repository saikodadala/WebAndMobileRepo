/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import com.movilizer.portal.sdk.shared.ir.domain.constants.GroupConstants;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.common")
public abstract class AbstractEntity implements Validateable {

  public static final String NA = "N/A";
  protected transient Logger logger = Logger.getLogger(AbstractEntity.class.getName());

  public static GroupConstants groupConstants;

  protected String id; // unique!

  protected String group;

  protected String creatorType; // 16
  protected String creatorId; // 64
  protected Long created;

  protected String modifierType; // 16
  protected String modifierId; // 64
  protected Long modified;

  public static final String PROPERTY_NAME_BACKENDID = "backendId";
  protected String backendId; // length 128

  private HashMap<String, String> attachedProperties = new HashMap<>();

  private static ArrayList<String> reservedWords;
  private transient boolean isAbstract;

  @JsIgnore
  public List<String> reservedWords() {
    if (reservedWords == null) {
      reservedWords = new ArrayList<>();
      reservedWords.add("id");
      reservedWords.add("creatorType");
      reservedWords.add("creatorId");
      reservedWords.add("created");
      reservedWords.add("modifierType");
      reservedWords.add("modifierId");
      reservedWords.add("modified");
      reservedWords.add("parentPool");
      reservedWords.add("parentId");
      reservedWords.add("backendId");
      reservedWords.add("extendsId");
      reservedWords.add("attachedProperties");
      reservedWords.add("isAbstract");
    }
    return Collections.unmodifiableList(reservedWords);
  }

  public HashMap<String, String> getAttachedProperties() {
    return attachedProperties;
  }

  public void setAttachedProperties(HashMap<String, String> attachedProperties) {
    this.attachedProperties = attachedProperties;
  }

  @JsMethod
  public Set<String> keys() {
    return attachedProperties.keySet();
  }

  public String getAttachedPropertyValue(String key) {
    return attachedProperties.get(key);
  }

  public void addAttachedProperty(String key, String value) {
    this.attachedProperties.put(key, value);
  }

  public void removeAttachedProperty(String key) {
    this.attachedProperties.remove(key);
  }

  public String getId() {
    return this.id;
  }

  @JsIgnore
  public void setId(String id) {
    this.id = id;
  }

  public String getGroup() {
    return group;
  }

  public void setGroup(String group) {
    this.group = group;
  }

  public Long getCreated() {
    return created;
  }

  @JsIgnore
  public void setCreated(Long created) {
    this.created = created;
  }

  public Long getModified() {
    return modified;
  }

  @JsIgnore
  public void setModified(Long modified) {
    this.modified = modified;
  }

  public String getCreatorType() {
    return creatorType;
  }

  public String getModifierType() {
    return modifierType;
  }

  public void setModifierType(String modifierType) {
    this.modifierType = modifierType;
  }

  public String getModifierId() {
    return modifierId;
  }

  public void setModifierId(String modifierId) {
    this.modifierId = modifierId;
  }

  @JsIgnore
  public void setCreatorType(String creatorType) {
    this.creatorType = creatorType;
  }

  public String getCreatorId() {
    return creatorId;
  }

  @JsIgnore
  public void setCreatorId(String creatorId) {
    this.creatorId = creatorId;
  }

  public String getBackendId() {
    return this.backendId;
  }

  public void setBackendId(String backendid) {
    this.backendId = backendid;
  }

  public boolean isAbstract() {
    return isAbstract;
  }

  public void setAbstract(boolean anAbstract) {
    isAbstract = anAbstract;
  }

  @JsMethod
  public abstract String poolName();

  // MOVOR-4199
  @JsMethod
  public abstract String pool();

  @Override
  public ValidationResult validate() {
    ValidationResult res = new ValidationResult();

    /*this makes sure, there is never a pool name exceeding 17 characters. Therefore we can be sure about the pool name length, which is important when we concating relation ids.*/
    ValidationUtils.validateStringProperty(res, "poolName", poolName(), true, 17);

    ValidationUtils.validateStringProperty(
        res, "id", this.id, false, ValidationUtils.L_128, ValidationUtils.RESERVED_SYMBOLS);
    ValidationUtils.validateStringProperty(
        res, "creatorType", this.creatorType, false, ValidationUtils.XS_16);
    ValidationUtils.validateStringProperty(
        res, "creatorId", this.creatorId, false, ValidationUtils.M_64);
    ValidationUtils.validateStringProperty(
        res, "modifierType", this.modifierType, false, ValidationUtils.XS_16);
    ValidationUtils.validateStringProperty(
        res, "modifierId", this.modifierId, false, ValidationUtils.M_64);

    ValidationUtils.validateStringProperty(
        res, "backendId", this.backendId, false, ValidationUtils.L_128);
    ValidationUtils.validateMapProperty(
        res,
        "attachedProperties",
        this.attachedProperties,
        false,
        ValidationUtils.S_32,
        ValidationUtils.XXXL_1024);

    ValidationUtils.validateStringProperty(res, "filter1", filter1(), false, ValidationUtils.R_31);
    ValidationUtils.validateStringProperty(res, "filter2", filter2(), false, ValidationUtils.R_31);
    ValidationUtils.validateStringProperty(res, "filter3", filter3(), false, ValidationUtils.R_31);
    return res;
  }

  @JsIgnore
  @JsMethod
  public String filter1() {
    return null;
  }

  @JsIgnore
  @JsMethod
  public String filter2() {
    return null;
  }

  @JsIgnore
  @JsMethod
  public String filter3() {
    return null;
  }

  @JsIgnore
  @JsMethod
  public long filter4() {
    return 0L;
  }

  @JsIgnore
  @JsMethod
  public long filter5() {
    return 0L;
  }

  @JsIgnore
  @JsMethod
  public long filter6() {
    return 0L;
  }

  @JsIgnore
  @JsMethod
  public String key() {
    return this.id;
  }

  @JsIgnore
  @JsMethod
  public String group() {
    if (isAbstract && (this.group == null || this.group.trim().length() <= 0)) {
      return GroupConstants.MASTERDATA_GROUP_BROADCAST;
    }
    return group;
  }

  @JsIgnore
  @JsMethod
  public String desc() {
    return null;
  }
}
