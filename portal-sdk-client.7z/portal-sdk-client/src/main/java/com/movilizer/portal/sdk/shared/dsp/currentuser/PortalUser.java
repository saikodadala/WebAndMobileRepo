/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.currentuser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.movilizer.portal.domain.client.rights.PortalUserRole;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk", name = "PortalUser")
public class PortalUser {

  private String id;
  private String userName;
  private long systemID;
  private long fistWSSystemID;
  private String title;
  private String firstName;
  private String lastName;
  private byte authMode;
  private String language;
  private List<PortalUserRole> roles;
  private List<String> rights;
  private List<Long> webserviceSystems;
  private Map<Long, String> availableSystems;
  private List<String> adGroups;

  /**
   * **
   *
   * <p>DONT USE A CONSTRUCTOR IN A DSP CLASS!!!
   */
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public long getSystemID() {
    return systemID;
  }

  public void setSystemID(long systemID) {
    this.systemID = systemID;
  }

  public long getFistWSSystemID() {
    return fistWSSystemID;
  }

  public void setFistWSSystemID(long systemID) {
    this.fistWSSystemID = systemID;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getLanguage() {
    return language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }

  public byte getAuthMode() {
    return authMode;
  }

  public void setAuthMode(byte authMode) {
    this.authMode = authMode;
  }

  public List<PortalUserRole> getRoles() {
    return roles;
  }

  public void setRoles(List<PortalUserRole> roles) {
    this.roles = roles;
  }

  public void addRole(PortalUserRole role) {
    if (this.roles == null) {
      this.roles = new ArrayList<PortalUserRole>();
    }
    this.roles.add(role);
  }

  public void setWebServiceSystems(List<Long> systems) {
    this.webserviceSystems = systems;
  }

  public List<Long> getWebServiceSystems() {
    return this.webserviceSystems;
  }

  public void setWebserviceSystems(List<Long> webserviceSystems) {
    this.webserviceSystems = webserviceSystems;
  }

  public List<Long> getWebserviceSystems() {
    return webserviceSystems;
  }

  public void addSystem(long id, String name) {
    if (this.availableSystems == null) {
      this.availableSystems = new HashMap<Long, String>();
    }
    availableSystems.put(id, name);
  }

  public String getSystemNameById(long id) {
    if (!this.availableSystems.containsKey(id)) return "";
    return this.availableSystems.get(id);
  }

  public Map<Long, String> getAvailableSystems() {
    return this.availableSystems;
  }

  public void setAvailableSystems(Map<Long, String> availableSystems) {
    this.availableSystems = availableSystems;
  }

  public List<String> getRights() {
    return rights;
  }

  public void setRights(List<String> rights) {
    this.rights = rights;
  }

  public void addRight(String right) {
    if (this.rights == null) {
      this.rights = new ArrayList<String>();
    }
    this.rights.add(right);
  }

  public List<String> getAdGroups() {
    return adGroups;
  }

  public void setAdGroups(List<String> adGroups) {
    this.adGroups = adGroups;
  }
}
