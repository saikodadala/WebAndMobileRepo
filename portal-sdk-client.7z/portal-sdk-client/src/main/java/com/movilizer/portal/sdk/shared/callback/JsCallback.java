/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.callback;

import com.movilizer.portal.sdk.shared.paging.SdkRequestPagingState;
import com.movilizer.portal.sdk.shared.util.GwtUUID;

import jsinterop.annotations.JsConstructor;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk")
public class JsCallback<T> {

  JsOnSuccessFunction<T> succ;
  JsOnFailFunction fail;

  private String callbackId;
  private int pageSize = -1;

  @JsConstructor
  public JsCallback(JsOnSuccessFunction<T> succ, JsOnFailFunction fail) {
    this.succ = succ;
    this.fail = fail;
    this.callbackId = GwtUUID.uuid();
  }

  @JsMethod
  public void onSuccess(T o) {
    this.succ.exec(o);
  }

  @JsMethod
  public void onFailure(String msg) {
    this.fail.exec(msg);
  }

  public JsOnSuccessFunction<T> getSucc() {
    return succ;
  }

  public JsOnFailFunction getFail() {
    return fail;
  }

  public String getCallbackId() {
    return callbackId;
  }

  public int getPageSize() {
    return pageSize;
  }

  public void setPageSize(int pageSize) {
    this.pageSize = pageSize;
  }

  public void setCallbackId(String callbackId) {
    this.callbackId = callbackId;
  }
}
