/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.common")
public abstract class AttachedEntity extends ExtendableEntity {

  public static final String PROPERTY_NAME_PARENTID = "parentId";

  // 31 //without default value, it won't validate in JS, values get overwritten in
  // backend
  protected String parentPool = NA;

  // 31 //without default value, it won't validate in JS, values get overwritten in
  // backend
  protected String parentId = NA;

  public String getParentPool() {
    return parentPool;
  }

  @JsIgnore
  public void setParentPool(String pool) {
    this.parentPool = pool;
  }

  public String getParentId() {
    return parentId;
  }

  public void setParentId(String id) {
    this.parentId = id;
  }

  @Override
  @JsIgnore
  @JsMethod
  public String filter1() {
    return this.parentPool;
  }

  @Override
  @JsIgnore
  @JsMethod
  public String filter2() {
    return this.parentId;
  }
}
