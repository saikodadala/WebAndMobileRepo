/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.inbox")
public class InboxImportResult implements Serializable {

  private String index; // uuid
  private Integer errorCode;
  private List<String> entryUuid;
  private Boolean success;

  public InboxImportResult() {
    this.errorCode = 200;
    this.success = true;
  }

  public String getIndex() {
    return this.index;
  }

  public void setIndex(String index) {
    this.index = index;
  }

  public Integer getErrorCode() {
    return this.errorCode;
  }

  public void setErrorCode(Integer errorCode) {
    this.errorCode = errorCode;
  }

  public List<String> getEntryUuid() {
    return this.entryUuid;
  }

  public void addEntryUuid(String uuid) {
    if (this.entryUuid == null) this.entryUuid = new ArrayList<String>();
    this.entryUuid.add(uuid);
  }

  public void setEntryUuid(List<String> uuid) {
    this.entryUuid = uuid;
  }

  public Boolean getSuccess() {
    return this.success;
  }

  public void setSuccess(Boolean success) {
    this.success = success;
  }
}
