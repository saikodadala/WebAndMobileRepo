package com.movilizer.portal.sdk.shared.dsp.customersystem;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.customer")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private Integer graceDays;
	private Integer warningDays;
	private String billingRefID;
	private Long expiryDate;
	private Long validTillDate;
	private String salesEmail;
	private String supportEmail;
	private String customerType;
	private boolean subscriptionReady;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getGraceDays() {
		return graceDays;
	}

	public void setGraceDays(Integer graceDays) {
		this.graceDays = graceDays;
	}

	public Integer getWarningDays() {
		return warningDays;
	}

	public void setWarningDays(Integer warningDays) {
		this.warningDays = warningDays;
	}

	public String getBillingRefID() {
		return billingRefID;
	}

	public void setBillingRefID(String billingRefID) {
		this.billingRefID = billingRefID;
	}

	public Long getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Long expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Long getValidTillDate() {
		return validTillDate;
	}

	public void setValidTillDate(Long validTillDate) {
		this.validTillDate = validTillDate;
	}

	public String getSalesEmail() {
		return salesEmail;
	}

	public void setSalesEmail(String salesEmail) {
		this.salesEmail = salesEmail;
	}

	public String getSupportEmail() {
		return supportEmail;
	}

	public void setSupportEmail(String supportEmail) {
		this.supportEmail = supportEmail;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public boolean isSubscriptionReady() {
		return subscriptionReady;
	}

	public void setSubscriptionReady(boolean subscriptionReady) {
		this.subscriptionReady = subscriptionReady;
	}

	@Override
	public String toString() {
		return "CustomerDetails [id=" + id + ", graceDays=" + graceDays + ", warningDays=" + warningDays
				+ ", billingRefID=" + billingRefID + ", expiryDate=" + expiryDate + ", validTillDate=" + validTillDate
				+ ", salesEmail=" + salesEmail + ", supportEmail=" + supportEmail + ", customerType=" + customerType
				+ ", subscriptionReady=" + subscriptionReady + "]";
	}

}
