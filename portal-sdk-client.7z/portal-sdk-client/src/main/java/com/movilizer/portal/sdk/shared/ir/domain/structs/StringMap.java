/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.structs;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.structs")
public class StringMap {

  private String name;
  private HashMap<String, String> backingMap = new HashMap<>();

  public String getName() {
    return name;
  }

  @JsIgnore
  public void setName(String name) {
    this.name = name;
  }

  public HashMap<String, String> getBackingMap() {
    return backingMap;
  }

  public Set<String> keySet() {
    return backingMap.keySet();
  }

  public Collection<String> values() {
    return backingMap.values();
  }

  public Set<Map.Entry<String, String>> entrySet() {
    return backingMap.entrySet();
  }

  public String get(String key) {
    return backingMap.get(key);
  }

  @JsIgnore
  public void setBackingMap(HashMap<String, String> backingMap) {
    this.backingMap = backingMap;
  }

  @JsIgnore
  public void clear() {
    backingMap.clear();
  }

  @JsIgnore
  public boolean containsKey(Object key) {
    return backingMap.containsKey(key);
  }

  @JsIgnore
  public boolean containsValue(Object value) {
    return backingMap.containsValue(value);
  }

  @JsIgnore
  public String put(String key, String value) {
    return backingMap.put(key, value);
  }

  @JsIgnore
  public void putAll(Map<String, String> map) {
    this.backingMap.putAll(map);
  }

  @JsIgnore
  public String remove(String key) {
    return backingMap.remove(key);
  }
}
