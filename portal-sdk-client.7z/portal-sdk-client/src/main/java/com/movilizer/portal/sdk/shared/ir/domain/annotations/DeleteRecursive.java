/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * * DeleteRecursive specifies entities that can be deleted together with the one having this
 * annotation. During the deletion process related entities of the ones specfied in DeleteRecursive
 * will be deleted.
 *
 * @author H225706
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface DeleteRecursive {
  String[] entities();
}
