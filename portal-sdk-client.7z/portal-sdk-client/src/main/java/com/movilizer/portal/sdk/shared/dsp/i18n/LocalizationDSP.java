/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.i18n;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import jsinterop.annotations.JsType;

/**
 * DSD localization values localization values contain date, time format as well as textual
 * customization
 *
 * @author Marcus Schumacher
 */
@JsType(namespace = "mov.sdk")
public class LocalizationDSP implements Serializable {
  private static final long serialVersionUID = 610812675892801741L;

  @SuppressWarnings("unusable-by-js")
  public static String FIELD_NAME = "LOCALIZATION_FIELDS";

  // is this localization from the DB or from a properties file
  private String source;
  private String module;

  private String language;

  // the localizati0on values
  private Map<String, String> fields;

  public LocalizationDSP() {}

  /**
   * fill the map for the DB with the values of this object
   *
   * @param map
   */
  public void fillMap(Map<String, Object> map) {
    if (this.fields == null) {
      this.fields = new HashMap<>();
    }
    fields.put("#lang#", language);
    fields.put("#module#", module);
    String fieldName = FIELD_NAME + "_" + module.toUpperCase() + "_" + language.toUpperCase();
    map.put(fieldName, fields);
  }

  /**
   * put the map values from the DB to this object
   *
   * @param object
   */
  public void putValues(Object object) {
    if (object instanceof Map) {
      if (this.fields == null) {
        this.fields = new HashMap<>();
      }
      this.fields = (Map<String, String>) object;
      this.language = fields.get("#lang#");
      this.module = fields.get("#module#");
      this.fields.remove("#lang#");
      this.fields.remove("#module#");
    }
  }

  /**
   * get a localization value
   *
   * @param key
   * @return
   */
  public String getValue(String key) {
    if (this.fields == null) {
      return null;
    }
    return fields.get(key);
  }

  /**
   * add a new value to the localization map but be aware of the used keys, as they need to be
   * systemwide the same
   *
   * @param key
   * @param value
   */
  public void addValue(String key, String value) {
    if (this.fields == null) {
      this.fields = new HashMap<>();
    }
    this.fields.put(key, value);
  }

  /**
   * get the language of this localization
   *
   * @return
   */
  public String getLanguage() {
    return language;
  }

  /**
   * set the language of this localization
   *
   * @param language
   */
  public void setLanguage(String language) {
    this.language = language;
  }

  /**
   * is the source of this localization a properties file or the DB
   *
   * @return
   */
  public String getSource() {
    return source;
  }

  /**
   * set the source of this localization (DB, or propertiesFile
   *
   * @param source is either 'DB' or 'PROP'
   */
  public void setSource(String source) {
    this.source = source;
  }

  /**
   * for which module is this localization
   *
   * @return
   */
  public String getModule() {
    return module;
  }

  /**
   * set the module of this localization
   *
   * @param module
   */
  public void setModule(String module) {
    this.module = module;
  }

  public Map<String, String> getFields() {
    return fields;
  }

  public void setFields(Map<String, String> fields) {
    this.fields = fields;
  }

  @Override
  public String toString() {
    return "LocalizationDSP [source="
        + source
        + ", module="
        + module
        + ", language="
        + language
        + ", fields="
        + fields
        + "]";
  }
}
