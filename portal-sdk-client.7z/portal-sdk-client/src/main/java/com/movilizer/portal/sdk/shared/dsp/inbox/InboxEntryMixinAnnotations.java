/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
// @JsonIgnore - to ignore fields
// @JsonUnwrapped - for nested POJOs to unwrap
// @JsonProperty to rename

public abstract class InboxEntryMixinAnnotations {

  @JsonProperty("UUID")
  public abstract String getUuid();

  @JsonProperty("RECORD_TIME")
  public abstract long getRecordTime();

  @JsonProperty("STATUS")
  public abstract int getStatus();

  @JsonProperty("STATUS_MESSAGE")
  public abstract String getStatusMessage();

  @JsonProperty("STATUS_VALUE")
  public abstract String getStatusValue();

  @JsonProperty("STATUS_SOURCE")
  public abstract String getStatusSource();

  @JsonProperty("RECALL_ID")
  public abstract String getRecallId();

  @JsonAnyGetter
  public abstract HashMap<String, Object> getEntryValues();

  @JsonProperty("SYSTEM_ID")
  public abstract long getSystemId();
}
