/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 20.09.2021
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

import com.movilizer.portal.sdk.shared.ir.domain.Asset;
import com.movilizer.portal.sdk.shared.ir.domain.Category;
import com.movilizer.portal.sdk.shared.ir.domain.Task;

public class RelationValidator {

  public static boolean isTaskChildOfAssetOrAbstractAssetOrCategory(
      final Task task, final Asset asset, final Asset abstractAsset, final Category category) {
    final boolean isDirectChild =
        task != null && asset != null && task.getParentId().equals(asset.getId());
    final boolean isIndirectChild =
        task != null && abstractAsset != null && task.getParentId().equals(abstractAsset.getId());
    final boolean belongsToCategoryOfAsset =
        task != null
            && asset != null
            && category != null
            && asset.listCategories().contains(category.getId());
    final boolean belongsToCategoryOfAbstractAsset =
        task != null
            && abstractAsset != null
            && category != null
            && abstractAsset.listCategories().contains(category.getId());
    return isDirectChild
        || isIndirectChild
        || belongsToCategoryOfAsset
        || belongsToCategoryOfAbstractAsset;
  }
}
