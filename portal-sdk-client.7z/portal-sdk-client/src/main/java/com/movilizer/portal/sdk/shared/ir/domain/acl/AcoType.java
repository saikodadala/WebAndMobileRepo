/*
 * Copyright (c) 2015-2021 Honeywell International Inc.
 *  @date Sep 13, 2021
 */

package com.movilizer.portal.sdk.shared.ir.domain.acl;

import java.util.Set;

public class AcoType {

  public static class AcoAction {
    private final String id;
    private String name;

    public AcoAction(String id, String name) {
      this.id = id;
      this.name = name;
    }

    public String getId() {
      return id;
    }

    public String getName() {
      return name;
    }
  }

  public static final AcoAction ACO_RESERVED_ACTION_ANY =
      new AcoAction("*ACL_RESERVED_ACTION_ANY", "*ACL_RESERVED_ACTION_ANY");

  private String id;
  private Set<AcoAction> actions;

  public AcoType(String id, Set<AcoAction> actions) {
    this.id = id;
    this.actions = actions;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Set<AcoAction> getActions() {
    return actions;
  }

  public void setActions(Set<AcoAction> actions) {
    this.actions = actions;
  }
}
