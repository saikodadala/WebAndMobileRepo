/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
/*relation is not an attached entity, because it already defines a relation, therefore is already attached*/

public class Relation extends AbstractEntity {
  public static final String POOL_NAME = "Relations";

  public static final String LEFT_HASMANY_RIGHT = "LhasR"; // DO NOT CHANGE! Used in MAF Scripts!
  public static final String LEFT_BELONGSTOMANY_RIGHT =
      "LbelongsToR"; // DO NOT CHANGE! Used in MAF Scripts!

  public static final String LEFT_ISINHERITEDBY_RIGHT =
      "RexL"; // DO NOT CHANGE! Used in MAF Scripts! right extends left

  public static final String LEFT_APPLIES_RIGHT =
      "LappR"; // DO NOT CHANGE! Used in MAF Scripts! right is applied by left

  public static final String LEFT_IS_REQUIRED_BY_RIGHT =
      "LisReqByR"; // DO NOT CHANGE! Used in MAF Scripts! right is required by left
  public static final String LEFT_REQUIRES_RIGHT =
      "LreqR"; // DO NOT CHANGE! Used in MAF Scripts! right is required by left
  public static final String LEFT_CONTAINS_RIGHT = "LaddedForR";

  private String leftPool; // max 31, mandatory
  private String leftId; // max 31, mandatory

  private String rightPool; // max 31, mandatory
  private String
      rightId; // max 512, mandatory (not all entities have 31 character ids, e.g. user, device)

  // The type field may define the type of relationship, e.g. belongsTo or
  // employedBy or partOf. Therefore giving the relation a semantic. Currently defaults to
  // BELONGS_TO
  private String type;

  @Override
  public String poolName() {
    return POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public void setCompact(String leftPool, String leftId, String rightPool, String rightId) {
    this.leftPool = leftPool;
    this.leftId = leftId;
    this.rightPool = rightPool;
    this.rightId = rightId;
  }

  public String getLeftPool() {
    return leftPool;
  }

  public void setLeftPool(String leftPool) {
    this.leftPool = leftPool;
  }

  public String getLeftId() {
    return leftId;
  }

  public void setLeftId(String leftId) {
    this.leftId = leftId;
  }

  public String getRightPool() {
    return rightPool;
  }

  public void setRightPool(String rightPool) {
    this.rightPool = rightPool;
  }

  public String getRightId() {
    return rightId;
  }

  public void setRightId(String rightId) {
    this.rightId = rightId;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  @Override
  @JsIgnore
  @JsMethod
  public String filter1() {
    return this.getLeftPool();
  }

  @Override
  @JsIgnore
  @JsMethod
  public String filter2() {
    return this.getLeftId();
  }

  @Override
  @JsIgnore
  @JsMethod
  public String filter3() {
    return this.getRightPool();
  }

  @Override
  @JsIgnore
  @JsMethod
  public String desc() {
    return this.getRightId();
  }

  @Override
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    ValidationUtils.validateStringProperty(
        res, "leftPool", this.leftPool, true, ValidationUtils.R_31);
    ValidationUtils.validateStringProperty(res, "leftId", this.leftId, true, ValidationUtils.R_31);

    ValidationUtils.validateStringProperty(
        res, "rightPool", this.rightPool, true, ValidationUtils.R_31);
    ValidationUtils.validateStringProperty(
        res, "rightId", this.rightId, true, ValidationUtils.XXL_512);
    ValidationUtils.validateStringProperty(res, "type", this.type, true, ValidationUtils.R_31);
    return res;
  }

  @Override
  public String toString() {
    return "Relation: [leftPool:"
        + leftPool
        + ", leftId:"
        + leftId
        + ", rightPool:"
        + rightPool
        + ", rightId:"
        + rightId
        + "]";
  }
}
