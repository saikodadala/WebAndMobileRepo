/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.constants;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir")
public class AclConstants {

  /**
   * Examples
   *
   * <p>AclPermission::AROs|Groups|SUPERVISOR::ACOs|PropertyValues|Issues|status|PENDING -> The maf
   * index name of a acl group permission index for the ACO that represents an Issue status with
   * value "PENDING".
   *
   * <p>AclPermission:AROs|1234567890ß::ACOs|PropertyValues|Issues|status|PENDING -> The maf index
   * name of a acl user permission index for the ACO that represents an Issue status with value
   * "PENDING".
   */

  // special values
  /**
   * Can be used e.g. to set a permission from a null value to some other value e.g. for ACO:
   * Issue.status=null
   */
  public static final String ACL_NULL_VALUE = "ACL_NULL_VALUE";

  /** Basically a wildcard for any value */
  public static final String ACL_RESERVED_ACTION_ANY = "*ACL_RESERVED_ACTION_ANY";

  // delimiters
  public static final String ACL_MAFIDX_NAME_CONCAT_DELIMITER = "::";
  public static final String ACL_ACOARO_CONCAT_DELIMITER = "|";

  // prefixes
  public static final String ACL_ARO_PREFIX = "ARO";
  public static final String ACL_ACO_PREFIX = "ACO";
  public static final String ACL_ACOTYPE_PREFIX = "ACOTYPE";
  public static final String ACL_ACO_PREFIX_PROPERTY_VALUES =
      ACL_ACO_PREFIX + ACL_ACOARO_CONCAT_DELIMITER + "PropertyValues";
  public static final String ACL_ARO_USER_PREFIX =
      ACL_ARO_PREFIX + ACL_ACOARO_CONCAT_DELIMITER + "U" + AclConstants.ACL_ACOARO_CONCAT_DELIMITER;
  public static final String ACL_ACOTYPE_ENTITY_PROPERTY_PREFIX =
      ACL_ACOTYPE_PREFIX + ACL_ACOARO_CONCAT_DELIMITER + "EntityProperty";

  // ARO TYPES
  public static final String ACL_ARO_TYPE_USER = "user";
  public static final String ACL_ARO_TYPE_GROUP = "group";
  public static final String ACL_ARO_TYPE_IDP_GROUP = "idp_group";
  public static final String ACL_ARO_TYPE_PORTAL_ROLE = "portal_role";

  private AclConstants() {}

  public static final String acoForEntityPropertyValue(
      String entity, String property, String fromValue) {
    StringBuilder sb = new StringBuilder();
    sb.append(
        AclConstants.ACL_ACO_PREFIX_PROPERTY_VALUES
            + AclConstants.ACL_ACOARO_CONCAT_DELIMITER
            + entity
            + AclConstants.ACL_ACOARO_CONCAT_DELIMITER
            + property);
    if (fromValue != null) sb.append(AclConstants.ACL_ACOARO_CONCAT_DELIMITER + fromValue);
    return sb.toString();
  }

  public static final String acoTypeForEntityProperty(String entity, String property) {
    StringBuilder sb = new StringBuilder();
    sb.append(
        AclConstants.ACL_ACOTYPE_ENTITY_PROPERTY_PREFIX
            + AclConstants.ACL_ACOARO_CONCAT_DELIMITER
            + entity
            + AclConstants.ACL_ACOARO_CONCAT_DELIMITER
            + property);

    return sb.toString();
  }

  public static String aroForUser(String user) {
    return AclConstants.ACL_ARO_USER_PREFIX + user;
  }
}
