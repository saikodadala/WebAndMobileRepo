/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.constants;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.constants")
public class MimeTypes {
  public static final String APPLICATION_JSON = "application/json";
  public static final String APPLICATION_PDF = "application/pdf";
  public static final String TEXT_XML = "text/xml";
  public static final String TEXT_HTML = "text/html";
  public static final String TEXT_PLAIN = "text/plain";
  public static final String IMAGE_JPEG = "image/jpeg";
  public static final String IMAGE_JPG = "image/jpg";
  public static final String IMAGE_PNG = "image/png";
  public static final String IMAGE_GIF = "image/gif";
}
