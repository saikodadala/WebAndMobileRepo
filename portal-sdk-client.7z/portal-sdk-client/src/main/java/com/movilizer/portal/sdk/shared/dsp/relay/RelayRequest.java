/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.relay;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.relay")
public class RelayRequest implements Serializable {

  private static final long serialVersionUID = 1L;
  private String uuid;
  private long systemId;
  private Map<String, Boolean> destinations;
  private List<String> manyUuids;

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  public long getSystemId() {
    return systemId;
  }

  public void setSystemId(long systemId) {
    this.systemId = systemId;
  }

  public Map<String, Boolean> getDestinations() {
    return destinations;
  }

  public void setManyUuids(List<String> manyuuids) {
    this.manyUuids = manyuuids;
  }

  public List<String> getManyUuids() {
    return manyUuids;
  }

  public void setDestinations(Map<String, Boolean> destinations) {
    this.destinations = destinations;
  }

  public void addDestination(String key, boolean value) {
    if (this.destinations == null) {
      this.destinations = new HashMap<String, Boolean>();
    }
    this.destinations.put(key, value);
  }

  public void addUuid(String uuid) {
    if (this.manyUuids == null) {
      this.manyUuids = new ArrayList<String>();
    }
    this.manyUuids.add(uuid);
  }
}
