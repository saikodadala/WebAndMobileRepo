/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */

package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.io.Serializable;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.inbox")
public class InboxMessageStatistic implements Serializable {

  private int unrpocessed;
  private int pending;
  private int success;
  private int failure;
  private int recalled;
  private int warning;
  private String messageType;

  public void setUnprocessed(int value) {
    this.unrpocessed = value;
  }

  public void setPending(int value) {
    this.pending = value;
  }

  public void setSuccess(int value) {
    this.success = value;
  }

  public void setFailure(int value) {
    this.failure = value;
  }

  public void setRecalled(int value) {
    this.recalled = value;
  }

  public void setWarning(int value) {
    this.warning = value;
  }

  public void setMessageType(String value) {
    this.messageType = value;
  }

  public int getUnprocessed() {
    return this.unrpocessed;
  }

  public int getPending() {
    return this.pending;
  }

  public int getSuccess() {
    return this.success;
  }

  public int getFailure() {
    return this.failure;
  }

  public int getRecalled() {
    return this.recalled;
  }

  public int getWarning() {
    return this.warning;
  }

  public String getMessageType() {
    return this.messageType;
  }
}
