/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;

import jsinterop.annotations.JsMethod;

public class CollectionUtils {

  @JsMethod(namespace = "mov.sdk.util")
  public static <T> LinkedHashSet<T> createSet() {
    return new LinkedHashSet<>();
  }

  @JsMethod(namespace = "mov.sdk.util")
  public static <T> ArrayList<T> createList() {
    return new ArrayList<>();
  }

  @JsMethod(namespace = "mov.sdk.util")
  public static <T> Map<String, T> createMap() {
    return new HashMap<>();
  }
}
