/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp;

import java.util.HashMap;
import java.util.Map;

public class SdkResponse {
  private long systemId;
  private Map<String, Object> values;
  private String result;

  public long getSystemId() {
    return systemId;
  }

  public void setSystemId(long systemId) {
    this.systemId = systemId;
  }

  public Map<String, Object> getValues() {
    return values;
  }

  public void setValues(Map<String, Object> values) {
    this.values = values;
  }

  public void addValue(String key, Object value) {
    if (this.values == null) {
      this.values = new HashMap<>();
    }
    this.values.put(key, value);
  }

  public Object getValue(String key) {
    if (this.values != null) {
      this.values.get(key);
    }
    return null;
  }

  public String getResult() {
    return result;
  }

  public void setResult(String result) {
    this.result = result;
  }
}
