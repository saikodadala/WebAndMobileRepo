/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Device extends AttachedEntity {

  public static final String POOL_NAME = "Devices";
  // id taken from address

  private String name;
  private String address; // ALSO USED AS ID IN CASSANDRA and in column description
  private String type = "phone";

  @Override
  public String poolName() {
    return Device.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  // Device.address is used as unique id (will not be generated uuid)
  @Override
  public String getId() {
    return this.address;
  }
  // Device.address is used as unique id (will not be generated uuid)
  @Override
  public void setId(String id) {
    this.id = id;
    this.address = id;
  }

  /**
   * this method is just there for backward compatibility with R2
   *
   * @return
   */
  // @Deprecated
  @JsonIgnore
  public String getLevelId() {
    return this.parentId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.id = address;
    this.address = address;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public void setCompact(String levelId, String name, String address, String type) {

    this.parentId = levelId;
    this.parentPool = Level.POOL_NAME;

    this.name = name;
    this.address = address;
    this.id = address;
    this.type = type;
  }

  @Override
  @JsIgnore
  @JsMethod
  public String desc() {
    return this.getAddress();
  }

  @Override
  @JsMethod
  public ValidationResult validate() {

    ValidationResult res = super.validate();
    // required
    ValidationUtils.validateStringProperty(
        res, "name", name, true, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res,
        "address",
        address,
        true,
        ValidationUtils.L_128,
        null,
        this); // address is used as key in cassandra MUST BE SET

    // optional
    ValidationUtils.validateStringProperty(
        res, "type", type, false, ValidationUtils.S_32, null, this);

    return res;
  }
}
