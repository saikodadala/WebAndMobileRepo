/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.inbox")
public class InboxExport implements Serializable {

  private InboxSearch inboxSearch;
  private String recipient;
  private List<String> fields;

  public void setInboxSearch(InboxSearch search) {
    this.inboxSearch = search;
  }

  public InboxSearch getInboxSearch() {
    return this.inboxSearch;
  }

  public void setRecipient(String recipient) {
    this.recipient = recipient;
  }

  public String getRecipient() {
    return this.recipient;
  }

  public void addField(String field) {
    if (this.fields == null) {
      this.fields = new ArrayList<String>();
    }
    if (!this.fields.contains(field)) this.fields.add(field);
  }

  public List<String> getFields() {
    return this.fields;
  }

  public void setFields(List<String> fields) {
    this.fields = fields;
  }
}
