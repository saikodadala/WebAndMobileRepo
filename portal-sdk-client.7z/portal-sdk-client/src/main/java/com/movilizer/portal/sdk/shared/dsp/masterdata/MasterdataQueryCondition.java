/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.masterdata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.masterdata")
public class MasterdataQueryCondition implements Serializable {

  private static final long serialVersionUID = -2990194359523013029L;
  private String pool;
  private String group;
  private List<String> groups;
  private List<String> excludeGroups;
  private String key;
  private String language;
  private long systemId;
  private boolean listReferences = true;
  private boolean listOnlyReferences = false;
  private boolean searchFullContent = true;
  private String searchConditions;
  private int limit;

  public String getPool() {
    return this.pool;
  }

  public void setPool(String pool) {
    this.pool = pool;
  }

  public String getGroup() {
    return this.group;
  }

  public void setGroup(String group) {
    this.group = group;
  }

  public String getKey() {
    return this.key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public String getLanguage() {
    return this.language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }

  public long getSystemId() {
    return this.systemId;
  }

  public void setSystemId(long systemId) {
    this.systemId = systemId;
  }

  public List<String> getExcludeGroups() {
    return this.excludeGroups;
  }

  public void setExcludeGroups(List<String> excludeGroups) {
    this.excludeGroups = excludeGroups;
  }

  public void addExcludeGroup(String groupStartsWith) {
    if (this.excludeGroups == null) {
      this.excludeGroups = new ArrayList<>();
    }
    this.excludeGroups.add(groupStartsWith);
  }

  public boolean isListReferences() {
    return listReferences;
  }

  public void setListReferences(boolean listReferences) {
    this.listReferences = listReferences;
  }

  public List<String> getGroups() {
    return groups;
  }

  public void setGroups(List<String> groups) {
    this.groups = groups;
  }

  public void addGroup(String group) {
    if (this.groups == null) {
      this.groups = new ArrayList<>();
    }
    this.groups.add(group);
  }

  public boolean isListOnlyReferences() {
    return listOnlyReferences;
  }

  public void setListOnlyReferences(boolean listOnlyReferences) {
    this.listOnlyReferences = listOnlyReferences;
  }

  public String getSearchConditions() {
    return searchConditions;
  }

  public void setSearchConditions(String searchConditions) {
    this.searchConditions = searchConditions;
  }

  public int getLimit() {
    return limit;
  }

  public void setLimit(int limit) {
    this.limit = limit;
  }

  public boolean isSearchFullContent() {
    return searchFullContent;
  }

  public void setSearchFullContent(boolean searchFullContent) {
    this.searchFullContent = searchFullContent;
  }
}
