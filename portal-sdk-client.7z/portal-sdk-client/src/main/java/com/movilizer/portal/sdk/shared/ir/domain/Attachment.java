/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;
import com.movilizer.portal.sdk.shared.ir.domain.constants.MimeTypes;

import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Attachment extends AttachedEntity {

  public static final String POOL_NAME = "Attachments";
  public static MimeTypes mimeTypes;

  private String name;
  private String description;
  private String mimeType;
  private String data; // max 5 MB

  @Override
  public String poolName() {
    return POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getData() {
    return data;
  }

  public void setData(String data) {
    this.data = data;
  }

  public String getMimeType() {
    return mimeType;
  }

  public void setMimeType(String mimeType) {
    this.mimeType = mimeType;
  }

  public void setCompact(String name, String data, String mimeType) {
    this.name = name;
    this.data = data;
    this.mimeType = mimeType;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();
    // madatory
    ValidationUtils.validateStringProperty(
        res, "name", this.name, true, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "mimeType", this.mimeType, true, ValidationUtils.M_64, null, this);
    ValidationUtils.validateStringProperty(
        res, "data", this.data, true, ValidationUtils.BASE64_MAX, null, this);

    // optional
    ValidationUtils.validateStringProperty(
        res, "description", this.description, false, ValidationUtils.XXXL_1024, null, this);

    return res;
  }
}
