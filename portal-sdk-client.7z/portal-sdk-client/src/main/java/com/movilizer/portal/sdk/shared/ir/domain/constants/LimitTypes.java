/*
 * Copyright (c) 2015-2021 Honeywell International Inc.
 * @date 04.02.2021
 */
package com.movilizer.portal.sdk.shared.ir.domain.constants;

import java.util.HashSet;
import java.util.Set;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.constants")
public class LimitTypes {
  public static final String HIGH = "high";
  public static final String LOW = "low";
  public static final String VALIDATION_FLOAT = "VAL_F";
  public static final String VALIDATION_INTEGER = "VAL_I";
  public static final String VALIDATION_STRING = "VAL_S";

  private static Set<String> limitType = new HashSet<String>();

  static {
    limitType.add(HIGH);
    limitType.add(LOW);
    limitType.add(VALIDATION_FLOAT);
    limitType.add(VALIDATION_INTEGER);
    limitType.add(VALIDATION_STRING);
  }

  public static boolean isLimitType(final String limitType) {
    return limitType.contains(limitType);
  }

  public static Set<String> getLimitTypes() {
    return new HashSet<>(limitType);
  }
}
