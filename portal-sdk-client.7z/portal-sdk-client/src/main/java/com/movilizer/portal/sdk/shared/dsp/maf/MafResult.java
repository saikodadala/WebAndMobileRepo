/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.maf;

import java.io.Serializable;

public class MafResult implements Serializable {

  private static final long serialVersionUID = 7403533460744449090L;
  private String result;
  private MafData dataEntry;
  private MafIndexEntry indexEntry;

  public String getResult() {
    return result;
  }

  public void setResult(String result) {
    this.result = result;
  }

  public MafData getDataEntry() {
    return dataEntry;
  }

  public void setDataEntry(MafData dataEntry) {
    this.dataEntry = dataEntry;
  }

  public MafIndexEntry getIndexEntry() {
    return indexEntry;
  }

  public void setIndexEntry(MafIndexEntry indexEntry) {
    this.indexEntry = indexEntry;
  }
}
