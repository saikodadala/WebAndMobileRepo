/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.LinkedHashSet;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;
import com.movilizer.portal.sdk.shared.ir.domain.structs.Pointer;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(
    property = RoundTemplate.PROPERTY_NAME_NAME,
    groupByProperty = AttachedEntity.PROPERTY_NAME_PARENTID)
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class RoundTemplate extends AttachedEntity {

  public static final String POOL_NAME = "RoundTemplates";

  public static final String PROPERTY_NAME_NAME = "name";
  private String name;
  private String gracePeriod;
  private String category;

  private LinkedHashSet<Pointer> onEnter;
  private LinkedHashSet<Pointer> onLeave;

  private LinkedHashSet<String>
      taskIds; // contains all selected task ids of all assigned assets. This is for internal
  // processing only. To avoid recursive calls
  private LinkedHashSet<String> assetIds;

  @Override
  public String poolName() {
    return RoundTemplate.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  //  @Deprecated
  @JsonIgnore
  public String getLevelId() {
    return this.parentId;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public LinkedHashSet<Pointer> getonEnter() {
    return this.onEnter;
  }

  public void setonEnter(LinkedHashSet<Pointer> onEnter) {
    this.onEnter = onEnter;
  }

  public void addOnEnter(Pointer onEnter) {
    if (this.onEnter == null) this.onEnter = new LinkedHashSet<>();
    this.onEnter.add(onEnter);
  }

  public void removeOnEnter(Pointer pointer) {
    Pointer pointerToBeRemoved = null;
    if (this.onEnter != null) {
      for (Pointer ptr : this.onEnter) {
        if (ptr.getPool().equals(pointer.getPool()) && ptr.getId().equals(pointer.getId())) {
          pointerToBeRemoved = ptr;
          break;
        }
      }
      this.onEnter.remove(pointerToBeRemoved);
    }
  }

  public LinkedHashSet<Pointer> getonLeave() {
    return this.onLeave;
  }

  public void setonLeave(LinkedHashSet<Pointer> onLeave) {
    this.onLeave = onLeave;
  }

  public void addOnLeave(Pointer onLeave) {
    if (this.onLeave == null) this.onLeave = new LinkedHashSet<>();
    this.onLeave.add(onLeave);
  }

  public void removeOnLeave(Pointer onLeave) {
    if (this.onLeave != null) this.onLeave.remove(onLeave);
  }

  public void addonLeave(LinkedHashSet<Pointer> onLeave) {
    if (this.onLeave == null) this.onLeave = new LinkedHashSet<>();
    this.onLeave.addAll(onLeave);
  }

  public void removeonLeave(LinkedHashSet<Pointer> onLeave) {
    if (this.onLeave != null) this.onLeave.removeAll(onLeave);
  }

  public LinkedHashSet<String> getTaskIds() {
    return this.taskIds;
  }

  public void setTaskIds(LinkedHashSet<String> taskIds) {
    this.taskIds = taskIds;
  }

  public void addTaskId(String taskId) {
    if (this.taskIds == null) this.taskIds = new LinkedHashSet<>();
    this.taskIds.add(taskId);
  }

  public void removeTaskId(String taskId) {
    if (this.taskIds != null) this.taskIds.remove(taskId);
  }

  public void addTaskIds(LinkedHashSet<String> taskIds) {
    if (this.taskIds == null) this.taskIds = new LinkedHashSet<>();
    this.taskIds.addAll(taskIds);
  }

  public void removeTaskIds(LinkedHashSet<String> taskIds) {
    if (this.taskIds != null) this.taskIds.removeAll(taskIds);
  }

  public LinkedHashSet<String> getAssetIds() {
    return this.assetIds;
  }

  @JsIgnore
  public void setAssetIds(LinkedHashSet<String> assetIds) {
    this.assetIds = assetIds;
  }

  public void addAssetId(String assetId) {
    if (this.assetIds == null) this.assetIds = new LinkedHashSet<>();
    this.assetIds.add(assetId);
  }

  public void addAssetIds(LinkedHashSet<String> assetIds) {
    if (this.assetIds == null) this.assetIds = new LinkedHashSet<>();
    this.assetIds.addAll(assetIds);
  }

  public void removeAssetId(String assetId) {
    if (assetIds != null) assetIds.remove(assetId);
  }

  public String getGracePeriod() {
    return this.gracePeriod;
  }

  public void setGracePeriod(String endOfGrace) {
    this.gracePeriod = endOfGrace;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public void setCompact(String levelId, String name, String gracePeriod) {
    this.parentId = levelId;
    this.parentPool = Level.POOL_NAME;
    this.name = name;
    this.gracePeriod = gracePeriod;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();
    // mandatory
    ValidationUtils.validateStringProperty(
        res, "name", name, true, ValidationUtils.L_128, null, this);

    // optional
    ValidationUtils.validateStringProperty(
        res, "category", category, false, ValidationUtils.M_64, null, this);
    if (onEnter != null) {
      for (Pointer p : onEnter) ValidationUtils.validateValidateable(res, "onEnter", p, false);
    }
    if (onLeave != null) {
      for (Pointer p : onLeave) ValidationUtils.validateValidateable(res, "onLeave", p, false);
    }

    // MOVOR-5025
    ValidationUtils.validateIntegerProperty(res, "gracePeriod", this.gracePeriod, this);

    return res;
  }
}
