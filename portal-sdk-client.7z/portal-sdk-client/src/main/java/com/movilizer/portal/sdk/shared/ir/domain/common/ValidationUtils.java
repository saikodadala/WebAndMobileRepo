/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

import java.util.Map;
import java.util.Set;

import com.movilizer.portal.sdk.shared.ir.domain.constants.Operators;
import com.movilizer.portal.sdk.shared.ir.domain.structs.Pointer;
import com.movilizer.portal.sdk.shared.ir.domain.structs.PointerSequence;

public class ValidationUtils {

  public static final int XS_16 = 16;
  public static final int R_31 = 31; // length restriction for filter columns is 31 characters
  public static final int S_32 = 32;
  public static final int M_64 = 64;
  public static final int L_128 = 128;
  public static final int XL_256 = 256;
  public static final int XXL_512 = 512;
  public static final int XXXL_1024 = 1024;
  public static final int BASE64_MAX = 1024 * 1024 * 5; // MiB

  public static final String[] RESERVED_SYMBOLS =
      new String[] {Pointer.SYMBOL, PointerSequence.SYMBOL};

  public static boolean validateValidateable(
      ValidationResult res, String propertyName, Validateable object, boolean required) {
    if (required && object == null) {
      res.addValidationMessage("property '" + propertyName + "' is required, but was not set");
      return false;
    }
    if (!required && object == null) {
      return true;
    }

    final ValidationResult validationResult = object.validate();
    if (object != null && !validationResult.isValid()) {
      res.addValidationMessage(
          "property '"
              + propertyName
              + "' did not validate: "
              + validationResult.getValidationMessages().toString());

      return false;
    }

    return true;
  }

  public static boolean validateStringProperty(
      ValidationResult res, String propertyName, String value, boolean required, int maxlength) {
    if (required && (value == null || value.trim().isEmpty())) {
      res.addValidationMessage("property '" + propertyName + "' is required, but was not set");
      return false;
    }

    if (required && value != null && value.trim().isEmpty()) {
      res.addValidationMessage("property '" + propertyName + "' is required, but an empty string");
      return false;
    }

    if (value != null && value.length() > maxlength) {
      res.addValidationMessage(
          "property '"
              + propertyName
              + "' exceeds maximum character limit of "
              + maxlength
              + ". Invalid value: "
              + value);
      return false;
    }
    return true;
  }

  public static boolean validateStringProperty(
      ValidationResult res,
      String propertyName,
      String value,
      boolean required,
      int maxlength,
      String[] forbiddenTexts) {

    if (value != null && forbiddenTexts != null) {
      for (String forbiddenText : forbiddenTexts) {
        if (value.contains(forbiddenText)) {
          res.addValidationMessage(
              "property '"
                  + propertyName
                  + "' contains forbidden char sequence "
                  + "'"
                  + forbiddenText
                  + "'");
          return false;
        }
      }
    }

    return validateStringProperty(res, propertyName, value, required, maxlength);
  }

  public static boolean validateStringProperty(
      ValidationResult res,
      String propertyName,
      String value,
      boolean required,
      int maxlength,
      String regex,
      AbstractEntity entity) {

    if (required
        && (value == null || value.trim().isEmpty())
        && (entity instanceof ExtendableEntity)
        && (((ExtendableEntity) entity).getExtendsId() != null
            && !((ExtendableEntity) entity).getExtendsId().trim().isEmpty())) {
      return true;
    }

    if (value != null && regex != null) {
      if (!value.matches(regex)) {
        res.addValidationMessage(
            "property '" + propertyName + "' does not match the expected pattern " + regex);
        return false;
      }
    }

    return validateStringProperty(res, propertyName, value, required, maxlength);
  }

  public static boolean validateMapProperty(
      ValidationResult res,
      String propertyName,
      Map<String, String> mp,
      boolean required,
      int keyMaxlength,
      int valueMaxlength) {
    if (required && mp == null) {
      res.addValidationMessage("property '" + propertyName + "' is required, but was not set");
      return false;
    }

    if (mp != null && !mp.isEmpty()) {
      for (Map.Entry<String, String> entry : mp.entrySet()) {
        if (entry.getKey().length() > keyMaxlength) {
          res.addValidationMessage(
              "property '"
                  + propertyName
                  + "' exceeds maximum character limit for key of "
                  + keyMaxlength
                  + ". Invalid key: "
                  + entry.getKey());
          return false;
        }
        if (entry.getValue().length() > valueMaxlength) {
          res.addValidationMessage(
              "property '"
                  + propertyName
                  + "' exceeds maximum character limit for value of "
                  + valueMaxlength
                  + ". Invalid value: "
                  + entry.getValue());
          return false;
        }
      }
    }
    return true;
  }

  public static boolean validateSetProperty(
      ValidationResult res,
      String propertyName,
      Set<String> set,
      boolean required,
      int valueMaxlength) {
    if (required && set == null) {
      res.addValidationMessage("property '" + propertyName + "' is required, but was not set");
      return false;
    }

    if (set != null && !set.isEmpty()) {
      for (String entry : set) {
        if (entry.length() > valueMaxlength) {
          res.addValidationMessage(
              "property '"
                  + propertyName
                  + "' exceeds maximum character limit for value of "
                  + valueMaxlength
                  + ". Invalid value: "
                  + entry);
          return false;
        }
      }
    }
    return true;
  }

  // MOVOR-5025 : added to do the allowed value check for the converted datatypes, since everything
  // is a string now
  public static boolean validateBooleanProperty(
      ValidationResult res,
      String propertyName,
      String value,
      boolean required,
      AbstractEntity entity) {
    if (required
        && (value == null || value.trim().isEmpty())
        && (entity instanceof ExtendableEntity)
        && (((ExtendableEntity) entity).getExtendsId() != null
            && !((ExtendableEntity) entity).getExtendsId().trim().isEmpty())) {
      return true;
    }

    if (required && value == null) {
      res.addValidationMessage("property '" + propertyName + "' is required, but was not set");
      return false;
    }
    if (value != null && !(value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false"))) {
      res.addValidationMessage(
          "property '" + propertyName + "' is not a valid Boolean value. Invalid value: " + value);
      return false;
    }
    return true;
  }

  // this method checks if 'operator' is a constant defined in Operators class
  public static boolean validateOperator(ValidationResult res, String operator, boolean required) {
    if (required && operator == null) {
      res.addValidationMessage("operator is required, but was not set");
      return false;
    }

    if (operator != null && !Operators.isOperator(operator)) {
      res.addValidationMessage(
          "Operator '"
              + operator
              + "' is not a valid operator. Valid operators are "
              + Operators.getOperators().toString());
      return false;
    }
    return true;
  }

  public static boolean validateDoubleProperty(
      ValidationResult res, String propertyName, String value, AbstractEntity entity) {
    return validateDoubleProperty(
        res,
        propertyName,
        value,
        false,
        (double) Integer.MIN_VALUE,
        (double) Integer.MAX_VALUE,
        entity);
  }

  public static boolean validateDoubleProperty(
      ValidationResult res,
      String propertyName,
      String value,
      boolean required,
      Double min,
      Double max,
      AbstractEntity entity) {

    if (required
        && (value == null || value.trim().isEmpty())
        && (entity instanceof ExtendableEntity)
        && (((ExtendableEntity) entity).getExtendsId() != null
            && !((ExtendableEntity) entity).getExtendsId().trim().isEmpty())) {
      return true;
    }

    Double parsedValue = null;
    if (required && value == null) {
      res.addValidationMessage("property '" + propertyName + "' is required, but was not set");
      return false;
    }
    if (value != null) {
      try {
        parsedValue = Double.parseDouble(value);
      } catch (NumberFormatException ex) {
        res.addValidationMessage(
            "property '"
                + propertyName
                + "' is not a valid float/double value.  Invalid value: "
                + value);

        return false;
      }

      if (parsedValue > max) {
        res.addValidationMessage(
            "property '"
                + propertyName
                + "' exceeds maximum of "
                + max
                + ". Invalid value: "
                + value);

        return false;
      }
      if (parsedValue < min) {
        res.addValidationMessage(
            "property '"
                + propertyName
                + "' is below minimum of "
                + min
                + ". Invalid value: "
                + value);
        return false;
      }
    }

    return true;
  }

  public static boolean validateIntegerProperty(
      ValidationResult res, String propertyName, String value, AbstractEntity entity) {
    return validateIntegerProperty(
        res,
        propertyName,
        value,
        false,
        (long) Integer.MIN_VALUE,
        (long) Integer.MAX_VALUE,
        entity);
  }

  public static boolean validateIntegerProperty(
      ValidationResult res,
      String propertyName,
      String value,
      boolean required,
      Long min,
      Long max,
      AbstractEntity entity) {

    if (required
        && (value == null || value.trim().isEmpty())
        && (entity instanceof ExtendableEntity)
        && (((ExtendableEntity) entity).getExtendsId() != null
            && !((ExtendableEntity) entity).getExtendsId().trim().isEmpty())) {
      return true;
    }

    Long parsedValue = null;
    if (required && value == null) {
      res.addValidationMessage("property '" + propertyName + "' is required, but was not set");
      return false;
    }

    if (value != null) {
      try {
        parsedValue = Long.parseLong(value);
      } catch (NumberFormatException ex) {
        res.addValidationMessage(
            "property '"
                + propertyName
                + "' is not a valid integer/long value.  Invalid value: "
                + value);

        return false;
      }

      if (parsedValue > max) {
        res.addValidationMessage(
            "property '"
                + propertyName
                + "' exceeds maximum of "
                + max
                + ". Invalid value: "
                + value);

        return false;
      }
      if (parsedValue < min) {
        res.addValidationMessage(
            "property '"
                + propertyName
                + "' is below minimum of "
                + min
                + ". Invalid value: "
                + value);
        return false;
      }
    }

    return true;
  }
}
