/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.util;

import java.util.ArrayList;
import java.util.List;

public class StringUtil {
  public static String convertListIntoString(final List<String> list, final String separator) {
    final StringBuilder sb = new StringBuilder();

    if (list != null && !list.isEmpty()) {
      for (int i = 0; i < list.size() - 1; i++) {
        sb.append(list.get(i));
        sb.append(separator);
      }
      sb.append(list.get(list.size() - 1));
    }

    return sb.toString();
  }

  public static List<String> convertStringIntoList(final String string, final String separator) {
    final List<String> list = new ArrayList<>();
    for (final String token : string.split(separator)) {
      if (!StringUtil.isBlank(token)) {
        list.add(token.trim());
      }
    }
    return list;
  }

  public static boolean isBlank(final String... str) {
    if (str == null) {
      return true;
    }
    for (final String string : str) {
      if (string != null && !"".equals(string.trim())) {
        return false;
      }
    }
    return true;
  }

  /** Returns true iff all String are Empty or null */
  public static boolean isEmpty(final String... str) {
    if (str == null) {
      return true;
    }
    for (final String string : str) {
      if (string != null && string.length() > 0) {
        return false;
      }
    }
    return true;
  }

  public static boolean valueChanged(final String oldValue, final String newValue) {
    if (oldValue == null && newValue == null) {
      return false;
    }
    if (oldValue == null) {
      return true;
    }
    return !oldValue.equals(newValue);
  }

  public static String convertIntoSortableString(final Integer value, final int minLength) {
    String string;
    final boolean negative = value != null && value < 0;

    if (value == null) {
      string = "0";
    } else {
      if (!negative) {
        string = value.toString();
      } else {
        string = value.toString().substring(1); // remove minus
      }
    }
    for (int i = string.length(); i < minLength; i++) {
      string = "0" + string;
    }
    if (negative) {
      return "-" + string;
    }
    return string;
  }

  public static String reduceStringTo(
      final String textToReduce, final int maxLenght, final String postFix) {
    if (textToReduce == null || textToReduce.length() <= maxLenght) {
      return textToReduce;
    }

    if (postFix != null) {
      if (maxLenght - postFix.length() <= 0) {
        return postFix;
      }
      final int stringReduceLength = maxLenght - postFix.length();
      return textToReduce.substring(0, stringReduceLength).trim() + postFix;

    } else {

      final String result = textToReduce.substring(0, maxLenght);
      return result.trim();
    }
  }

  public static final String formatPercent(final long part, final long whole) {

    final boolean isPossible = whole >= 0;
    final double onePercent = (double) whole / 100;
    if (!isPossible) {
      return "--";
    } else {
      final double ret = (double) Math.round(part / onePercent * 100) / 100;
      return ret + " %";
    }
  }

  public static boolean checkMinLength(final String text, final int minLength) {
    return !(text == null || text.trim().length() < minLength);
  }

  public static int compare(final String str1, final String str2) {
    if (str1 != null && str2 == null) {
      return 1;
    } else if (str2 != null && str1 == null) {
      return -1;
    } else if (str1 != null) {
      return str1.compareTo(str2);
    } else {
      return 0;
    }
  }

  public static boolean containsAny(final String str, final String... searchString) {
    if (str == null || searchString == null) {
      return false;
    }
    for (final String string : searchString) {
      if (str.contains(string)) {
        return true;
      }
    }
    return false;
  }

  public static boolean containsAny(final String str, final List<String> searchStrings) {
    if (str == null || searchStrings == null) {
      return false;
    }
    return containsAny(str, searchStrings.toArray(new String[searchStrings.size()]));
  }

  public static boolean endsWith(final String str, final String end) {
    if (str == null || end == null) {
      return false;
    }
    return str.trim().toLowerCase().endsWith(end.toLowerCase());
  }

  public static boolean equals(final String str1, final String str2) {
    return compare(str1, str2) == 0;
  }

  public static String repeat(String string, int fak) {
    final StringBuilder sb = new StringBuilder();
    for (int i = 0; i < fak; i++) {
      sb.append(string);
    }
    return sb.toString();
  }
}
