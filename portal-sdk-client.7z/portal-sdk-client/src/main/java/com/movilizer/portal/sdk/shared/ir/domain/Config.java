/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Config extends AttachedEntity {

  public static final String POOL_NAME = "Configurations";

  // id required, maxlength 60 <-- maxlength in config specific

  private HashMap<String, String> keyValuePairs = new HashMap<>();

  @Override
  public String poolName() {
    return Config.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public void setKeyValuePairs(HashMap<String, String> pairs) {
    this.keyValuePairs = pairs;
  }

  public HashMap<String, String> getKeyValuePairs() {
    return keyValuePairs;
  }

  @JsMethod
  public Set<String> keys() {
    return keyValuePairs.keySet();
  }

  public String getValue(String key) {
    return keyValuePairs.get(key);
  }

  public void addKeyValuePair(String key, String value) {
    this.keyValuePairs.put(key, value);
  }

  public void removeKeyValuePair(String key) {
    this.keyValuePairs.remove(key);
  }

  /** Needs to be made accessible in JS, because config id can be set freely */
  @Override
  public void setId(String id) {
    super.setId(id);
  }

  public void mergeFrom(Config config, boolean overwrite) {
    if (overwrite) {
      for (Map.Entry<String, String> entry : config.getKeyValuePairs().entrySet())
        this.addKeyValuePair(entry.getKey(), entry.getValue());
    } else {
      for (Map.Entry<String, String> entry : config.getKeyValuePairs().entrySet()) {
        if (!this.keyValuePairs.containsKey(entry.getKey()))
          this.addKeyValuePair(entry.getKey(), entry.getValue());
      }
    }
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();
    ValidationUtils.validateStringProperty(
        res, "id", this.id, true, 60, null,
        this); // id MUST be set, because it is used as ID in cassandra. Also id must not be
    // longer than 60, because otherwise relation id to this config will exceed 128.

    for (int i = 0; i < reservedWords().size(); i++) {
      if (keyValuePairs.containsKey(reservedWords().get(i)))
        res.addValidationMessage(
            "The string "
                + reservedWords().get(i)
                + " cannot be used as a key inside a configuration, because it is a reserved term");
    }

    for (Map.Entry<String, String> e : keyValuePairs.entrySet()) {
      if (e.getKey().length() > ValidationUtils.XXL_512)
        res.addValidationMessage(
            "Key \"" + e.getKey() + "\" exceeds maximum length of " + ValidationUtils.XXL_512);
      if (e.getValue().length() > ValidationUtils.XXXL_1024)
        res.addValidationMessage(
            "Value \""
                + e.getValue()
                + "\" exceeds maximum length of "
                + ValidationUtils.XXXL_1024);
    }

    return res;
  }
}
