/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.paging;

import java.util.HashMap;
import java.util.Map;

public class SdkRequestPagingState {

  public static final String PAGED_LIMIT = "Paged-Limit";
  public static final String PAGED_VALUE = "Paged-Value";
  public static final String SEARCHQUERY = "SEARCHQUERY";
  private String id;
  private long offset;
  private String pagingState;
  private int limit = 100;
  private HashMap<String, String> entries = new HashMap<String, String>();
  private HashMap<String, Long> multiOffset = new HashMap<String, Long>();
  private Map<String, String> upperLowerCaseNameMapper = new HashMap<>();

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public long getOffset() {
    return offset;
  }

  public void setOffset(long offset) {
    this.offset = offset;
  }

  public int getLimit() {
    return limit;
  }

  public void setLimit(int limit) {
    this.limit = limit;
  }

  public HashMap<String, String> getEntries() {
    return entries;
  }

  public void setEntries(HashMap<String, String> entries) {
    this.entries = entries;
  }

  public void addEntry(String key, String value) {
    this.entries.put(key, value);
  }

  public HashMap<String, Long> getMultiOffset() {
    return multiOffset;
  }

  public void setMultiOffset(HashMap<String, Long> multiOffset) {
    this.multiOffset = multiOffset;
  }

  public void addMultiOffset(String key, Long value) {
    String origName = upperLowerCaseNameMapper.get(key.toLowerCase());
    if (origName == null) {
      this.upperLowerCaseNameMapper.put(key.toLowerCase(), key);
    } else {
      key = origName;
    }
    this.multiOffset.put(key, value);
  }

  public String getPagingState() {
    return pagingState;
  }

  public void setPagingState(String pagingState) {
    this.pagingState = pagingState;
  }
}
