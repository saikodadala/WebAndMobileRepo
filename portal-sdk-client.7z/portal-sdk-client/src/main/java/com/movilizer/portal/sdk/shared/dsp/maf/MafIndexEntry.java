/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.maf;

import java.util.ArrayList;
import java.util.List;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.mafdata")
public class MafIndexEntry {

  private String key;
  private long systemId;
  private byte[] ref;
  private List<Object> partitionKeyParts;
  private Object value;
  private String additionalMessage;

  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public long getSystemId() {
    return systemId;
  }

  public void setSystemId(long systemId) {
    this.systemId = systemId;
  }

  public byte[] getRef() {
    return ref;
  }

  public void setRef(byte[] ref) {
    this.ref = ref;
  }

  public List<Object> getPartitionKeyParts() {
    return partitionKeyParts;
  }

  public void setPartitionKeyParts(List<Object> partitionKeyParts) {
    this.partitionKeyParts = partitionKeyParts;
  }

  public void addPartionKeyPart(Object part) {
    if (this.partitionKeyParts == null) {
      this.partitionKeyParts = new ArrayList<>();
    }
    this.partitionKeyParts.add(part);
  }

  public Object getValue() {
    return value;
  }

  public void setValue(Object value) {
    this.value = value;
  }

  public String getAdditionalMessage() {
    return additionalMessage;
  }

  public void setAdditionalMessage(String additionalMessage) {
    this.additionalMessage = additionalMessage;
  }
}
