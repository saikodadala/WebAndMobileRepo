/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 26.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.LinkedHashSet;
import java.util.Set;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Schedule extends AttachedEntity {

  public static final String POOL_NAME = "Schedules";

  private String name;

  private String cronExpression; // holding the cron expression for scheduling
  private String active; // if false, the round is suspended
  private String duration;

  /* groups that should be able to execute the round (round is hidden for users not in one of these groups) */
  private Set<String> groups = new LinkedHashSet<>();
  private String validFrom; // schedule is valid from this point on
  private String validTo; // schedule is valid up to this point

  @Override
  public String poolName() {

    return POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCronExpression() {
    return cronExpression;
  }

  public void setCronExpression(String cronExpression) {
    this.cronExpression = cronExpression;
  }

  public String isActive() {
    return active;
  }

  public void setActive(String active) {
    this.active = active;
  }

  public String getDuration() {
    return duration;
  }

  public void setDuration(String duration) {
    this.duration = duration;
  }

  public Set<String> getGroups() {
    return groups;
  }

  @JsIgnore
  public void setGroups(Set<String> groups) {
    this.groups = groups;
  }

  public void addGroup(String group) {
    this.groups.add(group);
  }

  public void removeGroup(String group) {
    this.groups.remove(group);
  }

  public String getValidFrom() {
    return validFrom;
  }

  public void setValidFrom(String validFrom) {
    this.validFrom = validFrom;
  }

  public String getValidTo() {
    return validTo;
  }

  public void setValidTo(String validTo) {
    this.validTo = validTo;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    // required
    // max length of a cron expression apparently can be 999 characters
    ValidationUtils.validateStringProperty(
        res,
        "cronExpression",
        this.cronExpression,
        true,
        ValidationUtils.XXXL_1024,
        null,
        this);

    // MOVOR-5025
    ValidationUtils.validateBooleanProperty(res, "active", this.active, false, this);
    ValidationUtils.validateIntegerProperty(res, "duration", this.duration, this);
    ValidationUtils.validateIntegerProperty(res, "validFrom", this.validFrom, this);
    ValidationUtils.validateIntegerProperty(res, "validTo", this.validTo, this);

    return res;
  }
}
