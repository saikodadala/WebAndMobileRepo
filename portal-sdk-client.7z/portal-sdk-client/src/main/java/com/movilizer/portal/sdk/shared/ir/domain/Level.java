/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.LinkedHashSet;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;
import com.movilizer.portal.sdk.shared.ir.domain.core.AppGroup;
import com.movilizer.portal.sdk.shared.ir.domain.structs.Polygon;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
@Index(property = Level.PROPERTY_NAME_NAME, groupByProperty = AttachedEntity.PROPERTY_NAME_PARENTID)
public class Level extends AttachedEntity {

  public static final String POOL_NAME = "Levels";

  // constant used for index
  public static final String PROPERTY_NAME_NAME = "name";
  private String name;
  private String type;
  private String timezone;

  private Polygon geographicalArea; //  format: decimal_lat;decimal_long;decimal_alt::repeat...

  private AppGroup appGroup;

  private LinkedHashSet<String> assetIds;
  private LinkedHashSet<String> userIds;
  private LinkedHashSet<String> roundTemplateIds;
  private LinkedHashSet<String> levelIds;
  private LinkedHashSet<String> deviceIds;
  private LinkedHashSet<String> workflowIds;

  @Override
  public String poolName() {
    return Level.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getTimezone() {
    return this.timezone;
  }

  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  public Polygon getGeographicalArea() {
    return geographicalArea;
  }

  public void setGeographicalArea(Polygon area) {
    this.geographicalArea = area;
  }

  public AppGroup getAppGroup() {
    return appGroup;
  }

  public void setAppGroup(AppGroup appGroup) {
    this.appGroup = appGroup;
  }

  @JsIgnore
  public LinkedHashSet<String> getAssetIds() {
    return this.assetIds;
  }

  @JsIgnore
  public void setAssetIds(LinkedHashSet<String> assetIds) {
    this.assetIds = assetIds;
  }

  @JsIgnore
  public void addAssetId(String assetId) {
    if (this.assetIds == null) this.assetIds = new LinkedHashSet<>();
    this.assetIds.add(assetId);
  }

  @JsIgnore
  public void removeAssetId(String assetId) {
    if (this.assetIds != null) this.assetIds.remove(assetId);
  }

  @JsIgnore
  public LinkedHashSet<String> getUserIds() {
    return this.userIds;
  }

  @JsIgnore
  public void setUserIds(LinkedHashSet<String> userIds) {
    this.userIds = userIds;
  }

  @JsIgnore
  public void addUserId(String userId) {
    if (this.userIds == null) this.userIds = new LinkedHashSet<>();
    this.userIds.add(userId);
  }

  @JsIgnore
  public void removeUserId(String userId) {
    if (this.userIds != null) this.userIds.remove(userId);
  }

  @JsIgnore
  public LinkedHashSet<String> getDeviceIds() {
    return this.deviceIds;
  }

  @JsIgnore
  public void setDeviceIds(LinkedHashSet<String> deviceIds) {
    this.deviceIds = deviceIds;
  }

  @JsIgnore
  public void addDeviceId(String deviceId) {
    if (this.deviceIds == null) this.deviceIds = new LinkedHashSet<>();
    this.deviceIds.add(deviceId);
  }

  @JsIgnore
  public void removeDeviceId(String deviceId) {
    if (this.deviceIds != null) this.deviceIds.remove(deviceId);
  }

  @JsIgnore
  public LinkedHashSet<String> getRoundTemplateIds() {
    return this.roundTemplateIds;
  }

  @JsIgnore
  public void setRoundTemplateIds(LinkedHashSet<String> roundTemplateIds) {
    this.roundTemplateIds = roundTemplateIds;
  }

  @JsIgnore
  public void addRoundTemplateId(String roundTemplateId) {
    if (this.roundTemplateIds == null) this.roundTemplateIds = new LinkedHashSet<>();
    this.roundTemplateIds.add(roundTemplateId);
  }

  @JsIgnore
  public void removeRoundTemplateId(String roundTemplateId) {
    if (this.roundTemplateIds != null) this.roundTemplateIds.remove(roundTemplateId);
  }

  @JsIgnore
  public LinkedHashSet<String> getWorkflowIds() {
    return this.workflowIds;
  }

  @JsIgnore
  public void setWorkflowIds(LinkedHashSet<String> workflowIds) {
    this.workflowIds = workflowIds;
  }

  @JsIgnore
  public void addWorkflowId(String workflowId) {
    if (this.workflowIds == null) this.workflowIds = new LinkedHashSet<>();
    this.workflowIds.add(workflowId);
  }

  @JsIgnore
  public void removeWorkflowId(String workflowId) {
    if (this.workflowIds != null) this.workflowIds.remove(workflowId);
  }

  @JsIgnore
  public LinkedHashSet<String> getLevelIds() {
    return this.levelIds;
  }

  @JsIgnore
  public void setLevelIds(LinkedHashSet<String> childIds) {
    this.levelIds = childIds;
  }

  @JsIgnore
  public void addLevelId(String childId) {
    if (this.levelIds == null) this.levelIds = new LinkedHashSet<>();
    this.levelIds.add(childId);
  }

  @JsIgnore
  public void removeLevelId(String childId) {
    if (this.levelIds != null) this.levelIds.remove(childId);
  }

  public void setCompact(String parentId, String name, String type, String timezone) {
    this.parentId = parentId;
    this.parentPool = Level.POOL_NAME;
    this.name = name;
    this.type = type;
    this.timezone = timezone;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    // mandatory
    ValidationUtils.validateStringProperty(
        res, "name", name, true, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "timezone", timezone, true, ValidationUtils.S_32, null, this);

    // not mandatory
    ValidationUtils.validateValidateable(res, "geographicalArea", this.geographicalArea, false);
    ValidationUtils.validateValidateable(res, "appGroup", this.appGroup, false);
    ValidationUtils.validateStringProperty(
        res,
        "parentId",
        this.parentId,
        false,
        ValidationUtils.R_31,
        null,
        this); // can be null, will be attached to root level then
    ValidationUtils.validateStringProperty(
        res, "type", type, false, ValidationUtils.L_128, null, this);

    return res;
  }
}
