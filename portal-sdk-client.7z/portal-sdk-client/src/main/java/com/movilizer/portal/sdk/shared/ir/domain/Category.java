/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
@Index(property = Category.PROPERTY_NAME)
public class Category extends AttachedEntity {

  public static final String POOL_NAME = "Categories";

  public static final String PROPERTY_NAME = "name";
  private String name;

  @Override
  public String poolName() {
    return POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();
    // mandatory
    ValidationUtils.validateStringProperty(res, "name", this.name, true, ValidationUtils.L_128);
    // optional

    return res;
  }
}
