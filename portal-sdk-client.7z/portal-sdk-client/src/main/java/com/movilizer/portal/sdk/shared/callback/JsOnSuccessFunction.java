/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.callback;

import jsinterop.annotations.JsFunction;

@FunctionalInterface
@JsFunction
public interface JsOnSuccessFunction<T> {
  void exec(T o); // the name of this method seems to have no meaning at all. The interface itself
  // represents the method...(?)
}
