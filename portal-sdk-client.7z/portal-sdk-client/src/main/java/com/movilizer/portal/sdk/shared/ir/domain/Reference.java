/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Reference extends AttachedEntity {
  public static final String POOL_NAME = "References";

  private String targetPool;
  private String targetId;

  private String name;

  @Override
  public String poolName() {
    return POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getTargetPool() {
    return targetPool;
  }

  public void setTargetPool(String targetPool) {
    this.targetPool = targetPool;
  }

  public String getTargetId() {
    return targetId;
  }

  public void setTargetId(String targetId) {
    this.targetId = targetId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setCompact(String targetPool, String targetId) {
    this.targetPool = targetPool;
    this.targetId = targetId;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    ValidationUtils.validateStringProperty(
        res, "targetPool", targetPool, true, ValidationUtils.R_31, null, this);
    ValidationUtils.validateStringProperty(
        res, "targetId", targetId, true, ValidationUtils.XXL_512, null, this);

    ValidationUtils.validateStringProperty(
        res, "name", name, false, ValidationUtils.L_128, null, this);

    return res;
  }
}
