/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.movilizer.portal.sdk.shared.ir.domain.PropertySnapshot;

/**
 * @author H225706 TraceProperties will be observed. Whenever they change, the change is stored as a
 *     {@link PropertySnapshot}.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface TraceProperties {
  String[] properties();
}
