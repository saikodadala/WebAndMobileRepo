/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.constants;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.constants")
public class RegexConstants {
  public static final String NUMBER = "((\\-)?([0-9]+))";
  public static final String FLOATING_NUMBER = "((\\-)?([0-9]+\\.?[0-9]+))";
}
