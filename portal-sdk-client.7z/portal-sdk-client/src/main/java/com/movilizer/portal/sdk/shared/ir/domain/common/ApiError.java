/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.common")
public class ApiError {

  private String message;
  private String debugMessage;
  private String stacktrace;
  private String code;

  @JsIgnore
  public void setMessage(String message) {
    this.message = message;
  }

  public String getMessage() {
    return message;
  }

  @JsIgnore
  public void setStacktrace(String msg) {
    this.stacktrace = msg;
  }

  public String getStacktrace() {
    return this.stacktrace;
  }

  @JsIgnore
  public void setDebugMessage(String debugMessage) {
    this.debugMessage = debugMessage;
  }

  public String getDebugMessage() {
    return debugMessage;
  }

  public String getCode() {
    return code;
  }

  @JsIgnore
  public void setCode(String code) {
    this.code = code;
  }
}
