/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.constants;

public class RelationConstants {
  public static final String RELATIONS_MAFIDX_NAME_CONCAT_DELIMITER = "_";
  public static final String RELATIONS_MAFIDX_NAME_MAPPING = "HFIR_RELATION_MAPPING";
}
