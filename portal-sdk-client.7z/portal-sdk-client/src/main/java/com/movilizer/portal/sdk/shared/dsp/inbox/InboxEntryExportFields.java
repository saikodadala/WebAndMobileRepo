/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class InboxEntryExportFields {
  // nested maps not supported
  private static List<String> getMessageFieldIds() {
    return Arrays.asList(
        "STATUS",
        "RECORD_TIME",
        "EVENT_TIME",
        "MESSAGE_TYPE",
        "F_ID",
        "EO_ID",
        "COMMENT",
        "USER_ID",
        "SUMMARY",
        "TRANSPORT_VEHICLE",
        "ORDER_NUMBER",
        "ORDER_DATE",
        "REF_DOCS_LINK",
        "UP_UIS",
        "REF_DOC");
  }

  // nested maps not supported
  private static List<String> getOrderMessageFieldIds() {
    return Arrays.asList(
        "MESSAGE_TYPE",
        "ORDER_NUMBER",
        "ORDER_DATE",
        "REF_DOCS_LINK",
        "RECORD_TIME",
        "UUID",
        "SUMMARY",
        "EVENT_TIME",
        "EO_ID",
        "F_ID",
        "USER_ID",
        "COMMENT",
        "STATUS",
        "STATUS_MESSAGE",
        "STATUS_SOURCE",
        "STATUS_VALUE",
        "SCAN_TYPE",
        "UP_UIS",
        "A_UIS");
  }

  // nested maps not supported
  private static List<String> getPaymentMessageFieldIds() {
    return Arrays.asList(
        "MESSAGE_TYPE",
        "PAYMENT_DATE",
        "PAYMENT_TYPE",
        "PAYMENT_AMOUNT",
        "CURRENCY",
        "PAYER_EO_ID",
        "RECIPIENT_EO_ID",
        "REF_INVOICES",
        "REF_INVOICES_SET",
        "PAYMENT_EU_TERRITIORY",
        "PAYER_IS_EU",
        "PAYER_LEGAL_NAME",
        "PAYER_NAME",
        //        "PAYER_ADDRESS",
        "PAYER_COUNTRY",
        "PAYER_TAX_NUMBER",
        "EO_ID",
        "RECIPIENT_NAME",
        "INVOICE_DATE",
        "COMMENT");
  }

  // nested maps not supported
  private static List<String> getTransloadingMessageFieldIds() {
    return Arrays.asList(
        "A_UIS",
        "COMMENT",
        "EO_ID",
        "EVENT_TIME",
        //        "DESTINATION_ADDRESS",
        "DESTINATION_F_ID",
        "DESTINATION_F_ID_LIST",
        "DESTINATION_R_ID",
        "DESTINATION_TYPE",
        "DESTINATION_VV_LIST",
        "EMCS_ARC",
        "EMCS_ARC_SET",
        "TRANSPORT_MODE",
        "TRANSPORT_SSCC",
        "TRANSPORT_SSCC_SET",
        "TRANSPORT_VEHICLE",
        "MESSAGE_TYPE",
        "F_ID",
        "RECORD_TIME",
        "REF_DOCS_LINK",
        "REF_DOC",
        "SCAN_TYPE",
        "STATUS",
        "STATUS_MESSAGE",
        "STATUS_SOURCE",
        "STATUS_VALUE",
        "SUMMARY",
        "UP_UIS",
        "USER_ID");
  }

  // nested maps not supported
  private static List<String> getInvoiceMessageFieldIds() {
    return Arrays.asList(
        "MESSAGE_TYPE",
        "INVOICE_TYPE",
        "INVOICE_TYPE_OTHER",
        "INVOICE_NUMBER",
        "INVOICE_DATE",
        "SELLER_EO_ID",
        "SELLER_NAME",
        "BILL_TO_EO_ID",
        "NET",
        "CURRENCY",
        "REF_DOCS_LINK",
        "BILL_TO_EU_TERRITORY",
        "BILL_TO_LEGAL_NAME",
        //        "BILL_TO_ADDRESS",
        "BILL_TO_COUNTRY",
        "BILL_TO_TAX_REG_NUMBER",
        "TPIDS",
        "PNS",
        "PRODUCT_PRICE",
        "FIRST_SELLER_EU",
        "COMMENT",
        "INVOICE_OTHER",
        "START_DATE",
        "END_DATE",
        "EO_ID",
        "ID_COUNT");
  }

  // combine and remove duplicate keys
  public static Set<String> getCSVExportFields() {
    Set<String> set = new LinkedHashSet<>();
    set.add("UUID");
    set.add("RECORD_TIME");
    set.add("STATUS");
    set.add("STATUS_MESSAGE");
    set.add("STATUS_VALUE");
    set.add("STATUS_SOURCE");
    set.add("RECALL_ID");
    set.add("SYSTEM_ID");

    set.addAll(getMessageFieldIds());
    set.addAll(getOrderMessageFieldIds());
    set.addAll(getPaymentMessageFieldIds());
    set.addAll(getTransloadingMessageFieldIds());
    set.addAll(getInvoiceMessageFieldIds());

    return set;
  }
}
