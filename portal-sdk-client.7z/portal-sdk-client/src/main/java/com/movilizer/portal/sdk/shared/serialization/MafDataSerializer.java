/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.serialization;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.github.nmorel.gwtjackson.client.JsonSerializationContext;
import com.github.nmorel.gwtjackson.client.JsonSerializer;
import com.github.nmorel.gwtjackson.client.JsonSerializerParameters;
import com.github.nmorel.gwtjackson.client.ser.BaseNumberJsonSerializer.DoubleJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.BaseNumberJsonSerializer.IntegerJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.BaseNumberJsonSerializer.NumberJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.BooleanJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.CollectionJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.StringJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.array.ArrayJsonSerializer;
import com.github.nmorel.gwtjackson.client.stream.JsonWriter;
import com.movilizer.portal.sdk.client.util.ConsoleLogger;
import com.movilizer.portal.sdk.shared.dsp.maf.MafData;

public class MafDataSerializer extends JsonSerializer<MafData> {

  @Override
  protected void doSerialize(
      JsonWriter writer,
      MafData value,
      JsonSerializationContext ctx,
      JsonSerializerParameters params) {

    writer.beginObject();

    writer.name("id");
    writer.value(value.getId());
    writer.name("systemId");
    writer.value(Long.valueOf(value.getSystemId()));

    Map<String, Object> map = value.getAttributes();

    if (map != null && map.size() > 0) {
      writer.name("attributes");
      serializeMap(writer, ctx, params, map);
    }
    writer.endObject();
  }

  private void serializeMap(
      JsonWriter writer,
      JsonSerializationContext ctx,
      JsonSerializerParameters params,
      Map<String, Object> map) {
    writer.beginObject();
    for (String key : map.keySet()) {
      Object mapValue = map.get(key);
      if (mapValue == null) {
        continue;
      }

      if (mapValue.getClass().isArray()) {
        getArraySerializer(key, writer, ctx, params, mapValue);
        continue;
      }
      if (mapValue instanceof String[]) {
        getArraySerializer(key, writer, ctx, params, mapValue);
        continue;
      }

      if (mapValue instanceof List) {
        List list = (List) mapValue;
        if (list.size() == 0) {
          continue;
        }
        writer.name(key);
        getListSerializer(writer, ctx, params, list);
        continue;
      }

      writer.name(key);

      if (mapValue instanceof Map) {
        serializeMap(writer, ctx, params, (Map) mapValue);
        continue;
      }

      if (mapValue instanceof String) {
        writer.value((String) mapValue);
        continue;
      }

      if (mapValue instanceof Boolean) {
        writer.value((Boolean) mapValue);
        continue;
      }
      if (mapValue instanceof Long) {
        writer.value((Long) mapValue);
        continue;
      }
      if (mapValue instanceof Number) {
        writer.value((Number) mapValue);
        continue;
      }

      String jsonString = getJson(mapValue);
      writer.rawValue(jsonString);
    }
    writer.endObject();
  }

  private void getListSerializer(
      JsonWriter writer, JsonSerializationContext ctx, JsonSerializerParameters params, List list) {
    Object listValue = list.get(0);
    if (listValue instanceof String) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(StringJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
    if (listValue instanceof Boolean) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(BooleanJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
    if (listValue instanceof Double) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(DoubleJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
    if (listValue instanceof Integer) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(IntegerJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
    if (listValue instanceof Number) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(NumberJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
  }

  private void getArraySerializer(
      String name,
      JsonWriter writer,
      JsonSerializationContext ctx,
      JsonSerializerParameters params,
      Object value) {

    if (value == null) {
      return;
    }

    Object[] objArray = (Object[]) value;
    if (objArray.length == 0) {
      return;
    }
    writer.name(name);
    if (value.getClass().isArray()) {
      ConsoleLogger.log("Serialisation: is Array");
      if (objArray != null && objArray.length > 0) {
        Object firstValue = objArray[0];
        if (firstValue instanceof String) {
          ArrayJsonSerializer<String> arraySerializer =
              ArrayJsonSerializer.newInstance(StringJsonSerializer.getInstance());
          String[] array = new String[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (String) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
        if (firstValue instanceof Boolean) {
          ArrayJsonSerializer<Boolean> arraySerializer =
              ArrayJsonSerializer.newInstance(BooleanJsonSerializer.getInstance());
          Boolean[] array = new Boolean[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (Boolean) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
        if (firstValue instanceof Double) {
          ArrayJsonSerializer<Double> arraySerializer =
              ArrayJsonSerializer.newInstance(DoubleJsonSerializer.getInstance());
          Double[] array = new Double[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (Double) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
        if (firstValue instanceof Integer) {
          ArrayJsonSerializer<Integer> arraySerializer =
              ArrayJsonSerializer.newInstance(IntegerJsonSerializer.getInstance());
          Integer[] array = new Integer[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (Integer) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
        if (firstValue instanceof Number) {
          ArrayJsonSerializer<Number> arraySerializer =
              ArrayJsonSerializer.newInstance(NumberJsonSerializer.getInstance());
          Number[] array = new Number[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (Number) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
      }
    }

    if (value instanceof String[]) {
      ConsoleLogger.log("Serialisation: is String[]");
      ArrayJsonSerializer<String> arraySerializer =
          ArrayJsonSerializer.newInstance(StringJsonSerializer.getInstance());
      String[] array = (String[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
    if (value instanceof Boolean[]) {
      ConsoleLogger.log("Serialisation: is Boolean[]");
      ArrayJsonSerializer<Boolean> arraySerializer =
          ArrayJsonSerializer.newInstance(BooleanJsonSerializer.getInstance());
      Boolean[] array = (Boolean[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
    if (value instanceof Double[]) {
      ConsoleLogger.log("Serialisation: is Double[]");
      ArrayJsonSerializer<Double> arraySerializer =
          ArrayJsonSerializer.newInstance(DoubleJsonSerializer.getInstance());
      Double[] array = (Double[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
    if (value instanceof Integer[]) {
      ConsoleLogger.log("Serialisation: is Integer[]");
      ArrayJsonSerializer<Integer> arraySerializer =
          ArrayJsonSerializer.newInstance(IntegerJsonSerializer.getInstance());
      Integer[] array = (Integer[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
    if (value instanceof Number[]) {
      ConsoleLogger.log("Serialisation: is Number[]");
      ArrayJsonSerializer<Number> arraySerializer =
          ArrayJsonSerializer.newInstance(NumberJsonSerializer.getInstance());
      Number[] array = (Number[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    } else {
      ArrayJsonSerializer<String> arraySerializer =
          ArrayJsonSerializer.newInstance(StringJsonSerializer.getInstance());
      String[] array = (String[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
  }

  public static native String getJson(Object obj) /*-{
	return JSON.stringify(obj);
}-*/;
}
