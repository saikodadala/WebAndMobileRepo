/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp;

import java.util.ArrayList;
import java.util.List;

public class JsonEntry {

  private String name;
  private String valStr;
  private List<JsonEntry> children;

  public JsonEntry() {}

  public JsonEntry(String name, String valStr) {
    this.name = name;
    this.valStr = valStr;
  }

  public JsonEntry(String name, int valStr) {
    this.name = name;
    this.valStr = "" + valStr;
  }

  public JsonEntry(String name, boolean valStr) {
    this.name = name;
    this.valStr = "" + valStr;
  }

  public JsonEntry(String name, List<String> valStr) {
    this.name = name;
    int counter = 0;
    if (this.getChildren() == null) {
      this.children = new ArrayList<JsonEntry>();
    }
    for (String val : valStr) {
      JsonEntry entry = new JsonEntry();
      entry.setName("" + counter);
      entry.setValStr(val);
      counter++;
      children.add(entry);
    }
    this.valStr = "" + valStr;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getValStr() {
    return valStr;
  }

  public void setValStr(String valStr) {
    this.valStr = valStr;
  }

  public List<JsonEntry> getChildren() {
    return children;
  }

  public void setChildren(List<JsonEntry> children) {
    this.children = children;
  }
}
