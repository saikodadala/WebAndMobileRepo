/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.util.Map;

import com.github.nmorel.gwtjackson.client.JsonSerializationContext;
import com.github.nmorel.gwtjackson.client.JsonSerializer;
import com.github.nmorel.gwtjackson.client.JsonSerializerParameters;
import com.github.nmorel.gwtjackson.client.stream.JsonWriter;
import com.movilizer.portal.sdk.shared.paging.SdkRequestPagingState;

public class InboxSearchSerializer extends JsonSerializer<InboxSearch> {

  @Override
  protected void doSerialize(
      JsonWriter writer,
      InboxSearch value,
      JsonSerializationContext ctx,
      JsonSerializerParameters params) {
    if (value == null) {
      return;
    }

    writer.beginObject();
    writer.name("fromDate");
    writer.value(Long.valueOf(value.getFromDate()));
    writer.name("tillDate");
    writer.value(Long.valueOf(value.getTillDate()));

    if (value.getSource() != null) {
      writer.name("source");
      writer.value(value.getSource());
    }
    writer.name("systemId");
    writer.value(Long.valueOf(value.getSystemId()));

    writer.name("status");
    writer.value(value.getStatus());

    Map<String, String> map = value.getPredicates();
    if (map != null) {
      writer.name("predicates");
      writer.beginObject();
      for (String key : map.keySet()) {
        String mapValue = map.get(key);
        writer.name(key);
        writer.value(mapValue);
      }
      writer.endObject();
    }

    writer.name("requestCbId");
    writer.value(value.getRequestCbId());

    Map<String, SdkRequestPagingState> paging = value.getPagingCache();
    if (paging != null) {

      writer.name("pagingCache");
      writer.beginObject();
      for (String key : paging.keySet()) {

        writer.name(key);
        writer.beginObject();
        SdkRequestPagingState state = paging.get(key);
        if (state != null) {
          writer.name("id");
          writer.value(state.getId());
          writer.name("offset");
          writer.value(state.getOffset());
          writer.name("limit");
          writer.value(state.getLimit());

          writer.name("entries");
          writer.beginObject();
          Map<String, String> entries = state.getEntries();
          for (String entryKey : entries.keySet()) {
            String entryValue = entries.get(entryKey);
            writer.name(entryKey);
            writer.value(entryValue);
          }
          writer.endObject();
        }
        writer.endObject();
      }
      writer.endObject();
    }
    writer.endObject();
  }
}
