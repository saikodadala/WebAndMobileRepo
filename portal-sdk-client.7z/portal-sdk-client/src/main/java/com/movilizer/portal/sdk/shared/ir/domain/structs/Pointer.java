/*
 * Copyright (c) 2015-2021 Honeywell International Inc.
 * @date 18.02.2021
 */
package com.movilizer.portal.sdk.shared.ir.domain.structs;

import com.movilizer.portal.sdk.shared.ir.domain.common.Validateable;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.structs")
public class Pointer implements Validateable {

  public static final String SYMBOL = "¤";

  private String pool;
  private String id;

  public String getPool() {
    return pool;
  }

  @JsIgnore
  public void setPool(String pool) {
    this.pool = pool;
  }

  public String getId() {
    return id;
  }

  @JsIgnore
  public void setId(String id) {
    this.id = id;
  }

  @Override
  public ValidationResult validate() {
    ValidationResult res = new ValidationResult();
    ValidationUtils.validateStringProperty(
        res, "pool", this.pool, true, 17, ValidationUtils.RESERVED_SYMBOLS);
    ValidationUtils.validateStringProperty(
        res, "id", this.id, true, ValidationUtils.L_128, ValidationUtils.RESERVED_SYMBOLS);
    return res;
  }

  public void setCompact(String pool, String id) {
    this.setPool(pool);
    this.setId(id);
  }

  @Override
  public String toString() {
    if ((pool == null || pool.isEmpty()) && (id == null || id.isEmpty())) {
      return "";
    } else {
      return this.pool + Pointer.SYMBOL + this.id;
    }
  }

  @JsIgnore
  public static Pointer fromString(String pointerString) {
    Pointer p = new Pointer();
    String[] parts = pointerString.split(Pointer.SYMBOL);
    if (parts.length == 2) {
      p.setPool(parts[0].trim());
      p.setId(parts[1].trim());
    }

    return p;
  }
}
