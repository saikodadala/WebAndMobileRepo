/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.common")
public class EntityServiceUtils<T> {
  public static boolean isDeletionSuccessful(SharedResponseEntity<Boolean> response) {
    return response != null && !response.isErroneous() && Boolean.TRUE.equals(response.getBody());
  }
}
