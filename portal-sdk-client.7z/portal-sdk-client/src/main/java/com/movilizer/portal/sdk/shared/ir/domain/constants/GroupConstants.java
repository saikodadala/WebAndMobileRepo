/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.constants;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.constants")
public class GroupConstants {
  public static final String MASTERDATA_GROUP_ALL = "All";
  public static final String MASTERDATA_GROUP_ABSTRACT = "abstract";
  public static final String MASTERDATA_GROUP_BROADCAST = "broadcast";
}
