/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Formula extends AttachedEntity {

  public static final String POOL_NAME = "Formulas";

  private String name;
  private String operator;
  private List<String> taskIds;

  @Override
  public String poolName() {
    return Formula.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return name;
  }

  public void setName(final String name) {
    this.name = name;
  }

  public String getOperator() {
    return operator;
  }

  public void setOperator(final String operator) {
    this.operator = operator;
  }

  public List<String> getTaskIds() {
    return taskIds;
  }

  @JsIgnore
  public void setTaskIds(final List<String> taskIds) {
    this.taskIds = taskIds;
  }

  public void addTaskIds(final LinkedHashSet<String> taskIds) {
    if (this.taskIds == null) this.taskIds = new ArrayList<>();
    this.taskIds.addAll(taskIds);
  }

  public void addTaskId(final String taskId) {
    if (this.taskIds == null) this.taskIds = new ArrayList<>();
    this.taskIds.add(taskId);
  }

  public void removeTaskId(final String taskId) {
    if (this.taskIds != null) this.taskIds.remove(taskId);
  }

  @Override
  @JsMethod
  public ValidationResult validate() {

    ValidationResult res = super.validate();
    // require
    ValidationUtils.validateStringProperty(
        res, "name", this.name, false, ValidationUtils.L_128, null, this);
    ValidationUtils.validateOperator(res, this.operator, false);

    // optional

    return res;
  }
}
