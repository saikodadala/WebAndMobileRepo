/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.LinkedHashSet;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.movilizer.portal.sdk.shared.ir.domain.annotations.DeleteRecursive;
import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import com.movilizer.portal.sdk.shared.ir.domain.structs.Pointer;
import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@DeleteRecursive(entities = {Limit.POOL_NAME})
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Task extends AttachedEntity {

  public static final String POOL_NAME = "Tasks";

  private String name;
  private String type;
  private String uom;
  private String description;
  private String category;
  private String valueRange;

  private String SAPTag;
  private String DCSTag;
  private String fieldTag;
  private String ipsTag;
  private String historianTag;

  private String historianTagEnabled = "false";
  private String uploadSource = "-1";

  private LinkedHashSet<String> values;
  private LinkedHashSet<String> modes;

  private LinkedHashSet<String> limitIds;
  private LinkedHashSet<Limit> limits; // just needed for recursive add

  private String position;

  private String subtype;

  private LinkedHashSet<Pointer> onEnter;

  @Override
  public String poolName() {
    return Task.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  @Deprecated
  @JsonIgnore
  public String getAssetId() {
    return this.parentId;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getUom() {
    return this.uom;
  }

  public void setUom(String uom) {
    this.uom = uom;
  }

  public String getDescription() {
    return this.description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public LinkedHashSet<String> getValues() {
    return this.values;
  }

  @JsIgnore
  public void setValues(LinkedHashSet<String> values) {
    this.values = values;
  }

  public void addValue(String value) {
    if (this.values == null) this.values = new LinkedHashSet<>();
    this.values.add(value);
  }

  public void removeValue(String value) {
    if (this.values != null) this.values.remove(value);
  }

  public LinkedHashSet<String> getLimitIds() {
    return this.limitIds;
  }

  @JsIgnore
  public void setLimitIds(LinkedHashSet<String> limitIds) {
    this.limitIds = limitIds;
  }

  public void addLimitId(String limitId) {
    if (this.limitIds == null) this.limitIds = new LinkedHashSet<>();
    this.limitIds.add(limitId);
  }

  public void removeLimitId(String limitid) {
    if (this.limitIds != null) this.limitIds.remove(limitid);
  }

  public LinkedHashSet<Limit> getLimits() {
    return this.limits;
  }

  @JsIgnore
  public void setLimits(LinkedHashSet<Limit> limits) {
    this.limits = limits;
  }

  public void addLimit(Limit limit) {
    if (this.limits == null) this.limits = new LinkedHashSet<>();
    this.limits.add(limit);
  }

  public void removeLimit(Limit limit) {
    if (this.limits != null) this.limits.remove(limit);
  }

  public String getSAPTag() {
    return this.SAPTag;
  }

  public void setSAPTag(String sAPTag) {
    this.SAPTag = sAPTag;
  }

  public String getFieldTag() {
    return this.fieldTag;
  }

  public void setFieldTag(String fieldTag) {
    this.fieldTag = fieldTag;
  }

  public String getIpsTag() {
    return this.ipsTag;
  }

  public void setIpsTag(String ipsTag) {
    this.ipsTag = ipsTag;
  }

  public String getHistorianTag() {
    return this.historianTag;
  }

  public void setHistorianTag(String historianTag) {
    this.historianTag = historianTag;
  }

  public String getUploadSource() {
    return uploadSource;
  }

  public void setUploadSource(String uploadSource) {
    this.uploadSource = uploadSource;
  }

  public String getHistorianTagEnabled() {
    return this.historianTagEnabled;
  }

  public void setHistorianTagEnabled(String historianTagEnabled) {
    this.historianTagEnabled = historianTagEnabled;
  }

  public String getDCSTag() {
    return this.DCSTag;
  }

  public void setDCSTag(String dCSTag) {
    this.DCSTag = dCSTag;
  }

  public LinkedHashSet<String> getModes() {
    return this.modes;
  }

  @JsIgnore
  public void setModes(LinkedHashSet<String> modes) {
    this.modes = modes;
  }

  public void addMode(String mode) {
    if (this.modes == null) this.modes = new LinkedHashSet<>();
    this.modes.add(mode);
  }

  public void removeMode(String mode) {
    if (this.modes != null) this.modes.remove(mode);
  }

  public String getPosition() {
    return position;
  }

  public void setPosition(String position) {
    this.position = position;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public String getValueRange() {
    return valueRange;
  }

  public void setValueRange(String valueRange) {
    this.valueRange = valueRange;
  }

  public String getSubtype() {
    return subtype;
  }

  public void setSubtype(String subtype) {
    this.subtype = subtype;
  }

  public LinkedHashSet<Pointer> getonEnter() {
    return this.onEnter;
  }

  public void setonEnter(LinkedHashSet<Pointer> onEnter) {
    this.onEnter = onEnter;
  }

  public void addOnEnter(Pointer onEnter) {
    if (this.onEnter == null) this.onEnter = new LinkedHashSet<>();
    this.onEnter.add(onEnter);
  }

  public void removeOnEnter(Pointer pointer) {
    Pointer pointerToBeRemoved = null;
    if (this.onEnter != null) {
      for (Pointer ptr : this.onEnter) {
        if (ptr.getPool().equals(pointer.getPool()) && ptr.getId().equals(pointer.getId())) {
          pointerToBeRemoved = ptr;
          break;
        }
      }
      this.onEnter.remove(pointerToBeRemoved);
    }
  }

  public void setCompact(
      String assetId,
      String name,
      String type,
      String uom,
      String sapTag,
      String dcsTag,
      String histoTag,
      String histoTagEnabled,
      String backendid) {
    this.parentId = assetId;
    this.parentPool = Asset.POOL_NAME;
    this.name = name;
    this.type = type;
    this.uom = uom;
    this.SAPTag = sapTag;
    this.DCSTag = dcsTag;
    this.historianTag = histoTag;
    this.historianTagEnabled = histoTagEnabled;
    this.backendId = backendid;
  }

  @Override
  @JsIgnore
  @JsMethod
  public String desc() {
    if (this.getModes() != null) {
      return String.join(",", this.getModes());
    } else {
      return super.desc();
    }
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    // required
    ValidationUtils.validateStringProperty(
        res, "name", this.name, true, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "type", this.type, true, ValidationUtils.S_32, null, this);
    ValidationUtils.validateIntegerProperty(
        res,
        "position",
        this.position,
        true,
        (long) Integer.MIN_VALUE,
        (long) Integer.MAX_VALUE,
        this);

    // optional
    ValidationUtils.validateStringProperty(
        res, "uom", this.uom, false, ValidationUtils.XS_16, null, this);
    ValidationUtils.validateStringProperty(
        res, "description", this.description, false, ValidationUtils.XL_256, null, this);
    ValidationUtils.validateStringProperty(
        res, "category", this.category, false, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "subtype", this.subtype, false, ValidationUtils.XS_16, null, this);
    ValidationUtils.validateStringProperty(
        res, "valueRange", this.valueRange, false, ValidationUtils.L_128, null, this);

    ValidationUtils.validateStringProperty(
        res, "SAPTag", this.SAPTag, false, ValidationUtils.M_64, null, this);
    ValidationUtils.validateStringProperty(
        res, "historianTag", this.historianTag, false, ValidationUtils.M_64, null, this);
    ValidationUtils.validateStringProperty(
        res, "DCSTag", this.DCSTag, false, ValidationUtils.M_64, null, this);
    ValidationUtils.validateStringProperty(
        res, "fieldTag", this.fieldTag, false, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "ipsTag", this.ipsTag, false, ValidationUtils.L_128, null, this);

    // MOVOR-5025
    ValidationUtils.validateBooleanProperty(
        res, "historianTagEnabled", this.historianTagEnabled, false, this);
    ValidationUtils.validateIntegerProperty(res, "uploadSource", this.uploadSource, this);
    ValidationUtils.validateIntegerProperty(res, "position", this.position, this);

    if (this.modes != null) {
      int i = 0;
      for (String m : this.modes) {
        if (!ValidationUtils.validateStringProperty(
            res, "modes[" + i + "]", m, false, ValidationUtils.S_32, null, this))
          return res; // return immediately, because we don't want this message to be repeated
        i++;
      }
    }

    if (this.values != null) {
      int i = 0;
      for (String v : this.values) {
        if (!ValidationUtils.validateStringProperty(
            res, "values[" + i + "]", v, false, ValidationUtils.L_128, null, this))
          return res; // return immediately, because we don't want this message to be repeated
        i++;
      }
    }

    if (onEnter != null) {
      for (Pointer p : onEnter) ValidationUtils.validateValidateable(res, "onEnter", p, false);
    }

    return res;
  }
}
