/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 18.05.2021
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;
import com.movilizer.portal.sdk.shared.ir.domain.structs.Pointer;
import com.movilizer.portal.sdk.shared.ir.domain.structs.State;

import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(
    property = Workflow.PROPERTY_NAME_NAME,
    groupByProperty = AttachedEntity.PROPERTY_NAME_PARENTID)
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Workflow extends AttachedEntity {

  public static final String POOL_NAME = "Workflows";
  public static final String PROPERTY_NAME_NAME = "name";

  private String name;
  private String gracePeriod;
  private String duration;
  private String category;

  private LinkedHashSet<Pointer> onEnter = new LinkedHashSet<>();
  private LinkedHashSet<Pointer> onLeave = new LinkedHashSet<>();
  private Map<String, State> states = new LinkedHashMap<>();

  @Override
  public String poolName() {
    return Workflow.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getGracePeriod() {
    return gracePeriod;
  }

  public void setGracePeriod(String gracePeriod) {
    this.gracePeriod = gracePeriod;
  }

  public String getDuration() {
    return duration;
  }

  public void setDuration(String duration) {
    this.duration = duration;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public Map<String, State> getStates() {
    return states;
  }

  public void setStates(Map<String, State> states) {
    this.states = states;
  }

  public LinkedHashSet<Pointer> getOnEnter() {
    return onEnter;
  }

  public void setOnEnter(LinkedHashSet<Pointer> onEnter) {
    this.onEnter = onEnter;
  }

  public LinkedHashSet<Pointer> getOnLeave() {
    return onLeave;
  }

  public void setOnLeave(LinkedHashSet<Pointer> onLeave) {
    this.onLeave = onLeave;
  }

  public void addOnLeave(Pointer onLeave) {
    this.onLeave.add(onLeave);
  }

  public void addOnEnter(Pointer onEnter) {
    this.onEnter.add(onEnter);
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult validationResult = super.validate();
    // mandatory
    ValidationUtils.validateStringProperty(
        validationResult, "name", name, true, ValidationUtils.L_128, null, this);

    // optional
    ValidationUtils.validateStringProperty(
        validationResult, "category", category, false, ValidationUtils.M_64, null, this);
    ValidationUtils.validateStringProperty(
        validationResult,
        "gracePeriod",
        gracePeriod,
        false,
        ValidationUtils.XS_16,
        null,
        this);
    ValidationUtils.validateStringProperty(
        validationResult, "duration", duration, false, ValidationUtils.XS_16, null, this);
    if (onEnter != null && !onEnter.isEmpty()) {
      for (Pointer pointer : onEnter) {
        ValidationUtils.validateValidateable(validationResult, "onEnter", pointer, false);
      }
    }
    if (onLeave != null && !onLeave.isEmpty()) {
      for (Pointer pointer : onLeave) {
        ValidationUtils.validateValidateable(validationResult, "onLeave", pointer, false);
      }
    }
    for (Entry<String, State> entry : states.entrySet()) {
      ValidationUtils.validateStringProperty(
          validationResult,
          "states.key",
          entry.getKey(),
          false,
          ValidationUtils.S_32,
          null,
          this);
      ValidationUtils.validateValidateable(
          validationResult, "states.value", entry.getValue(), false);
    }

    return validationResult;
  }
}
