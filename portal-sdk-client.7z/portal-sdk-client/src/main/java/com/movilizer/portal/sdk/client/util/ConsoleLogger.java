/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.client.util;

/**
 * if for debugging purpose it is necessary to log something to the browser console, you can use
 * this class for it.
 *
 * @author Marcus Schumacher
 */
public class ConsoleLogger {

  public static native void log(String message) /*-{
													console.log("me:" + message);
													}-*/;
}
