/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.auth;

import java.util.Set;
import java.util.UUID;

public interface APIAuthenticated {

  /** @return the email address of this user */
  public String getLogin();

  /** @return the ID this user */
  public UUID getID();

  /** @return the systemId */
  public Long getSystemID();

  /** @return the role */
  public Set<String> getRoles();

  public Set<String> getRights();

  /**
   * Check if for the user system is debug active
   *
   * @return
   */
  public boolean isDebug();
}
