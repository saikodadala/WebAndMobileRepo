/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.paging;

import java.io.Serializable;
import java.util.HashMap;

public class ResultPagination implements Serializable {

  private static final long serialVersionUID = 1L;

  private String requestCbId;
  private HashMap<String, SdkRequestPagingState> pagingCache =
      new HashMap<String, SdkRequestPagingState>();

  public String getRequestCbId() {
    return requestCbId;
  }

  public void setRequestCbId(String requestCbId) {
    this.requestCbId = requestCbId;
  }

  public boolean containsPagingState(String cbId) {
    return this.pagingCache.containsKey(cbId);
  }

  public void addPagingState(String cbId, SdkRequestPagingState pagingState) {
    this.pagingCache.put(cbId, pagingState);
  }

  public SdkRequestPagingState getPagingState(String cbId) {
    return this.pagingCache.get(cbId);
  }

  public HashMap<String, SdkRequestPagingState> getPagingCache() {
    return pagingCache;
  }

  public void setPagingCache(HashMap<String, SdkRequestPagingState> pagingCache) {
    this.pagingCache = pagingCache;
  }
}
