/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.structs;

import com.movilizer.portal.sdk.shared.ir.domain.common.Validateable;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.structs")
public class Location implements Validateable {

  public static final String COORD_DELIMITER = ";";

  private String latitude;
  private String longitude;
  private String altitude;

  public String getLatitude() {
    return latitude;
  }

  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  public String getLongitude() {
    return longitude;
  }

  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }

  public String getAltitude() {
    return altitude;
  }

  public void setAltitude(String altitude) {
    this.altitude = altitude;
  }

  public static Location fromString(String location) {

    Location loc = new Location();
    loc.setAltitude("0");
    loc.setLatitude("0");
    loc.setLongitude("0");

    if (location != null) {
      String[] parts = location.split(COORD_DELIMITER);
      if (parts.length >= 1) {
        loc.setLatitude(parts[0]);
      }
      if (parts.length >= 2) {
        loc.setLongitude(parts[1]);
      }
      if (parts.length >= 3) {
        loc.setAltitude(parts[2]);
      }
    }
    return loc;
  }

  @Override
  public String toString() {
    return this.latitude + COORD_DELIMITER + this.longitude + COORD_DELIMITER + this.altitude;
  }

  @Override
  public ValidationResult validate() {
    ValidationResult res = new ValidationResult();

    ValidationUtils.validateStringProperty(res, "latitude", latitude, true, ValidationUtils.S_32);
    ValidationUtils.validateStringProperty(res, "longitude", longitude, true, ValidationUtils.S_32);
    ValidationUtils.validateStringProperty(res, "altitude", altitude, true, ValidationUtils.S_32);

    // make sure values do not contain coord delimiter
    if (latitude.contains(COORD_DELIMITER))
      res.addValidationMessage("Latitude contains invalid character \"" + COORD_DELIMITER + "\"");
    if (longitude.contains(COORD_DELIMITER))
      res.addValidationMessage("Longitude contains invalid character \"" + COORD_DELIMITER + "\"");
    if (altitude.contains(COORD_DELIMITER))
      res.addValidationMessage("Altitude contains invalid character \"" + COORD_DELIMITER + "\"");

    // make sure values do not contain location delimiter
    if (latitude.contains(Polygon.LOCATION_DELIMITER))
      res.addValidationMessage(
          "Latitude contains invalid character \"" + Polygon.LOCATION_DELIMITER + "\"");
    if (longitude.contains(Polygon.LOCATION_DELIMITER))
      res.addValidationMessage(
          "Longitude contains invalid character \"" + Polygon.LOCATION_DELIMITER + "\"");
    if (altitude.contains(Polygon.LOCATION_DELIMITER))
      res.addValidationMessage(
          "Altitude contains invalid character \"" + Polygon.LOCATION_DELIMITER + "\"");

    try {
      Double.parseDouble(latitude);
    } catch (Exception e) {
      res.addValidationMessage(
          "Invalid latitude. Values for latitude, longitude and altitude must be in decimal format");
    }
    try {
      Double.parseDouble(longitude);
    } catch (Exception e) {
      res.addValidationMessage(
          "Invalid longitude. Values for latitude, longitude and altitude must be in decimal format");
    }
    try {
      Double.parseDouble(altitude);
    } catch (Exception e) {
      res.addValidationMessage(
          "Invalid altitude. Values for latitude, longitude and altitude must be in decimal format");
    }

    return res;
  }
}
