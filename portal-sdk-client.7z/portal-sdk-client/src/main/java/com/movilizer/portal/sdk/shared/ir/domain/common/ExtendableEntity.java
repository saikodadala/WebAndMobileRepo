package com.movilizer.portal.sdk.shared.ir.domain.common;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.common")
public abstract class ExtendableEntity extends AbstractEntity {

  public static final String HFIR_ROOT_ENTITY_ID = "HFIR_ROOT_ENTITY_ID";
  protected String extendsId =
      HFIR_ROOT_ENTITY_ID; // by default, all entities inherit from HFIR_ROOT_ENTITY_ID

  public String getExtendsId() {
    return this.extendsId;
  }

  public void setExtendsId(String extendsId) {
    this.extendsId = extendsId;
  }

  @Override
  @JsIgnore
  @JsMethod
  public String filter3() {
    return this.extendsId;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    ValidationUtils.validateStringProperty(
        res, "extendsId", this.extendsId, true, ValidationUtils.R_31);

    return res;
  }
}
