/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.Collections;
import java.util.LinkedHashSet;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.movilizer.portal.sdk.shared.ir.domain.annotations.DeleteRecursive;
import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;
import com.movilizer.portal.sdk.shared.ir.domain.structs.Location;
import com.movilizer.portal.sdk.shared.ir.domain.structs.Pointer;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@DeleteRecursive(entities = {Task.POOL_NAME})
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
@Index(property = Asset.PROPERTY_NAME_NAME, groupByProperty = AttachedEntity.PROPERTY_NAME_PARENTID)
public class Asset extends AttachedEntity {

  public static final String POOL_NAME = "Assets";

  public static final String PROPERTY_NAME_NAME = "name";
  private String name;
  private String type;
  private Location location;

  private String saptag;
  private String dcstag;
  private String fieldTag;
  private String historianTag;

  private String historianTagEnabled = "false";
  private String uploadSource = "-1";

  private LinkedHashSet<String> taskIds;
  private LinkedHashSet<Task> tasks; // just needed for recursive add
  private LinkedHashSet<String> modes;
  private LinkedHashSet<Pointer> categories;
  private LinkedHashSet<Pointer> onEnter;

  @Override
  public String poolName() {
    return Asset.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  // @Deprecated
  @JsonIgnore
  public String getLevelId() {
    if (parentPool.equals(Level.POOL_NAME)) {
      return parentId;
    } else {
      return null;
    }
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public LinkedHashSet<String> getModes() {
    return this.modes;
  }

  @JsIgnore
  public void setModes(LinkedHashSet<String> modes) {
    this.modes = modes;
  }

  public void addMode(String mode) {
    if (this.modes == null) this.modes = new LinkedHashSet<>();
    this.modes.add(mode);
  }

  public void removeMode(String mode) {
    if (this.modes != null) this.modes.remove(mode);
  }

  public LinkedHashSet<Pointer> getCategories() {
    return categories;
  }

  public LinkedHashSet<String> listCategories() {
    LinkedHashSet<String> categoriesList = new LinkedHashSet<>();
    if (this.categories != null) {
      for (Pointer ptr : this.categories) {
        categoriesList.add(ptr.getId());
      }
    }
    return categoriesList;
  }

  @JsIgnore
  public void setCategories(LinkedHashSet<Pointer> categories) {
    this.categories = categories;
  }

  public void addCategory(Pointer category) {
    if (this.categories == null) this.categories = new LinkedHashSet<>();
    this.categories.add(category);
  }

  public LinkedHashSet<String> getTaskIds() {
    return this.taskIds;
  }

  @JsIgnore
  public void setTaskIds(LinkedHashSet<String> taskIds) {
    this.taskIds = taskIds;
  }

  public void addTaskId(String taskId) {
    if (this.taskIds == null) this.taskIds = new LinkedHashSet<>();
    this.taskIds.add(taskId);
  }

  public void removeTaskId(String taskid) {
    if (this.taskIds != null) this.taskIds.remove(taskid);
  }

  @JsIgnore
  public LinkedHashSet<Task> getTasks() {
    return this.tasks;
  }

  public void setTasks(LinkedHashSet<Task> tasks) {
    this.tasks = tasks;
  }

  public void addTask(Task task) {
    if (this.tasks == null) this.tasks = new LinkedHashSet<>();
    this.tasks.add(task);
  }

  public void removeTask(Task task) {
    if (tasks != null) this.tasks.remove(task);
  }

  public String getSAPTag() {
    return this.saptag;
  }

  public void setSAPTag(String sAPTag) {
    this.saptag = sAPTag;
  }

  public String getDCSTag() {
    return this.dcstag;
  }

  public void setDCSTag(String dCSTag) {
    this.dcstag = dCSTag;
  }

  public String getFieldTag() {
    return this.fieldTag;
  }

  public void setFieldTag(String fieldTag) {
    this.fieldTag = fieldTag;
  }

  public String getUploadSource() {
    return uploadSource;
  }

  public void setUploadSource(String uploadSource) {
    this.uploadSource = uploadSource;
  }

  public String getHistorianTag() {
    return this.historianTag;
  }

  public void setHistorianTag(String historianTag) {
    this.historianTag = historianTag;
  }

  public String getHistorianTagEnabled() {
    return this.historianTagEnabled;
  }

  public void setHistorianTagEnabled(String historianTagEnabled) {
    this.historianTagEnabled = historianTagEnabled;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public Location getLocation() {
    return this.location;
  }

  public void setLocation(Location location) {
    this.location = location;
  }

  public LinkedHashSet<Pointer> getonEnter() {
    return this.onEnter;
  }

  public void setonEnter(LinkedHashSet<Pointer> onEnter) {
    this.onEnter = onEnter;
  }

  public void addOnEnter(Pointer onEnter) {
    if (this.onEnter == null) this.onEnter = new LinkedHashSet<>();
    this.onEnter.add(onEnter);
  }

  public void removeOnEnter(Pointer pointer) {
    Pointer pointerToBeRemoved = null;
    if (this.onEnter != null) {
      for (Pointer ptr : this.onEnter) {
        if (ptr.getPool().equals(pointer.getPool()) && ptr.getId().equals(pointer.getId())) {
          pointerToBeRemoved = ptr;
          break;
        }
      }
      this.onEnter.remove(pointerToBeRemoved);
    }
  }

  public void setCompact(
      String levelId,
      String name,
      String SAPTag,
      String DCSTag,
      String histoTag,
      String histoTagEnabled,
      String backendid,
      String type) {

    this.parentPool = Level.POOL_NAME;
    this.parentId = levelId;

    this.name = name;
    this.saptag = SAPTag;
    this.dcstag = DCSTag;
    this.historianTag = histoTag;
    this.historianTagEnabled = histoTagEnabled;
    this.backendId = backendid;
    this.type = type;
  }

  @Override
  public String desc() {
    if (categories != null) {
      String ret = "";
      // since description should be max 256 char and we need to support more categories, hence we
      // trim category id to 10 characters
      for (Pointer p : categories) ret += p.getId().substring(0, 10) + ",";

      return ret.substring(0, ret.length() - 1);
    }
    return null;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    // required
    ValidationUtils.validateStringProperty(
        res, "name", this.name, true, ValidationUtils.L_128, null, null);

    // optional
    ValidationUtils.validateValidateable(res, "location", this.location, false);
    ValidationUtils.validateStringProperty(
        res, "type", this.type, false, ValidationUtils.S_32, null, this);
    ValidationUtils.validateStringProperty(
        res, "SAPTag", this.saptag, false, ValidationUtils.M_64, null, this);
    ValidationUtils.validateStringProperty(
        res, "historianTag", this.historianTag, false, ValidationUtils.M_64, null, this);
    ValidationUtils.validateStringProperty(
        res, "DCSTag", this.dcstag, false, ValidationUtils.M_64, null, this);
    ValidationUtils.validateStringProperty(
        res, "fieldTag", this.fieldTag, false, ValidationUtils.L_128, null, this);

    if (this.modes != null) {
      int i = 0;
      for (String m : this.modes) {
        if (!ValidationUtils.validateStringProperty(
            res, "modes[" + i + "]", m, false, ValidationUtils.S_32, null, this))
          return res; // return immediately, because we don't want this message to be repeated

        if (m != null && m.contains(",")) {
          res.addValidationMessage(
              "modes[" + i + "] contains invalid character (comma): \"" + m + "\"");
          return res;
        }
        i++;
      }
    }

    if (categories != null) {
      for (Pointer pointer : categories) {
        if (!pointer.getPool().equals(Category.POOL_NAME)) {
          res.addValidationMessage(
              "Pointer "
                  + pointer.toString()
                  + " does not point to Category. Pointers of categories have to point to Category.");
          return res;
        }
        ValidationUtils.validateValidateable(res, "categories", pointer, false);
      }

      /*Category ids get serialized to comma separated string in Masterdata description. 23*10+22 =252 (23*10 characters of category_uuid plus 22 commas). More than 23 categories cannot be serialized to Masterdata "description" field*/
      if (categories.size() > 23)
        res.addValidationMessage(
            "An asset can only belong to a maximum of 23 categories. "
                + categories.size()
                + " categories have been set");
    }

    if (onEnter != null) {
      for (Pointer p : onEnter) ValidationUtils.validateValidateable(res, "onEnter", p, false);
    }

    // MOVOR-5025
    ValidationUtils.validateBooleanProperty(
        res, "historianTagEnabled", this.historianTagEnabled, false, this);
    ValidationUtils.validateIntegerProperty(res, "uploadSource", this.uploadSource, this);

    return res;
  }
}
