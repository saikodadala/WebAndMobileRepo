package com.movilizer.portal.sdk.shared.ir.domain.extensions;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.extensions")
public class DeletionParameterExtension extends MaintenanceParameterExtension {
  // Extension point for further maintenance deletion options
  private UserControlParameterExtension lockUserParameterExtension;

  public UserControlParameterExtension getLockUserParameterExtension() {
    return lockUserParameterExtension;
  }

  public void setLockUserParameterExtension(UserControlParameterExtension lockUserParameterExtension) {
    this.lockUserParameterExtension = lockUserParameterExtension;
  }
}
