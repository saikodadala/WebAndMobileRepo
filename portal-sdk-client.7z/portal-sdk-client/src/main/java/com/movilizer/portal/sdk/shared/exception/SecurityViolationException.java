/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.exception;

import java.io.Serializable;

import com.google.gwt.user.client.rpc.IsSerializable;

public class SecurityViolationException extends RuntimeException
    implements Serializable, IsSerializable {
  private static final long serialVersionUID = -3368881908183211716L;
  private boolean sessionTimeout = false;

  public SecurityViolationException() {
    super();
  }

  public SecurityViolationException(final String cause, final boolean sessionTimeout) {
    super(cause);
    this.sessionTimeout = sessionTimeout;
  }

  public SecurityViolationException(final String cause) {
    super(cause);
  }

  public SecurityViolationException(final String cause, final Exception e) {
    super(cause, e);
  }

  public boolean isSessionTimedOut() {
    return this.sessionTimeout;
  }
}
