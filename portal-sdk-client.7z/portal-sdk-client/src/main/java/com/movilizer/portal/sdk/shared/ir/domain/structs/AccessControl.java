/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.structs;

import java.util.ArrayList;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir")
public class AccessControl {

  private ArrayList<String> userLevels;
  private ArrayList<String> userHierarchy;
  private String firstWebserviceSystem;

  private boolean canRead;
  private boolean canAdd;
  private boolean canUpdate;
  private boolean canDelete;
  private boolean canMediaRead;
  private boolean canMediaAdd;
  private boolean canMediaDelete;

  private boolean admin;
  private boolean global;

  public String getFirstWebserviceSystem() {
    return firstWebserviceSystem;
  }

  @JsIgnore
  public void setFirstWebserviceSystem(String firstWebserviceSystem) {
    this.firstWebserviceSystem = firstWebserviceSystem;
  }

  /**
   * user levels are the leaves in the tree the user is assigned to. It is a subset of user
   * hierarchy
   */
  public ArrayList<String> getUserLevels() {
    if (userLevels == null) userLevels = new ArrayList<>();
    return userLevels;
  }

  @JsIgnore
  public void setUserLevels(ArrayList<String> userLevels) {
    this.userLevels = userLevels;
  }

  @JsIgnore
  public void addUserLevel(String userLevel) {
    if (this.userLevels == null) this.userLevels = new ArrayList<>();
    this.userLevels.add(userLevel);
  }

  /**
   * user hierarchy is not only the levels the user is assigned to, but also their parents
   * recursively*
   */
  public ArrayList<String> getUserHierarchy() {
    if (this.userHierarchy == null) this.userHierarchy = new ArrayList<>();
    return this.userHierarchy;
  }

  @JsIgnore
  public void setUserHierarchy(ArrayList<String> assignedLevels) {
    this.userHierarchy = assignedLevels;
  }

  @JsIgnore
  public void addToUserHierarchy(String level) {
    if (this.userHierarchy == null) this.userHierarchy = new ArrayList<>();
    this.userHierarchy.add(level);
  }

  public boolean isCanRead() {
    return canRead;
  }

  @JsIgnore
  public void setCanRead(boolean canRead) {
    this.canRead = canRead;
  }

  public boolean isCanAdd() {
    return canAdd;
  }

  @JsIgnore
  public void setCanAdd(boolean canAdd) {
    this.canAdd = canAdd;
  }

  public boolean isCanUpdate() {
    return canUpdate;
  }

  @JsIgnore
  public void setCanUpdate(boolean canUpdate) {
    this.canUpdate = canUpdate;
  }

  public boolean isCanDelete() {
    return canDelete;
  }

  @JsIgnore
  public void setCanDelete(boolean canDelete) {
    this.canDelete = canDelete;
  }

  public boolean isAdmin() {
    return admin;
  }

  @JsIgnore
  public void setAdmin(boolean admin) {
    this.admin = admin;
  }

  public boolean isGlobal() {
    return global;
  }

  public void setGlobal(boolean global) {
    this.global = global;
  }

  public boolean isCanMediaRead() {
    return canMediaRead;
  }

  @JsIgnore
  public void setCanMediaRead(boolean canMediaRead) {
    this.canMediaRead = canMediaRead;
  }

  public boolean isCanMediaAdd() {
    return canMediaAdd;
  }

  @JsIgnore
  public void setCanMediaAdd(boolean canMediaAdd) {
    this.canMediaAdd = canMediaAdd;
  }

  public boolean isCanMediaDelete() {
    return canMediaDelete;
  }

  @JsIgnore
  public void setCanMediaDelete(boolean canMediaDelete) {
    this.canMediaDelete = canMediaDelete;
  }
}
