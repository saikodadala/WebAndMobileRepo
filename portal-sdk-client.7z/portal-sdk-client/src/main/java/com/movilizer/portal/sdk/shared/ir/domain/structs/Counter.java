/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.structs;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.structs")
public class Counter {

  private int count;

  public int getCount() {
    return count;
  }

  @JsIgnore
  public void setCount(int count) {
    this.count = count;
  }
}
