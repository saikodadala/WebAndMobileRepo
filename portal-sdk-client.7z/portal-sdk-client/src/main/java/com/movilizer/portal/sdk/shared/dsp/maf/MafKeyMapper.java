/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.maf;

import com.github.nmorel.gwtjackson.client.ObjectMapper;

public interface MafKeyMapper extends ObjectMapper<MafDataKey> {}
