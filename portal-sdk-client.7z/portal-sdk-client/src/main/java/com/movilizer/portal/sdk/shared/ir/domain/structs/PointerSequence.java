package com.movilizer.portal.sdk.shared.ir.domain.structs;

import java.util.Iterator;
import java.util.LinkedHashSet;

import com.movilizer.portal.sdk.shared.ir.domain.common.Validateable;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.structs")
public class PointerSequence implements Validateable {
  public static final String SYMBOL = "::";

  private LinkedHashSet<Pointer> sequence = new LinkedHashSet<>();

  /*
   * We use the builder syntax here, so we can do things like new
   * PointerSequence().add(pointer1).add(pointer2);
   */
  @JsMethod
  public PointerSequence add(Pointer pointer) {
    this.sequence.add(pointer);
    return this;
  }

  public LinkedHashSet<Pointer> getSequence() {
    return sequence;
  }

  @JsIgnore
  public void setSequence(LinkedHashSet<Pointer> sequence) {
    this.sequence = sequence;
  }

  @Override
  public String toString() {
    if (sequence == null || sequence.isEmpty()) {
      return "";
    } else {
      String resultString = "";
      for (final Pointer pointer : sequence) {
        resultString += pointer.toString() + SYMBOL;
      }
      return resultString.substring(0, resultString.length() - SYMBOL.length());
    }
  }

  @JsIgnore
  public static PointerSequence fromString(String pointerSequenceString) {
    PointerSequence pointerSequence = new PointerSequence();
    String[] parts = pointerSequenceString.split(SYMBOL);
    for (String pointerString : parts) {
      final Pointer pointer = Pointer.fromString(pointerString);
      pointerSequence.add(pointer);
    }
    return pointerSequence;
  }

  private boolean isAssetBeforeTask() {
    Iterator<Pointer> pointerIterator = sequence.iterator();

    // Checks if Task is before Asset and returns false if yes
    if (pointerIterator.next().getPool().equals("Tasks")) {
      if (pointerIterator.next().getPool().equals("Assets")) {
        return false;
      }
    }
    return true;
  }

  @JsMethod
  @Override
  public ValidationResult validate() {
    ValidationResult res = new ValidationResult();
    if (sequence != null && !sequence.isEmpty()) {
      if (sequence.size() != 2) {
        res.addValidationMessage(
            "property 'model' did not validate: In one PointerSequence only one Asset-Task combination is allowed");
      }
      for (Pointer pointer : sequence) {
        ValidationUtils.validateValidateable(res, "sequence", pointer, false);
      }
    }
    if (!isAssetBeforeTask()) {
      res.addValidationMessage(
          "property 'model' did not validate: In PointerSequence Asset should come before Task.");
    }
    return res;
  }

  @JsIgnore
  public Pointer[] asArray(PointerSequence sequence) {
    if (sequence.validate().getValidationMessages().size() == 0) {
      LinkedHashSet<Pointer> pointers = sequence.getSequence();
      Pointer[] pointerArr = new Pointer[pointers.size()];
      System.arraycopy(pointers.toArray(), 0, pointerArr, 0, pointers.size());
      return pointerArr;
    }
    return new Pointer[0];
  }
}
