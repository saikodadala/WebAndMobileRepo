/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.util.Map;

import com.github.nmorel.gwtjackson.client.JsonSerializationContext;
import com.github.nmorel.gwtjackson.client.JsonSerializer;
import com.github.nmorel.gwtjackson.client.JsonSerializerParameters;
import com.github.nmorel.gwtjackson.client.stream.JsonWriter;

public class InboxSerializer extends JsonSerializer<InboxEntry> {

  public static InboxSerializer INSTANCE = new InboxSerializer();

  public static InboxSerializer getInstance() {
    return INSTANCE;
  }

  public InboxSerializer() {}

  @Override
  protected void doSerialize(
      JsonWriter writer,
      InboxEntry value,
      JsonSerializationContext ctx,
      JsonSerializerParameters params) {
    // writer.beginObject();
    if (value == null) {
      return;
    }
    writer.value(value.getRecordTime());
    writer.value(value.getStatusMessage());
    writer.value(value.getStatusSource());
    writer.value(value.getStatusValue());
    writer.value(value.getUuid());
    writer.value(value.getStatus());
    writer.value(value.getSystemId());
    Map<String, Object> map = value.getEntryValues();

    if (map != null) {
      writer.beginObject();
      for (String key : map.keySet()) {
        Object o = map.get(key);
      }
      writer.endObject();
    }
  }
}
