/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.util;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;

public interface PropertyReaderConstants {

  /** Mime Type for Mobile Client Favorite list */
  public static final String MIMETYPE_GROUP = "MIMEType";

  // USERMANAGEMENT PROPERTIES
  /** Usermanagement Group contains all user and login related stuff */
  public static final String USERMANAGEMENT_GROUP = "usermanagement";

  /**
   * As Email is a Primary Key it is not changeable. Therefore is the Domain substitution so that at
   * least emails can be send.
   */
  public static final String EMAIL_DOMAIN_SUBSTITUTION =
      "EMAIL_DOMAIN_SUBSTITUTION"; // domain1=substitution1|domain2=substitution2|......

  /** Develop parameter all EMails will be send to the given email */
  public static final String DEVELOPER_EMAIL =
      "DEVELOP_EMAIL"; // All mails are send to this Address

  /** Self registration parameter: All new Customer will sub customer of the given customer id. */
  public static final String DEFAULT_CUSTOMER_ID =
      "DEFAULT_CUSTOMER_ID"; // REQUIRED Customer system Id that is used
  // for Registration

  /**
   * Self registration parameter: A self registered user is only valid for the given time periode
   */
  public static final String REGISTER_VALID_TIME_IN_DAYS =
      "REGISTER_VALID_TIME_IN_DAYS"; // REQUIRED Validity of user
  // that are registered
  // without
  // confirm.

  /** Self registration parameter: For the created system the limit of movelet will be set */
  public static final String REGISTER_LIMIT_MOVELET_PER_MONTH =
      "REGISTER_LIMIT_MOVELET_PER_MONTH"; // REQUIRED limit

  /** Self registration parameter: For the created system the limit of request will be set */
  public static final String REGISTER_LIMIT_REQUEST_PER_MONTH =
      "REGISTER_LIMIT_REQUEST_PER_MONTH"; // REQUIRED limit

  /** /** Self registration parameter: For the created system the limit of responses will be set */
  public static final String REGISTER_LIMIT_RESPONSE_PER_MONTH =
      "REGISTER_LIMIT_RESPONSE_PER_MONTH"; // REQUIRED
  // limit

  /** Self registration parameter: Switch for selfregistration on/off (true/false) */
  public static final String ALLOW_REGISTRATION = "ALLOW_USER_REGISTRATION"; // true
  // or
  // otherwise
  /** Self registration parameter: System tag used for selfregistration systems */
  public static final String REGISTER_SYSTEM_TAG = "REGISTER_SYSTEM_TAG";

  /** Self registration parameter: Customer tag used for selfregistration customer */
  public static final String REGISTER_CUSTOMER_TAG = "REGISTER_CUSTOMER_TAG";

  /** Self registration parameter: Max participants for created system */
  public static final String REGISTER_MAX_PARTICIPANT = "REGISTER_MAX_PARTICIPANT";

  /** Self registration parameter: Max Monthly volume for created system */
  public static final String REGISTER_ALLOWED_VOLUME = "REGISTER_ALLOWED_VOLUME";

  /**
   * Special Parameter used for private cloud. Allows to set regex on user level for paraticipant
   * management. Only matching regex is allowed to change participants
   */
  public static final String USE_PARTICPANT_REGEX =
      "USE_PARTICPANT_REGEX"; // Allow to use an additional filter for
  // administrate particpant.

  /** Defines the regex that is used to check requirement for password strength. */
  public static final String GLOBAL_PASSWORD_REGEX = "GLOBAL_PASSWORD_REGEX";

  public static final String GLOBAL_PASSWORD_REGEX_TOOLTIP = "GLOBAL_PASSWORD_REGEX_TOOLTIP";
  // GENERIC
  /** Required System parameter are grouped in generic */
  public static final String GENERIC_GROUP = "generic";

  /** URL to the install web application */
  public static final String APP_URL_PATH = "APP_URL_PATH"; // http://<server>/Portal

  /** Name of the system */
  public static final String APP_NAME = "APP_NAME";

  /** Start page after login */
  public static final String CONTENT_URL_START = "CONTENT_URL_START";

  /** Use email address to send emails to users */
  public static final String NO_REPLY_ADDRESS = "NO_REPLY_ADDRESS";

  public static final String TEST_ENVIROMENT = "TEST_ENVIROMENT";

  public static final String EMAIL_GROUP = "email";
  public static final String SMTP_HOST_NAME = "HOST_NAME"; // http://<server>/Portal
  public static final String SMTP_PORT = "PORT"; // http://<server>/Portal
  public static final String SMTP_USER_NAME = "USER_NAME"; // http://<server>/Portal
  public static final String SMTP_USER_PASSWORD = "USER_PASSWORD"; // http://<server>/Portal
  public static final String SMTP_AUTH = "SMTP_AUTH"; // http://<server>/Portal
  public static final String SMTP_STARTTLS_ENABLE =
      "SMTP_STARTTLS_ENABLE"; // http://<server>/Portal
  public static final String SMTP_TIMEOUT = "SMTP_TIMEOUT"; // http://<server>/Portal
  public static final String SMTP_SSL_PROTOCOLS = "SMTP_SSL_PROTOCOLS"; // http://<server>/Portal
  public static final String RELOAD_EMAIL_CONFIG = "RELOAD";

  // Movilizer <Demo> Portal
  // ####MDS###
  public static final String MDS_DOCUMENT_UPLOAD_URL = "MDS_DOCUMENT_UPLOAD_SERVLET_URL";
  public static final String REMOTE_ADDRESS_CLIENT_DEPLOYMENT = "REMOTE_ADDRESS_CLIENT_DEPLOYMENT";
  public static final String REMOTE_ADDRESS_APP_GROUPS = "REMOTE_ADDRESS_APP_GROUPS";
  public static final String REMOTE_ADDRESS_REPLIC = "REMOTE_ADDRESS_REPLIC";
  public static final String REMOTE_ADDRESS_PARTICIPANT_MANAGEMENT =
      "REMOTE_ADDRESS_PARTICIPANT_MANAGEMENT";
  public static final String REMOTE_ADDRESS_MASTER_DATA_ADMIN = "REMOTE_ADDRESS_MASTER_DATA_ADMIN";
  public static final String REMOTE_ADDRESS_ASSIGNMENT = "REMOTE_ADDRESS_ASSIGNMENT";
  public static final String REMOTE_ADDRESS_MDSMoveletServer = "REMOTE_ADDRESS_MDSMoveletServer";
  public static final String REMOTE_ADDRESS_MDSMAFAdminServer = "REMOTE_ADDRESS_MDSMAFAdminServer";
  public static final String REMOTE_ADDRESS_PORTAL_MIGRATOR = "REMOTE_ADDRESS_PORTAL_MIGRATOR";
  public static final String REMOTE_ADDRESS_MDSPropertyServer = "REMOTE_ADDRESS_MDSPropertyServer";
  public static final String REMOTE_ADDRESS_MDSLocalizationServer =
      "REMOTE_ADDRESS_MDSLocalizationServer";
  public static final String REMOTE_ADDRESS_ATTRIBUTE_SERVICE = "REMOTE_ADDRESS_ATTRIBUTE_SERVICE";
  public static final String REMOTE_ADDRESS_DOCUMENT_SERVICE = "REMOTE_ADDRESS_DOCUMENT_SERVICE";
  public static final String REMOTE_MASTERDATA_ATTRIBUTE_SERVICE =
      "REMOTE_MASTERDATA_ATTRIBUTE_SERVICE";
  public static final String REMOTE_ADDRESS_MDSNOTIFICATION_SERVICE =
      "REMOTE_ADDRESS_MDSNOTIFICATION_SERVICE";
  public static final String REMOTE_ADDRESS_MDSSYSTEMBACKUPADMIN_SERVICE =
      "REMOTE_ADDRESS_MDSSYSTEMBACKUPADMIN_SERVICE";

  // SYNCPARAMETER
  public static final String SYNCHRONISATION_PARAMTER = "SYNC_PARAMETER";
  public static final String POLLING_STOPPED =
      "POLLING_STOPPED"; // true stops the polling for all systems
  public static final String SYSTEM_STOPPED_PREFIX =
      "SYSTEM_STOPPED_"; // Prefix for sysid SYSTEM_STOPPED_100=true stops polling for systemid 100;
  public static final String DEVELOPER_SYSTEMS_TO_POLL =
      "DEVELOPER_SYSTEMS_TO_POLL"; // Poll on system the given
  // system IDs 100;101,...

  // Nice Label Constants
  public static final String NICE_LABEL_GROUP = "NICE_LABEL";
  public static final String NICE_LABEL_HOST_WEB = "NICE_LABEL_HOST_WEB";
  public static final String NICE_LABEL_HOST_TCP = "NICE_LABEL_HOST_TCP";
  public static final String NICE_LABEL_SOCKET_PORT = "NICE_LABEL_SOCKET_PORT";
  public static final String NICE_LABEL_SECURE_KEY_TCP = "NICE_LABEL_SECURE_KEY_TCP";
  public static final String NICE_LABEL_SECURE_KEY_URL = "NICE_LABEL_SECURE_KEY_URL";
  public static final String NICE_LABEL_SECURE_KEY_URL_IV = "NICE_LABEL_SECURE_KEY_URL_IV";
  public static final String NICE_LABEL_URL_PATH_CLIENT_ONLINE =
      "NICE_LABEL_URL_PATH_CLIENT_ONLINE";
  public static final String NICE_LABEL_WEB_PORT = "NICE_LABEL_WEB_PORT";
  public static final String NICE_LABEL_TOKEN_LENGTH = "NICE_LABEL_TOKEN_LENGTH";
  public static final String NICE_LABEL_DELIMTER = "NICE_LABEL_DELIMTER";
  public static final String NICE_LABEL_PARAMETER_USER = "NICE_LABEL_PARAMETER_USER";
  public static final String NICE_LABEL_PARAMETER_PW = "NICE_LABEL_PARAMETER_PW";
  public static final String NICE_LABEL_TOKEN_VALID = "NICE_LABEL_TOKEN_VALID";

  // App Configuration
  public static final String APP_ID_GROUP = "CUSTOM_APPS"; // Row key cloumns are the App Ids

  // App Column Row Key is the appId;
  public static final String CUSTOM_APP_USER = "USER"; // Technical User of App
  public static final String CUSTOM_APP_SYSTEM = "SYSTEMID"; // System of App
  public static final String CUSTOM_APP_ROLES = "ROLES"; // Roles of Technical User
  public static final String CUSTOM_APP_SUB_ACCESS = "SUB_ACCESS"; // Allow to switch the system Id

  public static final String DOCUMENTATION_GROUP =
      "Documentation"; // Configuration group for documentation
  // properties
  public static final String PORTAL_DOCUMENTATION_URL =
      "PORTAL_DOCUMENTATION_URL"; // Link to the Portal
  // Documentation

  // Tracking road service url
  public static final String TRACKING_SCENARIO = "Tracking";
  public static final String ROAD_SERVICE_URL = "RoadServiceURL";

  // BusinessScenario Exam
  public static final String MOVELT_KEY_MAP = "MOVELT_KEY_MAP";

  // BrandedClient
  /** build server */
  public static final String BRANDED_CLIENT = "BrandedClient";

  public static final String BUILD_SERVER_URL = "BuildServerURL";

  // CustomerManagerment Group
  public static final String CUSTOMER_MANAGEMENT_GROUP = "CustomerManagement";
  public static final String DEFAULT_PARTICIPANT_TTL = "DefaultAppGroupParticipantTTL";

  public static final Collection<String> ADMIN_GROUPS =
      Collections.unmodifiableSet(
          new HashSet<String>() {
            {
              add(PropertyReaderConstants.USERMANAGEMENT_GROUP);
              add(PropertyReaderConstants.GENERIC_GROUP);
            }
          });

  public static final String SCRIPTS = "SCRIPTS";
  public static final String LIBRARY_SCRIPT_TIMEOUT = "LIBRARY_SCRIPT_TIMEOUT";
  public static final String LIBRARY_MANAGER_SCRIPT_TIMEOUT = "LIBRARY_MANAGER_SCRIPT_TIMEOUT";
  public static final String CHART_SCRIPT_TIMEOUT = "CHART_SCRIPT_TIMEOUT";

  // Web Client config parameter
  public static final String WEB_CLIENT_URL = "URL";
  public static final String WEB_CLIENT = "WEB_CLIENT";
  public static final String WEB_CLIENT_HWID = "HWID";

  public static final String WEB_CLIENT_ENCRYPTE_PHRASE = "CRYPTO_PHRASE";

  public static final String MAX_ALLOWED_OSRM_DISTANCE_POINTS = "MAX_ALLOWED_OSRM_DISTANCE_POINTS";

  public static final String ANALYTICS_GROUP = "Analytics";
  public static final String ANALYTICS_BULK_REPORTS_TIMEOUT_MINUTES =
      "BULK_REPORTS_TIMEOUT_MINUTES";

  public static final String BILLING_GROUP = "Billing";

  public static final String MAPS_API_GROUP = "Maps";
  public static final String MAPS_API_URL = "MAPS_API_URL";
  public static final String MAPS_API_URL_CN = "MAPS_API_URL_CN";

  public static final String TNT_GROUP = "Track & Trace";
  public static final String TNT_SCAN_EXPORT_TIMEOUT_MINUTES = "TNT_SCAN_EXPORT_TIMEOUT_MINUTES";
  public static final String TNT_HIERARCHY_EXPORT_TIMEOUT_MINUTES =
      "TNT_HIERARCHY_EXPORT_TIMEOUT_MINUTES";
  public static final String TNT_EPCIS_EVENT_EXPORT_TIMEOUT_MINUTES =
      "TNT_EPCIS_EVENT_EXPORT_TIMEOUT_MINUTES";
  public static final String TNT_RESPONSE_SERVLET_RATE = "TNT_RESPONSE_SERVLET_RATE";
  public static final String TNT_RESPONSE_SERVLET_TIMEOUT = "TNT_RESPONSE_SERVLET_TIMEOUT";
}
