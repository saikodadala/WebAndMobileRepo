/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.common")
public class SharedResponseEntity<T> {

  private T body;
  private boolean erroneous;
  private ApiError error;

  public boolean isErroneous() {
    return this.erroneous;
  }

  public void setErroneous(boolean erroneous) {
    this.erroneous = erroneous;
  }

  public T getBody() {
    return this.body;
  }

  @JsIgnore
  public void setBody(T body) {
    this.body = body;
  }

  @JsIgnore
  public void setError(ApiError error) {
    this.error = error;
    this.erroneous = error != null;
  }

  public ApiError getError() {
    return this.error;
  }
}
