/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

import java.util.ArrayList;
import java.util.List;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.common")
public class ValidationResult {

  private boolean valid = true;
  private List<String> validationMessages = new ArrayList<>();

  public boolean isValid() {
    return this.valid;
  }

  public void setValid(boolean valid) {
    this.valid = valid;
  }

  public List<String> getValidationMessages() {
    return this.validationMessages;
  }

  public void setValidationMessages(List<String> validationMessages) {
    this.validationMessages = validationMessages;
    this.valid = false;
  }

  public void addValidationMessage(String msg) {
    this.validationMessages.add(msg);
    this.valid = false;
  }
}
