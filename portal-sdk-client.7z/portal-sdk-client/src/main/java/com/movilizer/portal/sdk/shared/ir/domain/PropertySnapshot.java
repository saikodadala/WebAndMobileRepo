/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class PropertySnapshot extends AttachedEntity {

  public static final String POOL_NAME = "PropertySnapshots";

  String name;
  String value;
  String oldValue;

  @Override
  public String poolName() {
    return PropertySnapshot.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getOldValue() {
    return oldValue;
  }

  public void setOldValue(String oldValue) {
    this.oldValue = oldValue;
  }

  @Override
  public ValidationResult validate() {

    return super.validate();
  }
}
