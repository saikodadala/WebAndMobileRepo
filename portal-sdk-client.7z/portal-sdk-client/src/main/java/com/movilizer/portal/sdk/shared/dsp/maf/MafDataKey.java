/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.maf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jsinterop.annotations.JsType;

/**
 * This class is used to specifiy all values necessary value to get data from MAF. This can be a
 * data entry, discrete index entry, timeseries entry,...
 */
@JsType(namespace = "mov.sdk.mafdata")
public class MafDataKey implements Serializable {

  private static final long serialVersionUID = -4044698157363082149L;
  private long systemId;
  private String key;
  private List<Object> partitionKeyParts;
  private long start;
  private long end;

  public List<Object> getPartitionKeyParts() {
    return partitionKeyParts;
  }

  public void setPartitionKeyParts(List<Object> partitionKeyParts) {
    this.partitionKeyParts = partitionKeyParts;
  }

  public void addPartitionKeyPart(Object part) {
    if (this.partitionKeyParts == null) {
      this.partitionKeyParts = new ArrayList<>();
    }
    this.partitionKeyParts.add(part);
  }

  public long getSystemId() {
    return systemId;
  }

  public void setSystemId(long systemId) {
    this.systemId = systemId;
  }

  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public long getStart() {
    return start;
  }

  public void setStart(long start) {
    this.start = start;
  }

  public long getEnd() {
    return end;
  }

  public void setEnd(long end) {
    this.end = end;
  }
}
