/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.maf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk")
public class MafData {

  private String id;
  private long systemId;
  private Map<String, Object> attributes = new HashMap<>();

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public long getSystemId() {
    return systemId;
  }

  public void setSystemId(long systemID) {
    this.systemId = systemID;
  }

  public Map<String, Object> getAttributes() {
    return attributes;
  }

  public Object getValue(String key) {
    if (this.attributes != null) {
      return this.attributes.get(key);
    }
    return null;
  }

  public Object getAttribute(String key) {
    if (this.attributes != null) {
      return this.attributes.get(key);
    }
    return null;
  }

  public void addValue(String key, Object value) {
    if (this.attributes == null) {
      this.attributes = new HashMap<>();
    }
    this.attributes.put(key, value);
  }

  public void addAttribute(String key, Object value) {
    if (this.attributes == null) {
      this.attributes = new HashMap<>();
    }
    this.attributes.put(key, value);
  }

  public void setAttributes(Map<String, Object> attributes) {
    this.attributes = attributes;
  }

  public List<?> getList(final String key) {
    final Object obj = this.attributes.get(key);
    if (obj == null) {
      return null;
    }
    if (obj instanceof List<?>) {
      return (List<?>) obj;
    } else {
      throw new IllegalStateException("Attribute " + key + " not of type List.");
    }
  }

  public String getString(final String key) {
    final Object obj = this.attributes.get(key);
    if (obj == null) {
      return null;
    }
    if (obj instanceof String) {
      return (String) obj;
    } else {
      throw new IllegalStateException("Attribute " + key + " not of type String.");
    }
  }
}
