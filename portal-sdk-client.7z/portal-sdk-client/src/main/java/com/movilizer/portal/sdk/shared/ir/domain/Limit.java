/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.LinkedHashSet;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;
import com.movilizer.portal.sdk.shared.ir.domain.constants.LimitTypes;
import com.movilizer.portal.sdk.shared.ir.domain.structs.Pointer;

import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Limit extends AttachedEntity {

  public static final String POOL_NAME = "Limits";
  public static final String REGEX_FEXPRESSION =
      "f\\(((now|NOW){1}([\\+\\-]{1}([0-9]+(\\.[0-9]+)*))*)\\)";

  private String type;

  private String value;
  private String name;
  private String cause;
  private String consequence;
  private String action;
  private String severity;
  private String category;
  private Pointer applyOn;
  private LinkedHashSet<Pointer> requires = new LinkedHashSet<Pointer>(); // MOVOR-7058, MOVOR-7383

  public static final String SEPERATOR = ";";

  @Override
  public String poolName() {
    return Limit.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  // @Deprecated
  @JsonIgnore
  public String getTaskId() {
    return this.parentId;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getValue() {
    return this.value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getCause() {
    return this.cause;
  }

  public void setCause(String cause) {
    this.cause = cause;
  }

  public String getConsequence() {
    return this.consequence;
  }

  public void setConsequence(String consequence) {
    this.consequence = consequence;
  }

  public String getAction() {
    return this.action;
  }

  public void setAction(String action) {
    this.action = action;
  }

  public String getSeverity() {
    return severity;
  }

  public void setSeverity(String severity) {
    this.severity = severity;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public Pointer getApplyOn() {
    return applyOn;
  }

  public void setApplyOn(Pointer applyOn) {
    this.applyOn = applyOn;
  }

  public LinkedHashSet<Pointer> getRequires() {
    return requires;
  }

  public void setRequires(LinkedHashSet<Pointer> requires) {
    this.requires = requires;
  }

  public void addRequires(Pointer require) {
    this.requires.add(require);
  }

  public void setCompact(
      String taskId, String type, String value, String cause, String consequence, String action) {
    this.parentId = taskId;
    this.parentPool = Task.POOL_NAME;
    this.type = type;
    this.value = value;
    this.cause = cause;
    this.consequence = consequence;
    this.action = action;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {

    ValidationResult res = super.validate();

    // require
    ValidationUtils.validateStringProperty(
        res, "type", type, true, ValidationUtils.S_32, null, this);
    ValidationUtils.validateStringProperty(
        res, "value", value, true, ValidationUtils.L_128, null, this);

    // optional
    ValidationUtils.validateValidateable(res, "applyOn", this.applyOn, false);

    if (requires != null && !requires.isEmpty()) {
      for (Pointer require : requires) {
        ValidationUtils.validateValidateable(res, "requires", require, false);
      }
    }
    ValidationUtils.validateStringProperty(
        res, "cause", cause, false, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "name", name, false, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "consequence", consequence, false, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "action", action, false, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "severity", severity, false, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "category", category, false, ValidationUtils.L_128, null, this);

    if (this.type != null) {
      if (this.type.equalsIgnoreCase(LimitTypes.HIGH)
          || this.type.equalsIgnoreCase(LimitTypes.LOW)) {
        validateLimitValue(res, value);
      } else if (this.type.equalsIgnoreCase(LimitTypes.VALIDATION_FLOAT)) {
        for (String eachVal : this.value.split(SEPERATOR)) {
          ValidationUtils.validateDoubleProperty(res, "value", eachVal, this);
        }
      } else if (this.type.equalsIgnoreCase(LimitTypes.VALIDATION_INTEGER)) {
        for (String eachVal : this.value.split(SEPERATOR)) {
          ValidationUtils.validateIntegerProperty(res, "value", eachVal, this);
        }
      } else if (this.type.equalsIgnoreCase(LimitTypes.VALIDATION_STRING)) {
        // Is already covered by general string validation from above
      } else {
        res.addValidationMessage(
            "property 'type' is not a valid value. Invalid value: "
                + type
                + ". Valid values are: "
                + LimitTypes.getLimitTypes().toString());
      }
    }

    return res;
  }

  public void validateLimitValue(ValidationResult res, String value) {
    if (value != null && value.startsWith("f(")) {
      ValidationUtils.validateStringProperty(
          res, "value", value, false, ValidationUtils.L_128, REGEX_FEXPRESSION, this);
    } else {
      ValidationUtils.validateDoubleProperty(res, "value", value, this);
    }
  }
}
