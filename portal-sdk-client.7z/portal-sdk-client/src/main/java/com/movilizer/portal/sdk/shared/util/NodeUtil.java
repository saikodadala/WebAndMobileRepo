/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.util;

import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Node;
import com.google.gwt.xml.client.NodeList;

public class NodeUtil {

  public static String getNodeText(Node entry) {
    String result = null;
    NodeList valStrs = ((Element) entry).getElementsByTagName("valstr");
    if (valStrs.getLength() > 0) {
      Node node = valStrs.item(0);
      if (node.getFirstChild() != null) {
        return node.getFirstChild().getNodeValue();
      }
    } else {
      NodeList valBytes = ((Element) entry).getElementsByTagName("valbyte");
      if (valBytes.getLength() > 0) {
        Node node = valBytes.item(0);
        if (node.getFirstChild() != null) {
          return node.getFirstChild().getNodeValue();
        }
      }
    }

    return result;
  }
}
