/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.paging;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.common")
public class Paginator<T> {

  private T result;
  private long timeRangeStart;
  private long timeRangeEnd;
  private int offset;
  private int limit;
  private long totalCount;

  public T getResult() {
    return result;
  }

  public void setResult(T result) {
    this.result = result;
  }

  public long getTimeRangeStart() {
    return timeRangeStart;
  }

  public void setTimeRangeStart(long timeRangeStart) {
    this.timeRangeStart = timeRangeStart;
  }

  public long getTimeRangeEnd() {
    return timeRangeEnd;
  }

  public void setTimeRangeEnd(long timeRangeEnd) {
    this.timeRangeEnd = timeRangeEnd;
  }

  public int getOffset() {
    return offset;
  }

  public void setOffset(int offset) {
    this.offset = offset;
  }

  public int getLimit() {
    return limit;
  }

  public void setLimit(int limit) {
    this.limit = limit;
  }

  public long getTotalCount() {
    return totalCount;
  }

  public void setTotalCount(long totalCount) {
    this.totalCount = totalCount;
  }

  public static <T, U> Paginator<U> fabricate(Paginator<T> model, U res) {
    Paginator<U> clone = new Paginator<>();
    clone.setResult(res);
    clone.setTimeRangeStart(model.getTimeRangeStart());
    clone.setTimeRangeEnd(model.getTimeRangeEnd());
    clone.setOffset(model.getOffset());
    clone.setLimit(model.getLimit());
    clone.setTotalCount(model.getTotalCount());
    return clone;
  }
}
