/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.serialization;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.github.nmorel.gwtjackson.client.JsonSerializationContext;
import com.github.nmorel.gwtjackson.client.JsonSerializer;
import com.github.nmorel.gwtjackson.client.JsonSerializerParameters;
import com.github.nmorel.gwtjackson.client.ser.BaseNumberJsonSerializer.DoubleJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.BaseNumberJsonSerializer.IntegerJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.BaseNumberJsonSerializer.NumberJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.BooleanJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.CollectionJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.StringJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.array.ArrayJsonSerializer;
import com.github.nmorel.gwtjackson.client.ser.map.key.KeySerializer;
import com.github.nmorel.gwtjackson.client.stream.JsonWriter;

public class MapSerializer<M extends Map<K, V>, K, V> extends JsonSerializer<M> {

  protected final KeySerializer<K> keySerializer;

  protected final JsonSerializer<V> valueSerializer;

  public static <M extends Map<?, ?>> MapSerializer<M, ?, ?> newInstance(
      KeySerializer<?> keySerializer, JsonSerializer<?> valueSerializer) {
    return new MapSerializer(keySerializer, valueSerializer);
  }

  public MapSerializer(KeySerializer<K> keySerializer, JsonSerializer<V> valueSerializer) {
    if (null == keySerializer) {
      throw new IllegalArgumentException("keySerializer need to be defined");
    }
    if (null == valueSerializer) {
      throw new IllegalArgumentException("valueSerializer need to be defined");
    }
    this.keySerializer = keySerializer;
    this.valueSerializer = valueSerializer;
  }

  @Override
  protected void doSerialize(
      JsonWriter writer, M map, JsonSerializationContext ctx, JsonSerializerParameters params) {
    writer.beginObject();
    if (map != null && !map.isEmpty()) {
      for (K key : map.keySet()) {

        if (key instanceof Long) {
          writer.value((Long) key);
        } else {
          String name = keySerializer.serialize(key, ctx);
          if (keySerializer.mustBeEscaped(ctx)) {
            writer.name(name);
          } else {
            writer.unescapeName(name);
          }
        }

        V value = map.get(key);
        if (value == null) {
          continue;
        }

        if (value.getClass().isArray()) {
          getArraySerializer(writer, ctx, params, value);
          continue;
        }
        if (value instanceof String[]) {
          getArraySerializer(writer, ctx, params, value);
          continue;
        }

        if (value instanceof List) {
          List list = (List) value;
          if (list.size() == 0) {
            continue;
          }

          getListSerializer(writer, ctx, params, list);
          continue;
        }
        if (value instanceof Map) {
          doSerialize(writer, (M) value, ctx, params);
          continue;
        }
        this.valueSerializer.serialize(writer, value, ctx);
      }
    }
    writer.endObject();
  }

  private void getListSerializer(
      JsonWriter writer, JsonSerializationContext ctx, JsonSerializerParameters params, List list) {
    Object listValue = list.get(0);
    if (listValue instanceof String) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(StringJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
    if (listValue instanceof Boolean) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(BooleanJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
    if (listValue instanceof Double) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(DoubleJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
    if (listValue instanceof Integer) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(IntegerJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
    if (listValue instanceof Number) {

      CollectionJsonSerializer<Collection<?>, ?> collectionSerializer =
          CollectionJsonSerializer.newInstance(NumberJsonSerializer.getInstance());
      collectionSerializer.serialize(writer, list, ctx);
      return;
    }
  }

  private void getArraySerializer(
      JsonWriter writer, JsonSerializationContext ctx, JsonSerializerParameters params, V value) {

    if (value.getClass().isArray()) {
      Object[] objArray = (Object[]) value;
      if (objArray != null && objArray.length > 0) {
        Object firstValue = objArray[0];
        if (firstValue instanceof String) {
          ArrayJsonSerializer<String> arraySerializer =
              ArrayJsonSerializer.newInstance(StringJsonSerializer.getInstance());
          String[] array = new String[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (String) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
        if (firstValue instanceof Boolean) {
          ArrayJsonSerializer<Boolean> arraySerializer =
              ArrayJsonSerializer.newInstance(BooleanJsonSerializer.getInstance());
          Boolean[] array = new Boolean[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (Boolean) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
        if (firstValue instanceof Double) {
          ArrayJsonSerializer<Double> arraySerializer =
              ArrayJsonSerializer.newInstance(DoubleJsonSerializer.getInstance());
          Double[] array = new Double[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (Double) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
        if (firstValue instanceof Integer) {
          ArrayJsonSerializer<Integer> arraySerializer =
              ArrayJsonSerializer.newInstance(IntegerJsonSerializer.getInstance());
          Integer[] array = new Integer[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (Integer) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
        if (firstValue instanceof Number) {
          ArrayJsonSerializer<Number> arraySerializer =
              ArrayJsonSerializer.newInstance(NumberJsonSerializer.getInstance());
          Number[] array = new Number[objArray.length];
          for (int i = 0; i < objArray.length; i++) {
            array[i] = (Number) objArray[i];
          }
          arraySerializer.doSerialize(writer, array, ctx, params);
          return;
        }
      }
    }

    if (value instanceof String[]) {
      ArrayJsonSerializer<String> arraySerializer =
          ArrayJsonSerializer.newInstance(StringJsonSerializer.getInstance());
      String[] array = (String[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
    if (value instanceof Boolean[]) {
      ArrayJsonSerializer<Boolean> arraySerializer =
          ArrayJsonSerializer.newInstance(BooleanJsonSerializer.getInstance());
      Boolean[] array = (Boolean[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
    if (value instanceof Double[]) {
      ArrayJsonSerializer<Double> arraySerializer =
          ArrayJsonSerializer.newInstance(DoubleJsonSerializer.getInstance());
      Double[] array = (Double[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
    if (value instanceof Integer[]) {
      ArrayJsonSerializer<Integer> arraySerializer =
          ArrayJsonSerializer.newInstance(IntegerJsonSerializer.getInstance());
      Integer[] array = (Integer[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
    if (value instanceof Number[]) {
      ArrayJsonSerializer<Number> arraySerializer =
          ArrayJsonSerializer.newInstance(NumberJsonSerializer.getInstance());
      Number[] array = (Number[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    } else {
      ArrayJsonSerializer<String> arraySerializer =
          ArrayJsonSerializer.newInstance(StringJsonSerializer.getInstance());
      String[] array = (String[]) value;
      arraySerializer.doSerialize(writer, array, ctx, params);
      return;
    }
  }
}
