package com.movilizer.portal.sdk.shared.ir.domain.extensions;

import java.util.ArrayList;
import java.util.List;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.extensions")
public class UserControlParameterExtension extends MaintenanceParameterExtension {
  // Extension point for further maintenance deletion options
  private List<String> excludedUsers = new ArrayList<>();

  public List<String> getExcludedUsers() {
    return excludedUsers;
  }

  public void setExcludedUsers(List<String> excludedUsers) {
    this.excludedUsers = excludedUsers;
  }
}
