package com.movilizer.portal.sdk.shared.ir.domain.structs;

import java.util.HashMap;
import java.util.LinkedHashSet;

import com.movilizer.portal.sdk.shared.ir.domain.common.Validateable;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.structs.workflow")
public class State implements Validateable {

  private LinkedHashSet<PointerSequence> model = new LinkedHashSet<>();
  private HashMap<String, String> view = new HashMap<>();

  public LinkedHashSet<PointerSequence> getModel() {
    return model;
  }

  @JsIgnore
  public void setModel(LinkedHashSet<PointerSequence> model) {
    this.model = model;
  }

  public HashMap<String, String> getView() {
    return view;
  }

  @JsIgnore
  public void setView(HashMap<String, String> view) {
    this.view = view;
  }

  @Override
  public ValidationResult validate() {
    ValidationResult res = new ValidationResult();
    ValidationUtils.validateMapProperty(
        res, "view", this.view, false, ValidationUtils.S_32, ValidationUtils.XXXL_1024);
    for (PointerSequence pointerSequence : model) {
      ValidationUtils.validateValidateable(res, "model", pointerSequence, false);
    }

    return res;
  }
}
