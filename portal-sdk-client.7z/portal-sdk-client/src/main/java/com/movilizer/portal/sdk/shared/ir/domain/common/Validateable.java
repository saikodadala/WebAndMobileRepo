/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.common;

public interface Validateable {

  public ValidationResult validate();
}
