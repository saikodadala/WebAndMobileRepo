/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.structs;

import java.util.ArrayList;
import java.util.LinkedHashSet;

import com.movilizer.portal.sdk.shared.ir.domain.common.Validateable;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities.structs")
public class Polygon implements Validateable {

  public static final String LOCATION_DELIMITER = "::";
  private LinkedHashSet<Location> locations = new LinkedHashSet<>();

  public LinkedHashSet<Location> getLocations() {
    return locations;
  }

  @JsIgnore
  public void setLocations(LinkedHashSet<Location> locations) {
    this.locations = locations;
  }

  public void addLocation(Location location) {
    this.locations.add(location);
  }

  public void removeLocation(Location location) {
    this.locations.remove(location);
  }

  public static Polygon fromString(String polygon) {
    Polygon poly = new Polygon();
    String[] locations = polygon.split(LOCATION_DELIMITER);
    for (String s : locations) {
      poly.addLocation(Location.fromString(s));
    }

    return poly;
  }

  @Override
  public String toString() {

    ArrayList<String> locString = new ArrayList<>();
    for (Location loc : locations) locString.add(loc.toString());
    return String.join(LOCATION_DELIMITER, locString);
  }

  @Override
  public ValidationResult validate() {

    ValidationResult res = new ValidationResult();
    if (locations.size() < 3) {
      res.addValidationMessage("Polygon must consist of at least three locations.");
      return res;
    }
    int i = 0;
    for (Location loc : this.locations) {
      ValidationUtils.validateValidateable(res, "location[" + i + "]", loc, true);
      i++;
    }
    return res;
  }
}
