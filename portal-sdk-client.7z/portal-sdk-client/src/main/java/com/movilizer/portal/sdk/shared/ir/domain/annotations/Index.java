/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.movilizer.portal.sdk.shared.ir.domain.constants.IndexConstants;

/**
 * * Adding an index to an entity means that the specified property will be kept in an index as the
 * key. The value is the id of the entity. By specifying the groupBy attribute the index will
 * grouped by the property defined as groupBy. That way it is f.i. possible to have an index of all
 * level names for the same parentLevel. With tis index it is easy to check if a level name is
 * already taken within the parent level's children.
 *
 * @author H225706
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Repeatable(Indices.class)
public @interface Index {

  String property();

  String groupByProperty() default IndexConstants.NO_GROUPING;
}
