/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */

package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.inbox")
public class InboxMessageStatisticSeries implements Serializable {

  private List<InboxMessageStatistic> statistic;
  private String date;

  public void setDate(String value) {
    this.date = value;
  }

  public void setStatistic(List<InboxMessageStatistic> value) {
    this.statistic = value;
  }

  public String getDate() {
    return this.date;
  }

  public void addStatistic(InboxMessageStatistic stat) {
    if (this.statistic == null) statistic = new ArrayList<InboxMessageStatistic>();
    statistic.add(stat);
  }

  public List<InboxMessageStatistic> getStatistic() {
    if (this.statistic == null) this.statistic = new ArrayList<InboxMessageStatistic>();
    return this.statistic;
  }
}
