/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class WorkNotification extends AttachedEntity {

  public static final String POOL_NAME = "WorkNotifications";

  // id is backend created / preset / unique

  private String creatorName;

  private String name;
  private String type;
  private String description;
  private String priority;
  private String text;
  private String start;
  private String end;

  @Override
  public String poolName() {
    return WorkNotification.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  public String getStart() {
    return start;
  }

  public void setStart(String start) {
    this.start = start;
  }

  public String getEnd() {
    return end;
  }

  public void setEnd(String end) {
    this.end = end;
  }

  public String getPriority() {
    return priority;
  }

  public void setPriority(String priority) {
    this.priority = priority;
  }

  public void setCompact(
      String name,
      String type,
      String description,
      String text,
      String start,
      String end,
      String prio) {
    this.name = name;
    this.type = type;
    this.description = description;
    this.text = text;
    this.start = start;
    this.end = end;
    this.priority = prio;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();
    Long min = 0L;

    // mandatory
    ValidationUtils.validateStringProperty(
        res, "name", this.name, true, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "type", this.type, true, ValidationUtils.XS_16, null, this);
    ValidationUtils.validateStringProperty(
        res, "description", this.description, true, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "priority", this.priority, true, ValidationUtils.XS_16, null, this);
    ValidationUtils.validateIntegerProperty(
        res, "start", this.start, true, min, Long.MAX_VALUE, this);
    ValidationUtils.validateIntegerProperty(
        res, "end", this.end, true, min, Long.MAX_VALUE, this);

    // optional
    ValidationUtils.validateStringProperty(
        res, "text", this.text, false, ValidationUtils.XXXL_1024, null, this);
    ValidationUtils.validateStringProperty(
        res, "creatorName", this.creatorName, false, ValidationUtils.L_128, null, this);

    return res;
  }
}
