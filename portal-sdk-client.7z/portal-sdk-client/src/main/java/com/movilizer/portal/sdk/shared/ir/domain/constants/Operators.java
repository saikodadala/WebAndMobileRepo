/*
 * Copyright (c) 2015-2021 Honeywell International Inc.
 * @date 04.02.2021
 */
package com.movilizer.portal.sdk.shared.ir.domain.constants;

import java.util.HashSet;
import java.util.Set;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.constants")
public class Operators {
  // arithmetic operators
  public static final String MULTIPLICATION = "MULTIPLICATION";
  public static final String ADDITION = "ADDITION";
  public static final String SUBTRACTION = "SUBTRACTION";
  public static final String DIVISION = "DIVISION";
  public static final String MODULO = "MODULO";

  // logical operators
  public static final String AND = "AND";
  public static final String OR = "OR";
  public static final String XOR = "XOR";

  private static Set<String> arithmeticalOperator = new HashSet<String>();
  private static Set<String> logicalOperator = new HashSet<String>();
  private static Set<String> operators = new HashSet<String>();

  static {
    arithmeticalOperator.add(MULTIPLICATION);
    arithmeticalOperator.add(ADDITION);
    arithmeticalOperator.add(SUBTRACTION);
    arithmeticalOperator.add(DIVISION);
    arithmeticalOperator.add(MODULO);
    logicalOperator.add(AND);
    logicalOperator.add(OR);
    logicalOperator.add(XOR);

    addToOperators(arithmeticalOperator);
    addToOperators(logicalOperator);
  }

  private static void addToOperators(final Set<String> operators) {
    for (String operator : operators) {
      Operators.operators.add(operator);
    }
  }

  public static boolean isArithmetical(final String operator) {
    return arithmeticalOperator.contains(operator);
  }

  public static boolean isLogical(final String operator) {
    return logicalOperator.contains(operator);
  }

  public static boolean isOperator(final String operator) {
    return operators.contains(operator);
  }

  public static Set<String> getOperators() {
    return new HashSet<>(operators);
  }
}
