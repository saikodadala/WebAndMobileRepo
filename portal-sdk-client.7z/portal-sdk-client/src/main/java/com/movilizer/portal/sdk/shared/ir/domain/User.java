/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class User extends AttachedEntity {

  public static final String POOL_NAME = "Users";

  // id is same as employeeid

  private String employeeId; // ALSO USED AS ID IN CASSANDRA
  private String name;
  private String password;
  private String roleId;
  private String email;

  @Override
  public String poolName() {
    return User.POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  // User.employeeId is used as unique id (will not be generated uuid)
  @Override
  public String getId() {
    return this.employeeId;
  }
  // User.employeeId is used as unique id (will not be generated uuid)
  @Override
  public void setId(String id) {
    this.employeeId = id;
    this.id = id;
  }

  //  @Deprecated
  @JsonIgnore
  public String getLevelId() {
    return this.parentId;
  }

  public String getEmployeeId() {
    return this.employeeId;
  }

  public void setEmployeeId(String eId) {
    this.id = eId;
    this.employeeId = eId;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPassword() {
    return this.password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getRoleId() {
    return this.roleId;
  }

  public void setRoleId(String roleId) {
    this.roleId = roleId;
  }

  public void setCompact(String levelId, String name, String password, String empoloyeeId) {
    this.parentId = levelId;
    this.parentPool = Level.POOL_NAME;
    this.name = name;
    this.password = password;
    this.employeeId = empoloyeeId;
    this.id = empoloyeeId;
  }

  @Override
  @JsIgnore
  @JsMethod
  public String desc() {
    return this.getEmail();
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    // required
    ValidationUtils.validateStringProperty(
        res, "name", name, true, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "password", password, true, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res,
        "employeeId",
        employeeId,
        true,
        ValidationUtils.M_64,
        null,
        this); // employee id MUST be set, because it is used as ID in cassandra

    return res;
  }
}
