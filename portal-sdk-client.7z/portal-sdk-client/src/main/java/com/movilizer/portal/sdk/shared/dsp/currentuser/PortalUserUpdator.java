/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.currentuser;

import java.util.ArrayList;
import java.util.List;

import com.movilizer.portal.domain.client.rights.PortalUserRole;

public class PortalUserUpdator {

  private String userName;
  private String firstName;
  private String lastName;
  private List<PortalUserRole> rolesToBeAdded;
  private List<PortalUserRole> rolesToBeRemoved;
  private List<String> rightsToBeAdded;
  private List<String> rightsToBeRemoved;

  public String getUserName() {
    return userName;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public List<PortalUserRole> getRolesToBeAdded() {
    return rolesToBeAdded;
  }

  public List<PortalUserRole> getRolesToBeRemoved() {
    return rolesToBeRemoved;
  }

  public List<String> getRightsToBeAdded() {
    return rightsToBeAdded;
  }

  public List<String> getRightsToBeRemoved() {
    return rightsToBeRemoved;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public void setRolesToBeAdded(List<PortalUserRole> rolesToBeAdded) {
    this.rolesToBeAdded = rolesToBeAdded;
  }

  public void setRolesToBeRemoved(List<PortalUserRole> rolesToBeRemoved) {
    this.rolesToBeRemoved = rolesToBeRemoved;
  }

  public void setRightsToBeAdded(List<String> rightsToBeAdded) {
    this.rightsToBeAdded = rightsToBeAdded;
  }

  public void setRightsToBeRemoved(List<String> rightsToBeRemoved) {
    this.rightsToBeRemoved = rightsToBeRemoved;
  }

  public void addRolesToBeAdded(PortalUserRole role) {
    if (this.rolesToBeAdded == null) this.rolesToBeAdded = new ArrayList<PortalUserRole>();
    this.rolesToBeAdded.add(role);
  }

  public void addRightsToBeAdded(String right) {
    if (this.rightsToBeAdded == null) this.rightsToBeAdded = new ArrayList<String>();
    this.rightsToBeAdded.add(right);
  }

  public void addRolesToBeRemoved(PortalUserRole role) {
    if (this.rolesToBeRemoved == null) this.rolesToBeRemoved = new ArrayList<PortalUserRole>();
    this.rolesToBeRemoved.add(role);
  }

  public void addRightsToBeRemoved(String right) {
    if (this.rightsToBeRemoved == null) this.rightsToBeRemoved = new ArrayList<String>();
    this.rightsToBeRemoved.add(right);
  }
}
