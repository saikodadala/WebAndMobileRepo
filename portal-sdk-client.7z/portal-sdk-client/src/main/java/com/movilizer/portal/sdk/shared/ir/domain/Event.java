/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 09.12.2020
 */
package com.movilizer.portal.sdk.shared.ir.domain;

import java.util.LinkedHashSet;
import java.util.Set;

import com.movilizer.portal.sdk.shared.ir.domain.annotations.Index;
import com.movilizer.portal.sdk.shared.ir.domain.common.AbstractEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.AttachedEntity;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationResult;
import com.movilizer.portal.sdk.shared.ir.domain.common.ValidationUtils;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.ir.entities")
@Index(property = AbstractEntity.PROPERTY_NAME_BACKENDID)
public class Event extends AttachedEntity {

  public static final String POOL_NAME = "Events";

  private String source; // e.g. the RoundId, the source defines WHAT has lead to the event
  private String type; // type of event. something like"StatusPropertyChanged" is the most common
  private String value; // e.g. "IN_PROGRESS" in a status Changed event to IN_PROGRESS

  @Override
  public String poolName() {
    return POOL_NAME;
  }

  @Override
  public String pool() {
    return poolName();
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  @Override
  @JsMethod
  public ValidationResult validate() {
    ValidationResult res = super.validate();

    // mandatory
    ValidationUtils.validateStringProperty(
        res, "source", source, true, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "type", type, false, ValidationUtils.L_128, null, this);
    ValidationUtils.validateStringProperty(
        res, "value", value, false, ValidationUtils.L_128, null, this);

    return res;
  }
}
