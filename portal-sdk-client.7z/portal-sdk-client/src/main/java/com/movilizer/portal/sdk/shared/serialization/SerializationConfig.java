/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.serialization;

import java.util.Map;

import com.github.nmorel.gwtjackson.client.AbstractConfiguration;
import com.movilizer.portal.sdk.shared.dsp.inbox.InboxEntry;
import com.movilizer.portal.sdk.shared.dsp.inbox.InboxEntrySerializer;
import com.movilizer.portal.sdk.shared.dsp.inbox.InboxExport;
import com.movilizer.portal.sdk.shared.dsp.inbox.InboxExportSerializer;
import com.movilizer.portal.sdk.shared.dsp.inbox.InboxSearch;
import com.movilizer.portal.sdk.shared.dsp.inbox.InboxSearchExtended;
import com.movilizer.portal.sdk.shared.dsp.inbox.InboxSearchExtendedSerializer;
import com.movilizer.portal.sdk.shared.dsp.inbox.InboxSearchSerializer;

public class SerializationConfig extends AbstractConfiguration {

  @Override
  protected void configure() {
    type(Map.class).serializer(MapSerializer.class);
    type(InboxSearch.class).serializer(InboxSearchSerializer.class);
    type(InboxEntry.class).serializer(InboxEntrySerializer.class);
    type(InboxSearchExtended.class).serializer(InboxSearchExtendedSerializer.class);
    type(InboxExport.class).serializer(InboxExportSerializer.class);
    //    type(MafData.class).serializer(MafDataSerializer.class);
  }
}
