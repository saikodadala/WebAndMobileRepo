/*
 * Copyright (c) 2015-2020 Honeywell International Inc.
 * @date 15.10.2020
 */
package com.movilizer.portal.sdk.shared.dsp.inbox;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jsinterop.annotations.JsType;

@JsType(namespace = "mov.sdk.inbox")
public class InboxImport implements Serializable {
  /*
   * !!Careful with getter renaming, Refer InboxEntryMixinAnnotations on how the csv export
   * references the fields
   */

  private List<InboxEntry> inboxEntries;
  private InboxSearch inboxSearch;
  private Map<String, Boolean> destinations;

  public void addInboxEntry(InboxEntry entry) {
    if (this.inboxEntries == null) {
      this.inboxEntries = new ArrayList<InboxEntry>();
    }
    this.inboxEntries.add(entry);
  }

  public List<InboxEntry> getInboxEntries() {
    return this.inboxEntries;
  }

  public void setInboxEntries(List<InboxEntry> entries) {
    this.inboxEntries = entries;
  }

  public void setInboxSearch(InboxSearch search) {
    this.inboxSearch = search;
  }

  public InboxSearch getInboxSearch() {
    return this.inboxSearch;
  }

  public Map<String, Boolean> getDestinations() {
    return destinations;
  }

  public void setDestinations(Map<String, Boolean> destinations) {
    this.destinations = destinations;
  }

  public void addDestination(String key, boolean value) {
    if (this.destinations == null) {
      this.destinations = new HashMap<String, Boolean>();
    }
    this.destinations.put(key, value);
  }
}
