# Portal SDK Client

## Usage

```java
import com.honeywell.movilizer.portalsdk.client.RESTClient;
import com.movilizer.portal.sdk.shared.ir.domain.common.SharedResponseEntity;
import com.movilizer.portal.sdk.shared.ir.domain.structs.StringMap;
import com.honeywell.movilizer.portalsdk.client.ir;

public static final main(String args[]) {
    String token = "TAKE IT FROM auth Cookie when logged to Portal";
    String endpoint = "https://test.psr.plus.movilizer.cloud";
    IndexService p = null;
    try {
        RESTClient client = new RESTClient(endpoint, token);
        p = new IndexProvider(client);
    } catch (MalformedURLException e) {
        // handle error
        return;
    }
    try {
        SharedResponseEntity<StringMap> res = p.get("Levels", "name", "parentId", "20002");
        if (res.isErroneous()) {
            System.out.println(res.getError().getMessage());
        }
    } catch (Exception e) {
        // Handle the exception
    }
}
```

## Updating from new changes in PortalSDK interfaces

### Copy Portal SDK shared objects

```bash
cp -r $PORTAL_SDK_REPO/portal-sdk/src/main/java/com/movilizer/portal/sdk/shared/* ./src/main/java/com/movilizer/portal/sdk/shared/.
cp -r $PORTAL_SDK_REPO/portal-sdk/src/main/java/com/movilizer/portal/sdk/client/util/* ./src/main/java/com/movilizer/portal/sdk/client/util/.
cp -r $PORTAL_SDK_REPO/portal-sdk/src/main/java/com/movilizer/portal/sdk/client/ir/*Service.java ./src/main/java/com/honeywell/movilizer/portalsdk/client/ir/. 
```

### Update interfaces

* **Remove** imports in all `com/honeywell/movilizer/portalsdk/client/ir/*Service.java` files:

```java
import org.fusesource.restygwt.client.MethodCallback;
```

```java
import org.fusesource.restygwt.client.RestService;
```


* **Replace** the method signatures in all `com/honeywell/movilizer/portalsdk/client/ir/*Service.java` in a way:

```java
  @Path("updateTo/{parentPool}/{parentId}")
  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  public void updateTo(
      @PathParam("parentPool") String parentPool,
      @PathParam("parentId") String parentId,
      Level entity,
      MethodCallback<SharedResponseEntity<Level>> callback);
```

Should remove the `MethodCallback` parameter and the return payload to be set as return of the method:

```java
  @Path("updateTo/{parentPool}/{parentId}")
  @PUT
  @Produces(MediaType.APPLICATION_JSON)
  public SharedResponseEntity<Level> updateTo(
    @PathParam("parentPool") String parentPool, 
    @PathParam("parentId") String parentId, 
    Level entity) throws Exception;
```